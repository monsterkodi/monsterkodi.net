//
//  Stack.m

#import "Stack.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation StackEvent
//------------------------------------------------------------------------------------------------------------------------
@synthesize stack;

- (id)initWithStack:(Stack*)stack_ type:(NSString*)type
{
  if (self = [super initWithType:type bubbles:NO])
  {
    stack = stack_;
  }
  return self;
}
@end

//------------------------------------------------------------------------------------------------------------------------
@implementation Stack
//------------------------------------------------------------------------------------------------------------------------
 
- (id) init
{
  if ((self = [super init]))
  {
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) dealloc
{
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) clear
{
  [cells removeAllObjects];
  [self changed];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) changed
{
  [self dispatchEvent:[[StackEvent alloc] initWithStack:self type:SP_EVENT_TYPE_STACK_CHANGED]];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) push:(Cell*)cell
{
  if (DBG_STACK) NSLog(@"%@ push %@", self, cell);

  if (cell) 
  {
    [cells addObject:cell];
    [self dispatchEvent:[[StackEvent alloc] initWithStack:self type:SP_EVENT_TYPE_STACK_DID_PUSH]];
    [self changed];
  }  
}

//------------------------------------------------------------------------------------------------------------------------

- (Cell*) pop
{
  if (DBG_STACK) NSLog(@"%@ pop", self);

  [self dispatchEvent:[[StackEvent alloc] initWithStack:self type:SP_EVENT_TYPE_STACK_WILL_POP]];
  
  for (Cell * cell in cells) [cell highlight:NO];
  
  Cell * cell = [self lastCell];
  assert(cell);
  [cells removeLastObject];
  
  [self changed];
  
  return cell;
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) endOfTopLevelFunc
{
  if (self.numCells < 2) return NO;
  
  BOOL isAtEnd = YES;
  
  for (int i = 1; i < self.numCells; i++)
  {
    Cell * cell     = [self cellAtIndex:i-1];
    Cell * nextCell = [self cellAtIndex:i];
    
    if ([[cell defCell] lastFunctionCellWithCommand] != nextCell)
    {
      isAtEnd = NO;
      break;
    }     
  }

  return isAtEnd;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) restoreState:(NSString*)state
{
  [self clear];
  NSArray * cellIdentifiers = [state componentsSeparatedByString:@"#"];
  for (NSString * identStr in cellIdentifiers)
  {
    if ([identStr length])
    {
      Cell * cell = [memory cellWithIdentifier:[identStr intValue]];
      [cells addObject:cell];      
    }
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (NSString*) stateString
{
  NSString * s = @"";
  for (Cell * cell in cells)
    s = [s stringByAppendingFormat:@"#%02d", cell.identifier];
  return s;
}

//------------------------------------------------------------------------------------------------------------------------

- (NSString*) description
{
  NSString * s = @"";
  for (Cell * cell in cells)
    s = [s stringByAppendingFormat:@"%c", cell.code];
  s = [s stringByPaddingToLength:20 withString:@"_" startingAtIndex:0];

  s = [s stringByAppendingString:[self stateString]];

  s = [s stringByPaddingToLength:80 withString:@" " startingAtIndex:0];
  return s;
}

@end
