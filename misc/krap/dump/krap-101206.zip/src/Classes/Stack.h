//
//  Stack.h

#import "Memory.h"

#define SP_EVENT_TYPE_STACK_WILL_POP @"stack_will_pop"
#define SP_EVENT_TYPE_STACK_DID_PUSH @"stack_did_push"
#define SP_EVENT_TYPE_STACK_CHANGED  @"stack_changed"

@class Stack;
//------------------------------------------------------------------------------------------------------------------------
@interface StackEvent : SPEvent
//------------------------------------------------------------------------------------------------------------------------
{
  Stack * stack;
}
@property (nonatomic, readonly) Stack * stack;
- (id)initWithStack:(Stack*)stack type:(NSString*)type;
@end

//------------------------------------------------------------------------------------------------------------------------
@interface Stack : Memory 
//------------------------------------------------------------------------------------------------------------------------
{
}

//------------------------------------------------------------------------------------------------------------------------

- (id)        init;
- (void)      clear;
- (void)      push:(Cell*)cell;
- (Cell*)     pop;
- (NSString*) stateString;
- (void)      restoreState:(NSString*)state;
- (BOOL)      endOfTopLevelFunc;
- (void)      changed;

@end

//------------------------------------------------------------------------------------------------------------------------
