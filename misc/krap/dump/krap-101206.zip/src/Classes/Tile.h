//
//  Tile.h

#import "Sprite.h"

typedef enum TileMode_ // remember to change TILEMODENAMES in .m also!
{
  BRICK, 
  VISIT, 
  TOGGLE,
  SWITCH,
  TILEMODENUM
  
} TileMode;

//------------------------------------------------------------------------------------------------------------------------
@interface Tile : Sprite 
//------------------------------------------------------------------------------------------------------------------------
{
  int      state;
  TileMode mode;
}

- (id)      initWithFile:(NSString *)imageFile;

- (void)    toggleOn;
- (void)    switchOn;
- (void)    switchOff;
- (void)    switchState;
- (void)    setState:(int)state;
- (void)    stateChanged;

- (void)    setModeByName:(NSString*)modeName;

@property (nonatomic, readonly) Field      field;
@property (nonatomic, assign)   TileMode mode;
@property (nonatomic, assign)   int      state;
@property (readonly)            BOOL     on;

@end
