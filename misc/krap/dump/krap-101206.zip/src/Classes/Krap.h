//
//  Krap.h

#import "Bot.h"
#import "Command.h"
#import "Compi.h"

#define SP_EVENT_TYPE_KRAP_DID_MOVE         @"krap_did_move"
#define SP_EVENT_TYPE_KRAP_DID_ROTATE       @"krap_did_rotate"
#define SP_EVENT_TYPE_KRAP_DID_EXECUTE      @"krap_did_execute"

@class Krap;
//------------------------------------------------------------------------------------------------------------------------
@interface KrapEvent : SPEvent
//------------------------------------------------------------------------------------------------------------------------
{
  Krap * krap;
}

- (id)initWithKrap:(Krap*)krap type:(NSString*)type;

@property (nonatomic, readonly) Krap * krap;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface Krap : Bot 
//------------------------------------------------------------------------------------------------------------------------
{
	int       moviedir;
  float     angle;
  Direction direction;
  Field     field;
  Speed     speed;
  SPTween * execTween;
}

@property (nonatomic, assign) Direction direction;
@property (nonatomic, retain) Field       field;
@property (nonatomic, assign) float     angle;
@property (nonatomic, assign) Speed     speed;

+ (Krap*)   withParent:(SPDisplayObjectContainer*)parent;

- (void)    stop;
- (void)    pause;
- (BOOL)    fakeForward;
- (BOOL)    moveForward;
- (BOOL)    fakeRotate:(float)degrees;
- (BOOL)    rotate:(float)degrees;
- (BOOL)    rotateLeft;
- (BOOL)    rotateRight;

- (BOOL)    fakeCommand:(Command*)command;
- (BOOL)    executeCommand:(Command*)command;
- (BOOL)    reverseCommand:(Command*)command;

- (Direction)   directionForAngle:(float)angle;

- (void) jumpWithHeight:(double)height time:(double)time;

- (void)        dump:(NSString*)title;

@end
