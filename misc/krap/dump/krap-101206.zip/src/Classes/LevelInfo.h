//
//  LevelInfo.h

#import "Sprite.h"
#import "Level.h"

//------------------------------------------------------------------------------------------------------------------------
@interface LevelInfo : SPSprite
//------------------------------------------------------------------------------------------------------------------------
{
  SPSprite * bg;
  SPTextField * levelName;
  SPTextField * modeName;
  SPTextField * bestName;
  SPTextField * bestScore;
  SPTextField * lastName;
  SPTextField * lastScore;
  SPTextField * star1Score;
  SPTextField * star2Score;
  SPTextField * star3Score;
  Sprite      * star1;
  Sprite      * star2;
  Sprite      * star3;
}

//------------------------------------------------------------------------------------------------------------------------

+ (LevelInfo*) withParent:(SPDisplayObjectContainer*)parent;

- (id)            init;
- (void)          layoutLandscape;
- (void)          layoutPortrait;
- (void)          setLevel:(Level*)level;
- (void)          fadeIn;
- (void)          fadeOut;
- (SPTextField*)  addText;
- (SPTextField*)  addNumber;
- (void)          setLastRunTitle:(NSString*)title;

@end
