//
//  PathFinder.h

//------------------------------------------------------------------------------------------------------------------------
@interface PathFinder : NSObject 
//------------------------------------------------------------------------------------------------------------------------
{
  NSMutableArray * open;
  NSMutableArray * closed;
}

//------------------------------------------------------------------------------------------------------------------------

- (id) init;

+ (NSString*) pathFrom:(Field)start to:(Field)end direction:(Direction)dir;
- (NSString*) pathFrom:(Field)start to:(Field)end direction:(Direction)dir;

@end
