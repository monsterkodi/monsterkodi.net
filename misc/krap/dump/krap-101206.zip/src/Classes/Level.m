//
//  Level.m

#import "Level.h"
#import "Config.h"
#import "Board.h"
#import "Sound.h"
#import "Game.h"

Level * currentLevel;

//------------------------------------------------------------------------------------------------------------------------
@implementation Level
//------------------------------------------------------------------------------------------------------------------------

@synthesize name;
@synthesize bestProg;
@synthesize setupLines;
@synthesize boardLines;

//------------------------------------------------------------------------------------------------------------------------

+ (Level*) load:(NSString*)level
{
  NSString * levelStr = stringFromFile([NSString stringWithFormat:@"%@.txt", level]);
  if (!levelStr) {
    NSLog(@"ERROR unable to load level '%@'", level);  
    return [Level load:@"menu_main"];
  }
  assert(levelStr);
  
  [currentLevel release];
  currentLevel = [[Level alloc] initWithLines:[levelStr componentsSeparatedByString:@"\n"]];
  currentLevel.name = level;
  
  [board setupLevel:currentLevel];
  
  [config setString:currentLevel.name forKey:@"level_last"];

  if ([currentLevel.name isEqualToString:@"menu_main"]) [Sound play:SND_MENU];
  else [Sound play:SND_MAIN];
  
  return currentLevel;
}

//------------------------------------------------------------------------------------------------------------------------

- (id) initWithLines:(NSArray*)lines
{
  if (self = [super init])
  {
    boardLines = [[NSMutableArray arrayWithCapacity:10] retain];
    setupLines = [[NSMutableArray arrayWithCapacity:10] retain];

    BOOL b = YES;
    for (NSString * line in lines)
    {
      if ([line length])
      {
        if (b) [boardLines addObject:line];
        else   [setupLines addObject:line];      
      }
      else 
      {
        b = NO;
      }
    }
  }
  
  for (NSString * line in setupLines)
  {
    if ([line hasPrefix:@"star:"])
    {
      NSArray * scores = [[[[line stringAfter:@"star:"] slim] trim] componentsSeparatedByString:@" "];
      for (int i = 0; i < 3; i++)
        starScore[i] = [[scores objectAtIndex:i] intValue];
    }
    else if ([line hasPrefix:@"best:"])
    {
      bestProg = [[line stringAfter:@"best:"] retain];
    }
  }
  
  return self;
}

//------------------------------------------------------------------------------------------------------------------------

+ (int) bestScore:(NSString*)level
{
  NSString * scoreKey = [level stringByAppendingFormat:@"_best"];
  return [config getInteger:scoreKey default:INT_MAX];
}

//------------------------------------------------------------------------------------------------------------------------

+ (BOOL) isSolved:(NSString*)level
{
  return [config hasValueForKey:[level stringByAppendingFormat:@"_best"]];
}

//------------------------------------------------------------------------------------------------------------------------

+ (BOOL) isUnlocked:(NSString*)level
{   
  // TODO: proper evaluation of unlocked levels
  unichar c = [level characterAtIndex:[level length]-1];
  if (c == 'a') return YES;
  NSCharacterSet * bcd = [NSCharacterSet characterSetWithCharactersInString:@"bcd"];
  NSString * levelPrefix = [level substringToIndex:[level length]-1];
  if ([bcd characterIsMember:c])
  {
    NSString * parentLevel = [levelPrefix stringByAppendingString:@"a"];
    return [Level isSolved:parentLevel];    
  }
  if (c == 'e') return [Level isSolved:[levelPrefix stringByAppendingString:@"c"]] || [Level isSolved:[levelPrefix stringByAppendingString:@"d"]];
  if (c == 'f') return [Level isSolved:[levelPrefix stringByAppendingString:@"c"]] || [Level isSolved:[levelPrefix stringByAppendingString:@"b"]];
  
  return NO;
}

//------------------------------------------------------------------------------------------------------------------------

+ (BOOL) isLocked:(NSString*)level
{
  return ![Level isUnlocked:level];
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) isSolved     { return [Level isSolved:name];  }
- (int)  bestScore    { return [Level bestScore:name]; }
- (int)  currentScore { return [memory programSize]; }
- (int)  star1Score   { return starScore[0]; }
- (int)  star2Score   { return starScore[1]; }
- (int)  star3Score   { return starScore[2]; }

@end
