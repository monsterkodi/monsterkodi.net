//
//  Config.h

//------------------------------------------------------------------------------------------------------------------------
@interface Config : NSObject 
//------------------------------------------------------------------------------------------------------------------------
{
  BOOL dirty;
}

@property (assign) BOOL dirty;

//------------------------------------------------------------------------------------------------------------------------

- (id)        init;
- (void)      dealloc;

- (void)      setInteger:(int)value forKey:(NSString*)key;
- (void)      setDouble:(double)value forKey:(NSString*)key;
- (void)      setFloat:(float)value forKey:(NSString*)key;
- (void)      setBool:(BOOL)value forKey:(NSString*)key;
- (void)      setField:(Field)value forKey:(NSString*)key;
- (void)      setString:(NSString*)value forKey:(NSString*)key;
- (int)       getInteger:(NSString*)key;
- (int)       getInteger:(NSString*)key default:(int)value;
- (double)    getDouble:(NSString*)key;
- (float)     getFloat:(NSString*)key;
- (float)     getFloat:(NSString*)key default:(float)value;
- (BOOL)      getBool:(NSString*)key;
- (NSString*) getString:(NSString*)key;
- (Field)       getFieldForKey:(NSString*)key;
- (BOOL)      hasValueForKey:(NSString*)key;

@end

//------------------------------------------------------------------------------------------------------------------------

extern Config * config;

//------------------------------------------------------------------------------------------------------------------------
