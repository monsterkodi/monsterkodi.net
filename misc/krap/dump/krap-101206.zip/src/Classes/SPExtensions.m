//
//  SPCategories.m

#import "SPExtensions.h"
#import "SPPoint.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation OrientationEvent
//------------------------------------------------------------------------------------------------------------------------

@synthesize orientation;

//------------------------------------------------------------------------------------------------------------------------

- (id)initWithOrientation:(Orientation)o
{
  if (self = [super initWithType:SP_EVENT_TYPE_ORIENTATION bubbles:NO])
  {
    orientation = o;
  }
  return self;
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation SPDisplayObject (SPDisplayObjectExtensions)
//------------------------------------------------------------------------------------------------------------------------

- (SPDisplayObject*) hitTest:(CGPoint)localPos forTouch:(BOOL)isTouch
{
  return [self hitTestPoint:SPPOINT_FOR_POS(localPos) forTouch:isTouch];
}

//------------------------------------------------------------------------------------------------------------------------

- (CGPoint) localToGlobalPos:(CGPoint)localPos
{
  SPPoint * globalPoint = [self localToGlobal:SPPOINT_FOR_POS(localPos)];
  return POS(globalPoint.x, globalPoint.y);
}

//------------------------------------------------------------------------------------------------------------------------

- (CGPoint) globalToLocalPos:(CGPoint)globalPos
{
  SPPoint * localPoint = [self globalToLocal:SPPOINT_FOR_POS(globalPos)];
  return POS(localPoint.x, localPoint.y);
}

//------------------------------------------------------------------------------------------------------------------------

- (CGPoint) parentToGlobalPos:(CGPoint)parentPos
{
  if (self.parent)
    return [self.parent localToGlobalPos:parentPos];
  else
    return parentPos;
}

//------------------------------------------------------------------------------------------------------------------------

- (CGPoint) globalToParentPos:(CGPoint)globalPos
{
  if (self.parent)
    return [self.parent globalToLocalPos:globalPos];
  else
    return globalPos;
}

//------------------------------------------------------------------------------------------------------------------------

- (CGPoint) localPos:(CGPoint)localPoint toTarget:(SPDisplayObject*)target
{
  return [target globalToLocalPos:[self localToGlobalPos:localPoint]];
}

//------------------------------------------------------------------------------------------------------------------------

- (CGPoint) pos
{
  return POS(self.x, self.y);
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setPos:(CGPoint)pos
{
  self.x = pos.x;
  self.y = pos.y;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setScale:(float)scale
{
  self.scaleX = scale;
  self.scaleY = scale;
}

//------------------------------------------------------------------------------------------------------------------------

- (float) scale
{
  return self.scaleX;
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation SPQuad (SPQuadColor)
//------------------------------------------------------------------------------------------------------------------------

- (void) setVerticalGradientFromColor:(uint)col1 toColor:(uint)col2
{
  [self setColor:col1 ofVertex:0];
  [self setColor:col1 ofVertex:1];
  [self setColor:col2 ofVertex:2];
  [self setColor:col2 ofVertex:3];
}

- (void) setHorizontalGradientFromColor:(uint)col1 toColor:(uint)col2
{
  [self setColor:col1 ofVertex:0];
  [self setColor:col2 ofVertex:1];
  [self setColor:col1 ofVertex:2];
  [self setColor:col2 ofVertex:3];
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation SPRectangle (SPRectangleCGPoint)
//------------------------------------------------------------------------------------------------------------------------

- (BOOL) containsPos:(CGPoint)pos
{
  return [self containsPoint:[SPPoint pointWithX:pos.x y:pos.y]];
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation SPDisplayObjectContainer (SPDisplayObjectContainterCildren)
//------------------------------------------------------------------------------------------------------------------------

- (void) bringChildToFront:(SPDisplayObject*)child
{
  if (child) [self swapChild:[self childAtIndex:[self numChildren]-1] withChild:child];
}

- (void) sendChildToBack:(SPDisplayObject*)child
{
  if (child) [self swapChild:[self childAtIndex:0] withChild:child];
}

- (void) raiseChild:(SPDisplayObject*)child
{
  if (child && [self childIndex:child] < self.numChildren-1) [self swapChild:child withChild:[self childAtIndex:[self childIndex:child]+1]];
}

- (void) lowerChild:(SPDisplayObject*)child
{
  if (child && [self childIndex:child] > 0) [self swapChild:child withChild:[self childAtIndex:[self childIndex:child]-1]];
}

- (void) insertChild:(SPDisplayObject*)child atIndex:(int)index
{
  [self addChild:child atIndex:clamp(index, 0, self.numChildren)];
}

- (SPDisplayObject*) lastChild
{
  return [self childAtIndex:self.numChildren-1];
}

- (SPDisplayObject*) firstChild
{
  return [self childAtIndex:0];
}

- (NSArray*) children
{
  NSMutableArray * ary = [NSMutableArray arrayWithCapacity:self.numChildren];
  for (int i = 0; i < self.numChildren; i++)
    [ary addObject:[self childAtIndex:i]];
  return ary;
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation SPSprite (SPSpriteConstruction) 
//------------------------------------------------------------------------------------------------------------------------

+ (SPSprite*) withParent:(SPDisplayObjectContainer*)parent
{
  SPSprite * sprite = [[SPSprite alloc] init];
  [parent addChild:sprite];
  [sprite release];
  return sprite;  
}

//------------------------------------------------------------------------------------------------------------------------

+ (SPSprite*) withParent:(SPDisplayObjectContainer*)parent x:(float)x y:(float)y
{
  SPSprite * sprite = [SPSprite withParent:parent];
  sprite.x = x;
  sprite.y = y;
  return sprite;  
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation SPTouch (SPTouchPosition) 
//------------------------------------------------------------------------------------------------------------------------

- (SPPoint*) getPos
{
  return [SPPoint pointWithX:self.globalX y:self.globalY];
}

- (SPPoint*) getPreviousPos
{
  return [SPPoint pointWithX:self.previousGlobalX y:self.previousGlobalY];
}

- (SPPoint*) getDeltaFor:(SPDisplayObject*)localObject
{
  SPPoint * local         = [localObject globalToLocal:[self getPos]];
  SPPoint * previousLocal = [localObject globalToLocal:[self getPreviousPos]];
  return [SPPoint pointWithX:local.x - previousLocal.x y:local.y - previousLocal.y];
}

//------------------------------------------------------------------------------------------------------------------------

- (float) deltaX
{
  return self.globalX - self.previousGlobalX;
}

//------------------------------------------------------------------------------------------------------------------------

- (float) deltaY
{
  return self.globalY - self.previousGlobalY;
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation SPTouchEvent (SPTouchEventTouches)
//------------------------------------------------------------------------------------------------------------------------

- (SPTouch*) firstTouch
{
  return [[self.touches allObjects] objectAtIndex:0]; 
}

//------------------------------------------------------------------------------------------------------------------------

- (int) numTouches
{
  return [self.touches count];
}

//------------------------------------------------------------------------------------------------------------------------

- (float) pinchDelta
{
  if ([self numTouches] >= 2)
  {
    NSArray * ts = [self.touches allObjects];
    SPTouch * t0 = (SPTouch*)[ts objectAtIndex:0];
    SPTouch * t1 = (SPTouch*)[ts objectAtIndex:1];
    float xn0 = t0.globalX, xn1 = t1.globalX;
    float yn0 = t0.globalY, yn1 = t1.globalY;
    float xo0 = t0.previousGlobalX, xo1 = t1.previousGlobalX;
    float yo0 = t0.previousGlobalY, yo1 = t1.previousGlobalY;
        
    float xn = xn1-xn0, yn = yn1-yn0;
    float xo = xo1-xo0, yo = yo1-yo0;

    return sqrtf(xn*xn + yn*yn)-sqrtf(xo*xo + yo*yo);
  }
  return 0;
}

@end

