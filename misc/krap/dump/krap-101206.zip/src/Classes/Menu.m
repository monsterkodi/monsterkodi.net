//
//  Menu.m

#import "Menu.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation Menu
//------------------------------------------------------------------------------------------------------------------------

+ (Menu*) withParent:(SPDisplayObjectContainer*)parent x:(float)x y:(float)y
{
  Menu * menu = [[Menu alloc] init];
  [parent addChild:menu];
  [menu release];
  menu.x = x;
  menu.y = y;
  return menu;  
}

//------------------------------------------------------------------------------------------------------------------------

- (void) clearDropTarget
{
  if (dropTarget)
  {
    [dropTarget clearDraggedButton];
    dropTarget = nil;
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) buttonDragged:(Button*)button
{
  CGPoint buttonPos = CGPointSub(button.pos, [button globalFingerOffset]);
  Button * target = [self buttonAtPos:buttonPos excluding:button];
  
  if (target) 
  {
    if ([target handleDraggedButton:button])
    {
      if (dropTarget != target) [self clearDropTarget];
      dropTarget = target;
      return YES;
    }
  }

  [self clearDropTarget];

  return NO;
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) buttonDropped:(Button*)button
{
  [self clearDropTarget];
  
  CGPoint buttonPos = CGPointSub(button.pos, [button globalFingerOffset]);
  
  Button * target = [self buttonAtPos:buttonPos excluding:button];
  
  if (target)
  {
    if ([target handleDroppedButton:button])
    {
      return YES;
    }
  }
  
  return NO;
}

//------------------------------------------------------------------------------------------------------------------------

- (Button*) buttonAtPos:(CGPoint)pos excluding:(Button*)button
{
  SPDisplayObject * child = [self hitTest:pos forTouch:YES];
  
  if (child.parent != button && [child.parent isKindOfClass:[Button class]])
    return (Button*)child.parent;
  
  return nil;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) dealloc 
{
  NSLog(@"menu dealloc");
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) dump
{
  for (int i = 0; i < self.numChildren; i++)
  {
    NSLog(@"%@",[self childAtIndex:i]);
  }
}

@end

