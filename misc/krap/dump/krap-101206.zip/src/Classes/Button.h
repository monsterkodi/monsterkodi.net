//
//  Button.h

#import "Sprite.h"

//------------------------------------------------------------------------------------------------------------------------
@interface Button : Sprite 
//------------------------------------------------------------------------------------------------------------------------
{
  NSString * image;
  SPImage  * icon;
  SPImage  * border;
  SPImage  * background;
  BOOL       dragging;
  BOOL       dragable;
}

@property (nonatomic, readonly) SPImage  * icon;
@property (nonatomic, readonly) SPImage  * border;
@property (nonatomic, readonly) SPImage  * background;
@property (nonatomic, readonly) NSString * image;
@property (nonatomic, assign)   BOOL       dragable;

+ (Button*)  withParent:(SPDisplayObjectContainer*)parent;

- (void)     setImage:(NSString*)imageFile;
- (void)     removeImage;

- (void)     setBorderImage:(NSString*)imageFile;
- (void)     setBackgroundImage:(NSString*)imageFile;

- (void)     tapped:(int)tapCount;
- (BOOL)     startDrag:(CGPoint)pos;
- (void)     stopDrag:(CGPoint)pos;
- (void)     dragToPos:(CGPoint)pos;

- (BOOL)     handleDraggedButton:(Button*)button;
- (BOOL)     handleDroppedButton:(Button*)button;
- (void)     clearDraggedButton;

- (void)     highlight:(BOOL)on;
- (void)     highlight;

- (CGPoint)  globalFingerOffset;

@end
