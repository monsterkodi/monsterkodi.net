//
//  Command.h

#import "Button.h"

//------------------------------------------------------------------------------------------------------------------------

typedef enum Cmd_ 
{
  NOP,
  GO,
  TURN_LEFT,
  TURN_RIGHT,
  FUNC_A,
  FUNC_B,
  FUNC_C,
  FUNC_D,
  DOT,
  CMD_NUM
} Cmd;

//------------------------------------------------------------------------------------------------------------------------

typedef struct CMD_INFO_ 
{
  unichar    code;
  NSString * image;
  float      alpha;
  uint       color;
  uint       iconColor;
  
} CMD_INFO;

//------------------------------------------------------------------------------------------------------------------------

extern CMD_INFO CMD[CMD_NUM];

NSString * CMD_STR(Cmd cmd);

@class Cell;

//------------------------------------------------------------------------------------------------------------------------
@interface Command : Button
//------------------------------------------------------------------------------------------------------------------------
{
  Cmd cmd;
}

@property (readonly) Cmd     cmd;
@property (readonly) unichar code;

+ (Cmd)         cmdForCode:(unichar)code;
+ (Command*)    withParent:(SPDisplayObjectContainer*)parent cmd:(Cmd)cmd;
- (id)          initWithCmd:(Cmd)cmd;
- (Command*)    copy;
- (void)        startDrag:(CGPoint)pos;
- (unichar)     code;
- (BOOL)        isFunc;
- (BOOL)        isExec;

@end

