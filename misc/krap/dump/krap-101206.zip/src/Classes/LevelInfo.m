//
//  LevelInfo.m

#import "LevelInfo.h"
#import "Game.h"
#import "MenuLogic.h"

#define BDX 60

//------------------------------------------------------------------------------------------------------------------------
@implementation LevelInfo
//------------------------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------------------------

+ (LevelInfo*) withParent:(SPDisplayObjectContainer*)parent
{
  LevelInfo * info = [[LevelInfo alloc] init];
  [parent addChild:info];
  [info release];
  return info;
}

//------------------------------------------------------------------------------------------------------------------------
 
- (id) init
{
  if ((self = [super init]))
  {
    [self addEventListener:@selector(onTouch:) atObject:self forType:SP_EVENT_TYPE_TOUCH];  
    
    bg = [[SPSprite alloc] init];
    SPQuad * quad = [SPQuad quadWithWidth:10 height:10];
    quad.color = 0x111111;
    [bg addChild:quad];
    [self addChild:bg];    
    [bg release];
    
    levelName  = [self addText];
    modeName   = [self addText]; modeName.fontSize *= 0.8; modeName.color = 0x888800;
    bestName   = [self addText]; bestName.fontSize *= 0.8; bestName.color = 0x888800; bestName.text = @"Best Run:";
    bestScore  = [self addNumber];                        bestScore.color = 0x888800;
    lastName   = [self addText]; 
    lastScore  = [self addNumber];

    star1 = [Sprite withParent:bg image:@"star"];
    star2 = [Sprite withParent:bg image:@"star"];
    star3 = [Sprite withParent:bg image:@"star"];
    
    star1Score  = [self addNumber]; star1Score.fontSize *= 0.5; star1Score.color = 0x888800; star1Score.hAlign = SPHAlignCenter; star1Score.vAlign = SPVAlignCenter;
    star2Score  = [self addNumber]; star2Score.fontSize *= 0.5; star2Score.color = 0x888800; star2Score.hAlign = SPHAlignCenter; star2Score.vAlign = SPVAlignCenter;
    star3Score  = [self addNumber]; star3Score.fontSize *= 0.5; star3Score.color = 0x888800; star3Score.hAlign = SPHAlignCenter; star3Score.vAlign = SPVAlignCenter;
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) dealloc
{
  [self  removeEventListenersAtObject:self forType:SP_EVENT_TYPE_TOUCH];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setLevel:(Level*)level
{
  NSString * ppl = level.name;
  ppl = [ppl stringByReplacingCharactersInRange:NSMakeRange([ppl length]-1, 1) withString:[[ppl substringFromIndex:[ppl length]-1] uppercaseString]];
  ppl = [ppl stringByReplacingCharactersInRange:NSMakeRange(0, 1) withString:[[ppl substringToIndex:1] uppercaseString]];
  levelName.text = [ppl stringByReplacingOccurrencesOfString:@"_" withString:@" "];
  
  modeName.text = [NSString stringWithFormat:@"Mode: %@", [logic modeName]];
  
  uint starcolor = 0x222222;
  uint yellow    = 0xffff00;
  
  star1Score.text = [NSString stringWithFormat:@"%d", [level star1Score]];
  star2Score.text = [NSString stringWithFormat:@"%d", [level star2Score]];
  star3Score.text = [NSString stringWithFormat:@"%d", [level star3Score]];
  
  if ([level isSolved])
  {
    int best = [level bestScore];
    bestScore.text = [NSString stringWithFormat:@"%d", best];

    star1.color = (best <= [level star1Score]) ? yellow : starcolor;
    star2.color = (best <= [level star2Score]) ? yellow : starcolor;
    star3.color = (best <= [level star3Score]) ? yellow : starcolor;
  }
  else 
  {
    bestScore.text = @"???";
    
    star1.color = starcolor;
    star2.color = starcolor;
    star3.color = starcolor;    
  }
  
  int last = [level currentScore];
  if (last) 
  {
    lastScore.text    = [NSString stringWithFormat:@"%d", last];
    lastName.text     = @"Program:";
    lastScore.visible = YES;
    lastName.visible  = YES;
  }
  else 
  {
    lastScore.visible = NO;
    lastName.visible  = NO;
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setLastRunTitle:(NSString*)title
{
  lastName.text = title;
}

//------------------------------------------------------------------------------------------------------------------------

- (SPTextField*) addText
{ 
  SPTextField * tf = [SPTextField textFieldWithText:@""];
  
  tf.width     = 400;
  tf.height    = 50;
  
  tf.fontSize  = 26.0f;
  tf.color     = 0xdddd00;
  
  tf.fontName  = @"Elephants In Cherry Trees";
  
  tf.hAlign    = SPHAlignLeft;
  tf.vAlign    = SPVAlignTop;
  tf.border    = NO;
  tf.touchable = NO;
  
  [bg addChild:tf];
  return tf;
}

//------------------------------------------------------------------------------------------------------------------------

- (SPTextField*) addNumber
{ 
  SPTextField * tf = [self addText];
  
  tf.fontName = @"Too Much Paper!";
  tf.fontSize *= 2;
  
  return tf;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) fadeIn
{
  self.visible = YES;
  
  SPTween * tween = [SPTween tweenWithTarget:self time:INFO_FADE_IN_TIME transition:SP_TRANSITION_EASE_OUT];
  if (game.orientation == UP || game.orientation == DOWN)
  {
    self.x = 0;
    self.y = 6*BDX;
    [tween animateProperty:@"y" targetValue:0];    
  }
  else
  {
    self.y = 0;
    self.x = 6*BDX;
    [tween animateProperty:@"x" targetValue:0];    
  }
  [game.juggler addObject:tween];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) fadeOut
{
  SPTween * tween = [SPTween tweenWithTarget:self time:INFO_FADE_OUT_TIME transition:SP_TRANSITION_EASE_OUT];
  
  if (game.orientation == UP || game.orientation == DOWN)
  {
    self.y = 0;
    [tween animateProperty:@"y" targetValue:6*BDX];
  } 
  else 
  {
    self.x = 0;
    [tween animateProperty:@"x" targetValue:6*BDX];    
  }
  
  [tween addEventListener:@selector(fadedOut:) atObject:self forType:SP_EVENT_TYPE_TWEEN_COMPLETED];
  [game.juggler addObject:tween];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) fadedOut:(SPEvent*)event
{
  self.visible = false;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) onTouch:(SPTouchEvent*)event
{
  SPTouch * touch = event.firstTouch;
  if (event.numTouches == 1)
  {
    if (touch.phase == SPTouchPhaseEnded) [menu hideInfo];
  }      
  [event stopPropagation];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) layoutLandscape
{
  float sx =  self.stage.height/2 - 4.75*BDX;

  SPQuad * quad = (SPQuad*)[bg firstChild];
  quad.width  = 5.5*BDX;
  quad.height = self.stage.width;
  bg.x      = sx-0.625*BDX;
  bg.y      = -self.stage.width/2;  
  
  int bx = 30;
  int cx = 230;
  int y = bx;
  
  levelName.x = bx;
  levelName.y = y;
  y += 70;
  modeName.x = bx;
  modeName.y = y;
  y += 110;
  
  star1.x = 70;
  star2.x = 70 + 90;
  star3.x = 70 + 180;
  
  star1.y = y;
  star2.y = y;
  star3.y = y;

  star1Score.x = star1.x - star1Score.width/2 + 3;
  star2Score.x = star2.x - star2Score.width/2 + 3;
  star3Score.x = star3.x - star3Score.width/2 + 3;

  star1Score.y = y - star1Score.height/2 + 5;
  star2Score.y = y - star2Score.height/2 + 5;
  star3Score.y = y - star3Score.height/2 + 5;
  
  y += 70;
  bestName.x = bx;
  bestName.y = y + 5;
  bestScore.x = cx;
  bestScore.y = y;
  
  y += 70;
  lastName.x = bx;
  lastName.y = y;
  lastScore.x = cx;
  lastScore.y = y;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) layoutPortrait
{
  float sy =  self.stage.height/2 - 4.75*BDX;

  SPQuad * quad = (SPQuad*)[bg firstChild];
  quad.width  = self.stage.width;
  quad.height = 5.5*BDX;
  bg.x      = -self.stage.width/2;
  bg.y      = sy-0.625*BDX;
  
  int bx = 30;
  int cx = 230;
  int y = bx;
  
  levelName.x = bx;
  levelName.y = y;
  y += 70;
  modeName.x = bx;
  modeName.y = y;
  y += 105;
  
  star1.x = 70;
  star2.x = 70 + 90;
  star3.x = 70 + 180;
  
  star1.y = star2.y = star3.y = y;
  
  star1Score.x = star1.x - star1Score.width/2 + 3;
  star2Score.x = star2.x - star2Score.width/2 + 3;
  star3Score.x = star3.x - star3Score.width/2 + 3;
  
  star1Score.y = y - star1Score.height/2 + 5;
  star2Score.y = y - star2Score.height/2 + 5;
  star3Score.y = y - star3Score.height/2 + 5;
  
  y += 60;
  bestName.x = bx;
  bestName.y = y + 5;
  bestScore.x = cx;
  bestScore.y = y;
  
  lastName.x = bx + 5.5*BDX;
  lastName.y = y;
  lastScore.x = cx + 5.5*BDX;
  lastScore.y = y;  
}

@end
