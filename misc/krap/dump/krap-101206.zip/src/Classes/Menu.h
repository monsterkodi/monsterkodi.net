//
//  Menu.h

#import "Button.h"

//------------------------------------------------------------------------------------------------------------------------
@interface Menu : SPSprite 
//------------------------------------------------------------------------------------------------------------------------
{
	Button       * dropTarget;
}

+ (Menu*)   withParent:(SPDisplayObjectContainer*)parent x:(float)x y:(float)y;
- (BOOL)    buttonDragged:(Button*)button;
- (BOOL)    buttonDropped:(Button*)button;
- (Button*) buttonAtPos:(CGPoint)pos excluding:(Button*)button;
- (void)    dump;

@end
