//
//  Bridge.m

#import "Bridge.h"
#import "Theme.h"
#import "Logic.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation Bridge
//------------------------------------------------------------------------------------------------------------------------

+ (Bridge*) withParent:(SPDisplayObjectContainer*)parent direction:(Direction)direction
{
  Bridge * bridge = [[Bridge alloc] initWithDirection:direction];
  [parent addChild:bridge];
  [bridge release];
  return bridge;
}

//------------------------------------------------------------------------------------------------------------------------

- (id) initWithDirection:(Direction)direction_
{
  direction = direction_;

  NSString * imageFile;
  switch (direction) 
  {
    default:
    case NE:
    case SW: imageFile = @"floor0001"; break;
    case SE:
    case NW: imageFile = @"floor0002"; break;
  }
    
  if (self = [super initWithFile:imageFile]) 
  {
    self.touchable = NO;
  }
  
  return self;
}

@end

