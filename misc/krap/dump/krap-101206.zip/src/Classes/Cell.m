//
//  MemoryCell.m

#import "Cell.h"
#import "CommandButton.h"
#import "GameMenu.h"
#import "Game.h"
#import "Sound.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation Cell
//------------------------------------------------------------------------------------------------------------------------

@synthesize mem;

+ (Cell*) inMemory:(Memory*)mem withParent:(SPDisplayObjectContainer*)parent
{
  Cell * button = [[Cell alloc] initWithMemory:mem];
  [parent addChild:button];
  [mem addCell:button];
  [button release];
  return button;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) addIdentifierText
{
  SPTextField * tf = [SPTextField textFieldWithText:[NSString stringWithFormat:@"%02d", identifier]];
  
  tf.width     = 60;
  tf.height    = 20;
  tf.y         = -23;
  tf.x         = -23;
  
  tf.fontSize  = 14.0f;
  tf.color     = 0xffffff;
  
  tf.fontName  = @"Too Much Paper!";
  
  tf.hAlign    = SPHAlignLeft;
  tf.vAlign    = SPVAlignTop;
  tf.border    = NO;
  tf.touchable = NO;
  
  [self addChild:tf];
}

//------------------------------------------------------------------------------------------------------------------------

- (id) initWithMemory:(Memory*)mem_
{
  if (self = [super init])
  {
    mem = mem_;
    numDots = 0;
    identifier = mem.numCells;
    //[self addIdentifierText];
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) startInsertion
{
  SPTween * tween = [SPTween tweenWithTarget:command time:0.6 transition:SP_TRANSITION_EASE_OUT];
  
  [self.parent addChild:command];
  command.pos = self.pos;
  CGPoint nextPos = [self nextCell].pos;
  [tween animateProperty:@"x" targetValue:nextPos.x];
  [tween animateProperty:@"y" targetValue:nextPos.y];
  [game.juggler addObject:tween];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) stopInsertion
{
  [game.juggler removeTweensWithTarget:command];
  
  [self addChild:command];

  command.pos = CGVector(self.pos, command.pos);

  SPTween * tween = [SPTween tweenWithTarget:command time:0.4 transition:SP_TRANSITION_EASE_OUT];
  [tween animateProperty:@"x" targetValue:0];
  [tween animateProperty:@"y" targetValue:0];
  [game.juggler addObject:tween];  
}

//------------------------------------------------------------------------------------------------------------------------

- (void) finalizeInsertion
{
  [game.juggler removeTweensWithTarget:command];
  [self addChild:command];
  command.pos = POS(0,0);
}

//------------------------------------------------------------------------------------------------------------------------

- (void) highlight:(BOOL)on     { self.border.color = on ? 0xffffff : 0x222222; self.border.alpha = on ? 1 : 0; }
- (void) highlight              { [self highlight:YES]; }

//------------------------------------------------------------------------------------------------------------------------

- (void) delDot
{
  numDots--;
  [self removeChild:[self lastChild]];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) delDots
{
  while (numDots) [self delDot];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) addDot
{  
  SPImage * img = [self addImage:@"stack_dot"];
  
  double dotsize  = img.width;
  double cellsize = border.width;
  img.y += cellsize/2 + dotsize/8;
  img.scale = 0.7;
  
  numDots++;  
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setDots:(int)num color:(uint)col
{   
  while (min(20, num) > numDots) [self addDot]; // add maximal 20 dots
  
  double cellsize = border.width * 0.8;
  
  for (int i = 0; i < numDots; i++)
  {
    SPImage * img = (SPImage*)[self childAtIndex:self.numChildren-numDots+i];
    if ((cellsize-img.width)/max(numDots-1,1) < img.width)
    {
      img.x = -cellsize/2 + i * (cellsize-img.width)/(numDots-1);          
    }
    else
    {
      img.x = (i-numDots/2-(numDots/2.0-numDots/2)) * img.width;          
    }
    img.color = col;
  }  
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) handleDraggedButton:(Button*)button
{
  BOOL isCommand = [button isKindOfClass:[Command class]];
  if (isCommand)
  {
    self.image = button.image;
    if (command != button) command.visible = NO;
    self.background.color = button.background.color;
  }
  return isCommand;
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) handleDroppedButton:(Button*)button
{
  if ([button isKindOfClass:[Command class]])
  {
    self.command = (Command*)button;
    [Sound play:SND_DRAG_DROP];
    return YES;
  }
  return NO;
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) startDrag:(CGPoint)pos
{
  if (command)
  {
    if (menu.mode == COMP) // auto switch from COMP to EDIT mode
    {
      [menu stopCompi];
      [menu toggleEditMode];
    }
    if (menu.mode == TOOLS) [menu toggleTools]; // auto switch from TOOL to EDIT mode
    
    dragging = YES;
    
    [((GameMenu*)self.parent) dragStartedAtCell:self];

    [self.parent addChild:command];
    [command startDrag:pos];
    
    [Sound play:SND_DRAG_START];
  }
  else 
  {
    dragging = NO;
  }
  
  return dragging;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) dragToPos:(CGPoint)pos
{
  command.pos = CGPointAdd(pos, [self globalFingerOffset]);
  
  [((GameMenu*)self.parent) buttonDragged:command];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) stopDrag:(CGPoint)pos
{ 
  dragging = NO;
  
  Command * oldCommand = command;
  if (![((GameMenu*)self.parent) buttonDropped:command])
  {
    if (self.command == oldCommand) 
      self.command = nil;
    [Sound play:SND_DRAG_TRASH];
  }
  else 
  {
    if (command.parent != self) 
    {
      command = nil;
    }
  }
  
  [mem programChanged];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) clearDraggedButton
{
  [self removeImage];

  if (command) command.visible = YES;
  
  [mem colorize];
}

//------------------------------------------------------------------------------------------------------------------------

- (unichar) code
{
  if (command) return command.code;
  else return CMD[NOP].code;
}

//------------------------------------------------------------------------------------------------------------------------

- (Cmd) cmd
{
  if (command) return command.cmd;
  else return NOP;
}

//------------------------------------------------------------------------------------------------------------------------

- (NSString*) description
{
  int cellIndex = [mem indexOfCell:self];
  return [NSString stringWithFormat:@"[#%2d %@]", cellIndex, command];
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) isDef
{
  if (command && [command isFunc])
  {
    Cell * cell = [mem firstCell];
    do 
    {
      if (cell.cmd == self.cmd) return (cell == self); 
      if ([cell isDef]) cell = [cell defEndCell];      
    } 
    while (cell = [cell nextCell]);
  }
  return NO;
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) isDot
{
  return (command && command.cmd == DOT);
}

//------------------------------------------------------------------------------------------------------------------------

- (Cell*) defCell
{
  assert(command && [command isFunc]);
  
  Cell * cell = [mem firstCell];
  do 
  {
    if (cell.cmd == self.cmd) return cell; 
    if ([cell isDef]) cell = [cell defEndCell];      
  } 
  while (cell = [cell nextCell]);
  
  return nil;
}

//------------------------------------------------------------------------------------------------------------------------

- (Cell*) defStartCell
{
  return [self nextCell];
}

//------------------------------------------------------------------------------------------------------------------------

- (Cell*) defEndCell
{
  return [self nextCellWithCommand:DOT];
}

//------------------------------------------------------------------------------------------------------------------------

- (NSArray*) functionCells
{
  NSMutableArray * cells = [NSMutableArray arrayWithCapacity:10];
  Cell * cell = self;
  while (cell = [cell nextCell])
  {
    if (cell.cmd == DOT) break;
    [cells addObject:cell];
  }
  return cells;
}

//------------------------------------------------------------------------------------------------------------------------

- (NSArray*) functionCellsWithCommand
{
  NSMutableArray * cells = [NSMutableArray arrayWithCapacity:10];
  Cell * cell = self;
  while (cell = [cell nextCell])
  {
    if (cell.cmd == DOT) break;
    if (cell.cmd != NOP) [cells addObject:cell];
  }
  return cells;  
}

//------------------------------------------------------------------------------------------------------------------------

- (Cell*) firstFunctionCellWithCommand
{
  Cell * cell = self;
  while (cell = [cell nextCell])
  {
    if (cell.cmd == DOT) break;
    if (cell.cmd != NOP) return cell;
  }
  return nil;    
}

//------------------------------------------------------------------------------------------------------------------------

- (Cell*) lastFunctionCellWithCommand
{
  Cell * cell = [self defEndCell];
  while (cell = [cell prevCell])
  {
    if (cell == self) break;
    if (cell.command) return cell;
  }
  return nil;
}

//------------------------------------------------------------------------------------------------------------------------

- (Cell*) nextCell
{
  int index = [mem indexOfCell:self];
  if (index != NSNotFound)
  {
    if (index+1 < mem.numCells)
    {
      return [mem cellAtIndex:index+1];
    }
  }
  return nil;
}

//------------------------------------------------------------------------------------------------------------------------

- (Cell*) prevCell
{
  int index = [mem indexOfCell:self];
  if (index != NSNotFound)
  {
    if (index > 0)
    {
      return [mem cellAtIndex:index-1];
    }
  }
  return nil;
}

//------------------------------------------------------------------------------------------------------------------------

- (Cell*) nextCellWithCommand
{
  Cell * cell = self;
  while (cell = [cell nextCell])
  {
    if (cell.command) return cell;
  }
  return nil;
}

//------------------------------------------------------------------------------------------------------------------------

- (Cell*) prevCellWithCommand
{
  Cell * cell = self;
  while (cell = [cell prevCell])
  {
    if (cell.command) return cell;
  }
  return nil;
}

//------------------------------------------------------------------------------------------------------------------------

- (Cell*) prevCellWithExecutableCommand
{
  Cell * cell = self;
  while (cell = [cell prevCell])
  {
    if (cell.command) 
    {
      if (cell.command.cmd != DOT) 
      {
        if ([cell isDef]) return nil;
        return cell;
      }
      else                         
      {
        return [[mem defCellForDotCell:cell] prevCellWithExecutableCommand];
      }
    }
  }
  return nil;
}

//------------------------------------------------------------------------------------------------------------------------

- (Cell*) nextCellWithCommand:(Cmd)cmd
{
  Cell * cell = self;
  while (cell = [cell nextCell])
  {
    if (cell.cmd == cmd) return cell;
  }
  return nil;
}

//------------------------------------------------------------------------------------------------------------------------

- (Cell*) nextCellWithExecutableCommand
{
  Cell * cell = self;
  while (cell = [cell nextCell])
  {
    if (cell.command) 
    {
      if ([cell isDef]) 
      {
        return [[cell defEndCell] nextCellWithExecutableCommand];
      }
      else if (cell.command.cmd == DOT) return nil;

      return cell;
    }
  }
  return nil;
}

@end

