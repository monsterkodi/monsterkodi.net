//
//  GameMenu.m

#import "GameMenu.h"
#import "Game.h"
#import "CommandButton.h"
#import "Cell.h"
#import "Sound.h"

#define CCOL 4
#define CROW 2

#define BDX 60
#define BDY BDX

GameMenu * menu;

id BTN[MCOL*CROW];
id BTT[MCOL*CROW];

//------------------------------------------------------------------------------------------------------------------------
@implementation GameMenu
//------------------------------------------------------------------------------------------------------------------------

@synthesize mode;

//------------------------------------------------------------------------------------------------------------------------

+ (GameMenu*) withParent:(SPDisplayObjectContainer*)parent
{
  menu = [[GameMenu alloc] init];
  [parent addChild:menu];
  [menu release];
  return menu;  
}

//------------------------------------------------------------------------------------------------------------------------

- (id) init
{
  if (self = [super init])
  {
    mode   = EDIT;
    active = YES;
    
    bg = [SPQuad quadWithWidth:100 height:10];
    bg.color = 0x0;
    bg.alpha = 0.75;
    [self addChild:bg];
    
    insertionCells = [[NSMutableArray arrayWithCapacity:10] retain];
    
    [self addEventListener:@selector(onTouch:) atObject:self forType:SP_EVENT_TYPE_TOUCH];
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) dealloc
{
  [self        removeEventListenersAtObject:self forType:SP_EVENT_TYPE_TOUCH];
  [memory      removeEventListenersAtObject:self forType:SP_EVENT_TYPE_MEMORY_PROGRAM_CHANGED];
  [compi       removeEventListenersAtObject:self forType:SP_EVENT_TYPE_COMPI_STATE_CHANGED];
  [compi.stack removeEventListenersAtObject:self forType:SP_EVENT_TYPE_STACK_CHANGED];
  [commandButtons release];
  [insertionCells release];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) startAnimateInsertion
{
  Cell * cell = insertionCell;
  while (cell && cell.command && cell != dragSource)
  {
    [insertionCells addObject:cell];  
    cell = [cell nextCell];
  }
  
  if (cell)
  {
    ((Cell*)dropTarget).command.visible = YES;
    for (cell in insertionCells) 
    {
      if (cell != dragSource) [cell startInsertion];
    }
  }
  else 
  {
    [insertionCells removeAllObjects]; // no empty cell: abort
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (void) startInsertionTimer
{
  if ([insertionCells count] == 0)
  {    
    [game.juggler removeTweensWithTarget:self];
    insertionCell = (Cell*)dropTarget;    
    [[game.juggler delayInvocationAtTarget:self byTime:0.5] startAnimateInsertion];
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (void) stopInsertionTimer
{
  if (insertionCell)
  {
    insertionCell = nil;
    
    for (Cell * cell in insertionCells) [cell stopInsertion];
    
    [insertionCells removeAllObjects];
    [game.juggler removeTweensWithTarget:self];
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (void) dragStartedAtCell:(Cell*)cell
{
  dragSource = cell;
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) buttonDragged:(Button*)button
{
  if ([insertionCells count])
  {
    CGPoint buttonPos = CGPointSub(button.pos, [button globalFingerOffset]);
    Button * target = [self buttonAtPos:buttonPos excluding:button];
    if (target == insertionCell) return YES; // do nothing if insertion is active and target is insertion start cell
    
    [self stopInsertionTimer];
  }
    
  BOOL result = [super buttonDragged:button];
  if (dropTarget && dropTarget != dragSource) //  && (button.x < dropTarget.x - 5))
  {
    [self startInsertionTimer];
  }
  else 
  {
    [self stopInsertionTimer];
  }
  return result;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) finalizeInsertion
{
  for (Cell * cell in insertionCells) [cell finalizeInsertion];
  
  while ([insertionCells count])
  {
    Cell * cell = [insertionCells pop];
    if (cell == dragSource) 
    {
      [cell nextCell].command = nil;
    }
    else
    {
      [cell nextCell].command = cell.command;    
    }
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) buttonDropped:(Button*)button
{
  [button retain]; // finalizing the insertion might unparent the dragged button, retain it to avoid deallocation
  CGPoint oldPos = button.pos; // keep position of dragged command
  
  [self finalizeInsertion];
  
  [self addChild:button]; // restore dragged command state
  button.pos = oldPos;
  [button release];

  dragSource = nil;
  [self stopInsertionTimer];
  BOOL result = [super buttonDropped:button];
  return result;
}

//------------------------------------------------------------------------------------------------------------------------

- (ActionButton*) addAction:(NSString*)sel image:(NSString*)image
{
  ActionButton * button = [ActionButton withParent:self];
  button.image = image;
  button.target = self;
  button.selector = NSSelectorFromString(sel);  
  return button;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setupButtons
{
  play = [self addAction:@"openCompi"       image:@"button_play"];
  time = [self addAction:@"toggleTime"      image:@"button_time"];
  stop = [self addAction:@"stopCompi"       image:@"button_stop"];
  next = [self addAction:@"nextCompi"       image:@"button_next"];
  prev = [self addAction:@"prevCompi"       image:@"button_prev"];
  jmpp = [self addAction:@"jmppCompi"       image:@"button_jmpp"];
  jmpn = [self addAction:@"jmpnCompi"       image:@"button_jmpn"];
  jmpe = [self addAction:@"jmpeCompi"       image:@"button_jmpe"];
  exit = [self addAction:@"exit"            image:@"button_exit"];
  quit = [self addAction:@"quit"            image:@"button_menu"];
  pack = [self addAction:@"packProgram"     image:@"button_tools"];
  wipe = [self addAction:@"clearProgram"    image:@"button_wipe"];
  info = [self addAction:@"showInfo"        image:@"button_info"];
  opts = [self addAction:@"toggleTools"     image:@"button_tools"];
  best = [self addAction:@"loadBestProgram" image:@"button_jmpe"];

  play.longPress = NSSelectorFromString(@"startCompi");  
  
  pbar = [Sprite withParent:self image:@"button_pause_bar"];
  
  time.visible = NO;
  stop.visible = NO;
  prev.visible = NO;
  next.visible = NO;
  jmpp.visible = NO;
  jmpn.visible = NO;
  jmpe.visible = NO;
  exit.visible = NO;
  quit.visible = NO;
  pack.visible = NO;
  wipe.visible = NO;
  info.visible = NO;
  pbar.visible = NO;
  best.visible = NO;
  
  levelInfo = [LevelInfo withParent:self];
  levelInfo.visible = NO;
  
  id BTN_[MCOL*CROW] = { time, prev, stop, next, play,  nil, jmpp, jmpe, jmpn, exit };
  id BTT_[MCOL*CROW] = {  nil,  nil, pack,  nil,  nil, quit, best, wipe, info, opts };  
  
  for (int i = 0; i < CROW*MCOL; i++) { BTN[i] = BTN_[i]; BTT[i] = BTT_[i]; }
}

//------------------------------------------------------------------------------------------------------------------------

- (void) displayLevelEndScreen
{
  if (!levelInfo.visible)
  {
    [compi stop];
    [self toggleEditMode];
    [self showInfoWithLastRunTitle:@"This Run:"];
    [Sound play:SND_SOLVED];
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (void) showInfoWithLastRunTitle:(NSString*)lastRunTitle
{
  active = NO;
  [self raiseChild:levelInfo];
  [levelInfo setLevel:currentLevel];
  [levelInfo setLastRunTitle:lastRunTitle];
  [levelInfo fadeIn];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) showInfo
{
  [Sound play:SND_INFO];
  [self showInfoWithLastRunTitle:@"Program:"];  
}

//------------------------------------------------------------------------------------------------------------------------

- (void) hideInfo
{
  [board reset];
  [levelInfo fadeOut];
  [Sound play:SND_INFO_OUT];
  active = YES;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) startCompi
{
  if (mode == EDIT)
  {
    [self toggleEditMode];
    [compi start];
  }
  else 
  {
    [self openCompi];
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (void) openCompi
{
  if (mode == EDIT) // edit mode -> play mode
  {
    [self toggleEditMode];
  }
  else // already in play mode
  {
    if (compi.state == END)
    {
      [compi stop];
      [board reset];
    }
    
    if (compi.state != STEP_NEXT && compi.state != STEP_PREV) 
    {
      [compi togglePause];
    }
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (void) stopCompi
{
  [compi stop];
  [board reset];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) memoryChanged
{
  assert(mode == EDIT || mode == TOOLS);
  [memory colorize];
  play.visible = (mode == EDIT && [memory hasValidProgram] && [memory programSize]);
}

//------------------------------------------------------------------------------------------------------------------------

- (void) memoryProgramChanged:(MemoryEvent*)event
{
  [self memoryChanged];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) compiStateChanged:(CompiEvent*)event
{
  [self updateCompiState];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) stackChanged:(StackEvent*)event
{
  [self updateStackState];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) updateCompiState
{
  if (mode != COMP) return;
  if (pbar.visible = (compi.state != PLAY))
  {
    Cell * cell;
    switch (compi.state)
    {
      case READY: cell = [memory     firstCell];    break;
      case END:   cell = [memory      lastCell];    break;
      default:    
      {
        if ([compi.stack endOfTopLevelFunc] == NO || compi.state == STEP_NEXT || compi.state == STEP_PREV)
        {
          cell = [compi.stack lastCell];      
        }
        else
        {
          cell = [compi.stack firstCell];
        }
      }
      break;
    }
    pbar.x = cell.x + ((compi.state == READY || compi.state == STEP_PREV) ? -BDX/2 : BDX/2);
    pbar.y = cell.y;
  }
  
  BOOL stepping = (compi.state == STEP_NEXT || compi.state == STEP_PREV);
  next.icon.visible = !stepping && compi.state != END;
  jmpn.icon.visible = !stepping && compi.state != END && compi.state != PLAY;
  jmpe.icon.visible = !stepping && compi.state != END;
  prev.icon.visible = !stepping && compi.state != READY;  
  jmpp.icon.visible = !stepping && compi.state != READY && compi.state != PLAY;  
  stop.icon.visible = (compi.state != READY);
  play.icon.visible = !stepping;
  play.image = (compi.state != PLAY ? @"button_play" : @"button_pause");
  
  NSLog(@"%@", compi);
  
  [self updateStackState];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) updateStackState
{
  for (Cell * cell in memory.cells) 
  {
    [cell delDots];
    [cell highlight:NO];
  }
  
  NSMutableArray     * dottedCells = [NSMutableArray      arrayWithCapacity:10];
  NSMutableDictionary * depthCells = [NSMutableDictionary dictionaryWithCapacity:4];
  NSMutableDictionary * funcDepths = [NSMutableDictionary dictionaryWithCapacity:4];
  
  if ([compi.stack endOfTopLevelFunc] == NO || compi.state == STEP_NEXT || compi.state == STEP_PREV)
  {
    for (Cell * cell in compi.stack.stackCells) 
    {
      if (cell == [compi.stack lastCell])
      {        
        if (compi.state != PAUSE) [cell highlight];
        continue; // don't paint dots for last stack cell
      }

      Cell * defCell = [cell defCell];
      assert(defCell);
      NSString * cmdKey = CMD_STR(defCell.cmd);
      int depth = [[funcDepths objectForKey:cmdKey] intValue];
      [funcDepths setObject:[NSNumber numberWithInt:depth+1] forKey:cmdKey];          
      
      if (![dottedCells containsObject:cell])
      {
        [dottedCells addObject:cell];
        [cell setDots:[dottedCells count] color:0xffffff];
        [cell highlight];
        [depthCells setObject:defCell forKey:cmdKey];
      }
    }        
  }
  
  for (Cell * defCell in [depthCells allValues])
  {
    int depth = [[funcDepths objectForKey:CMD_STR(defCell.cmd)] intValue];

    float gray = 0.25;
    uint color = RGBCOLOR(gray+(1-gray)*clamp((depth-7)/13.0,0,1), gray+(1-gray)*clamp((depth-20)/5.0,0,1), gray);
    if (depth > 25) color = 0x0;
    [defCell setDots:depth color:color];
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (void) nextCompi
{
  if (!active) return;
  if (compi.state != STEP_NEXT && compi.state != STEP_PREV && compi.state != END && !levelInfo.visible)
  {
    [compi next];
    [Sound play:SND_NEXT];
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (void) prevCompi
{
  if (!active) return;
  if (compi.state != STEP_NEXT && compi.state != STEP_PREV && compi.state != READY)
  {
    [compi prev];
    [Sound play:SND_PREV];
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (void) jmpeCompi
{
  if (!active) return;
  if (compi.state != STEP_NEXT && compi.state != STEP_PREV && compi.state != END && !levelInfo.visible)
  {
    [compi jump_end];
    [Sound play:SND_JMPE];
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (void) jmpnCompi
{
  if (!active) return;
  if (compi.state != STEP_NEXT && compi.state != STEP_PREV && compi.state != END && !levelInfo.visible)
  {
    [compi jump_next];
    [Sound play:SND_JMPN];
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (void) jmppCompi
{
  if (!active) return;
  if (compi.state != STEP_NEXT && compi.state != STEP_PREV && compi.state != READY)
  {
    [compi jump_prev];
    [Sound play:SND_JMPP];
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (void) exit
{
  if (!active) return;
  [self stopCompi];
  [self toggleEditMode];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) quit
{
  if (!active) return;
  [game exitLevel];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setMode:(MenuMode)mode_
{
  MenuMode oldMode = mode;
  mode = mode_;
  
  if (oldMode == COMP || mode == COMP)
  {    
    BOOL v = (mode == COMP);
    
    play.image = v ? @"button_pause" : @"button_play";
    
    stop.visible = v;
    next.visible = v;
    prev.visible = v;
    jmpn.visible = v;
    jmpp.visible = v;
    jmpe.visible = v;
    time.visible = v;
    exit.visible = v;
    pbar.visible = v;
    
    v = !v;
    
    opts.visible = v;
    for (CommandButton * button in commandButtons)
      button.visible = v;
    
    if (v) [memory colorize];
    else 
    {
      for (Cell * cell in memory.cells) [cell highlight:NO];
    }
  }
  else if (oldMode == TOOLS || mode == TOOLS)
  {
    BOOL v = (mode == TOOLS);
    
    quit.visible = v;
    info.visible = v;
    pack.visible = v;
    wipe.visible = v;
    best.visible = v && currentLevel.bestProg;
        
    v = !v;
    
    play.visible = v && [memory programSize];
    for (CommandButton * button in commandButtons)
      button.visible = v;
  }
  
  [compi stateChanged]; // trigger update to position pbar
  if (mode == EDIT) [self memoryChanged]; // updates play button
}

//------------------------------------------------------------------------------------------------------------------------

- (void) toggleEditMode
{
  [self setMode:(mode == EDIT ? COMP : EDIT)];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) toggleTools
{
  [self setMode:(mode == TOOLS ? EDIT : TOOLS)];
  [Sound play:SND_CLICK];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) toggleTime
{
  compi.speed = (compi.speed + 1) % SPEED_NUM;
  NSLog(@"speed %d", compi.speed);
  switch (compi.speed)
  {
    default:
    case NORM: time.image = @"button_time"; break;
    case SLOW: time.image = @"button_slow"; break;
    case FAST: time.image = @"button_fast"; break;
  }
  [Sound play:SND_CLICK];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setup
{
  Cmd cmds[CCOL*CROW] = { GO, TURN_LEFT, TURN_RIGHT, DOT, FUNC_A, FUNC_B, FUNC_C, FUNC_D };

  commandButtons = [[NSMutableArray arrayWithCapacity:CCOL*CROW] retain];
  
  [memory      addEventListener:@selector(memoryProgramChanged:) atObject:self forType:SP_EVENT_TYPE_MEMORY_PROGRAM_CHANGED];
  [compi       addEventListener:@selector(compiStateChanged:)    atObject:self forType:SP_EVENT_TYPE_COMPI_STATE_CHANGED];
  [compi.stack addEventListener:@selector(stackChanged:)         atObject:self forType:SP_EVENT_TYPE_STACK_CHANGED];
  
  for (int y = 0; y < CROW; y++)
  {
    for (int x = 0; x < CCOL; x++)
    {
      Cmd cmd = cmds[y*CCOL+x];
      
      CommandButton * button         = [CommandButton withParent:self];
      if (cmd != NOP) button.command = [Command withParent:button cmd:cmd];        
      [commandButtons addObject:button];
    }
  }
  
  for (int x = 0; x < MCOL; x++)
  {
    for (int y = 0; y < MROW; y++)
    {
      [Cell inMemory:memory withParent:self]; 
    }
  }
  
  [self setupButtons];  
}

//------------------------------------------------------------------------------------------------------------------------

- (void) packProgram
{
  NSString * packed = [memory packedProgram];
  [self clearProgram];
  [memory loadProgram:packed];
  [Sound play:SND_TRASH];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) clearProgram
{
  [memory clear];
  [Sound play:SND_TRASH];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) loadBestProgram
{
  [self clearProgram];
  [memory loadProgram:currentLevel.bestProg];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) loadProgram:(NSString*)program
{
  [memory loadProgram:program];  
}

//------------------------------------------------------------------------------------------------------------------------

- (void) fadeIn
{
  [self showInfoWithLastRunTitle:@"Program:"];
  
  [self setMode:EDIT];

  self.visible = YES;
  
  SPTween * tween = [SPTween tweenWithTarget:self time:MENU_FADE_OUT_TIME transition:SP_TRANSITION_EASE_OUT];
  if (game.orientation == UP || game.orientation == DOWN)
  {
    self.x = 0;
    self.y = 6*BDX;
    [tween animateProperty:@"y" targetValue:0];    
  }
  else
  {
    self.y = 0;
    self.x = 6*BDX;
    [tween animateProperty:@"x" targetValue:0];    
  }
  [game.juggler addObject:tween];
  
  [tween setDelay:MENU_FADE_IN_TIME-MENU_FADE_OUT_TIME ];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) fadeOut
{
  SPTween * tween = [SPTween tweenWithTarget:self time:MENU_FADE_OUT_TIME transition:SP_TRANSITION_EASE_IN];
  
  if (game.orientation == UP || game.orientation == DOWN)
  {
    self.y = 0;
    [tween animateProperty:@"y" targetValue:6*BDX];
  } 
  else 
  {
    self.x = 0;
    [tween animateProperty:@"x" targetValue:6*BDX];    
  }

  [tween addEventListener:@selector(fadedOut:) atObject:self forType:SP_EVENT_TYPE_TWEEN_COMPLETED];
  [game.juggler addObject:tween];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) fadedOut:(SPEvent*)event
{
  self.visible = false;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) layoutLandscape
{
  //NSLog(@"Menu::layoutLandscape");
  
  landscape = YES;
  
  [levelInfo layoutLandscape];
  
  int   i  = 1;
  float sx =  self.stage.height/2 - 4.75*BDX;
  float sy = -self.stage.width/2  + 0.75*BDY;
  float oy = 2.25*BDY;
  
  bg.width  = 5.5*BDX;
  bg.height = self.stage.width;
  bg.x      = sx-0.625*BDX;
  bg.y      = -self.stage.width/2;

  for (int y = 0; y < CROW; y++)
  {
    for (int x = 0; x < CCOL; x++)
    {
      [self childAtIndex:i++].pos = POINT(sx+x*BDX, sy+y*BDY); 
    }
  }
  
  for (int y = 0; y < MROW; y++)
  {
    for (int x = 0; x < MCOL; x++)    
    {
      [self childAtIndex:i++].pos = POINT(sx+x*BDX, sy+y*BDY+oy); 
    }
  }
  
  i = 0;
  for (int y = 0; y < CROW; y++)
  {
    for (int x = 0; x < MCOL; x++)
    {
      if (BTN[i]) ((ActionButton*)BTN[i]).pos = POINT(sx+x*BDX, sy+y*BDY); 
      if (BTT[i]) ((ActionButton*)BTT[i]).pos = POINT(sx+x*BDX, sy+y*BDY); 
      i++;
    }
  }    
}

//------------------------------------------------------------------------------------------------------------------------

- (void) layoutPortrait
{
  //NSLog(@"Menu::layoutPortrait");
  
  landscape = NO;
  
  [levelInfo layoutPortrait];

  int   i  = 1;
  float sx = -self.stage.width/2  + 0.8*BDX;
  float sy =  self.stage.height/2 - 4.75*BDY;
  float ox = 10.25*BDX;
  
  bg.width  = self.stage.width;
  bg.height = 5.5*BDY;
  bg.x      = -self.stage.width/2;
  bg.y      = sy-0.625*BDY;
  
  for (int y = CROW-1; y >= 0; y--)
  {
    for (int x = 0; x < CCOL; x++)
    {
      [self childAtIndex:i++].pos = POINT(ox+sx+y*BDX, sy+x*BDY); 
    }
  }
  
  for (int y = 0; y < MCOL; y++)
  {
    for (int x = 0; x < MROW; x++)
    {
      [self childAtIndex:i++].pos = POINT(sx+x*BDX, sy+y*BDY); 
    }
  }
    
  i = 0;
  for (int y = CROW-1; y >= 0; y--)
  {
    for (int x = 0; x < MCOL; x++)
    {
      if (BTN[i]) ((ActionButton*)BTN[i]).pos = POINT(ox+sx+y*BDX, sy+x*BDY); 
      if (BTT[i]) ((ActionButton*)BTT[i]).pos = POINT(ox+sx+y*BDX, sy+x*BDY); 
      i++;
    }
  }  
}

//------------------------------------------------------------------------------------------------------------------------

- (void) onTouch:(SPTouchEvent *)event
{
  [event stopPropagation]; // prevents world movement in between button gaps
}

@end

