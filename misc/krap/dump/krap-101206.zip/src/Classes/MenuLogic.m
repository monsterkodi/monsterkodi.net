//
//  MenuLogic.m

#import "MenuLogic.h"
#import "PathFinder.h"
#import "Level.h"
#import "Krap.h"
#import "Board.h"
#import "Action.h"
#import "Config.h"
#import "Game.h"
#import "Sound.h"

NSString   * nextLevel;
BOOL         inTransition;
Compi      * moveCompi = nil;
FloorEvent * delayedFloorClickEvent;
Field          krapTargetField = nil;

//------------------------------------------------------------------------------------------------------------------------
@implementation Logic (MenuLogic)
//------------------------------------------------------------------------------------------------------------------------

- (void) initMenuLogic
{
  for (Floor * floor in [board floors])
    [floor addEventListener:@selector(floorClicked:) atObject:self forType:SP_EVENT_TYPE_FLOOR_CLICKED];  
  
  if ([currentLevel.name isEqualToString:@"menu_sound"])
  {
    [self resetBoard];
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (Floor*) floorWithAction:(NSString*)actionName
{
  for (Floor * floor in [board floors])
  {
    for (SPDisplayObject * child in floor.children)
    {
      if (child != [floor firstChild])
      {          
        if ([child isKindOfClass:[Action class]])
        {
          Action * action = (Action*)child;
          if ([action.name isEqualToString:actionName])
            return floor;
        }
      }
    }    
  }
  return nil;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) resetBoard
{
  [board switchAllTilesOff];    
  if ([currentLevel.name isEqualToString:@"menu_sound"])
  {
    NSString * soundAction = [NSString stringWithFormat:@"sound:%0.1f", [Sound volume]];
    NSLog(@"setting sound action field [%@]", soundAction);
    [[self floorWithAction:soundAction] setState:2];    
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) performMenuAction:(NSString*)action
{
  NSLog(@"performMenuAction %@", action);
    
  if ([action hasPrefix:@"level_"] || [action hasPrefix:@"menu_"])
  {
    if (mode == MENU)
    {
      [self storeMenuState];
    }
    
    [nextLevel release];
    nextLevel = [action retain];
    [self startMenuFadeOut];    
    return YES; // stops move compi
  }
  else if ([action hasPrefix:@"sound:"])
  {
    float volume = [[action stringAfter:@"sound:"] floatValue];
    [Sound setVolume:volume];
    [config setFloat:volume forKey:@"sound_volume"];
    [self resetBoard];
    [Sound play:SND_TRASH];
    return YES; // stops move compi
  }
  return NO;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) storeMenuState
{
  NSLog(@"store menu state %@ %@", currentLevel.name, board.krap.field);
  [config setField:board.krap.field forKey:[@"krap_pos_" stringByAppendingString:currentLevel.name]];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) restoreMenuState
{
  NSLog(@"restore menu state %@ %@", currentLevel.name, [config getFieldForKey:[@"krap_pos_" stringByAppendingString:currentLevel.name]]);
  if ([config hasValueForKey:[@"krap_pos_" stringByAppendingString:currentLevel.name]])
    board.krap.field = [config getFieldForKey:[@"krap_pos_" stringByAppendingString:currentLevel.name]];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) startMenuFadeOut
{
  inTransition = true;
  Krap * krap = board.krap;
  
  double fadeOutTime = MENU_FADE_OUT_TIME;
  double fadeInTime  = MENU_FADE_IN_TIME;
  double maxOutDelay = 0;
  double maxInDelay  = 0;
  
  oldWorld = [SPSprite sprite];
  [game->world addChild:oldWorld];
  [game->world sendChildToBack:oldWorld];

  double maxDist = 0; // find maximum manhattan distance
  for (Tile * tile in [board tiles])
  {
    Field tf = tile.field;
    Field kf = krap.field;
    
    int dist = abs(kf.x-tf.x)+abs(kf.y-tf.y);
    if (dist > maxDist) maxDist = dist;
    
    tile.touchable = false;
    
    [oldWorld addChild:tile];
  }

  for (Tile * tile in [board tiles]) // let the tiles fly away
  {
    Field tf = tile.field;
    Field kf = krap.field;
    
    SPTween * tween = [SPTween tweenWithTarget:tile time:fadeOutTime transition:SP_TRANSITION_EASE_IN];
    SPPoint * tpos  = [board spPointAtField:tf];
    tpos.y += game.height/game->world.scale;
    [tween animateProperty:@"x" targetValue:tpos.x];
    [tween animateProperty:@"y" targetValue:tpos.y];
    int dist = abs(kf.x-tf.x)+abs(kf.y-tf.y);
    double delay = (1-dist/maxDist)/4;
    if (delay > maxOutDelay) maxOutDelay = delay;
    [tween setDelay:delay];
    [game.juggler addObject:tween];
  }
  
  double    krapA = krap.angle;
  double    krapX = krap.x;
  double    krapY = krap.y;
  Direction krapD = krap.direction;
  
  // -------------------------------------------
  //
  [Level load:[nextLevel lowercaseString]];
  //
  // -------------------------------------------
    
  krap = board.krap;
  
  maxDist = 0; // find maximum manhattan distance
  for (Tile * tile in [board tiles])
  {
    Field tf = tile.field;
    Field kf = krap.field;
    
    int dist = abs(kf.x-tf.x)+abs(kf.y-tf.y);
    if (dist > maxDist) maxDist = dist;
  }
  
  for (Tile * tile in [board tiles]) // let the tiles fly in
  {
    Field tf = tile.field;
    Field kf = krap.field;
    
    SPTween * tween = [SPTween tweenWithTarget:tile time:fadeInTime transition:SP_TRANSITION_EASE_OUT_BOUNCE];
    SPPoint * tpos  = [board spPointAtField:tf];
    tile.y -= game.height/game->world.scale;;
    [tween animateProperty:@"x" targetValue:tpos.x];
    [tween animateProperty:@"y" targetValue:tpos.y];
    int dist = abs(kf.x-tf.x)+abs(kf.y-tf.y);
    double delay = (dist/maxDist)/4;
    if (delay > maxInDelay) maxInDelay = delay;
    [tween setDelay:delay];
    [game.juggler addObject:tween];
  }
  
  // world scale & pos
  
  SPTween * worldTween = [SPTween tweenWithTarget:game->world time:fadeInTime transition:SP_TRANSITION_EASE_OUT];
  [worldTween animateProperty:@"scale" targetValue:board.defaultScale];
  [worldTween animateProperty:@"x" targetValue:0];
  [worldTween animateProperty:@"y" targetValue:0];
  [game.juggler addObject:worldTween];

  float pcy = (logic.mode == MENU) ? 0 : MENU_SIZE/2;
  if (game.orientation == LEFT || game.orientation == UP) pcy = -pcy;
  
  SPTween * pivotTween = [SPTween tweenWithTarget:game->pivot time:fadeInTime transition:SP_TRANSITION_EASE_OUT];
  [pivotTween animateProperty:@"y" targetValue:pcy];
  
  [game.juggler addObject:pivotTween];
  
  // kraps jump
      
  double x   = krap.x;
  double y   = krap.y;
  double a   = (logic.mode == MENU) ? krapA : krap.angle; // don't rotate krap in menu mode
  if (logic.mode == MENU) krap.direction = krapD;
  
  krap.x     = krapX;
  krap.y     = krapY;
  krap.angle = krapA;
  
  double jumpTime = (fadeInTime + maxInDelay) * 1.3;

  SPTween * tween = [SPTween tweenWithTarget:krap time:jumpTime transition:SP_TRANSITION_EASE_IN_OUT];
  [tween animateProperty:@"x"     targetValue:x];
  [tween animateProperty:@"y"     targetValue:y];
  [tween animateProperty:@"angle" targetValue:a];
  
  [game.juggler addObject:tween];
  
  double jumpHeight = (game.width/3)/game->world.scale;
  [krap jumpWithHeight:jumpHeight time:jumpTime];  
  
  // delayed clean up

  [[game.juggler delayInvocationAtTarget:self byTime:fadeOutTime+maxOutDelay] menuFadedOut];
  [[game.juggler delayInvocationAtTarget:self byTime:jumpTime] menuFadedIn];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) menuFadedOut
{
  [oldWorld removeFromParent];
  oldWorld = nil;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) menuFadedIn
{
  if (logic.mode == MENU)
  {
    if (board.krap.direction == NE) [board.krap rotateRight];
    if (board.krap.direction == NW) [board.krap rotateLeft];
  }
  
  inTransition = false;
  
  if (delayedFloorClickEvent) 
  {
    if ([[board floors] indexOfObject:delayedFloorClickEvent.floor] != NSNotFound)
         [self floorClicked:delayedFloorClickEvent];
    [delayedFloorClickEvent release];
    delayedFloorClickEvent = nil;
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (SPTextField*) addText:(NSString*)text y:(double)y
{  
  unichar c   = [text characterAtIndex:0];
  BOOL number = c >= '0' && c <= '9';
  
  SPTextField * tf = [SPTextField textFieldWithText:text];
  
  tf.width    = 300;
  tf.height   = 100;
  
  tf.x        = -tf.width/2;
  tf.y        = -y*tf.height;
  
  tf.fontSize = 40.0f;
  tf.color    = 0xdddd00;
  
  tf.fontName = @"Elephants In Cherry Trees";
  
  tf.hAlign   = SPHAlignCenter;
  tf.vAlign   = SPVAlignBottom;
  tf.border   = NO;
  
  if (number)
  {
    tf.fontName = @"Too Much Paper!";
    tf.fontSize *= 2;
  }
  
  return tf;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) parseFieldLine:(NSString*)line
{
  NSArray * values = [[[line trim] slim] componentsSeparatedByString:@" "];

  static Field lastField = nil;
  Field field;

  unichar c0 = [[values objectAtIndex:0] characterAtIndex:0];
  unichar c1 = [[values objectAtIndex:1] characterAtIndex:0];
  if (c0 == '+' || c0 == '-' || c1 == '+' || c1 == '-')
  {
    assert(lastField);
    field = [lastField sum:FIELD([[values objectAtIndex:0] intValue] * board.setupOffset, [[values objectAtIndex:1] intValue] * board.setupOffset)];
  }
  else 
  {
    field = FIELD([[values objectAtIndex:0] intValue] * board.setupOffset, [[values objectAtIndex:1] intValue] * board.setupOffset);
  }
    
  SPTextField * tf;
  
  double y = 0;
  for (int i = 2; i < [values count]; i++)
  {
    NSString * str = [values objectAtIndex:i];

    if ([str isEqualToString:@"y:"])
    {
      y = [[values objectAtIndex:i+1] doubleValue]; i++;
    }    
    else if ([str isEqualToString:@"t:"] || [str isEqualToString:@"T:"])
    {
      tf = [self addText:[values objectAtIndex:i+1] y:y];
      tf.touchable = [str isEqualToString:@"T:"];
      Floor * floor = [board floorAtField:field];
      assert(floor);
      [floor addChild:tf];
      i++;
    }
    else if ([str isEqualToString:@"a:"])
    {
      Floor * floor = [board floorAtField:field];
      assert(floor);
      NSString * actionName = [values objectAtIndex:i+1];
      [floor addChild:[Action withName:actionName]];
      
      if ([actionName hasPrefix:@"level_"])
      {
        if ([Level isLocked:actionName])
        {
          tf.alpha = 0;
          floor.color = 0x333333;
        }
        else if ([Level isSolved:actionName])
        {
          tf.color = 0x888800;  
        }
      }
//      else if ([actionName hasPrefix:@"sound:"])
//      {
//        if ([actionName isEqualToString:[NSString stringWithFormat:@"sound:%0.1f", [Sound volume]]])
//        {
//          floor.state = 2;
//        }
//      }
      
      i++;
    }
    else if ([str isEqualToString:@"on"])
    {
      Floor * floor = [board floorAtField:field];
      assert(floor);
      [floor switchOn];
    }
  }
  
  [lastField release];
  lastField = [field cpy];
}

//------------------------------------------------------------------------------------------------------------------------

- (Action*) actionAtField:(Field)field
{  
  Floor * floor = [board floorAtField:field];
  if (!floor) return nil;
  if (floor.numChildren <= 1) return nil;

  for (SPDisplayObject * child in floor.children)
  {
    if (child != [floor firstChild])
    {          
      if ([child isKindOfClass:[Action class]])
      {
        return (Action*)child;
      }
    }
  }
  return nil;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) floorClicked:(FloorEvent*)event;
{  
  if (inTransition) 
  {
    delayedFloorClickEvent = [event retain];
    return;
  }

  Floor * floor = event.floor;

  Action * action = [self actionAtField:floor.field];
  if ([action.name hasPrefix:@"level_"])
  {
    if (![Level isUnlocked:action.name])
      return;
  }
  
  [Sound play:SND_CLICK];
  
  if ([board->krap.field eql:floor.field])
  {
    Action * action = [self actionAtField:board->krap.field];
    if (action) [self performMenuAction:action.name];
    return;    
  }
  
  if ([krapTargetField eql:floor.field])
  {
    if (moveCompi)
    {
      [moveCompi stop];
      [moveCompi release]; 
      moveCompi = nil;
    }
    board.krap.field = krapTargetField;
    [self resetBoard];
    [krapTargetField release];
    krapTargetField = nil;
    
    Action * action = [self actionAtField:board->krap.field];
    if (action) [self performMenuAction:action.name];
    return;
  }
  
  [self resetBoard];
  
  [krapTargetField release];
  krapTargetField = [floor.field cpy];
  
  //NSLog(@"%@ clicked", floor);
  NSString * program = [PathFinder pathFrom:board.krap.field to:floor.field direction:board.krap.direction];
  //NSLog(@"path from %@ to %@: %@", board.krap.field, floor.field, program);
  
  [board->krap removeEventListenersAtObject:self forType:SP_EVENT_TYPE_KRAP_DID_MOVE];
  
  if (moveCompi)
  {
    [moveCompi stop];
    [moveCompi release]; 
  }
  moveCompi = [[Compi alloc] init];
  [moveCompi  executeProgram:program];
  [board->krap addEventListener:@selector(krapMoved:) atObject:self forType:SP_EVENT_TYPE_KRAP_DID_MOVE];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) krapMoved:(KrapEvent*)event
{
  Action * action = [self actionAtField:event.krap.field];
  if (action)
  {
    NSLog(@"%@ action %@", moveCompi, action.name);
    NSLog(@"%@ %@", event.krap.field, krapTargetField);    
    
    if ([event.krap.field eql:krapTargetField])
    {
      NSLog(@"exec target action");
      [self performMenuAction:action.name];
      return;
    }
  }

  [[board tileAtField:event.krap.field] switchOff];
}

@end
