//
//  Config.m

#import "Config.h"

//------------------------------------------------------------------------------------------------------------------------

Config * config;

//------------------------------------------------------------------------------------------------------------------------
@implementation Config
//------------------------------------------------------------------------------------------------------------------------

@synthesize dirty;

//------------------------------------------------------------------------------------------------------------------------
 
- (id) init
{
  if ((self = [super init]))
  {
    //NSLog(@"persistentDomainNames %@", [[NSUserDefaults standardUserDefaults] persistentDomainNames]);
    if (DBG_CONFIG) NSLog(@"config %@", [[NSUserDefaults standardUserDefaults] persistentDomainForName:[[NSBundle mainBundle] bundleIdentifier]]);
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) dealloc
{
  NSLog(@"Config dealloc dirty: %d", dirty);
  if (dirty) [[NSUserDefaults standardUserDefaults] synchronize];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setInteger:(int)value forKey:(NSString *)key
{
  if (DBG_CONFIG) NSLog(@"Config set %d forKey %@", value, key);
  [[NSUserDefaults standardUserDefaults] setInteger:value forKey:key];
	self.dirty = YES;
}

- (void) setDouble:(double)value forKey:(NSString *)key
{
  if (DBG_CONFIG) NSLog(@"Config set %f forKey %@", value, key);
  [[NSUserDefaults standardUserDefaults] setDouble:value forKey:key];
	self.dirty = YES;
}

- (void) setFloat:(float)value forKey:(NSString *)key
{
  if (DBG_CONFIG) NSLog(@"Config set %f forKey %@", value, key);
  [[NSUserDefaults standardUserDefaults] setFloat:value forKey:key];
	self.dirty = YES;
}

- (void) setBool:(BOOL)value forKey:(NSString *)key
{
  if (DBG_CONFIG) NSLog(@"Config set %d forKey %@", value, key);
  [[NSUserDefaults standardUserDefaults] setBool:value forKey:key];
	self.dirty = YES;
}

- (void) setString:(NSString*)value forKey:(NSString *)key
{
  if (DBG_CONFIG) NSLog(@"Config set '%@' forKey %@", value, key);
  [[NSUserDefaults standardUserDefaults] setObject:value forKey:key];
	self.dirty = YES;
}

- (void) setField:(Field)value forKey:(NSString *)key
{
  if (DBG_CONFIG) NSLog(@"Config set %@ forKey %@", value, key);
  [[NSUserDefaults standardUserDefaults] setObject:[NSArray arrayWithObjects:[NSNumber numberWithInt:value.x], [NSNumber numberWithInt:value.y], nil] forKey:key];
	self.dirty = YES;
}

- (int) getInteger:(NSString*)key
{
  if (DBG_CONFIG) NSLog(@"Config get integer %@ %d", key, [[NSUserDefaults standardUserDefaults] integerForKey:key]);
  return [[NSUserDefaults standardUserDefaults] integerForKey:key];
}

- (int) getInteger:(NSString*)key default:(int)value
{
  if ([self hasValueForKey:key]) return [self getInteger:key];
  return value;
}

- (double) getDouble:(NSString*)key
{
  if (DBG_CONFIG) NSLog(@"Config get double %@ %f", key, [[NSUserDefaults standardUserDefaults] doubleForKey:key]);
  return [[NSUserDefaults standardUserDefaults] doubleForKey:key];
}

- (float) getFloat:(NSString*)key
{
  if (DBG_CONFIG) NSLog(@"Config get float %@ %f", key, [[NSUserDefaults standardUserDefaults] floatForKey:key]);
  return [[NSUserDefaults standardUserDefaults] floatForKey:key];
}

- (float) getFloat:(NSString*)key default:(float)value
{
  if ([self hasValueForKey:key]) return [self getFloat:key];
  return value;
}

- (BOOL) getBool:(NSString*)key
{
  if (DBG_CONFIG) NSLog(@"Config get bool %@ %d", key, [[NSUserDefaults standardUserDefaults] boolForKey:key]);
  return [[NSUserDefaults standardUserDefaults] boolForKey:key];
}

- (NSString*) getString:(NSString*)key
{
  if (DBG_CONFIG) NSLog(@"Config get string %@ %@", key, [[NSUserDefaults standardUserDefaults] stringForKey:key]);
  return [[NSUserDefaults standardUserDefaults] stringForKey:key];
}

- (Field) getFieldForKey:(NSString *)key
{
  NSArray * posArray = [[NSUserDefaults standardUserDefaults] objectForKey:key];
  if (DBG_CONFIG) NSLog(@"Config get field %@ %@", key, FIELD([[posArray objectAtIndex:0] intValue], [[posArray objectAtIndex:1] intValue]));
  return FIELD([[posArray objectAtIndex:0] intValue], [[posArray objectAtIndex:1] intValue]);
}

- (BOOL) hasValueForKey:(NSString*)key
{
  return ([[NSUserDefaults standardUserDefaults] objectForKey:key] != nil);
}

@end
