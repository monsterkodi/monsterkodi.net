//
//  Squid.m

#import "Tools.h"
#import "Squid.h"
#import "Media.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation Squid
//------------------------------------------------------------------------------------------------------------------------

+ (Squid*) withParent:(SPDisplayObjectContainer*)parent
{
    Squid * squid = [[Squid alloc] init];
    [parent addChild:squid];
    [squid release];
    [squid start];
    return squid;
}

//------------------------------------------------------------------------------------------------------------------------
 
- (void) setupSprite 
{   
  movie = [[SPMovieClip alloc] initWithFrame:[Media textureByName:@"cala0000"] fps:30];
  
  for (int i = 1; i < 25; i++)
  {
      [movie addFrame:[Media textureByName:[NSString stringWithFormat:@"cala00%02d", i]]];
  }
    
  float size = 1.0f;
  movie.scaleX = size;
  movie.scaleY = size;
  movie.x      = -movie.width/2;
  movie.y      = -movie.height/2;
  movie.loop   = YES;
  
  [self addChild:movie];
  
  [movie play];    

  SPImage * shadow = [SPImage imageWithTexture:[Media textureByName:@"shadow"]];
  shadow.scaleX = 0.5f;
  shadow.scaleY = 0.5f;
  [shadow setPos:[SPPoint pointWithX:-movie.width/2 y:movie.width/3]];
  [self addChild:shadow];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) start
{
    [self.stage.juggler addObject:movie];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) onEnterFrame:(SPEnterFrameEvent*)event
{ 
    //[movie setCurrentFrame:movie.currentFrame + 1];
}

@end
