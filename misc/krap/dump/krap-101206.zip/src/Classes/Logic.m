//
//  Logic.m

#import "Logic.h"
#import "MenuLogic.h"
#import "Board.h"
#import "PathFinder.h"
#import "GameMenu.h"
#import "Game.h"
#import "Config.h"

Logic * logic;

static NSString * MODENAMES[MODENUM] = {
  @"MENU",
  @"FLANEUR",
  @"VISITOR",
  @"TOGGLER",
  @"CHECKER",
  @"SWITCHER"
};

//------------------------------------------------------------------------------------------------------------------------
@implementation Logic
//------------------------------------------------------------------------------------------------------------------------

@synthesize mode;

//------------------------------------------------------------------------------------------------------------------------
 
- (id) init
{
  if ((self = [super init]))
  {
    mode = FLANEUR;
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) dealloc
{
  if (mode == MENU) [self storeMenuState];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setupWithLines:(NSArray*)setupLines
{
  NSString * modeName = @"FLANEUR";
  
  for (NSString * line in setupLines)
  {
    if ([line hasPrefix:@"mode:"])
      modeName = [[line stringAfter:@"mode:"] trim];
  }
  
  [self setModeByName:modeName];
  
  for (NSString * line in setupLines)
  {
    if ([line hasPrefix:@"f:"])
      [self parseFieldLine:[line stringAfter:@"f:"]];
  }  
  
  if (mode == MENU) 
  {
    [self initMenuLogic];
    [self restoreMenuState]; 
    
    if (![currentLevel.name isEqualToString:@"menu_play"])
    {
      [game->world setFollows:NO];
    }
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (void) levelSolved
{
  NSLog(@"levelSolved"); 
  
  NSString * bestKey = [currentLevel.name stringByAppendingFormat:@"_best"];
  int score = [memory programSize];
  int best  = [config getInteger:bestKey default:INT_MAX];
  if (score < best)
  {
    NSLog(@"new record!");
    [config setInteger:score forKey:bestKey];
    [game saveProgram];
  }
  
  [menu displayLevelEndScreen];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) switchFloorAtField:(Field)field
{
  Floor * floor = (Floor*)[board tileAtField:field];
  BOOL bridges[4] = { NO, NO, NO, NO };
  if (floor.mode == SWITCH)
  {
    for (Direction dir = NE; dir <= NW; dir++)
    {
      Field neighbor = [board neighborAtField:field direction:dir];
      Bridge * bridge = (Bridge*)[board tileAtField:neighbor];
      if (bridge)
      {
        bridges[(dir+3)%4] = YES;
        [board delTileAtField:neighbor];
      }
    }
    
    for (Direction dir = NE; dir <= NW; dir++)
    {
      if (bridges[dir])
      {
        [board addBridgeAtField:[board neighborAtField:field direction:dir] direction:dir];  
      }
    }
  }  
}

//------------------------------------------------------------------------------------------------------------------------

- (void) krapWillMove:(BotMoveEvent*)event
{
  //NSLog(@"krapWillMove %@ -> %@", event.sourceField, event.targetField);
  
  switch (mode) 
  {
    case VISITOR:
    case TOGGLER:
    case CHECKER:
      if (compi.state != STEP_PREV) 
      {
        [[board tileAtField:event.targetField]                                 switchState];
        [[board tileBetweenField:event.targetField andField:event.sourceField] switchState];        
      }
      break;      
    case FLANEUR:
    default: break;
  }  
}

//------------------------------------------------------------------------------------------------------------------------

- (void) checkIfAtLevelEnd
{
  switch (mode) 
  {
    case SWITCHER: if ([board allTilesConnected]) [self levelSolved]; break;
    case CHECKER: 
    case VISITOR: 
    case TOGGLER: if ([board allTilesOn]) [self levelSolved]; break;
    default: break;
  }    
  
}

//------------------------------------------------------------------------------------------------------------------------

- (void) krapDidMove:(KrapEvent*)event
{
  if (mode == SWITCHER)
  {
    [self switchFloorAtField:event.krap.field];
  }
  
  [self checkIfAtLevelEnd];
}

//------------------------------------------------------------------------------------------------------------------------

- (GameMode) modeWithName:(NSString*)modeName
{
  for (int i = 0; i < MODENUM; i++)
  {
    if ([modeName isEqualToString:MODENAMES[i]]) return (GameMode)i;
  }
  return FLANEUR;
}

//------------------------------------------------------------------------------------------------------------------------

- (NSString*) modeName
{
  return MODENAMES[mode];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setModeByName:(NSString*)modeName
{
  [self setMode:[self modeWithName:modeName]];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) resetTiles
{
  for (Tile * tile in [board tiles])
  {
    [tile switchOff];
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setMode:(GameMode)mode_
{
  GameMode oldMode = mode;
  mode = mode_;
  
  [self resetTiles];

  [board.krap removeEventListener:@selector(krapWillMove:)        atObject:self forType:SP_EVENT_TYPE_BOT_WILL_MOVE];
  [board.krap removeEventListener:@selector(krapDidMove:)         atObject:self forType:SP_EVENT_TYPE_KRAP_DID_MOVE];

  if (mode != MENU)
    [board.krap addEventListener:@selector(krapDidMove:)          atObject:self forType:SP_EVENT_TYPE_KRAP_DID_MOVE];

  switch (mode) 
  {
    case SWITCHER:
    case CHECKER:
    case VISITOR:
    case TOGGLER:
      [board->krap addEventListener:@selector(krapWillMove:)        atObject:self forType:SP_EVENT_TYPE_BOT_WILL_MOVE];
      break;
    default: break;
  }
  
  if (oldMode == MENU && mode != MENU) [menu fadeIn];
}

@end
