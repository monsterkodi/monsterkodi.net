//
//  CommandButton.h

#import "CommandContainer.h"

//------------------------------------------------------------------------------------------------------------------------
@interface CommandButton : CommandContainer 
//------------------------------------------------------------------------------------------------------------------------
{
  Command * draggedCommand;
}

+ (CommandButton*) withParent:(SPDisplayObjectContainer*)parent;

- (BOOL) startDrag:(CGPoint)pos;
- (void) stopDrag: (CGPoint)pos;
- (void) dragToPos:(CGPoint)pos;

@end
