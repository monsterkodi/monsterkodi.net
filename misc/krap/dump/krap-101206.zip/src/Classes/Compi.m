//
//  Compi.m

#import "Compi.h"
#import "Game.h"
#import "Cell.h"
#import "Sound.h"

Compi * compi;

//------------------------------------------------------------------------------------------------------------------------
@implementation CompiEvent
//------------------------------------------------------------------------------------------------------------------------
@synthesize compi;

- (id)initWithCompi:(Compi*)compi_ type:(NSString*)type
{
  if (self = [super initWithType:type bubbles:NO])
  {
    self->compi = compi_;
  }
  return self;
}
@end

//------------------------------------------------------------------------------------------------------------------------
@implementation Compi
//------------------------------------------------------------------------------------------------------------------------

@synthesize state;
@synthesize speed;
@synthesize stack;

//------------------------------------------------------------------------------------------------------------------------

- (id) init 
{
  if (self = [super init]) 
  {
    stack = [[Stack alloc] init];
    speed = NORM;    
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) dealloc
{
  //NSLog(@"compi dealloc"); 
  [board.krap removeEventListenersAtObject:self forType:SP_EVENT_TYPE_KRAP_DID_EXECUTE];
  [programMemory release];
  [stack         release];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) krapExecuted:(KrapEvent*)event
{
  [event.krap removeEventListenersAtObject:self forType:SP_EVENT_TYPE_KRAP_DID_EXECUTE];
  if (DBG_COMPI) NSLog(@"%@ cellFinished", self);
  if (state == READY) return;

  if (state == PLAY)
  {
    [self play];
  }
  else 
  {       
    if (state == STEP_NEXT) 
    {
      state = PAUSE; 
    }    
  }
  
  [self stateChanged];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) krapReversed:(KrapEvent*)event
{
  [event.krap removeEventListenersAtObject:self forType:SP_EVENT_TYPE_KRAP_DID_EXECUTE];
  
  NSLog(@"%@ cellReversed %@", self, prevStack);

  [stack restoreState:prevStack];
  [prevStack release];
  prevStack = nil;
  
  if ([[stack stateString] length] == 0) self.state = READY;
  else                                   self.state = PAUSE;    
}

//------------------------------------------------------------------------------------------------------------------------

- (void) exec:(Cell*)cell
{
  if (cell.command)
  {
    Command * command = cell.command;
        
    [stack push:cell];
    
    if (DBG_COMPI) NSLog(@"%@ exec %@", self, cell);

    if ([command isExec]) 
    {
      //[board->krap dump:[NSString stringWithFormat:@"     %@", cell]];

      board->krap.speed = speed;
      if ([board->krap executeCommand:cell.command])
      {
        [board->krap addEventListener:@selector(krapExecuted:) atObject:self forType:SP_EVENT_TYPE_KRAP_DID_EXECUTE];
        return;
      }
      //NSLog(@"execute failed");
    }
    
    // either command failed, or it is a function, or the start of a function definition or the end of a function
    
    if (command.cmd == DOT)   // end of function
    {
      [stack pop];                 // remove dot from stack and
      cell = [stack pop];          // remove function call from stack, continue after function call
    }
    else if ([command isFunc])
    {
      if ([cell isDef])       // start of function definition
      {
        [stack pop];               // remove def from stack and
        cell = [cell defEndCell]; // jump over definition
        if (DBG_COMPI) NSLog(@"%@ jump to def end %@", self, cell);
      }
      else                    // function call  
      {
        if (DBG_COMPI) NSLog(@"%@ exec def start", self);
        [self exec:[[cell defCell] defStartCell]]; // execute first cell in function
        return;
      }
    }
    else
    {
      if (DBG_COMPI) NSLog(@"%@ command failed %@", self, cell);
      [stack pop];
    }
  }
    
  if (cell = [cell nextCell])
  {
    [self exec:cell];
  }
  else // end of program
  {
    if (DBG_COMPI) NSLog(@"%@ program end", self);
    self.state = END;
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (void) exec_reverse:(Cell*)cell
{
  assert(cell.command);
  
  [board->krap dump:[NSString stringWithFormat:@"  |< %@", cell]];
  
  board->krap.speed = speed;
  if ([board->krap reverseCommand:cell.command])
  {
    [cell highlight];
    [board->krap addEventListener:@selector(krapReversed:) atObject:self forType:SP_EVENT_TYPE_KRAP_DID_EXECUTE];
  }
  else
  {
    [board->krap dump:[NSString stringWithFormat:@"fail %@", cell]];  
    [self krapReversed:nil];
  }  
}

//------------------------------------------------------------------------------------------------------------------------

- (void) restoreStackWithState:(NSString*)previousStackState
{  
  Cell * revertCell = [stack lastCell];
  
  if (revertCell)
  {
    self.state = STEP_PREV;

    [board->krap fakeCommand:revertCell.command];
    [self exec_reverse:revertCell];
    prevStack = [previousStackState retain];
  }
  else
  {
    [stack restoreState:previousStackState];
  
    if ([previousStackState length] == 0) self.state = READY;
    else                                  self.state = PAUSE;    
  }
}


//------------------------------------------------------------------------------------------------------------------------

- (void) start
{
  [self executeProgramInMemory:memory];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) executeProgram:(NSString*)program
{  
  [programMemory release];
   programMemory = [[Memory alloc] initWithNumberOfCells:[program length]];
  [programMemory loadProgram:program];  
  
  [board.krap stop];
  [self executeProgramInMemory:programMemory];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) executeProgramInMemory:(Memory*)mem
{
  NSString * program = [mem program];
  if (DBG_COMPI || YES) NSLog(@"%@ start program '%@' (%d)", self, program, [mem programSize]);

  state = PLAY;
  
  [stack clear];
    
  [self exec:[mem firstCell]];
  
  [self stateChanged];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) play
{
  Cell * cell = [stack pop];
  
  if (cell = [cell nextCell])
  {
    [self exec:cell];
  }
  else 
  {
    self.state = END;
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (void) togglePause
{  
  state = (state == PLAY ? PAUSE : PLAY);
  
  [self stateChanged];
  
  if (state == PAUSE)
  {
    if (DBG_COMPI) NSLog(@"%@ pause", self);
    [board.krap removeEventListenersAtObject:self forType:SP_EVENT_TYPE_KRAP_DID_EXECUTE];
    [board.krap pause];
  }
  else 
  {
    if (DBG_COMPI) NSLog(@"%@ unpause", self);
    
    [board.krap setDirection:board.krap.direction]; // make sure krap starts at the right angle
    if ([stack lastCell] == nil) [self start];
    else [self play];
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (void) next
{
  if (DBG_COMPI) NSLog(@"%@ next", self);
  
  if (state == PLAY)
  {
    [self togglePause];
  }
  else if (state != END)
  {
    NSLog(@"%@ next %@", self, [stack stateString]);
    Cell * cell;
    if (state == READY)
    {
      state = STEP_NEXT;
      [self exec:[memory firstCell]];
    }
    else 
    {
      cell = [stack pop];
      if (cell = [cell nextCell])
      {
        state = STEP_NEXT;
        [self exec:cell];
      }
      else 
      {
        state = END;
      }
    }
  }
  
  [self stateChanged];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) prev
{
  if      (state == PLAY ) [self togglePause]; // just pause execution if playing
  else if (state != READY)
  {
    NSLog(@"%@ prev", self);
    
    NSString * stateString = [stack stateString];
    //NSLog(@"stateString %@", stateString);
    [board reset];
    [stack clear];
    
    Cell * cell = [memory firstCell];
    
    NSString * previousStackState = @"";

    while (cell)
    {      
      if (cell.command)
      {
        Command * command = cell.command;
        
        [stack.cells addObject:cell];
        
        if ([stateString isEqualToString:[stack stateString]])
        {
          [self restoreStackWithState:previousStackState];
          return;
        }
                
        if ([command isExec]) 
        {
          if ([board->krap fakeCommand:cell.command])
          {
            previousStackState = [stack stateString];
            
            cell = [stack lastCell]; 
            [stack.cells removeLastObject];
                        
            if (cell = [cell nextCell])
            {
              continue;
            }
            else 
            {
              NSLog(@"should this ever happen?");
              break;
            }
          }
          //NSLog(@"execute failed");
        }
        
        // either command failed, or it is a function, or the start of a function definition or the end of a function
        
        if (command.cmd == DOT)   // end of function
        {
          [stack.cells removeLastObject]; // remove dot from stack and          
          cell = [stack lastCell]; // remove function call from stack, continue after function call
          [stack.cells removeLastObject];
        }
        else if ([command isFunc])
        {
          if ([cell isDef])       // start of function definition
          {
            [stack.cells removeLastObject]; // remove def from stack and
            cell = [cell defEndCell]; // jump over definition
          }
          else                    // function call  
          {
            cell = [[cell defCell] defStartCell]; // execute first cell in function
            continue;
          }
        }
        else
        {
          [stack.cells removeLastObject];
        }
      }
      
      if (cell = [cell nextCell])
      {
        continue;
      }
      else // end of program (should only happen if we started in END mode)
      {
        [self restoreStackWithState:previousStackState];
        break;
      }    
    }
  }    
  
  [self stateChanged];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) jumpToStackState:(NSString*)targetStackState
{
  //NSLog(@"%@ jumpToStackState %@", self, targetStackState);
  
  [board reset];
  [stack clear];
  
  Cell * cell;
  
  if (programMemory) cell = [programMemory firstCell]; 
  else               cell = [memory        firstCell];
  
  NSString * stateString = @"";
  
  while (cell)
  {      
    if (cell.command)
    {
      Command * command = cell.command;
      
      [stack.cells addObject:cell];
      stateString = [stateString stringByAppendingFormat:@"#%2d", cell.identifier];
            
      if ([command isExec])
      {
        if ([board->krap fakeCommand:cell.command])
        {
          if (stack.numCells)
          {
            if ([targetStackState isEqualToString:stateString])
            {
              if ([targetStackState length] == 0) state = END;
              else                                state = PAUSE;
              break;
            }
            
            cell = [stack lastCell];
            [stack.cells removeLastObject];
            stateString = [stateString substringToIndex:[stateString length]-3];
          }
          else 
          {
            cell = nil;
            break; // nothing to pop, probably level solved, lets bail out
          }
          
          if (cell = [cell nextCell])
          {
            continue;
          }
          else 
          {
            NSLog(@"should this ever happen?");
            break;
          }
        }
        //NSLog(@"execute failed");
      }
      
      // either command failed, or it is a function, or the start of a function definition or the end of a function
      
      if (command.cmd == DOT)   // end of function
      {
        [stack.cells removeLastObject]; // remove dot from stack and

        cell = [stack lastCell]; 
        [stack.cells removeLastObject]; // remove function call from stack, continue after function call
        
        stateString = [stateString substringToIndex:[stateString length]-6];        
      }
      else if ([command isFunc])
      {
        if ([cell isDef])       // start of function definition
        {
          [stack.cells removeLastObject]; // remove def from stack and
          stateString = [stateString substringToIndex:[stateString length]-3];        

          cell = [cell defEndCell];      // jump over definition
        }
        else                    // function call  
        {
          cell = [[cell defCell] defStartCell]; // execute first cell in function
          continue;
        }
      }
      else
      {
        NSLog(@"execute failed? %@", stateString);

        if ([targetStackState isEqualToString:stateString])
        {
          state = PAUSE;
          break;          
        }       
        
        [stack.cells removeLastObject];
        stateString = [stateString substringToIndex:[stateString length]-3];        
      }
    }
    
    if (cell = [cell nextCell])
    {
      continue;
    }
    else // end of program (should only happen if target stack is empty)
    {
      if ([targetStackState length] == 0) state = END;
      else                                state = PAUSE;    
      break;
    }    
  }
  
  [stack changed];
  [self stateChanged];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) jump_prev
{
  if      (state == PLAY ) [self togglePause]; // just pause execution if playing
  else if (state != READY)
  {
    //NSLog(@"%@ jump_prev %@", self, [stack stateString]);
    
    Cell * prevCell = nil;
    
    if (stack.numCells == 0) // should only happen at end of program
    {
      prevCell = [[memory topLevelCells] lastObject];
    }    
    else // if (stack.numCells >= 1)
    {
      prevCell = [[stack firstCell] prevCellWithExecutableCommand];      
    }    
    
    if (prevCell)
    {
      NSString * stateString = [NSString stringWithFormat:@"#%2d", prevCell.identifier];
      
      while (prevCell && [prevCell.command isFunc])
      {
        prevCell = [[prevCell defCell] lastFunctionCellWithCommand];
        if (prevCell) 
        {
          stateString = [stateString stringByAppendingFormat:@"#%2d", prevCell.identifier];  
        }
      }

      [self jumpToStackState:stateString];
    }
    else
    {
      [board reset];
      [stack clear];
      self.state = READY;
    }    
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (void) jump_next
{
  if      (state == PLAY ) [self togglePause]; // just pause execution if playing
  else if (state != END)
  {
    Cell * nextCell = nil;
    Cell * lastCell = nil;
    
    if (stack.numCells == 0) // should only happen at start of program
    {
      nextCell = [[memory topLevelCells] firstObject];
    }
    else //if (stack.numCells > 0)
    {
      nextCell = [[stack firstCell] nextCellWithExecutableCommand];
    }
    
    if (nextCell)
    {
      NSString * stateString = [NSString stringWithFormat:@"#%2d", nextCell.identifier];
      
      NSLog(@"jump next start %@", stateString);
      
      while (nextCell && [nextCell.command isFunc])
      {
        lastCell = nextCell;
        nextCell = [[nextCell defCell] lastFunctionCellWithCommand];
        if (nextCell)
        {
          if (nextCell != lastCell)
          {
            stateString = [stateString stringByAppendingFormat:@"#%2d", nextCell.identifier];
            NSLog(@"jump next cell %@", stateString);
          }
          else
          {
            nextCell = [nextCell prevCellWithCommand];
            stateString = [stateString stringByAppendingFormat:@"#%2d", nextCell.identifier];
            NSLog(@"recursion %@!", stateString);
            [self jumpToStackState:stateString];
            return;
          }
        }
      }

      NSLog(@"jumpToStackState %@", stateString);
      [self jumpToStackState:stateString];      
    }
    else 
    {
      [self jumpToStackState:@""]; // lets jump to the end
    }
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (void) jump_end
{
  if (state != END)
  {
    //NSLog(@"%@ jump_end %@", self, [stack stateString]);
    
    [self jumpToStackState:@""];
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (void) stop
{
  if (DBG_COMPI) NSLog(@"%@ stop", self);
  
  if (self == compi && state != READY) [Sound play:SND_STOP];

  [board->krap stop];
  
  if (state == PLAY) [self togglePause];
    
  [stack unhighlight]; // clean highlights 
  [stack clear];       // and empty the stack
  
  self.state = READY;  
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setState:(State)state_
{
  if (state_ != state)
  {
    state = state_;
    [self stateChanged];
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (void) stateChanged
{
  [self dispatchEvent:[[CompiEvent alloc] initWithCompi:self type:SP_EVENT_TYPE_COMPI_STATE_CHANGED]];
}

//------------------------------------------------------------------------------------------------------------------------

- (NSString*) description
{
  static NSString * states[STATE_NUM] = { @"READY", @" PLAY", @"PAUSE", @" BACK", @" NEXT", @"  END" };
  return [NSString stringWithFormat:@"%@ |%@| ", states[state], stack];
}

@end

