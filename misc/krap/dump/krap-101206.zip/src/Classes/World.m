//
//  World.m

#import "World.h"
#import "Game.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation World
//------------------------------------------------------------------------------------------------------------------------

@synthesize follows;

//------------------------------------------------------------------------------------------------------------------------

+ (World*) withParent:(SPDisplayObjectContainer*)parent
{
  World * w = [[World alloc] init];
  [parent addChild:w];
  [w release];
  return w;  
}

//------------------------------------------------------------------------------------------------------------------------

- (id) init
{
  if ((self = [super init]))
  {
    [self addEventListener:@selector(onEnterFrame:) atObject:self forType:SP_EVENT_TYPE_ENTER_FRAME];
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) dealloc 
{
  [self removeEventListenersAtObject:self forType:SP_EVENT_TYPE_ENTER_FRAME];
  [super dealloc];  
}

//------------------------------------------------------------------------------------------------------------------------

- (void) onEnterFrame:(SPEnterFrameEvent*)event
{  
  if (follows)
  {
    targetPos = POINT(-board.krap.x * self.scale, -board.krap.y * self.scale);
    CGPoint nowPos = POINT(self.x, self.y);
    float distFact = CGPointLength(CGVector(targetPos, nowPos)) / 200.0;
    CGPoint newPos = CGPointFade(nowPos, targetPos, event.passedTime * distFact);
    self.x = newPos.x;
    self.y = newPos.y;    
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (void) moveBy:(SPPoint*)delta
{
  self.x += delta.x * self.scale;
  self.y += delta.y * self.scale;
  targetPos = POINT(self.x, self.y);
  self.follows = NO;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) scaleBy:(float)delta
{
  float s = self.scale;
  self.scale = clamp(s + s * delta * 2 / (game.width + game.height), 0.25f, 1.5f);
}

//------------------------------------------------------------------------------------------------------------------------

- (void) toggleFollows
{
  [self setFollows:!follows];
  
  if (!follows)
  {
    self.x = 0;
    self.y = 0;
    targetPos = POINT(0,0);
    self.scale = board.defaultScale;
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setFollows:(BOOL)follows_
{
  follows = follows_;
  
  if (follows)
  {
    self.scale = 1;
    self.x = -board.krap.x;
    self.y = -board.krap.y;
  }
}

@end
