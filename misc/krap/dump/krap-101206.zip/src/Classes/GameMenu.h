//
//  GameMenu.h

#import "Menu.h"
#import "ActionButton.h"
#import "LevelInfo.h"
#import "Cell.h"

typedef enum MenuMode_ { EDIT, COMP, TOOLS } MenuMode;

#define MENU_SIZE 5.375*60

//------------------------------------------------------------------------------------------------------------------------
@interface GameMenu : Menu 
//------------------------------------------------------------------------------------------------------------------------
{  
  BOOL             landscape;
  BOOL             active;
  MenuMode         mode;
  SPQuad         * bg;
  Cell           * dragSource;
  Cell           * insertionCell;
  NSMutableArray * insertionCells;

@public
  Sprite         * pbar;

  ActionButton   * play;
  ActionButton   * time;
  ActionButton   * stop;
  ActionButton   * next;
  ActionButton   * prev;
  ActionButton   * jmpn;
  ActionButton   * jmpp;
  ActionButton   * jmpe;
  ActionButton   * exit;
  ActionButton   * quit;
  ActionButton   * pack;
  ActionButton   * wipe;
  ActionButton   * info;
  ActionButton   * opts;

  ActionButton   * best;

  LevelInfo      * levelInfo;
    
  NSMutableArray * commandButtons;
}

@property (readonly) MenuMode mode;

+ (GameMenu*) withParent:(SPDisplayObjectContainer*)parent;
- (void)      setup;

- (void)      loadProgram:(NSString*)program;
- (void)      toggleEditMode;
- (void)      toggleTools;
- (void)      setMode:(MenuMode)mode;
- (void)      openCompi;
- (void)      packProgram;
- (void)      clearProgram;

- (void)      fadeIn;
- (void)      fadeOut;
- (void)      showInfo;
- (void)      hideInfo;
- (void)      showInfoWithLastRunTitle:(NSString*)lastRunTitle;
- (void)      displayLevelEndScreen;
- (void)      stopCompi;

- (void)      updateCompiState;
- (void)      updateStackState;

- (void)      layoutLandscape;
- (void)      layoutPortrait;

- (void)      dragStartedAtCell:(Cell*)cell;

@end

//------------------------------------------------------------------------------------------------------------------------

extern GameMenu * menu;

//------------------------------------------------------------------------------------------------------------------------
