//
//  Media.m

#import "Media.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation Media
//------------------------------------------------------------------------------------------------------------------------

SPTextureAtlas * atlas;

//------------------------------------------------------------------------------------------------------------------------
 
+ (void) initTextureAtlas:(NSString*)textureAtlasFile
{
  NSLog(@"initTextureAtlas %@", textureAtlasFile);
  atlas = [[SPTextureAtlas atlasWithContentsOfFile:textureAtlasFile] retain];
  NSLog(@"textureAtlas initialized");
}

//------------------------------------------------------------------------------------------------------------------------

+ (void) deallocTextureAtlas
{
  NSLog(@"deallocTextureAtlas");
  [atlas dealloc];
}

//------------------------------------------------------------------------------------------------------------------------

+ (SPTexture*) textureByName:(NSString *)textureName
{
  SPTexture * texture = [atlas textureByName:textureName];
  if (!texture)
  {
    NSLog(@"[ERROR] atlas contains no texture with name '%@'", textureName);
  }
  return texture;
}

@end
