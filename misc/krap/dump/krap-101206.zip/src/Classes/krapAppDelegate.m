//
//  krapAppDelegate.m

#import "krapAppDelegate.h"
#import "Tools.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation krapAppDelegate
//------------------------------------------------------------------------------------------------------------------------

@synthesize window;
@synthesize sparrowView;

//------------------------------------------------------------------------------------------------------------------------

- (void)applicationDidFinishLaunching:(UIApplication *)application 
{    
  NSLog(@"applicationDidFinishLaunching");
  
  SP_CREATE_POOL(pool);    
  
  game = [[Game alloc] initWithWidth:768 height:1024];        
  sparrowView.stage = game;
  sparrowView.frameRate = 60.0f;
  [sparrowView start];
  [window makeKeyAndVisible];
  [game release];
    
	[SPAudioEngine start];
	  
  [[NSNotificationCenter defaultCenter] addObserver:self
                                           selector:@selector(deviceOrientationDidChange:)
                                               name:@"UIDeviceOrientationDidChangeNotification"
                                             object:nil];  
  
  [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];

  SP_RELEASE_POOL(pool);
}

//------------------------------------------------------------------------------------------------------------------------
- (void) deviceOrientationDidChange:(NSNotification*)notification
{
  UIDeviceOrientation o = [[UIDevice currentDevice] orientation];

  //NSLog(@"deviceOrientationDidChange %d", o);
  
  Orientation orientation;

  switch (o)
  {
    case UIDeviceOrientationPortrait:           orientation = UP;     break;
    case UIDeviceOrientationLandscapeLeft:      orientation = LEFT;   break;
    case UIDeviceOrientationLandscapeRight:     orientation = RIGHT;  break;
    case UIDeviceOrientationPortraitUpsideDown: orientation = DOWN;   break;
    default: return;
  };
  
  OrientationEvent *event = [[OrientationEvent alloc] initWithOrientation:orientation];
  [game dispatchEvent:event];
  [event release];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) applicationDidBecomeActive:(UIApplication *)application 
{
  NSLog(@"krapAppDelegate applicationDidBecomeActive");
	
	[sparrowView start];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) applicationWillResignActive:(UIApplication *)application 
{
  NSLog(@"krapAppDelegate applicationWillResignActive");
	
	[sparrowView stop];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) applicationWillTerminate:(UIApplication *)application
{
  NSLog(@"krapAppDelegate applicationWillTerminate");  
	[SPAudioEngine stop];
  [window release];  
  [game   release];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) applicationDidReceiveMemoryWarning:(UIApplication *)application 
{
  [SPPoint     purgePool];
  [SPRectangle purgePool];
  [SPMatrix    purgePool];    
}

@end
