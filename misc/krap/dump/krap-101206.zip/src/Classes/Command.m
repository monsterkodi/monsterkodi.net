//
//  Command.m

#import "Command.h"

CMD_INFO CMD[CMD_NUM] =
{
  { ' ', nil,                    0.0f, 0x222222, 0x888888 },
  { '^', @"button_go",           0.9f, 0x222222, 0x888888 },
  { '<', @"button_rotate_left",  0.9f, 0x222222, 0x888888 },
  { '>', @"button_rotate_right", 0.9f, 0x222222, 0x888888 },  
  { 'a', @"button_a",            0.8f, 0x6B3305, 0x888888 },
  { 'b', @"button_b",            0.8f, 0x4D056B, 0x888888 },
  { 'c', @"button_c",            0.8f, 0x051161, 0x888888 },
  { 'd', @"button_d",            0.8f, 0x540000, 0x888888 },
  
  { '.', @"button_dot",          0.9f, 0x222222, 0x888888 }
};

//------------------------------------------------------------------------------------------------------------------------

NSString * CMD_STR(Cmd cmd) {
  return [NSString stringWithFormat:@"%c", CMD[cmd].code];
}

//------------------------------------------------------------------------------------------------------------------------
@implementation Command
//------------------------------------------------------------------------------------------------------------------------

@synthesize cmd;

//------------------------------------------------------------------------------------------------------------------------

+ (Command*) withParent:(SPDisplayObjectContainer*)parent cmd:(Cmd)cmd
{
  Command * button = [[Command alloc] initWithCmd:cmd];
  [parent addChild:button];
  [button release];
  return button;
}

//------------------------------------------------------------------------------------------------------------------------

+ (Cmd) cmdForCode:(unichar)code
{
  for (Cmd cmd = NOP; cmd < CMD_NUM; cmd++)
  {
    if (CMD[cmd].code == code) return cmd;
  }
  return NOP;
}

//------------------------------------------------------------------------------------------------------------------------

- (id) initWithCmd:(Cmd)cmd_
{
  if ((self = [super init]))
  {
    cmd = cmd_;
    
    self.image       = CMD[cmd].image;
    icon.color       = CMD[cmd].iconColor;
    background.color = CMD[cmd].color;
    background.alpha = CMD[cmd].alpha;
    
    [self removeEventListenersAtObject:self forType:SP_EVENT_TYPE_TOUCH];
    self.touchable = NO;
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) dealloc
{
  NSLog(@"dealloc %@", self);
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------

- (Command*) copy
{
  Command * copy = [Command withParent:self.parent cmd:cmd];
  copy.image = image;
  return copy;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) startDrag:(CGPoint)pos
{
  self.pos = CGPointAdd(pos, [self globalFingerOffset]);
  background.alpha = 0.5f; background.visible = YES;
  border    .alpha = 0.5f; border.visible = YES;
  icon      .alpha = 0.5f;  
}

  //------------------------------------------------------------------------------------------------------------------------

- (unichar) code
{
  return CMD[cmd].code;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) onTouch:(SPTouchEvent*)event
{
  assert(NO); // should never come here
}

//------------------------------------------------------------------------------------------------------------------------

- (NSString*) description
{
  return [NSString stringWithFormat:@"[%c]", CMD[cmd].code];
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) isFunc
{
  return (cmd >= FUNC_A && cmd <= FUNC_D);
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) isExec
{
  return (cmd >= GO && cmd < FUNC_A);
}

@end

