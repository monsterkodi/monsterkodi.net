//
//  Sound.h

//------------------------------------------------------------------------------------------------------------------------
@interface Sound : NSObject 
//------------------------------------------------------------------------------------------------------------------------

+ (void)  initialize;
+ (void)  shutdown;
+ (void)  add:(int)soundID file:(NSString*)file;
+ (void)  play:(int)soundID;
+ (void)  setVolume:(float)volume;
+ (float) volume;

@end
