//
//  CommandContainer.h

#import "Command.h"

//------------------------------------------------------------------------------------------------------------------------
@interface CommandContainer : Button 
//------------------------------------------------------------------------------------------------------------------------
{
  Command * command;
}

@property (nonatomic, assign) Command * command;

- (void) setCommand:(Command*)command;
- (void) setColorForCommand:(Command*)command;

@end
