//
//  Media.h

//------------------------------------------------------------------------------------------------------------------------
@interface Media : NSObject 
//------------------------------------------------------------------------------------------------------------------------

+ (void) initTextureAtlas:(NSString*)textureAtlasFile;
+ (void) deallocTextureAtlas;
+ (SPTexture*) textureByName:(NSString*)textureName;

@end
