//
//  CommandContainer.m

#import "CommandContainer.h"
#import "Menu.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation CommandContainer
//------------------------------------------------------------------------------------------------------------------------

@synthesize command;

//------------------------------------------------------------------------------------------------------------------------

- (void) setCommand:(Command*)command_
{
  if (command != command_)
  {
    if (command && (command.parent == self || command.parent == self.parent)) [command removeFromParent];
    command = command_;
  }
  if (command)
  {
    if (command.parent != self) [self addChild:command];
    command.x = 0;
    command.y = 0;
    
    command_.visible = YES;
    command_.icon.alpha = 1;
    command_.border.visible = NO;
    command_.background.visible = NO;
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setColorForCommand:(Command*)aCommand
{
  if (aCommand)
  {
    background.color = aCommand.background.color; 
  }
  else 
  {	
  	background.color = 0x222222; 
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (NSString*) description
{
  return [NSString stringWithFormat:@"[%@ %d cmd:%@]", NSStringFromClass([self class]), identifier, command];
}

@end

