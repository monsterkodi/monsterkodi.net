//
//  Memory.h

#import "Cell.h"

#define MCOL 5
#define MROW 10

#define SP_EVENT_TYPE_MEMORY_PROGRAM_CHANGED @"memory_program_changed"

@class Memory;
//------------------------------------------------------------------------------------------------------------------------
@interface MemoryEvent : SPEvent
//------------------------------------------------------------------------------------------------------------------------
{
  Memory * memory;
}
@property (nonatomic, readonly) Memory * memory;
- (id)initWithMemory:(Memory*)memory type:(NSString*)type;
@end

//------------------------------------------------------------------------------------------------------------------------
@interface Memory : SPEventDispatcher 
//------------------------------------------------------------------------------------------------------------------------
{
  NSMutableArray * cells;
}

@property (readonly) NSMutableArray * cells;
@property (readonly) int numCells;
@property (readonly) NSArray * stackCells;

//------------------------------------------------------------------------------------------------------------------------

- (id)        init;
- (id)        initWithNumberOfCells:(int)cellNum;

- (void)      clear;
- (void)      unhighlight;
- (void)      colorize;
- (void)      loadProgram:(NSString*)program;
- (void)      programChanged;
- (BOOL)      hasValidProgram;

- (int)       indexOfCell:(Cell*)cell;
- (Cell*)     addCell:(Cell*)cell;
- (Cell*)     cellAtIndex:(int)index;
- (Cell*)     cellWithIdentifier:(int)identifier;
- (Cell*)     firstCell;
- (Cell*)     lastCell;
- (Cell*)     firstCellWithCommand;
- (Cell*)     lastCellWithCommand;
- (Cell*)     defCellForDotCell:(Cell*)cell;

- (NSString*) program;
- (NSString*) packedProgram;
- (int)       programSize;

- (NSArray*)             topLevelCells;
- (NSArray*)             stackCells;
- (NSMutableDictionary*) sortedTopLevelCells;

@end

//------------------------------------------------------------------------------------------------------------------------

extern Memory * memory;

//------------------------------------------------------------------------------------------------------------------------
