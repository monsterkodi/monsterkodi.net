//
//  MenuLogic.h

#import "Logic.h"
#import "Floor.h"
#import "Compi.h"

//------------------------------------------------------------------------------------------------------------------------
@interface Logic (MenuLogic)
//------------------------------------------------------------------------------------------------------------------------

- (void) initMenuLogic;
- (void) resetBoard;
- (void) floorClicked:(FloorEvent*)event;
- (void) parseFieldLine:(NSString*)line;
- (void) menuFadedOut;
- (void) menuFadedIn;
- (BOOL) performMenuAction:(NSString*)action;
- (void) storeMenuState;
- (void) restoreMenuState;
- (void) startMenuFadeOut;

@end
