//
//  ActionButton.h

#import "Button.h"

//------------------------------------------------------------------------------------------------------------------------
@interface ActionButton : Button
//------------------------------------------------------------------------------------------------------------------------
{
	id  target;
  SEL selector;
  SEL longPress;
}

@property (nonatomic, assign) id  target;
@property (nonatomic, assign) SEL selector;
@property (nonatomic, assign) SEL longPress;

+ (ActionButton*) withParent:(SPDisplayObjectContainer*)parent;
- (void) tapped:(int)tapCount;

@end
