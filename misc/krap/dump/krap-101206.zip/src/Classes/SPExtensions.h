//
//  SPCategories.h

#import "SPDisplayObject.h"
#import "Tools.h"

#define SP_EVENT_TYPE_ORIENTATION @"orientation"

#define SPPOINT(a,b) [SPPoint pointWithX:(a) y:(b)]
#define SPPOINT_FOR_POS(p) SPPOINT(p.x, p.y)

//------------------------------------------------------------------------------------------------------------------------

typedef enum Orientation_ { UP, RIGHT, DOWN, LEFT } Orientation;

//------------------------------------------------------------------------------------------------------------------------
@interface OrientationEvent : SPEvent
//------------------------------------------------------------------------------------------------------------------------
{
  Orientation orientation;
}

- (id)initWithOrientation:(Orientation)orientation;

@property (nonatomic, readonly) Orientation orientation;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface SPDisplayObject (SPDisplayObjectExtensions) 
//------------------------------------------------------------------------------------------------------------------------

@property (nonatomic)         float   scale;
@property (nonatomic, assign) CGPoint pos;

- (CGPoint) localToGlobalPos:(CGPoint)localPos;
- (CGPoint) globalToLocalPos:(CGPoint)globalPos;
- (CGPoint) parentToGlobalPos:(CGPoint)localPos;
- (CGPoint) globalToParentPos:(CGPoint)globalPos;
- (CGPoint) localPos:(CGPoint)localPoint toTarget:(SPDisplayObject*)target;

- (CGPoint)   pos;
- (void)      setPos:(CGPoint)pos;
- (SPDisplayObject*) hitTest:(CGPoint)localPos forTouch:(BOOL)isTouch;

- (float)     scale;
- (void)      setScale:(float)scale;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface SPDisplayObjectContainer (SPDisplayObjectContainterExtensions)
//------------------------------------------------------------------------------------------------------------------------

@property (nonatomic, readonly) NSArray * children;

- (void) bringChildToFront:(SPDisplayObject*)child;
- (void) sendChildToBack:(SPDisplayObject*)child;
- (void) raiseChild:(SPDisplayObject*)child;
- (void) lowerChild:(SPDisplayObject*)child;
- (void) insertChild:(SPDisplayObject*)child atIndex:(int)index;
- (SPDisplayObject*) lastChild;
- (SPDisplayObject*) firstChild;
- (SPDisplayObject*) hitTest:(CGPoint)localPos forTouch:(BOOL)isTouch;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface SPRectangle (SPRectangleCGPoint)
//------------------------------------------------------------------------------------------------------------------------

- (BOOL) containsPos:(CGPoint)pos;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface SPSprite (SPSpriteConstruction) 
//------------------------------------------------------------------------------------------------------------------------

+ (SPSprite*) withParent:(SPDisplayObjectContainer*)parent x:(float)x y:(float)y;
+ (SPSprite*) withParent:(SPDisplayObjectContainer*)parent;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface SPQuad (SPQuadColor)
//------------------------------------------------------------------------------------------------------------------------

- (void) setHorizontalGradientFromColor:(uint)col1 toColor:(uint)col2;
- (void) setVerticalGradientFromColor:(uint)col1 toColor:(uint)col2;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface SPTouch (SPTouchPosition) 
//------------------------------------------------------------------------------------------------------------------------

- (SPPoint*) getPos;
- (SPPoint*) getPreviousPos;
- (SPPoint*) getDeltaFor:(SPDisplayObject*)localObject;
- (float)    deltaX;
- (float)    deltaY;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface SPTouchEvent (SPTouchEventTouches)
//------------------------------------------------------------------------------------------------------------------------

@property (nonatomic, readonly) SPTouch * firstTouch;
@property (nonatomic, readonly) int       numTouches;
@property (nonatomic, readonly) float     pinchDelta;

- (SPTouch*) firstTouch;
- (int)      numTouches;
- (float)    pinchDelta;

@end
