//
//  Level.h

//------------------------------------------------------------------------------------------------------------------------
@interface Level : NSObject 
//------------------------------------------------------------------------------------------------------------------------
{
  NSMutableArray * boardLines;
  NSMutableArray * setupLines;
  NSString       * name;
  NSString       * bestProg;
  int              starScore[3];
}

@property (retain)   NSString        * name;
@property (readonly) NSString        * bestProg;
@property (readonly) NSMutableArray  * boardLines;
@property (readonly) NSMutableArray  * setupLines;

+ (Level*)  load:(NSString*)level;
- (id)      initWithLines:(NSArray *)lines;

+ (int)     bestScore:(NSString*)level;
+ (BOOL)    isSolved:(NSString*)level;
+ (BOOL)    isLocked:(NSString*)level;
+ (BOOL)    isUnlocked:(NSString*)level;

- (BOOL)    isSolved;
- (int)     bestScore;
- (int)     currentScore;
- (int)     star1Score;
- (int)     star2Score;
- (int)     star3Score;

@end

//------------------------------------------------------------------------------------------------------------------------

extern Level * currentLevel;

//------------------------------------------------------------------------------------------------------------------------
