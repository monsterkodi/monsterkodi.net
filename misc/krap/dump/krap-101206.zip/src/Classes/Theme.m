//
//  Theme.m

#import "Theme.h"

Theme * theme;

//------------------------------------------------------------------------------------------------------------------------
@implementation Theme
//------------------------------------------------------------------------------------------------------------------------

- (uint) color:(ThemeColor)c
{
  return colors[c];
}

//------------------------------------------------------------------------------------------------------------------------

- (id) init
{
  if ((self = [super init]))
  {
    colors = (uint*)calloc(sizeof(uint), COLOR_NUM);
    
    colors[COLOR_FLOOR_TOGGLE]    = 0x444444;
    colors[COLOR_FLOOR_TOGGLE_ON] = 0xbb4400;
    colors[COLOR_FLOOR]           = 0x666666;
    colors[COLOR_FLOOR_ON]        = 0xff8800;
    colors[COLOR_FLOOR_ON_2]      = 0xffff00;
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) dealloc
{
  free (colors);
  [super dealloc];
}

@end

