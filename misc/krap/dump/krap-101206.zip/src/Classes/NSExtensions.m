//
//  NSExtensions.m

#import "NSExtensions.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation NSString (NSStringExtensions) 
//------------------------------------------------------------------------------------------------------------------------

- (NSString*) trim
{
  return [self stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
}

- (NSString*) slim
{
  NSString * str = [self stringByReplacingOccurrencesOfString:@"\t" withString:@" "];
  return           [str  stringByReplacingOccurrencesOfString:@"  " withString:@" "];
}

- (NSString*) stringAfter:(NSString*)str
{
  NSRange range = [self rangeOfString:str];
  if (range.location != NSNotFound) 
    return [self substringFromIndex:range.location + range.length];
  return @"";
}
@end

//------------------------------------------------------------------------------------------------------------------------
@implementation NSArray (NSArrayExtensions) 
//------------------------------------------------------------------------------------------------------------------------

- (id) firstObject
{
  return [self objectAtIndex:0];
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation NSMutableArray (NMutableArrayExtensions) 
//------------------------------------------------------------------------------------------------------------------------

- (id) enqueue:(id)obj
{
  [self insertObject:obj atIndex:[self count]-1];
  return obj;
}

- (id) dequeue
{
  id first = [self objectAtIndex:0];
  [self removeObjectAtIndex:0];
  return first;
}

- (id) push:(id)obj
{
  [self addObject:obj];
  return obj;
}

- (id) pop
{
  id last = [self lastObject];
  [self removeObjectAtIndex:[self count]-1];
  return last;
}

@end
