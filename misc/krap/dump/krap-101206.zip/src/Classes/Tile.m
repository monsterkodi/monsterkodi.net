//
//  Tile.m

#import "Tile.h"
#import "Board.h"
#import "Theme.h"

static NSString * TILEMODENAMES[TILEMODENUM] = {
  @"BALL",
  @"VISIT", 
  @"TOGGLE", 
};

//------------------------------------------------------------------------------------------------------------------------
@implementation Tile
//------------------------------------------------------------------------------------------------------------------------

@synthesize on;
@synthesize state;
@synthesize mode;

//------------------------------------------------------------------------------------------------------------------------

- (id) initWithFile:(NSString *)imageFile
{
  if (self = [super initWithFile:imageFile])
  {
    state = 0;
    mode  = VISIT;
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) dealloc
{
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------

- (NSString*) description
{
  int index = [board indexOfTile:self];
  return [NSString stringWithFormat:@"%@ %@ %d", NSStringFromClass([self class]), [board fieldAtIndex:index], index];
}

//------------------------------------------------------------------------------------------------------------------------

- (Field) field
{
  return [board fieldAtIndex:[board indexOfTile:self]];
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) on        { return (state > 0); }
- (void) toggleOn  { if (self.on) [self switchOff]; else [self switchOn]; }
- (void) switchOn  { if (self.on == NO) self.state = 1; }
- (void) switchOff { if (self.on == YES) self.state = 0; }

//------------------------------------------------------------------------------------------------------------------------

- (void) setState:(int)state_
{
  state = state_;
  [self stateChanged];    
}

//------------------------------------------------------------------------------------------------------------------------

- (void) switchState // warning!
{ 
  if (mode == TOGGLE) [self toggleOn];
  else [self switchOn];
}

//------------------------------------------------------------------------------------------------------------------------

- (TileMode) modeWithName:(NSString*)modeName
{
  for (int i = 0; i < TILEMODENUM; i++)
  {
    if ([modeName isEqualToString:TILEMODENAMES[i]]) return (TileMode)i;
  }
  return VISIT;
}

//------------------------------------------------------------------------------------------------------------------------

- (NSString*) modeName
{
  return TILEMODENAMES[mode];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setModeByName:(NSString*)modeName
{
  [self setMode:[self modeWithName:modeName]];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setMode:(TileMode)tileMode
{
  mode = tileMode;
  [self stateChanged];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) stateChanged
{
  uint col;
  if (state == 2)
  {
    col = COLOR_FLOOR_ON_2;
  }
  else
  {
    col = (self.on ? (mode == TOGGLE ? COLOR_FLOOR_TOGGLE_ON : COLOR_FLOOR_ON) : (mode == TOGGLE ? COLOR_FLOOR_TOGGLE : COLOR_FLOOR));
  }
  ((SPImage*)[self firstChild]).color = [theme color:col];    
}

@end
