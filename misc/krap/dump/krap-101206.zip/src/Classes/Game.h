//
//  Game.h

#import "Krap.h"
#import "World.h"
#import "Board.h"
#import "Compi.h"
#import "Logic.h"
#import "Memory.h"
#import "Theme.h"
#import "GameMenu.h"

//------------------------------------------------------------------------------------------------------------------------
@interface Game : SPStage
//------------------------------------------------------------------------------------------------------------------------
{
  @public
  
  SPQuad    * bg;
  SPSprite  * root;
  SPSprite  * pivot;
  SPSprite  * menupivot;
  World     * world;
  SPSprite  * items;
  GameMenu  * menu;
  
  Orientation orientation;
}

//------------------------------------------------------------------------------------------------------------------------

@property (nonatomic, assign)   uint        backgroundColor;
@property (nonatomic, readonly) Orientation orientation;

- (void) initSound;
- (void) exitLevel;
- (void) saveProgram;

@end

//------------------------------------------------------------------------------------------------------------------------

extern Game  * game;

//------------------------------------------------------------------------------------------------------------------------

enum SNDS 
{
  SND_NONE,
  SND_CLICK,
  SND_NEXT,
  SND_PREV,
  SND_JMPN,
  SND_JMPP,
  SND_JMPE,
  SND_DRAG_START,
  SND_DRAG_DROP,
  SND_DRAG_TRASH,
  SND_MAIN,
  SND_MENU,
  SND_INFO,
  SND_INFO_OUT,
  SND_JUMP,
  SND_MOVE,
  SND_MOVE_BACKWARD,
  SND_ROTL,
  SND_ROTR,
  SND_STOP,
  SND_TRASH,
  SND_SOLVED,
};

//------------------------------------------------------------------------------------------------------------------------
