//
//  Bot.h

#define SP_EVENT_TYPE_BOT_WILL_MOVE         @"bot_will_move"

//------------------------------------------------------------------------------------------------------------------------
@interface BotMoveEvent : SPEvent
//------------------------------------------------------------------------------------------------------------------------
{
  Field sourceField;
  Field targetField;
}

- (id)initWithSourceField:(Field)source targetField:(Field)target type:(NSString*)type;

@property (nonatomic, readonly) Field sourceField;
@property (nonatomic, readonly) Field targetField;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface Bot : SPSprite
//------------------------------------------------------------------------------------------------------------------------
{
  SPMovieClip * movie;
}

@property (nonatomic, readonly) SPMovieClip * movie;

- (void)setupMovie;

@end
