//
//  Sprite.h

//------------------------------------------------------------------------------------------------------------------------
@interface Sprite : SPSprite 
//------------------------------------------------------------------------------------------------------------------------
{
	int identifier;
}

@property (nonatomic, setter=setImage, assign) NSString * imageFile;
@property (nonatomic, readonly) int identifier;
@property (nonatomic, assign) uint color;

+ (Sprite*)   withParent:(SPDisplayObjectContainer*)parent image:(NSString*)imageFile;

- (id)        initWithFile:(NSString*)imageFile;
- (SPImage*)  addImage:(NSString*)imageFile;
- (NSString*) description;

@end
