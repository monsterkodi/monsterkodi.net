//
//  MemoryCell.h

#import "CommandContainer.h"

@class Memory;

//------------------------------------------------------------------------------------------------------------------------
@interface Cell : CommandContainer 
//------------------------------------------------------------------------------------------------------------------------
{
  Memory * mem;
  int numDots;
}

@property (readonly) Cmd      cmd;
@property (readonly) Memory * mem;

+ (Cell*)       inMemory:(Memory*)mem withParent:(SPDisplayObjectContainer*)parent;
- (id)          initWithMemory:(Memory*)mem;

- (BOOL)        handleDraggedButton:(Button*)button;
- (BOOL)        handleDroppedButton:(Button*)button;
- (void)        clearDraggedButton;
- (BOOL)        startDrag:(CGPoint)pos;
- (void)        stopDrag: (CGPoint)pos;
- (void)        dragToPos:(CGPoint)pos;
- (Cell*)       nextCell;
- (Cell*)       prevCell;
- (Cell*)       prevCellWithCommand;
- (Cell*)       prevCellWithExecutableCommand;
- (Cell*)       nextCellWithCommand;
- (Cell*)       nextCellWithCommand:(Cmd)cmd;
- (Cell*)       nextCellWithExecutableCommand;
- (unichar)     code;
- (Cmd)         cmd;

- (BOOL)        isDef;
- (BOOL)        isDot;
- (Cell*)       defCell;
- (Cell*)       defStartCell;
- (Cell*)       defEndCell;
- (Cell*)       lastFunctionCellWithCommand;
- (Cell*)       firstFunctionCellWithCommand;
- (NSArray*)    functionCells;
- (NSArray*)    functionCellsWithCommand;

- (void)        setDots:(int)num color:(uint)color;
- (void)        delDots;

- (void)        startInsertion;
- (void)        stopInsertion;
- (void)        finalizeInsertion;

@end
