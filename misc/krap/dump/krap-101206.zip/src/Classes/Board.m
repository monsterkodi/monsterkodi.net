//
//  Board.m

#import "Board.h"
#import "Game.h"
#import "PathFinder.h"
#import "Memory.h"
#import "Action.h"
#import "Config.h"

//------------------------------------------------------------------------------------------------------------------------

Board * board;

//------------------------------------------------------------------------------------------------------------------------
@implementation Board
//------------------------------------------------------------------------------------------------------------------------

@synthesize krap;
@synthesize tiles;
@synthesize setupOffset;
@synthesize defaultScale;

//------------------------------------------------------------------------------------------------------------------------

+ (Board*) withParent:(SPDisplayObjectContainer*)parent
{
  Board * b = [[Board alloc] init];
  [parent addChild:b];
  [b release];
  return b;  
}

//------------------------------------------------------------------------------------------------------------------------

- (id) init
{
  if ((self = [super init]))
  {
    fields = nil;
    tiles = [[NSMutableArray arrayWithCapacity:100] retain];
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) dealloc 
{
  free(fields);
  [tiles release];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) reset
{
  [self setupItems];
  [self setupLogic];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) initDefaultScale
{
  for (NSString * line in currentLevel.setupLines)
  {
    if ([line hasPrefix:@"scale:"])
    {
      defaultScale = [[line stringAfter:@"scale:"] doubleValue];
      return;
    }
  }
  
  float minx = 0, maxx = 0;
  for (Tile * tile in tiles)
  {
    float x = [self spPointAtField:tile.field].x;
    minx = min(x, minx);
    maxx = max(x, maxx);
  }
  
  defaultScale = min(1, (logic.mode != MENU ? (game.height - MENU_SIZE - 60) : (game.width - 100)) / (maxx-minx + 100));
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setupLevel:(Level*)level
{
  [self removeAllChildren];
  [tiles removeAllObjects];
    
  setupOffset = 1; // field offset
  
  if ([[level.boardLines firstObject] hasPrefix:@"o:"])
  {
    setupOffset = [[[level.boardLines firstObject] stringAfter:@"o:"] intValue];
    [level.boardLines removeObjectAtIndex:0];
  }
    
  rows = [level.boardLines count] * setupOffset;
  cols = 0;
  
  for (NSString * line in level.boardLines)
  {
    cols = max(cols, [line length] * setupOffset);
  }
  
  if (fields) free(fields);
  fields = calloc(rows * cols, sizeof(id));
  
  krap = nil;
  
  int y = 0;
  for (NSString * line in level.boardLines)
  {
    for (int x = 0; x < [line length]; x++)
    {
      Field field = FIELD(x*setupOffset, y*setupOffset);
      switch ([line characterAtIndex:x])
      {
        case 'X':
        case 'O':
        case 'x':
        case '0':
        case 'o': [self addFloorAtField:field];               break;
        case 'I':
        case '|': [self addBridgeAtField:field direction:SW]; break;
        case '=':
        case '-': [self addBridgeAtField:field direction:SE]; break;
        default:  break;
      }
      switch ([line characterAtIndex:x])
      {
        case 'I':
        case 'X':
        case '=':
        case 'O': [self tileAtField:field].mode = TOGGLE;  break;
        case '0': [self tileAtField:field].mode = SWITCH;  break;
        case 'x':
        case 'o': 
        case '|': 
        case '-': [self tileAtField:field].mode = VISIT;   break;
        default:  break;
      }
    }
    y++;
  }

  [self addKrap];
        
  [self setupItems];
  [self setupProgram];  
  [self setupLogic];
  
  [self initDefaultScale];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setupItems
{
  assert(krap);
  
  BOOL krapFound = NO;
  int y = 0;
  for (NSString * line in currentLevel.boardLines)
  {
    for (int x = 0; x < [line length]; x++)
    {
      switch ([line characterAtIndex:x])
      {
        case 'x':
        case 'X': krap.field = FIELD(x*setupOffset,y*setupOffset); krapFound = YES; break;
        default: break;
      }
    }
    y++;
  }
   
  krap.direction = SE;

  for (NSString * line in currentLevel.setupLines)
  {
    if ([line hasPrefix:@"krap:"])
    {
      NSArray  * arg = [[[line stringAfter:@"krap:"] trim] componentsSeparatedByString:@" "];
      NSString * dir = [arg firstObject];
      if ([dir isEqualToString:@"NE"]) krap.direction = NE;
      if ([dir isEqualToString:@"NW"]) krap.direction = NW;
      if ([dir isEqualToString:@"SE"]) krap.direction = SE;
      if ([dir isEqualToString:@"SW"]) krap.direction = SW;
      
      if ([arg count] > 1)
      {
        if ([[arg objectAtIndex:1] isEqualToString:@"f:"])
        {
          krap.field = FIELD([[arg objectAtIndex:2] intValue]*setupOffset,[[arg objectAtIndex:3] intValue]*setupOffset); 
          krapFound = YES;
        }
      }
    }
  }
  
  assert(krapFound);  
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setupProgram
{  
  for (NSString * line in currentLevel.setupLines)
  {
    if ([line hasPrefix:@"prog:"])
    {
      [menu loadProgram:[line stringAfter:@"prog:"]];
      return;
    }
  }  
  
  NSString * prgKey = [currentLevel.name stringByAppendingString:@"_prog"];
  NSLog(@"check for previous prog %@", prgKey);
  if ([config hasValueForKey:prgKey])
  {
    NSLog(@"previous prog %@ found", prgKey);
    
    [menu loadProgram:[config getString:prgKey]];
  }
  else 
  {
    [memory clear];
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setupLogic
{  
  [logic setupWithLines:currentLevel.setupLines];
}

//------------------------------------------------------------------------------------------------------------------------

- (Krap*) addKrap
{
  krap           = [Krap withParent:self]; 
  krap.direction = SE;
  return krap;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) delTileAtField:(Field)field
{
  Tile * tile = [self tileAtField:field];
  fields[[self indexAtField:field]] = nil;
  [tiles removeObject:tile];
  [self removeChild:tile];
}

//------------------------------------------------------------------------------------------------------------------------

- (Floor*) addFloorAtField:(Field)field
{
	Floor * floor = [Floor withParent:self];
  floor.pos = [self pointAtField:field];
  fields[[self indexAtField:field]] = floor;
  [tiles addObject:floor];
  [floor stateChanged];
  return floor;
}

//------------------------------------------------------------------------------------------------------------------------

- (int) numFields { return rows*cols; }

//------------------------------------------------------------------------------------------------------------------------

- (int) childIndexAtField:(Field)field
{
  int childIndex = 0;
  int fieldIndex = [self indexAtField:field];
  for (int i = 0; i < fieldIndex; i++)
  {
    if (fields[i]) childIndex++;
  }
  return childIndex;
}

//------------------------------------------------------------------------------------------------------------------------

- (Bridge*) addBridgeAtField:(Field)field direction:(Direction)direction
{
  Bridge * bridge = [[Bridge alloc] initWithDirection:direction];
  int index = [self indexAtField:field];
  [self insertChild:bridge atIndex:[self childIndexAtField:field]];
  [bridge release];
  
  bridge.pos = [self pointAtField:field];
  fields[index] = bridge;
  [tiles addObject:bridge];
  [bridge stateChanged];
  return bridge;  
}

//------------------------------------------------------------------------------------------------------------------------

- (Floor*) floorAtField:(Field)field
{
  Tile * tile = [self tileAtField:field];
  if (tile)
  {
    if ([tile isKindOfClass:[Floor class]]) return (Floor*)tile;
  }
  return nil;
}

//------------------------------------------------------------------------------------------------------------------------

- (int) numActionsAtField:(Field)field
{
  int num = 0;
  Tile * tile = [self tileAtField:field];
  if (tile)
  {
    for (id child in tile.children)
      if ([child isKindOfClass:[Action class]]) num++;
  }
  return num;
}

//------------------------------------------------------------------------------------------------------------------------

- (Tile*) tileAtField:(Field)field
{
  if ([self isValidField:field])
    return fields[[self indexAtField:field]];
  //NSLog(@"[WARNING] tileAtField called with invalid field %@", field);
  return nil;
}

//------------------------------------------------------------------------------------------------------------------------

- (Tile*) tileBetweenField:(Field)fa andField:(Field)fb
{
  if ([self isValidField:fa] && [self isValidField:fb])
  {
    int dx = fb.x - fa.x;
    int dy = fb.y - fa.y;
    if (abs(dx) == 2 && abs(dy) == 0 || abs(dx) == 0 && abs(dy) == 2) 
    {
      Field field = FIELD(fa.x + dx/2, fa.y + dy/2);
      return fields[[self indexAtField:field]];
    }    
  }
    
  NSLog(@"[WARNING] tileBetweenField called with invalid fields %@ %@", fa, fb);
  return nil;
}

//------------------------------------------------------------------------------------------------------------------------

- (NSArray*) floors
{
  NSMutableArray * ary = [NSMutableArray arrayWithCapacity:cols*rows];
  for (int y = 0; y < rows; y++)
  {    
    for (int x = 0; x < cols; x++)
    {
      Tile * tile = [self tileAtField:FIELD(x,y)];
      if (tile && [tile isKindOfClass:[Floor class]]) [ary addObject:tile];
    }
  }
  return ary;
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) allTilesConnected
{
  return NO;
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) allTilesOn
{
  for (Tile * tile in tiles)
  {
    if (!tile.on) return NO;
  }
  return YES;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) switchAllTilesOff
{
  for (Tile * tile in tiles)
  {
    [tile switchOff];
  }  
}

//------------------------------------------------------------------------------------------------------------------------

- (int) indexOfTile:(Tile*)tile
{
  for (int i = 0; i < rows*cols; i++)
  {
    if (fields[i] == tile) return i;
  }
  return -1;
}

//------------------------------------------------------------------------------------------------------------------------

- (int) indexAtField:(Field)field
{
  return field.y * cols + field.x; 
}

//------------------------------------------------------------------------------------------------------------------------

- (Field) fieldAtIndex:(int)index
{
  return FIELD(index%cols, (index - index%cols)/cols);
}

//------------------------------------------------------------------------------------------------------------------------

- (Field) neighborAtField:(Field)field direction:(Direction)direction
{
  static int dirx[4] = {  0, 1, 0, -1 };
  static int diry[4] = { -1, 0, 1,  0 };
  return [field sum:FIELD(dirx[direction], diry[direction])];
}

//------------------------------------------------------------------------------------------------------------------------

- (Field) moveTargetAtField:(Field)field direction:(Direction)direction
{
  static int dirx[4] = {  0, 2, 0, -2 };
  static int diry[4] = { -2, 0, 2,  0 };
  return [field sum:FIELD(dirx[direction], diry[direction])];
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) isValidField:(Field)field
{
  return (field.x >= 0 && field.y >= 0 && field.x < cols && field.y < rows);
}

//------------------------------------------------------------------------------------------------------------------------
- (Direction) directionFromField:(Field)p1 toField:(Field)p2
{
  int dx = p2.x - p1.x;
  int dy = p2.y - p1.y;
  if (dx > 0 && dy == 0) return SE;
  if (dx < 0 && dy == 0) return NW;
  if (dy < 0 && dx == 0) return NE;
  if (dy > 0 && dx == 0) return SW;
  assert(NO);
  return NE;
}

//------------------------------------------------------------------------------------------------------------------------

- (CGPoint) pointAtField:(Field)field
{
  return [self pointAtX:field.x y:field.y];
}

//------------------------------------------------------------------------------------------------------------------------

- (CGPoint) pointAtX:(float)x y:(float)y
{
  static float dx = 54;
  static float dy = 27;
  float cx = dx*(rows-cols)/2.0;
  float cy = dy*(cols+rows-2)/2.0;
  return POINT((x-y)*dx+cx, (x+y)*dy-cy);
}

//------------------------------------------------------------------------------------------------------------------------

- (SPPoint*) spPointAtField:(Field)field
{
  return [self spPointAtX:field.x y:field.y];
}

//------------------------------------------------------------------------------------------------------------------------

- (SPPoint*) spPointAtX:(float)x y:(float)y
{
  static float dx = 54;
  static float dy = 27;
  float cx = dx*(rows-cols)/2.0;
  float cy = dy*(cols+rows-2)/2.0;
  return [SPPoint pointWithX:(x-y)*dx+cx y:(x+y)*dy-cy];
}

@end

