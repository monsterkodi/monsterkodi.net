//
//  CommandButton.m

#import "CommandButton.h"
#import "Menu.h"
#import "Memory.h"
#import "Game.h"
#import "Sound.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation CommandButton
//------------------------------------------------------------------------------------------------------------------------

+ (CommandButton*) withParent:(SPDisplayObjectContainer*)parent
{
  CommandButton * button = [[CommandButton alloc] init];
  [parent addChild:button];
  [button release];
  return button;
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) startDrag:(CGPoint)pos
{
  if (self.command)
  {
    dragging = YES;
    draggedCommand = [self.command copy];
    [self.parent addChild:draggedCommand];
    [draggedCommand startDrag:pos];
    
    [Sound play:SND_DRAG_START];
  }
  else 
  {
    dragging= NO;
  }

  return dragging;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) dragToPos:(CGPoint)pos
{  
  draggedCommand.pos = CGPointAdd(pos, [self globalFingerOffset]);
  [((Menu*)self.parent) buttonDragged:draggedCommand];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) stopDrag:(CGPoint)pos
{    
  //NSLog(@"%@ stopDrag %@", self, draggedCommand);
  
  dragging = NO;

  if (![((Menu*)self.parent) buttonDropped:draggedCommand])
  {
    [draggedCommand removeFromParent];
    draggedCommand = nil;
    [Sound play:SND_DRAG_TRASH];
  }
  else 
  {
    [memory programChanged];
  }
}

@end

//------------------------------------------------------------------------------------------------------------------------
