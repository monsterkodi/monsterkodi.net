//
//  Board.h

#import "Krap.h"
#import "Bridge.h"
#import "Floor.h"
#import "Level.h"

//------------------------------------------------------------------------------------------------------------------------
@interface Board : SPSprite 
//------------------------------------------------------------------------------------------------------------------------
{
  int       setupOffset;
  
@public
  
  double    defaultScale;
	int       rows, cols;
  id      * fields;
  Krap    * krap;
  
  NSMutableArray * tiles;
}

@property (readonly) Krap     * krap;
@property (readonly) int        setupOffset;
@property (readonly) double     defaultScale;
@property (readonly) NSArray  * tiles;
@property (readonly) int        numFields;

+ (Board*)    withParent:(SPDisplayObjectContainer*)parent;

- (void)      setupLevel:(Level*)level;
- (void)      setupItems;
- (void)      setupLogic;
- (void)      setupProgram;
- (void)      reset;

- (Krap*)     addKrap;
- (void)      delTileAtField:   (Field)field;
- (Floor*)    addFloorAtField:  (Field)field;
- (Bridge*)   addBridgeAtField: (Field)field direction:(Direction)direction;

- (Field)     neighborAtField:  (Field)field direction:(Direction)direction;
- (Field)     moveTargetAtField:(Field)field direction:(Direction)direction;
- (Direction) directionFromField:(Field)p1 toField:(Field)p2;
- (int)       numActionsAtField:(Field)field;

- (BOOL)      isValidField:     (Field)field;
- (BOOL)      allTilesOn;
- (BOOL)      allTilesConnected;

- (void)      switchAllTilesOff;

- (Field)     fieldAtIndex:     (int)index;
- (int)       indexAtField:     (Field)field;
- (int)       indexOfTile:      (Tile*)tile;
- (Floor*)    floorAtField:     (Field)field;
- (Tile*)     tileAtField:      (Field)field;
- (Tile*)     tileBetweenField:(Field)fa andField:(Field)fb;
- (NSArray*)  floors;

- (CGPoint)   pointAtField:   (Field)field;
- (CGPoint)   pointAtX:(float)x y:(float)y;

- (SPPoint*)  spPointAtField:   (Field)field;
- (SPPoint*)  spPointAtX:(float)x y:(float)y;

@end

//------------------------------------------------------------------------------------------------------------------------

extern Board * board;

//------------------------------------------------------------------------------------------------------------------------
