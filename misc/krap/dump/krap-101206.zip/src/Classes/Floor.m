//
//  Floor.m

#import "Floor.h"
#import "Theme.h"
#import "Board.h"
#import "Logic.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation FloorEvent
//------------------------------------------------------------------------------------------------------------------------
@synthesize floor;

- (id)initWithFloor:(Floor*)floor_ type:(NSString*)type
{
  if (self = [super initWithType:type bubbles:NO])
  {
    floor = floor_;
  }
  return self;
}
@end

//------------------------------------------------------------------------------------------------------------------------
@implementation Floor
//------------------------------------------------------------------------------------------------------------------------

+ (Floor*) withParent:(SPDisplayObjectContainer*)parent
{
  Floor * floor = [[Floor alloc] init];
  [parent addChild:floor];
  [floor release];
  return floor;
}

//------------------------------------------------------------------------------------------------------------------------

- (id)init 
{
  if (self = [super initWithFile:@"floor0000"]) 
  {
    [self addEventListener:@selector(onTouch:) atObject:self forType:SP_EVENT_TYPE_TOUCH];
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) dealloc
{
  [self removeEventListenersAtObject:self forType:SP_EVENT_TYPE_TOUCH];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setMode:(TileMode)tileMode
{
  if (tileMode == SWITCH) 
  {
    [self removeChildAtIndex:0];
    [self addImage:@"floor0003"];
  }

  [super setMode:tileMode];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) onTouch:(SPTouchEvent*)event 
{
  if (event.numTouches == 1)
  {
    SPTouch * touch = [event firstTouch];
    SPTouchPhase phase = touch.phase;

    if (phase == SPTouchPhaseEnded && touch.tapCount >= 1)
    {
      [self dispatchEvent:[[FloorEvent alloc] initWithFloor:self type:SP_EVENT_TYPE_FLOOR_CLICKED]];
    }
  }
  if (logic.mode == MENU)
    [event stopPropagation]; // disable double click zoom toggle
}

@end

