//
//  Memory.m

#import "Memory.h"
#import "Game.h"

Memory * memory;

//------------------------------------------------------------------------------------------------------------------------
@implementation MemoryEvent
//------------------------------------------------------------------------------------------------------------------------
@synthesize memory;

- (id)initWithMemory:(Memory*)memory_ type:(NSString*)type
{
  if (self = [super initWithType:type bubbles:NO])
  {
    self->memory = memory_;
  }
  return self;
}
@end

//------------------------------------------------------------------------------------------------------------------------
@implementation Memory
//------------------------------------------------------------------------------------------------------------------------

@synthesize cells;

//------------------------------------------------------------------------------------------------------------------------
 
- (id) init
{
  if ((self = [super init]))
  {
    cells  = [[NSMutableArray arrayWithCapacity:MCOL*MROW] retain];    
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------

- (id) initWithNumberOfCells:(int)num
{
  if ((self = [super init]))
  {
    cells  = [[NSMutableArray arrayWithCapacity:num] retain];    
    
    for (int x = 0; x < num; x++)
    {
      [self addCell:[[[Cell alloc] initWithMemory:self] autorelease]]; 
    }    
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) dealloc
{
  [cells release];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) clear
{
  for (Cell * cell in cells) cell.command = nil;
  [self programChanged];
}

//------------------------------------------------------------------------------------------------------------------------

- (NSString*) program
{  
  NSString * program = [NSString stringWithString:@""];
  Cell * cell = [self firstCell];
  while (cell)
  {
    program = [program stringByAppendingFormat:@"%c", cell.code];
    cell = [cell nextCell];
  }

  return program;  
}

//------------------------------------------------------------------------------------------------------------------------

- (NSString*) packedProgram
{
  NSString * prg = [self program];
  return [prg stringByReplacingOccurrencesOfString:@" " withString:@""];
}

//------------------------------------------------------------------------------------------------------------------------

- (int) programSize
{
  NSString * prg = [self program];
  prg = [prg stringByReplacingOccurrencesOfString:@" " withString:@""];
  int beforeDotsRemoved = [prg length];
  prg = [prg stringByReplacingOccurrencesOfString:@"." withString:@""];
  if ([prg length] < beforeDotsRemoved)
  {
    return (2*[prg length]-beforeDotsRemoved); // subtract number of dots for defs
  }
  return [prg length];  
}

//------------------------------------------------------------------------------------------------------------------------

- (void) loadProgram:(NSString*)program
{
  for (Cell * cell in cells) cell.command = nil;
  
  for (int i = 0; i < [program length]; i++)
  {
    Cell * cell = [self cellAtIndex:i];
    
    unichar code = [program characterAtIndex:i];
    if (code != ' ') cell.command = [Command withParent:cell cmd:[Command cmdForCode:code]];        
  } 
  [self programChanged];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) unhighlight
{
  for (Cell * cell in cells) [cell highlight:NO];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) programChanged
{
  [self dispatchEvent:[[MemoryEvent alloc] initWithMemory:self type:SP_EVENT_TYPE_MEMORY_PROGRAM_CHANGED]];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) colorize
{  
  for (Cell * cell in cells) // reset all cells
  {
    uint col = (cell.command ? cell.command.background.color : 0x222222);
    cell.background.color = col;
    cell.border.color = 0x222222;
    cell.border.alpha = 1;
    
    if (cell.command) cell.command.icon.color = 0xffffff; // CMD[cell.command.cmd].iconColor;
    
    [cell setBackgroundImage:@"button_background"];
  }
   
  NSMutableDictionary * cellDict = [self sortedTopLevelCells];

  int cols = (game->orientation == UP || game->orientation == DOWN) ? 10 : 5;
  
  for (Cmd cmd = FUNC_A; cmd <= FUNC_D; cmd++) // colorize functions
  {
    NSArray * funcCells = [cellDict objectForKey:CMD_STR(cmd)];
    if ([funcCells count])
    {
      Cell * defCell = [funcCells objectAtIndex:0];
      assert ([defCell isDef]);

      uint defCellCol = defCell.command.background.color;

      Cell * defEndCell = [defCell defEndCell];
      if (defEndCell) 
      {
        if (([self indexOfCell:defCell]%cols) == cols-1)
          [defCell setBackgroundImage:@"button_backgroundDefStartR"];
        else
          [defCell setBackgroundImage:@"button_backgroundDefStart"];
        
        defCell.command.icon.color = CMD[defCell.command.cmd].iconColor;
        defCell.border.color = defCellCol;
        defCell.border.alpha = 0;

        defEndCell.command.icon.color = CMD[defCell.command.cmd].iconColor;
        defEndCell.border.color = defCellCol;
        defEndCell.background.color = defCellCol;
        defEndCell.border.alpha = 0;
        
        if (([self indexOfCell:defEndCell]%cols) == 0)
          [defEndCell setBackgroundImage:@"button_backgroundDefEndL"];
        else
          [defEndCell setBackgroundImage:@"button_backgroundDefEnd"];

        for (Cell * cell in [defCell functionCells])
        {
          cell.border.alpha = 0;

          cell.border.color     = defCellCol; 
          cell.background.color = defCellCol;          
          
          int index = [self indexOfCell:cell];
          if ((index%cols) == 0) 
            [cell setBackgroundImage:@"button_backgroundDefL"];
          else if ((index%cols) == cols-1)
            [cell setBackgroundImage:@"button_backgroundDefR"];
          else
            [cell setBackgroundImage:@"button_backgroundDef"];
        }
      }
    }
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) checkForEmptyRecursionAtCell:(Cell*)firstCell checkedFunctions:(NSMutableSet*)checked
{
  Cell * defCellOfFirstCell = [firstCell defCell];
  Cell * firstCellOfDefCell = [defCellOfFirstCell firstFunctionCellWithCommand];
  if ([firstCellOfDefCell.command isFunc])
  {
    if ([checked containsObject:CMD_STR(firstCellOfDefCell.cmd)])
    {      
      firstCell.command.icon.color          = 0xff0000;
      firstCellOfDefCell.command.icon.color = 0xff0000;
      return YES;
    }
    
    if ([self checkForEmptyRecursionAtCell:firstCellOfDefCell checkedFunctions:checked])
    {
      firstCell.command.icon.color          = 0xff0000;
      return YES;
    }
  }
  
  return NO;
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) hasExecutableInFunctionCallAtCell:(Cell*)cell
{
  Cell * defCell = [cell defCell];
  Cell * firstFunctionCell = [defCell firstFunctionCellWithCommand];
  
  if (firstFunctionCell)
  {
    if ([firstFunctionCell.command isExec]) return YES;
    return [self hasExecutableInFunctionCallAtCell:firstFunctionCell];    
  }
  
  return NO;
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) hasValidProgram
{
  //NSLog(@"isValidProgram %@", [self sortedTopLevelCells]);
  
  NSMutableDictionary * sorted = [self sortedTopLevelCells];
  
  for (Cell * dotCell in [sorted objectForKey:CMD_STR(DOT)]) // check for stray dot cells
  {
    if (![self defCellForDotCell:dotCell])
    {
      //NSLog(@"SYNTAX ERROR: stray dot cell %@", dotCell);
      dotCell.command.icon.color = 0xff0000;
      return NO;
    }
  }
  
  for (Cmd cmd = FUNC_A; cmd <= FUNC_D; cmd++) // check for undefined functions
  {
    NSArray * funcCells = [sorted objectForKey:CMD_STR(cmd)];
    if ([funcCells count])
    {
      Cell * defCell = [funcCells objectAtIndex:0];
      if ([defCell isDef])
      {
        if (![defCell defEndCell])
        {
          //NSLog(@"SYNTAX ERROR: undefined function %@", defCell);
          defCell.command.icon.color = 0xff0000;
          return NO;          
        }
        
        NSArray * funcBody = [defCell functionCells];
        for (Cell * bodyCell in funcBody)
        {
          if (bodyCell.command && [bodyCell.command isFunc])
          {
            if (![bodyCell defCell]) 
            {
              //NSLog(@"SYNTAX ERROR: undefined function %@", bodyCell);
              bodyCell.command.icon.color = 0xff0000;
              return NO;
            }
          }
        }
      }
    }
  }
  
  for (Cmd cmd = FUNC_A; cmd <= FUNC_D; cmd++) // check for empty endless loops
  {
    NSArray * funcCells = [sorted objectForKey:CMD_STR(cmd)];
    if ([funcCells count])
    {
      Cell * defCell   = [funcCells objectAtIndex:0];
      NSArray * funcCells = [defCell functionCellsWithCommand];
      if ([funcCells count])
      {
        Cell * firstCell = [funcCells objectAtIndex:0];
        if (firstCell.cmd == cmd)
        {
          firstCell.command.icon.color = 0xff0000;
          //NSLog(@"SYNTAX ERROR: immediate empty recursion %@", firstCell);
          return NO;                  
        }
        else if ([firstCell.command isFunc])
        {
          NSMutableSet * checked = [NSMutableSet setWithObject:CMD_STR(cmd)];          
          [checked addObject:CMD_STR(firstCell.cmd)];
          
          if ([self checkForEmptyRecursionAtCell:firstCell checkedFunctions:checked])            
          {
            //NSLog(@"SYNTAX ERROR: indirect empty recursion %@", firstCell);
            return NO;                                        
          }
        }
      }
    }
  }
  
  // check for no command on top level
  
  BOOL topLevelFound = NO;
  topLevelFound |= [[sorted objectForKey:CMD_STR(GO)]         count] > 0;
  topLevelFound |= [[sorted objectForKey:CMD_STR(TURN_LEFT)]  count] > 0;
  topLevelFound |= [[sorted objectForKey:CMD_STR(TURN_RIGHT)] count] > 0;
  BOOL topLevelActionFound = topLevelFound;
  topLevelFound |= [[sorted objectForKey:CMD_STR(FUNC_A)]     count] > 1;
  topLevelFound |= [[sorted objectForKey:CMD_STR(FUNC_B)]     count] > 1;
  topLevelFound |= [[sorted objectForKey:CMD_STR(FUNC_C)]     count] > 1;
  topLevelFound |= [[sorted objectForKey:CMD_STR(FUNC_D)]     count] > 1;
  
  if (!topLevelFound) 
  {
    //NSLog(@"SYNTAX WARNING: no toplevel command");
    return NO;
  }
  
  if (!topLevelActionFound) // check for only empty function calls on toplevel
  {
    BOOL hasExecutable = NO;
    for (Cell * cell in [self topLevelCells])
    {
      if ([self hasExecutableInFunctionCallAtCell:cell])            
      {
        hasExecutable = YES;
        break;
      }      
    } 

    if (!hasExecutable)            
    {
      //NSLog(@"SYNTAX WARNING: only empty function calls");
      return NO;                                        
    }    
  }
  
  //NSLog(@"OK");
  return YES;
}

//------------------------------------------------------------------------------------------------------------------------

- (NSMutableDictionary*) sortedTopLevelCells
{
  NSMutableDictionary * cellDict = [NSMutableDictionary dictionaryWithCapacity:CMD_NUM];
  for (Cmd cmd = GO; cmd < CMD_NUM; cmd++)
    [cellDict setObject:[NSMutableArray arrayWithCapacity:5] forKey:CMD_STR(cmd)];
  
  Cell * cell = [self firstCellWithCommand];
  if (cell)
  {
    do 
    {
      [[cellDict objectForKey:CMD_STR(cell.cmd)] addObject:cell];
      
      if ([cell isDef])
      {
        cell = [cell defEndCell]; // jump to end of function
        if (cell) [[cellDict objectForKey:CMD_STR(cell.cmd)] addObject:cell]; // insert end marker  
      }
    } 
    while (cell = [cell nextCellWithCommand]);    
  }
  
  return cellDict;
}

//------------------------------------------------------------------------------------------------------------------------

- (NSArray*) topLevelCells
{
  NSMutableArray * tlcells = [NSMutableArray arrayWithCapacity:10];

  Cell * cell = [self firstCellWithCommand];
  if (cell)
  {
    do 
    {
      if ([cell isDef]) cell = [cell defEndCell]; // jump to end of function
      else              [tlcells addObject:cell]; // add cell to toplevel cells
    } 
    while (cell = [cell nextCellWithCommand]);    
  }
  
  return tlcells;
}

//------------------------------------------------------------------------------------------------------------------------

- (NSArray*) stackCells
{
  return [[cells reverseObjectEnumerator] allObjects];
}

//------------------------------------------------------------------------------------------------------------------------

- (int)   numCells                  { return [cells count];                }
- (int)   indexOfCell:(Cell*)cell   { return [cells indexOfObject:cell];   }
- (Cell*) addCell:(Cell*)cell       { [cells addObject:cell]; return cell; }
- (Cell*) cellAtIndex:(int)index    { return [cells objectAtIndex:index];  }
- (Cell*) firstCell                 { return [cells objectAtIndex:0];      }
- (Cell*) lastCell                  { return [cells lastObject];           }
- (Cell*) firstCellWithCommand      { Cell * cell = [self firstCell]; return (cell.command ? cell : [cell nextCellWithCommand]); }
- (Cell*) lastCellWithCommand       { Cell * cell = [self lastCell];  return (cell.command ? cell : [cell prevCellWithCommand]); }

//------------------------------------------------------------------------------------------------------------------------

- (Cell*) cellWithIdentifier:(int)identifier
{
  for (Cell * cell in cells)
    if (cell.identifier == identifier) return cell;
  return nil;
}

//------------------------------------------------------------------------------------------------------------------------

- (Cell*) defCellForDotCell:(Cell*)dotCell
{
  Cell * cell = [self firstCell];
  do 
  {    
    if ([cell isDef])
    {
      Cell * endCell = [cell defEndCell];
      if (endCell == dotCell) return cell;
      cell = endCell; // jump over function
    }
  } 
  while (cell = [cell nextCell]);
  return nil;
}

@end
