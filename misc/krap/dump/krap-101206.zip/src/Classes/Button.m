//
//  Button.m

#import "Button.h"
#import "Menu.h"
#import "Game.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation Button
//------------------------------------------------------------------------------------------------------------------------

@synthesize icon, border, background, image, dragable;

//------------------------------------------------------------------------------------------------------------------------

+ (Button*) withParent:(SPDisplayObjectContainer*)parent
{
  Button * button = [[Button alloc] init];
  [parent addChild:button];
  [button release];
  return button;
}

//------------------------------------------------------------------------------------------------------------------------

- (id)init 
{
  if ((self = [super initWithFile:@"button_background"]))
  {
    [self addEventListener:@selector(onTouch:) atObject:self forType:SP_EVENT_TYPE_TOUCH];  
    
    background = ((SPImage*)[self firstChild]);
    background.color = 0x222222; 
    background.alpha = 0.9f;
    
    border = [self addImage:@"button_border"];
    border.color = 0x222222;
    
    dragable = YES;
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) dealloc
{
  //NSLog(@"%@ dealloc", self);

  [self  removeEventListenersAtObject:self forType:SP_EVENT_TYPE_TOUCH];

  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setBorderImage:(NSString*)imageFile
{
  border.texture = [Media textureByName:imageFile];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setBackgroundImage:(NSString*)imageFile
{
  background.texture = [Media textureByName:imageFile];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setImage:(NSString*)imageFile
{
  if ([imageFile isEqualToString:image]) return;
  
  [self removeImage];
  
  if (imageFile)
  {
    image = [[NSString stringWithString:imageFile] retain];
    icon  = [self addImage:imageFile];
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (void) removeImage
{
  if (image) [image release];
  image = nil;
  if (icon) [self removeChild:icon];  
  icon = nil;
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) handleDraggedButton:(Button*)button { return NO; }
- (BOOL) handleDroppedButton:(Button*)button { return NO; }
- (void) clearDraggedButton                  { }
- (void) tapped:(int)tapCount                { }

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) startDrag:(CGPoint)pos
{
  NSLog(@"%@ Button::startDrag", self);
  
  dragging = YES;
  [self.parent bringChildToFront:self];
  self.pos = POINT(pos.x, pos.y-60);
  return dragging;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) dragToPos:(CGPoint)pos
{
  NSLog(@"%@ Button::dragToPos", self);

  self.pos = POINT(pos.x, pos.y-60);
  
  [((Menu*)self.parent) buttonDragged:self];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) stopDrag:(CGPoint)pos
{
  [((Menu*)self.parent) buttonDropped:self];
  
  dragging = NO;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) highlight:(BOOL)on { self.border.color = on ? 0xffffff : 0x222222; }
- (void) highlight          { [self highlight:YES]; }

//------------------------------------------------------------------------------------------------------------------------

- (CGPoint) globalFingerOffset
{
  return POS(0,-FINGEROFFSET);
}

//------------------------------------------------------------------------------------------------------------------------

- (void) onTouch:(SPTouchEvent*)event
{
  if (event.numTouches == 1)
  {
    SPTouch * touch = [event firstTouch];
    SPTouchPhase phase = touch.phase;

    if (phase == SPTouchPhaseBegan)
    {
      [self highlight];
    }
    else if (phase == SPTouchPhaseMoved)
    {
      CGPoint parentPos = [self globalToParentPos:POS(touch.globalX, touch.globalY)];

      if (dragable)
      {
        if (!dragging)  [self startDrag:parentPos];
        else            [self dragToPos:parentPos];        
      }
      else 
      {
				[self highlight:[self.bounds containsPos:parentPos]];
      }
    }      
    else if (phase == SPTouchPhaseEnded)
    {
      [self highlight:NO];
           
      CGPoint parentPos = [self globalToParentPos:POS(touch.globalX, touch.globalY)];
      
      if (touch.tapCount > 0 || [self.bounds containsPos:parentPos]) 
      {
        [self tapped:touch.tapCount]; 
      }

      if (dragging) [self stopDrag:parentPos];
    }
	}
  
  [event stopPropagation];
}

@end

