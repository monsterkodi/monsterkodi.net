//
//  Bridge.h

#import "Tile.h"

//------------------------------------------------------------------------------------------------------------------------
@interface Bridge : Tile 
//------------------------------------------------------------------------------------------------------------------------
{
	Direction direction;
}

+ (Bridge*) withParent:(SPDisplayObjectContainer*)parent direction:(Direction)direction;
- (id)      initWithDirection:(Direction)direction;

@end
