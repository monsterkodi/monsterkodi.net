//
//  PathFinder.m

#import "PathFinder.h"
#import "Board.h"

//------------------------------------------------------------------------------------------------------------------------
@interface ASNode : NSObject
//------------------------------------------------------------------------------------------------------------------------
{
  Field      field;
  ASNode * parent;
  int      costG;
  int      costH;
  int      costF;
}
@property (assign) Field      field;
@property (assign) ASNode * parent;
@property (assign) int      costG;
@property (assign) int      costH;
@property (assign) int      costF;

- (NSComparisonResult) compareCost:(ASNode*)node;

@end
//------------------------------------------------------------------------------------------------------------------------
@implementation ASNode
@synthesize field, parent, costG, costH, costF;

+ (ASNode*) withField:(Field)field
{
  ASNode * node = [[[ASNode alloc] init] autorelease];
  node.field = field;
  return node;
}

+ (ASNode*) withField:(Field)field parent:(ASNode*)parent_ costH:(int)costH
{
  ASNode * node = [ASNode withField:field];
  node.parent   = parent_;
  node.costH    = costH;
  node.costG    = parent_.costG + 10 + [board numActionsAtField:field] * 40;
  node.costF    = node.costH + node.costG; 
  return node;
}

- (NSString*) description
{
  return [NSString stringWithFormat:@"[%@ G:%d H:%d F:%d]", field, costG, costH, costF];
}

- (NSComparisonResult) compareCost:(ASNode*)n2 
{
  if (self.costF < n2.costF) return NSOrderedAscending;
  if (self.costF > n2.costF) return NSOrderedDescending;
  
  return NSOrderedSame;
};

@end

PathFinder * pathFinder;

//------------------------------------------------------------------------------------------------------------------------
@implementation PathFinder
//------------------------------------------------------------------------------------------------------------------------

+ (NSString*) pathFrom:(Field)start to:(Field)end direction:(Direction)dir 
{
  PathFinder * pf = [[PathFinder alloc] init];
  NSString * path = [pf pathFrom:start to:end direction:dir];
  [pf release];
  return path;
}

//------------------------------------------------------------------------------------------------------------------------

- (id) init
{
  if ((self = [super init]))
  {
    open   = [[NSMutableArray  arrayWithCapacity:10] retain];
    closed = [[NSMutableArray  arrayWithCapacity:10] retain];
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) dealloc
{
  [open   release];
  [closed release];
  [super  dealloc];
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) isOpen:(Field)field
{
  for (ASNode * node in open)
    if (node.field.x == field.x && node.field.y == field.y) return YES;
  return NO;
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) isClosed:(Field)field
{
  for (ASNode * node in closed)
    if (node.field.x == field.x && node.field.y == field.y) return YES;
  return NO;
}

//------------------------------------------------------------------------------------------------------------------------

- (NSString*) programForPathFrom:(Field)p1 to:(Field)p2 direction:(Direction)dir
{
  Direction td = [board directionFromField:p1 toField:p2];
  if (((dir+2)%4) == td) return [NSString stringWithFormat:@">>^"];
  if (((dir+1)%4) == td) return [NSString stringWithFormat:@">^"]; 
  if (((dir+3)%4) == td) return [NSString stringWithFormat:@"<^"]; 
  return [NSString stringWithFormat:@"^"];
}

//------------------------------------------------------------------------------------------------------------------------

- (NSString*) programForPathToNode:(ASNode*)node direction:(Direction)dir
{
  NSMutableArray * fields = [NSMutableArray arrayWithCapacity:10];
  do 
  {
    [fields insertObject:node.field atIndex:0];
    
  } while(node = node.parent);
  
  NSMutableString * prg = [NSMutableString stringWithCapacity:10];
  for (int i = 1; i < [fields count]; i++)
  {    
    Field p1 = [fields objectAtIndex:i-1];
    Field p2 = [fields objectAtIndex:i  ];
    
    [[board tileAtField:p2] switchOn];
    
    [prg appendString:[self programForPathFrom:p1 to:p2 direction:dir]];
    dir = [board directionFromField:p1 toField:p2];
  }
  return prg;
}

//------------------------------------------------------------------------------------------------------------------------

- (NSString*) pathFrom:(Field)start to:(Field)end direction:(Direction)startdir 
{
  NSString * path;
  
  [closed removeAllObjects];
  [open   removeAllObjects];
  [open   addObject:[ASNode withField:start]];
  
  while ([open count])
  {
    ASNode * node = [open objectAtIndex:0];
    for (Direction dir = NE; dir <= NW; dir++)
    {
      Field nf = [board moveTargetAtField:node.field direction:dir];
      if ([board isValidField:nf])
      {
        if ([nf eql:end])
        {            
          int costH = abs(node.field.x - end.x) * 10 + abs(node.field.y - end.y) * 10;

          [open addObject:[ASNode withField:end parent:node costH:costH]];
          
          path = [self programForPathToNode:[open lastObject] direction:startdir];
           
          [open removeAllObjects];

          break;
        }
          
        Floor * floor;
        if ((floor = [board floorAtField:nf]) && ![self isOpen:nf] && ![self isClosed:nf])
        {
          int costH = abs(node.field.x - end.x) * 10 + abs(node.field.y - end.y) * 10;

          [open addObject:[ASNode withField:nf parent:node costH:costH]];
        }
      }
    }
    
    if ([open count]) 
    {
      [closed addObject:node];
      [open   removeObjectAtIndex:0];
    }
    
//    NSComparator costComparator = ^(id node1, id node2) {
//            
//      ASNode * n1 = (ASNode*)node1;
//      ASNode * n2 = (ASNode*)node2;
//      if (n1.costF < n2.costF) return NSOrderedAscending;
//      if (n1.costF > n2.costF) return NSOrderedDescending;
//      
//      return NSOrderedSame;
//    };
    
    //[open sortUsingComparator:costComparator];
    
    [open sortUsingSelector:@selector(compareCost:)];
    
    //NSLog(@"open %@", open);
  }
  
  return path;
}

@end
