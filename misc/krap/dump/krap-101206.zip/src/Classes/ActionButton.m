//
//  ActionButton.m

#import "ActionButton.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation ActionButton
//------------------------------------------------------------------------------------------------------------------------

@synthesize target, selector, longPress;

//------------------------------------------------------------------------------------------------------------------------

+ (ActionButton*) withParent:(SPDisplayObjectContainer*)parent
{
  ActionButton * button = [[ActionButton alloc] init];
  [parent addChild:button];
  [button release];
  return button;
}

//------------------------------------------------------------------------------------------------------------------------

- (id) init 
{
  if (self = [super init]) 
  {
    dragable = NO;
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) tapped:(int)tapCount
{
  if (target) 
  {
    if (tapCount == 0 && longPress) [target performSelector:longPress];
    else [target performSelector:selector];
  }
}

@end

