//
//  Floor.h

#import "Tile.h"

#define SP_EVENT_TYPE_FLOOR_CLICKED @"floor_clicked"

@class Floor;

//------------------------------------------------------------------------------------------------------------------------
@interface FloorEvent : SPEvent
//------------------------------------------------------------------------------------------------------------------------
{
  Floor * floor;
}
@property (nonatomic, readonly) Floor * floor;
- (id)initWithFloor:(Floor*)floor type:(NSString*)type;
@end

//------------------------------------------------------------------------------------------------------------------------
@interface Floor : Tile 
//------------------------------------------------------------------------------------------------------------------------
{
	
}

+ (Floor*) withParent:(SPDisplayObjectContainer*)parent;

@end
