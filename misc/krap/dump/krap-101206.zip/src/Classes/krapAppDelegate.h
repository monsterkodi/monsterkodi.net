//
//  krapAppDelegate.h

#import <UIKit/UIKit.h>
#import "Sparrow.h" 
#import "Game.h" 

//------------------------------------------------------------------------------------------------------------------------
@interface krapAppDelegate : NSObject <UIApplicationDelegate> 
//------------------------------------------------------------------------------------------------------------------------
{
    UIWindow * window;
    SPView   * sparrowView;
    Game     * game;
}

@property (nonatomic, retain) IBOutlet UIWindow * window;
@property (nonatomic, retain) IBOutlet SPView   * sparrowView;

@end
