//
//  Bot.m

#import "Bot.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation BotMoveEvent
//------------------------------------------------------------------------------------------------------------------------

@synthesize sourceField, targetField;

//------------------------------------------------------------------------------------------------------------------------

- (id)initWithSourceField:(Field)source targetField:(Field)target type:(NSString*)type
{
  if (self = [super initWithType:type bubbles:NO])
  {
    sourceField = source;
    targetField = target;
  }
  return self;
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation Bot
//------------------------------------------------------------------------------------------------------------------------

@synthesize movie;

- (id)init 
{
  if (self = [super init]) 
  {        
    [self addEventListener:@selector(onEnterFrame:) atObject:self forType:SP_EVENT_TYPE_ENTER_FRAME];
    //[self addEventListener:@selector(onTouch:)      atObject:self forType:SP_EVENT_TYPE_TOUCH];

    [self setupMovie];  
    self.touchable = NO;
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setupMovie {}
- (void) onTouch:(SPTouchEvent*)event {}
- (void) onEnterFrame:(SPEnterFrameEvent*)event {}

//------------------------------------------------------------------------------------------------------------------------

- (void)dealloc 
{
  [self removeEventListenersAtObject:self forType:SP_EVENT_TYPE_ENTER_FRAME];
  //[self removeEventListenersAtObject:self forType:SP_EVENT_TYPE_TOUCH];
  [super dealloc];
}

@end

