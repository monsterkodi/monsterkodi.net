//
//  Krap.m

#import "Krap.h"
#import "Game.h"
#import "Sound.h"

double ROTATE_TIMES[3] = { 1.0, 0.5, 0.25 };
double MOVE_TIMES[3]   = { 2.0, 1.0, 0.5  };

//------------------------------------------------------------------------------------------------------------------------
@implementation KrapEvent
//------------------------------------------------------------------------------------------------------------------------

@synthesize krap;

//------------------------------------------------------------------------------------------------------------------------

- (id)initWithKrap:(Krap*)krap_ type:(NSString*)type
{
  if (self = [super initWithType:type bubbles:NO])
  {
    krap = krap_;
  }
  return self;
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation Krap
//------------------------------------------------------------------------------------------------------------------------

@synthesize angle, direction, field, speed;

+ (Krap*) withParent:(SPDisplayObjectContainer*)parent
{
  Krap * krap = [[Krap alloc] init];
  [parent addChild:krap];
  [krap release];
  return krap;
}

//------------------------------------------------------------------------------------------------------------------------

- (id) init 
{
    if (self = [super init]) 
    {
      moviedir = 1;
    }
    return self;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) resetJump
{
  movie.y = -movie.height+movie.height*0.1;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setAngle:(float)a
{
  while (a <    0) a += 360;
  while (a >= 360) a -= 360;
  angle = a;
  
  float movieAngle = angle - 225;
  while (movieAngle < 0) movieAngle += 360;
  
  movie.currentFrame = (int)((movie.numFrames-1) * movieAngle/360.0);
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setDirection:(Direction)direction_  
{
  direction = direction_;  
  static float angles [4] = { 0, -90, 180, 90 };
  self.angle = angles[direction];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setField:(Field)field_
{
  [field release];
  field = [field_ cpy];
  self.pos = [board pointAtField:field];
  [self resetJump];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) stop
{
  //NSLog(@"krap stop");
  if (execTween)
  {
    [execTween removeEventListenersAtObject:self forType:SP_EVENT_TYPE_TWEEN_COMPLETED];
    [game.juggler removeTweensWithTarget:self];
    execTween = nil;
    [self setField:field];
    [self setDirection:direction];
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (void) pause
{
  NSLog(@"krap pause");
  if (execTween)
  {
    //[execTween removeEventListenersAtObject:self forType:SP_EVENT_TYPE_TWEEN_COMPLETED]; // removed because level end detection depends on it
    execTween = nil;
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) rotateLeft
{
  [self stop];
  return [self rotate:90];
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) rotateRight
{
  [self stop];
  return [self rotate:-90];
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) rotate:(float)degrees
{
  float a = angle + degrees;
  direction = [self directionForAngle:a];
  
  double rotateTime = ROTATE_TIMES[speed] / SPEEDFACTOR;
  
  assert(execTween == nil);
  
  SPTween * tween = [SPTween tweenWithTarget:self time:rotateTime];
  [tween animateProperty:@"angle" targetValue:a];
  [game.juggler addObject:tween];    
  
  execTween = tween;
  [execTween addEventListener:@selector(rotateTweenFinished:) atObject:self forType:SP_EVENT_TYPE_TWEEN_COMPLETED];
  
  if      (degrees ==  90) [Sound play:SND_ROTL];
  else if (degrees == -90) [Sound play:SND_ROTR];
  
  return YES;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) jumpWithHeight:(double)height time:(double)time
{
  [Sound play:SND_JUMP];
  
  SPTween * jump = [SPTween tweenWithTarget:movie time:time/2 transition:SP_TRANSITION_EASE_OUT];
  [jump animateProperty:@"y" targetValue:movie.y-height];
  [game.juggler addObject:jump];  
  
  SPTween * land = [SPTween tweenWithTarget:movie time:time/2 transition:SP_TRANSITION_EASE_OUT_BOUNCE];
  [land animateProperty:@"y" targetValue:movie.y];
  land.delay = time/2;
  [game.juggler addObject:land];
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) fakeForward
{
  Field ff = [board moveTargetAtField:field direction:direction];
  id tile = [board tileAtField:ff];
  
  if (tile && [tile isKindOfClass:[Floor class]])
  { 
    [self dispatchEvent:[[BotMoveEvent alloc] initWithSourceField:field targetField:ff type:SP_EVENT_TYPE_BOT_WILL_MOVE]];
    self.field = ff; // set field *with* moving
    [self dispatchEvent:[[KrapEvent alloc] initWithKrap:self type:SP_EVENT_TYPE_KRAP_DID_MOVE]];
    return YES;
  }
  
  return NO;  
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) fakeRotate:(float)degrees
{
  self.direction = [self directionForAngle:angle + degrees]; // set angle and direction
  return YES;
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) moveForward
{
  Field ff = [board moveTargetAtField:field direction:direction];
  
  double moveTime = MOVE_TIMES[speed] / SPEEDFACTOR;
  
  id tile = [board tileAtField:ff];
  
  assert(execTween == nil);
  [game.juggler removeTweensWithTarget:self];

  if (tile && [tile isKindOfClass:[Floor class]])
  { 
    BOOL jump = NO;
    Field nf = [board neighborAtField:field direction:direction];
    if (![board tileAtField:nf])
    {
      jump = YES;
      
      [self resetJump];
      
      [self jumpWithHeight:40 time:moveTime];
    }
    else 
    {
      [Sound play:SND_MOVE];
    }
    
    SPTween * tween = [SPTween tweenWithTarget:self time:moveTime transition:jump ? SP_TRANSITION_EASE_OUT : SP_TRANSITION_EASE_IN_OUT];
    SPPoint * tpos  = [board spPointAtField:ff];
    [tween animateProperty:@"x" targetValue:tpos.x];
    [tween animateProperty:@"y" targetValue:tpos.y];
    [game.juggler addObject:tween];
    
    [self dispatchEvent:[[BotMoveEvent alloc] initWithSourceField:field targetField:ff type:SP_EVENT_TYPE_BOT_WILL_MOVE]];

    [field release]; // set field without moving
    field = [ff retain];

    execTween = tween;
    [execTween addEventListener:@selector(moveTweenFinished:) atObject:self forType:SP_EVENT_TYPE_TWEEN_COMPLETED];
    
    return YES;
  }
//  else 
//  {
//    [self dump:[NSString stringWithFormat:@"invalid! %@", field]];
//  }

  return NO;
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) moveBackward
{
  Field ff = [board moveTargetAtField:field direction:BACKWARD(direction)];
  
  double moveTime = MOVE_TIMES[speed] / SPEEDFACTOR;
  
  assert(execTween == nil);
  [game.juggler removeTweensWithTarget:self];
  
  id tile = [board tileAtField:ff];
  if (tile && [tile isKindOfClass:[Floor class]])
  { 
    BOOL jump = NO;
    Field nf = [board neighborAtField:field direction:BACKWARD(direction)];
    if (![board tileAtField:nf])
    {
      jump = YES;
      
      [self resetJump];

      [self jumpWithHeight:40 time:moveTime];      
    }
    else 
    {
      [Sound play:SND_MOVE];
    }
    
    SPTween * tween = [SPTween tweenWithTarget:self time:moveTime transition:jump ? SP_TRANSITION_EASE_OUT : SP_TRANSITION_EASE_IN_OUT];
    SPPoint * tpos  = [board spPointAtField:ff];
    [tween animateProperty:@"x" targetValue:tpos.x];
    [tween animateProperty:@"y" targetValue:tpos.y];
    [game.juggler addObject:tween];
    
    [field release]; // set field without moving
    field = [ff retain];
        
    execTween = tween;
    [execTween addEventListener:@selector(moveTweenFinished:) atObject:self forType:SP_EVENT_TYPE_TWEEN_COMPLETED];

    return YES;
  }
  
  return NO;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) moveTweenFinished:(SPEvent*)event
{
  //if (DBG_COMPI) 
  execTween = nil;
  if (DBG_COMPI) NSLog(@"%@ moveTweenFinished", compi);
  
  [self dispatchEvent:[[KrapEvent alloc] initWithKrap:self type:SP_EVENT_TYPE_KRAP_DID_MOVE]];
  
  if (DBG_COMPI) NSLog(@"%@ move dispatched", compi);
  
  [self dispatchEvent:[[KrapEvent alloc] initWithKrap:self type:SP_EVENT_TYPE_KRAP_DID_EXECUTE]];

  if (DBG_COMPI) NSLog(@"%@ execute dispatched", compi);
}

//------------------------------------------------------------------------------------------------------------------------

- (void) rotateTweenFinished:(SPEvent*)event
{
  //if (DBG_COMPI) 
  execTween = nil;
  if (DBG_COMPI) NSLog(@"%@ rotateTweenFinished", compi);
  
  [self dispatchEvent:[[KrapEvent alloc] initWithKrap:self type:SP_EVENT_TYPE_KRAP_DID_ROTATE]];
  
  if (DBG_COMPI) NSLog(@"%@ rotate dispatched", compi);

  [self dispatchEvent:[[KrapEvent alloc] initWithKrap:self type:SP_EVENT_TYPE_KRAP_DID_EXECUTE]];

  if (DBG_COMPI) NSLog(@"%@ execute dispatched", compi);
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) executeCommand:(Command*)command
{
  if (DBG_COMPI) NSLog(@"execute command %@", command);
	switch (command.cmd) 
  {
    case TURN_LEFT:  return [self rotate: 90];
    case TURN_RIGHT: return [self rotate:-90];
    case GO:         return [self moveForward];
    case NOP:
    default:         return NO;
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) fakeCommand:(Command*)command
{
  if (DBG_COMPI) NSLog(@"fake command %@", command);
	switch (command.cmd) 
  {
    case TURN_LEFT:  return [self fakeRotate: 90];
    case TURN_RIGHT: return [self fakeRotate:-90];
    case GO:         return [self fakeForward];
    case NOP:
    default:         return NO;
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) reverseCommand:(Command*)command
{
	switch (command.cmd) 
  {
    case TURN_LEFT:  return [self rotate:-90];
    case TURN_RIGHT: return [self rotate: 90];
    case GO:         return [self moveBackward];
    case NOP:
    default:         return NO;
  }  
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setupMovie
{   
  movie = [[SPMovieClip alloc] initWithFrame:[Media textureByName:@"krap0000"] fps:60];

  for (int i = 1; i < 108; i++)
  {
    [movie addFrame:[Media textureByName:[NSString stringWithFormat:@"krap0%03d", i]]];
  }
  
  float size   = 1.0f;
  movie.scaleX = size;
  movie.scaleY = size;
  movie.x      = -movie.width/2;
  movie.y      = -movie.height+movie.height*0.1;
  movie.loop   = YES;
  
  [self addChild:movie];  
  
  SPImage * shadow = [SPImage imageWithTexture:[Media textureByName:@"shadow_dark"]];
  shadow.pos = POINT(-shadow.width/2, -0.63*shadow.height);
  [self addChild:shadow];
  
  [self lowerChild:shadow];
}

//------------------------------------------------------------------------------------------------------------------------

- (NSString*) description
{
  static NSString * dir[4] = { @"NE", @"SE", @"SW", @"NW" };
  return [NSString stringWithFormat:@"[%@ %3d° %@]", field, (int)angle, dir[direction]];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) dump:(NSString*)title
{
  NSLog(@"           %@: %@", title, self);
}

//------------------------------------------------------------------------------------------------------------------------

- (Direction) directionForAngle:(float)a
{
  while (a <    0) a += 360;
  while (a >= 360) a -= 360;
  
       if (a > 45  && a <= 135) return NW;
  else if (a > 135 && a <= 225) return SW;
  else if (a > 225 && a <= 315) return SE;  
                                return NE;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) onEnterFrame:(SPEnterFrameEvent*)event
{ 
}
      
//------------------------------------------------------------------------------------------------------------------------

- (void) dealloc 
{
  //NSLog(@"Krap dealloc %@", self);
  [super dealloc];
}

@end

