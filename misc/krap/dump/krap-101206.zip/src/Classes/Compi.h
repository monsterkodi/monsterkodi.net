//
//  Compi.h

#import "Stack.h"

@class Cell;

typedef enum State_ { READY, PLAY, PAUSE, STEP_PREV, STEP_NEXT, END, STATE_NUM } State;
typedef enum Speed_ { SLOW,  NORM, FAST,                             SPEED_NUM } Speed;

#define SP_EVENT_TYPE_COMPI_STATE_CHANGED @"compi_state_changed"

@class Compi;
//------------------------------------------------------------------------------------------------------------------------
@interface CompiEvent : SPEvent
//------------------------------------------------------------------------------------------------------------------------
{
  Compi * compi;
}
@property (nonatomic, readonly) Compi * compi;
- (id)initWithCompi:(Compi*)compi type:(NSString*)type;
@end

//------------------------------------------------------------------------------------------------------------------------
@interface Compi : SPEventDispatcher
//------------------------------------------------------------------------------------------------------------------------
{
  Speed         speed;
  BOOL          skips;
  State         state;
  Stack       * stack;
  Memory      * programMemory;
  NSString    * prevStack;
}

@property (nonatomic) State state;
@property (nonatomic) Speed speed;
@property (readonly)  Stack * stack;

- (void)        start;
- (void)        play;
- (void)        togglePause;
- (void)        stop;
- (void)        next;
- (void)        prev;

- (void)        jump_next;
- (void)        jump_prev;
- (void)        jump_end;

- (void)        executeProgram:(NSString*)program;
- (void)        executeProgramInMemory:(Memory*)mem;

- (void)        stateChanged;

@end

//------------------------------------------------------------------------------------------------------------------------

extern Compi * compi;

//------------------------------------------------------------------------------------------------------------------------
