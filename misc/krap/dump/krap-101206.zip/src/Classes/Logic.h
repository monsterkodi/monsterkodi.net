//
//  Logic.h

typedef enum GameMode_ // remember to change MODENAMES in .m also!
{  
  MENU,
  FLANEUR, 
  VISITOR, 
  TOGGLER, 
  CHECKER, 
  SWITCHER,
  MODENUM,

} GameMode;

//------------------------------------------------------------------------------------------------------------------------
@interface Logic : NSObject 
//------------------------------------------------------------------------------------------------------------------------
{
  GameMode mode;
  SPSprite * oldWorld;
}

@property (assign) GameMode mode;

//------------------------------------------------------------------------------------------------------------------------

- (id)        init;

- (void)      setupWithLines:(NSArray*)setupLines;
- (void)      setModeByName:(NSString*)modeName;
- (NSString*) modeName;

@end

//------------------------------------------------------------------------------------------------------------------------

extern Logic * logic;

//------------------------------------------------------------------------------------------------------------------------
