//
//  Sound.m

#import "Sound.h"

NSMutableDictionary * channels;
NSMutableDictionary * sounds;

//------------------------------------------------------------------------------------------------------------------------
@implementation Sound
//------------------------------------------------------------------------------------------------------------------------

+ (void) initialize
{
  if (!channels)
  {
    channels = [[NSMutableDictionary dictionaryWithCapacity:30] retain];
    sounds   = [[NSMutableDictionary dictionaryWithCapacity:30] retain];
  }
}

//------------------------------------------------------------------------------------------------------------------------

+ (void) shutdown
{
  [channels release];
  [sounds   release];
}

//------------------------------------------------------------------------------------------------------------------------

+ (void) add:(int)soundID file:(NSString*)file
{
  assert([channels objectForKey:[NSNumber numberWithInt:soundID]] == nil);
  
  SPSound * sound = [SPSound soundWithContentsOfFile:file];
  SPSoundChannel * channel = [sound createChannel];
  NSMutableArray * soundChannels = [NSMutableArray arrayWithCapacity:1];
  [soundChannels push:channel];
  [channels setObject:soundChannels forKey:[NSNumber numberWithInt:soundID]];
  
  [sounds setObject:sound forKey:[NSNumber numberWithInt:soundID]];
}

//------------------------------------------------------------------------------------------------------------------------

+ (void) play:(int)soundID
{
  NSNumber * soundKey = [NSNumber numberWithInt:soundID];
  NSMutableArray * soundChannels = [channels objectForKey:soundKey];
  for (SPSoundChannel * channel in soundChannels)
  {
    if (!channel.isPlaying) 
    {
      [channel play]; 
      return;
    }
  }
   
  if ([soundChannels count] < 10)
  {
    //NSLog(@"adding channel for sound %d", soundID);
    SPSound * sound = [sounds objectForKey:soundKey];
    SPSoundChannel * channel = [sound createChannel];
    [soundChannels addObject:channel];
    [channel play];
    return;
  }
  else 
  {
    NSLog(@"skipping sound %d", soundID);
  }
}

//------------------------------------------------------------------------------------------------------------------------

+ (void) setVolume:(float)volume
{
  [SPAudioEngine setMasterVolume:volume];
}

//------------------------------------------------------------------------------------------------------------------------

+ (float) volume
{
  return [SPAudioEngine masterVolume];
}

@end
