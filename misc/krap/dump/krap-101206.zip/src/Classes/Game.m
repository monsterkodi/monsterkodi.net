//
//  Game.m

#import "Game.h"
#import "Config.h"
#import "Floor.h"
#import "Bridge.h"
#import "Tools.h"
#import "Media.h"
#import "Sound.h"
#import "MenuLogic.h"
#import "SPExtensions.h"

Game  * game;

//------------------------------------------------------------------------------------------------------------------------
@implementation Game
//------------------------------------------------------------------------------------------------------------------------

@synthesize orientation;

//------------------------------------------------------------------------------------------------------------------------

- (id)initWithWidth:(float)width height:(float)height 
{
  if (self = [super initWithWidth:width height:height]) 
  {
    game        = self;
    orientation = UP;
    
    self.backgroundColor = 0x000000;
    
    [Media initTextureAtlas:@"krap.xml"];
  
    [self addEventListener:@selector(onOrientation:) atObject:self forType:SP_EVENT_TYPE_ORIENTATION];
    [self addEventListener:@selector(onEnterFrame:)  atObject:self forType:SP_EVENT_TYPE_ENTER_FRAME];
    [self addEventListener:@selector(onTouch:)       atObject:self forType:SP_EVENT_TYPE_TOUCH];

    float cx = width/2, cy = height/2;
    
    root      = [SPSprite withParent:self x:cx y:cy]; // root
    pivot     = [SPSprite withParent:root          ]; //     pivot
    world     = [World    withParent:pivot         ]; //          world
    board     = [Board    withParent:world         ]; //               board
    items     = [SPSprite withParent:world         ]; //               items
    menupivot = [SPSprite withParent:root          ]; //     menupivot
    menu      = [GameMenu withParent:menupivot     ]; //          menu

    config = [[Config alloc] init];
    theme  = [[Theme  alloc] init];
    logic  = [[Logic  alloc] init];
    compi  = [[Compi  alloc] init];
    memory = [[Memory alloc] init];
    
    [self initSound];
    
    [menu  setup];
    
    if ([config hasValueForKey:@"level_last"])
    {
      NSLog(@"level_last found %@", [config getString:@"level_last"]);
      [Level load:[config getString:@"level_last"]];
    }
    else
    {
      [Level load:@"menu_main"];
    }
    
    world.scale = board.defaultScale;
    
    if (logic.mode == MENU)
    {
      menu.visible = NO;
    }
    else 
    {
      menu.visible = YES;
    }
  }

  return self;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) initSound
{
  [Sound initialize];
  [Sound add:SND_STOP           file:@"click_1.caf"];
  [Sound add:SND_CLICK          file:@"click_3.caf"];
  [Sound add:SND_JMPE           file:@"click_4.caf"];
  [Sound add:SND_NEXT           file:@"click_5.caf"];
  [Sound add:SND_DRAG_START     file:@"click_6.caf"];
  [Sound add:SND_DRAG_TRASH     file:@"click_7.caf"];
  [Sound add:SND_DRAG_DROP      file:@"click_8.caf"];
  [Sound add:SND_JMPN           file:@"click_9.caf"];
  [Sound add:SND_JMPP           file:@"click_10.caf"];
  [Sound add:SND_PREV           file:@"click_12.caf"];
  [Sound add:SND_MENU           file:@"menu01.caf"];
  [Sound add:SND_MAIN           file:@"menu02.caf"];
  [Sound add:SND_INFO           file:@"slide_1.caf"];
  [Sound add:SND_INFO_OUT       file:@"slide_1.caf"];
  [Sound add:SND_JUMP           file:@"jump02.caf"];
  [Sound add:SND_MOVE           file:@"jump01.caf"];
  [Sound add:SND_MOVE_BACKWARD  file:@"jump02.caf"];
  [Sound add:SND_ROTL           file:@"move.caf"];
  [Sound add:SND_ROTR           file:@"move.caf"];
  [Sound add:SND_SOLVED         file:@"main_menu_5.caf"];
  [Sound add:SND_TRASH          file:@"trash.caf"];  
  
  [Sound setVolume:[config getFloat:@"sound_volume" default:0.5f]];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setBackgroundColor:(uint)color
{
  bg = [SPQuad quadWithWidth:self.width height:self.height];
  bg.color = color;
  [self addChild:bg];  
}

//------------------------------------------------------------------------------------------------------------------------

- (uint) backgroundColor
{
  return bg.color;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) dealloc
{
  NSLog(@"Game dealloc");
  
  if (logic.mode != MENU) [self saveProgram];
  
  [self removeEventListenersAtObject:self forType:SP_EVENT_TYPE_ORIENTATION];
  [self removeEventListenersAtObject:self forType:SP_EVENT_TYPE_TOUCH];
  
  [compi  release]; compi  = nil;
  [memory release]; memory = nil;
  [logic  release]; logic  = nil;
  [theme  release]; theme  = nil;
  [config release]; config = nil;

  [self  removeAllChildren];
  [Media deallocTextureAtlas];

  [Sound shutdown];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) saveProgram
{
  NSString * prgKey = [currentLevel.name stringByAppendingString:@"_prog"];
  [config setString:[memory program] forKey:prgKey];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) exitLevel
{
  [self saveProgram];
  [menu fadeOut];
  [logic performMenuAction:@"menu_play"];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) onEnterFrame:(SPEnterFrameEvent*)event
{ 
}

//------------------------------------------------------------------------------------------------------------------------

- (void) onOrientation:(OrientationEvent *)event
{
  orientation = event.orientation;
  
  float pcy = MENU_SIZE/2;
  
  if (logic.mode == MENU) pcy = 0; // move pivot to center in MENU mode
  
  switch (orientation)
  { 
    case LEFT:  pivot.rotation =  PI_HALF; pivot.y = -pcy; menupivot.rotation =  PI_HALF; [menu layoutLandscape]; break;
    case RIGHT: pivot.rotation = -PI_HALF; pivot.y = +pcy; menupivot.rotation = -PI_HALF; [menu layoutLandscape]; break;
    case UP:    pivot.rotation =  0;       pivot.y = -pcy; menupivot.rotation =  0;       [menu layoutPortrait];  break;
    case DOWN:  pivot.rotation =  PI;      pivot.y = +pcy; menupivot.rotation =  PI;      [menu layoutPortrait];  break;
    default: break;
  }
  
  [memory colorize];
  [menu updateCompiState];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) onTouch:(SPTouchEvent *)event
{
  if (logic.mode == MENU && ![currentLevel.name isEqualToString:@"menu_play"]) return;

  SPTouch * touch = event.firstTouch;
  int  numTouches = event.numTouches;
  if (numTouches == 1)
  {
    if (touch.phase == SPTouchPhaseMoved) // single finger drag: move the world
    {
      [world moveBy:[touch getDeltaFor:world]];
    }
    else if (touch.phase == SPTouchPhaseEnded) // double tap: reset scale and world pos
    {
      if (touch.tapCount == 2)
      {
        [world toggleFollows];
      }
    }
  }
  if (numTouches == 2) // pinch: scale
  {
    if (touch.phase == SPTouchPhaseMoved)
    {
      [world scaleBy:event.pinchDelta];
    }
  }
}

@end
