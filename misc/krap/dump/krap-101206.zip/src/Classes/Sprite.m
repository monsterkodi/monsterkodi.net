//
//  Sprite.m

#import "Sprite.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation Sprite
//------------------------------------------------------------------------------------------------------------------------

@synthesize identifier;
@synthesize color;

//------------------------------------------------------------------------------------------------------------------------

+ (Sprite*) withParent:(SPDisplayObjectContainer*)parent image:(NSString*)imageFile
{
  Sprite * sprite = [[Sprite alloc] initWithFile:imageFile];
  [parent addChild:sprite];
  [sprite release];
  return sprite;
}

//------------------------------------------------------------------------------------------------------------------------

- (id) initWithFile:(NSString*)imageFile
{
  if ((self = [super init]))
  {
    static int sprite_id = 0;
    identifier = sprite_id++;

    [self addImage:imageFile];
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------

- (SPImage*) addImage:(NSString*)imageFile
{
  SPTexture * texture = [Media textureByName:imageFile];
  if (texture)
  {
    SPImage * image = [SPImage imageWithTexture:texture];
    image.x = -image.width/2;
    image.y = -image.height/2;
    
    [self addChild:image];
    
    return image;    
  }
  return nil;
}

//------------------------------------------------------------------------------------------------------------------------

- (uint) color
{
  SPImage * image = (SPImage*)[self firstChild];
  if (image) return image.color;
  return 0x0;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setColor:(uint)c
{
  SPImage * image = (SPImage*)[self firstChild];
  if (image) image.color = c;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) dealloc 
{
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) onTouch:(SPTouchEvent*)event {}
- (NSString*) imageFile { return @""; }

//------------------------------------------------------------------------------------------------------------------------

- (NSString*) description
{
  return [NSString stringWithFormat:@"[%@ %d]", NSStringFromClass([self class]), identifier];
}

@end

