//
//  Quad.h

#import <OpenGLES/EAGL.h>
#import <OpenGLES/ES1/gl.h>
#import <OpenGLES/ES1/glext.h>

typedef struct quad_data {
  GLfloat x, y;
  GLuint  c;
} quad;

//------------------------------------------------------------------------------------------------------------------------
@interface Quad : NSObject
//------------------------------------------------------------------------------------------------------------------------
{  
  quad   * verts; // vertex data buffer
  uint     alloc; // number of allocated vertices
  uint     count; // number of used vertices
  uint     vsize; // size of vertex data in bytes 
  BOOL     additive; 
  NSString * key;
}

@property (assign)   NSString * key;
@property (assign)   BOOL additive;

+ (void)  initQuads;
+ (void)  flushQuads;
+ (Quad*) instance;

+ (void) withRect:(CGRect)rect color:(uint)color;
+ (void) atPoint:(CGPoint)point size:(CGSize)size color:(uint)color;

+ (Quad*) key:(NSString*)key;

- (id)   init;
- (void) initBuffer;
- (BOOL) growBuffer:(uint)num;
- (void) dealloc;

- (void) drawAtPoint:(CGPoint)point size:(CGSize)size color:(uint)color;
- (void) drawWithPoints:(CGPoint*)points color:(uint)color;
- (void) addVertex:(quad)vert;

- (void) flush;

@end
