//
//  Help.m
//  kraut

#import "Help.h"
#import "Tools.h"
#import "Controller.h"
#import "ExtraButton.h"
#import "HelpScript.h"
#import "Screen.h"
#import "Level.h"
#import "Extras.h"
#import "Timer.h"
#import "Sound.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation Help
//------------------------------------------------------------------------------------------------------------------------

@synthesize handStatus;
@synthesize firstRun;

//------------------------------------------------------------------------------------------------------------------------
+ (Help*) instance
{
  return [Controller instance].help;
}

//------------------------------------------------------------------------------------------------------------------------
- (id) init
{
  float bs = RAMP_SIZE;
  float rw = 8.0f/7.0f;
  float rh = 4.0f/7.0f;
  
  board     = [[MainBoard alloc] initWithRect:CGRectMake(-1.0f, -1.5f,    2.0f, 2.0f) size:7 name:@"main"];
  ramp      = [[Ramp      alloc] initWithRect:CGRectMake(-1,     1.5f-rh, rw,   rh)   size:6 name:@"ramp"];
  jump      = [[Jump      alloc] initWithRect:CGRectMake( 1-bs,  1.5f-bs, bs,   bs)   size:3 name:@"jump"];    
  score     = [[Score     alloc] init];
  clock     = [[Clock     alloc] init];
  menu      = [[GameMenu  alloc] init];
  extras    = [[Extras    alloc] init];
  
  [[Controller instance] addEventReceiver:self type:@"help"];
  
  board.game = self;
  ramp.game  = self;
  jump.game  = self;

  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [[Controller instance] removeEventReceiver:self type:@"help"];
  
  if (helpDict) CFRelease(helpDict);
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setup
{
  //[Controller instance].currentGame = self;
  [menu setupWithGame:self];
  menu.mainScreen.fadeInTime  = GAME_FADE_IN_TIME;
  menu.mainScreen.fadeOutTime = GAME_FADE_OUT_TIME;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setupHelp
{
  levelInfo = [[LevelInfo alloc] initWithDictionary:[topicDict valueForKey:@"info"]];
  
  [[Controller instance] addEventReceiver:self type:@"up"];
  
  buttons[BUT].count = levelInfo.buts;
  buttons[BUG].count = levelInfo.bugs;
  buttons[BEE].count = levelInfo.bees;
  
  [[MainMenu instance] fadeOut];
  
  [clock startWithLevelInfo:levelInfo];

  if (![topicDict valueForKey:@"nosetup"])
  {
    [board fadeIn];
    [ramp  fadeIn];
    [jump  fadeIn];
    [score fadeIn];
    [clock fadeIn];
    [menu  fadeIn];
  }
    
  score.color = ((StoneType*)[levelInfo.flowers objectAtIndex:0]).scoreColor;
  clock.color = score.color;
  uint buttonColor = ((StoneType*)[levelInfo.flowers objectAtIndex:0]).buttonColor;
  
  for (MenuObject * child in menu.currScreen.children)
  {
    if ([child isKindOfClass:[SpriteButton class]])
      [(SpriteButton*)child setColor:buttonColor forName:@"scorecolor"];
  }  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) displayHelp:(NSString*)help
{
  [Sound play:@"game fade in"];

  [Controller instance].currentGame = self;
  if (!helpDict) helpDict = LoadPropertyList(@"HelpXML.plist");
  topicDict = [helpDict valueForKey:help];
  
  [self setupHelp];
  
  scriptDicts = [topicDict valueForKey:@"scripts"];
  
  scriptIndex = 0;
  [self nextScript];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) showTopic:(NSString*)topicName
{
  topicDict = [helpDict valueForKey:topicName];

  [levelInfo release];
  levelInfo = [[LevelInfo alloc] initWithDictionary:[topicDict valueForKey:@"info"]];
  
  scriptDicts = [topicDict valueForKey:@"scripts"];
  scriptIndex = 0;
  
  [self nextScript];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) nextTopic
{
  [self showTopic:[topicDict valueForKey:@"nextTopic"]];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) endTopicOrNextTopic
{
  if (firstRun) 
    [self showTopic:@"firstRunEnd"];
  else 
    [self nextTopic];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) scriptFinished:(HelpScript*)script_
{
  if (script == script_) script = nil;
  [script_ release];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) nextScript
{
  [self cancelDrag];
  [self clearExtras];
  [blockList release]; blockList = nil;
  [script stop];
  script = [[HelpScript alloc] initWithDictionary:[scriptDicts objectAtIndex:scriptIndex++]];
  [script play];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) restartScript
{
  [self cancelDrag];
  [self clearExtras];
  scriptIndex--;
  [self nextScript];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startScript:(int)scriptIndex_
{
  [self cancelDrag];
  [self clearExtras];
  scriptIndex = scriptIndex_;
  [self nextScript];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) clearBoard
{
  [board explodeStones]; [board clear];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) cancelDrag
{
  [[Controller instance] cancelDrag];
  [board resetTargetFields];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) clearExtras
{
  [[Extras instance] deactivateAllExtras];  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) clearAll
{
  [script stop];
  [clock stop];
  [self cancelDrag];
  [self clearBoards];
  [self clearExtras];
  [levelInfo release];
  levelInfo = nil;
  handStatus = nil;
  script = nil;  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeOut
{
  [self clearAll];
  [super fadeOut];
  [Controller instance].currentGame = [Game instance];
  [[Controller instance] removeEventReceiver:self type:@"up"];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) hideBoards
{
  [clock stop];
  [self cancelDrag];
  [self clearBoards];
  [self clearExtras];
  [super fadeOut];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) finish
{
  [self fadeOut];
  if (firstRun)
  {
    [[MainMenu instance] loadScreenWithName:@"Kraut"]; 
  }
  else
  {
    [[MainMenu instance] loadScreenWithName:@"Help"]; 
    [[MainMenu instance] pushScreenWithName:@"Kraut"];   
  }
  firstRun = FALSE;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) scriptedTouchEvent:(TouchEvent*)event
{
  if ([[Controller instance] handleDragEvent:event])
  {
    [board onEvent:event];
    [jump  onEvent:event];
    [ramp  onEvent:event];
    [menu  onEvent:event];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) onEvent:(Event*)event
{
  if ([event isKindOfClass:[TouchEvent class]])
  {
    if ([event.type isEqualToString:@"up"]) 
    {
      [Sound play:@"block rotate"];
      
      if (CGRectContainsPoint(((Button*)[menu.currScreen.children objectAtIndex:0]).touchRect, ((TouchEvent*)event).point))
      {
        [self finish];
      }
      else 
      {
        [self nextScript];
      }
    }
  }
  else if ([event isKindOfClass:[KeyValueEvent class]])
  {
    KeyValueEvent * kvEvent = (KeyValueEvent*)event;
    if ([kvEvent.key isEqualToString:@"action"])
    {
      [script startAction:[kvEvent.value intValue]];
    }
    else if ([kvEvent.key isEqualToString:@"script"])
    {
      [self startScript:[kvEvent.value intValue]];
    }
  }
  
  return YES;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) rampFadedIn
{
}

//------------------------------------------------------------------------------------------------------------------------
- (void) jumpFadedIn
{
  if (!jump.block && ![ramp isEmpty]) [self nextBlock];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setBees:(int)bees bugs:(int)bugs buts:(int)buts
{
  levelInfo.bees = bees;
  levelInfo.bugs = bugs;
  levelInfo.buts = buts;
  
  buttons[BUT].count = levelInfo.buts;
  buttons[BUG].count = levelInfo.bugs;
  buttons[BEE].count = levelInfo.bees;
  
  [buttons[BUT].extra show];
  [buttons[BUG].extra show];
  [buttons[BEE].extra show];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) gameOverDisplayed:(Timer*)timer
{
  [self endTopicOrNextTopic];
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) isGameOver
{
  if ([ramp isEmpty] && [jump isEmpty]) return NO;
  return [super isGameOver];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) gameOver
{
  if (!gameIsOver)
  {
    [clock stop];
    [Sound play:@"end of help"];
    [PopupDisplay displayString:@"End Of" atPoint:POINT(0,0.15f) duration:GAME_OVER_PREPARE_TIME];
    [PopupDisplay displayString:@"Help" atPoint:POINT(0,-0.15f) duration:GAME_OVER_PREPARE_TIME];
    [Timer timerWithDuration:GAME_OVER_PREPARE_TIME object:self tick:nil finish:@selector(gameOverDisplayed:)];  
  }
  gameIsOver = YES;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setScore:(int)score_
{
  [score setValue:score_];
  //level.score = score_;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) clearScore
{
  [self setScore:0];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) actionWithKey:(NSString*)key
{
  if ([key isEqualToString:@"showMenuButton"])    [menu  fadeIn];
  else if ([key isEqualToString:@"showRamp"])     [ramp  fadeIn];
  else if ([key isEqualToString:@"fillRamp"])     [ramp  fill];
  else if ([key isEqualToString:@"showJump"])     [jump  fadeIn];
  else if ([key isEqualToString:@"fillJump"])     { if (!jump.block) [self nextBlock]; }
  else if ([key isEqualToString:@"showBoard"])    { [board fadeIn]; [score fadeIn]; [clock fadeIn]; }
  else if ([key isEqualToString:@"nextTopic"])    [self nextTopic];
  else if ([key isEqualToString:@"endOrNext"])    [self endTopicOrNextTopic];
  else if ([key isEqualToString:@"nextScript"])   [self nextScript];
  else if ([key isEqualToString:@"clearBoard"])   [self clearBoard];
  else if ([key isEqualToString:@"clearBoards"])  [self clearBoards];
  else if ([key isEqualToString:@"hideBoards"])   [self hideBoards];
  else if ([key isEqualToString:@"clearScore"])   [self clearScore];
  else if ([key isEqualToString:@"clearExtras"])  [self clearExtras];
  else if ([key isEqualToString:@"restart"])      [self restartScript];
  else if ([key isEqualToString:@"startClock"])   { [clock stop]; [clock startWithLevelInfo:levelInfo]; [clock startCountDown]; }
  else if ([key isEqualToString:@"cancelDrag"])   [self cancelDrag];
  else if ([key isEqualToString:@"finish"])       [self finish];
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) lefty { return NO; } 
- (float) stoneMoveTime { return 0.6f; }

@end
