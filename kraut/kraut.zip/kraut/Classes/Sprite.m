//
//  Sprite.m

#import "Sprite.h"
#import "Resources.h"
#import "Tools.h"
#import "Layers.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation Sprite
//------------------------------------------------------------------------------------------------------------------------

@synthesize texid;
@synthesize blend;
@synthesize layer;

//------------------------------------------------------------------------------------------------------------------------

+ (Sprite*) withName:(NSString*)name
{
  return [[Resources instance] sprite:name];
}

//------------------------------------------------------------------------------------------------------------------------

- (id) initWithTextureId:(uint)texture
{
  float uv_[4] = {0.0f,0.0f,1.0f,1.0f};
  return [self initWithTextureId:texture uv:uv_];
}

//------------------------------------------------------------------------------------------------------------------------

- (id) initWithTextureId:(uint)texture uv:(float*)uv_
{
  if ((self = [super init]))
  {
    texid = texture;
    blend = BLEND_ALPHA;
    uv[0] = uv_[0]; uv[1] = uv_[1]; 
    uv[2] = uv_[2]; uv[3] = uv_[3];
  }
  
  return self;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) dealloc
{
  //NSLog(@"Sprite::dealloc");
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) drawWithRect:(CGRect)rect
{
  [self drawAtPoint:CGRectCenter(rect) size:rect.size color:0xffffffff layer:layer];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) drawWithRect:(CGRect)rect layer:(uint)_layer_
{
  [self drawAtPoint:CGRectCenter(rect) size:rect.size color:0xffffffff layer:_layer_];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) drawWithRect:(CGRect)rect color:(uint)color
{
  [self drawAtPoint:CGRectCenter(rect) size:rect.size color:color layer:layer];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) drawWithRect:(CGRect)rect color:(uint)color layer:(uint)_layer_
{
  [self drawAtPoint:CGRectCenter(rect) size:rect.size color:color layer:_layer_];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) drawWithRect:(CGRect)rect alpha:(float)alpha
{
  uint color = 0xffffff | ((uint)(alpha*0xff)<<24);
  [self drawAtPoint:CGRectCenter(rect) size:rect.size color:color layer:layer];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) drawWithRect:(CGRect)rect alpha:(float)alpha layer:(uint)_layer_
{
  uint color = 0xffffff | ((uint)(alpha*0xff)<<24);
  [self drawAtPoint:CGRectCenter(rect) size:rect.size color:color layer:_layer_];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) drawAtPoint:(CGPoint)point size:(CGSize)size
{
  [self drawAtPoint:point size:size color:0xffffffff layer:layer];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) drawAtPoint:(CGPoint)point size:(CGSize)size layer:(uint)_layer_
{
  [self drawAtPoint:point size:size color:0xffffffff layer:_layer_];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) drawAtPoint:(CGPoint)point size:(CGSize)size alpha:(float)alpha
{
  uint color = 0xffffff | ((uint)(alpha*0xff)<<24);
  [self drawAtPoint:point size:size color:color layer:layer];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) drawAtPoint:(CGPoint)point size:(CGSize)size alpha:(float)alpha layer:(uint)_layer_
{
  uint color = 0xffffff | ((uint)(alpha*0xff)<<24);
  [self drawAtPoint:point size:size color:color layer:_layer_];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) drawAtPoint:(CGPoint)point size:(CGSize)size color:(uint)color
{
  [self drawAtPoint:point size:size color:color layer:layer];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) drawAtPoint:(CGPoint)point angle:(float)angle size:(CGSize)size color:(uint)color layer:(uint)_layer_
{
  if (angle)
  {
    CGAffineTransform rot = CGAffineTransformMakeRotation(DEG2RAD(angle));
    float w = size.width/2.0f;
    float h = size.height/2.0f;
    CGPoint points[4] = { CGPointAdd(point, CGPointApplyAffineTransform(CGPointMake(-w,-h), rot)),
                          CGPointAdd(point, CGPointApplyAffineTransform(CGPointMake( w,-h), rot)),
                          CGPointAdd(point, CGPointApplyAffineTransform(CGPointMake(-w, h), rot)),
                          CGPointAdd(point, CGPointApplyAffineTransform(CGPointMake( w, h), rot)) };

    [Layers drawSprite:self withPoints:points color:color layer:_layer_];
  }
  else
  {
    [self drawAtPoint:point size:size color:color layer:_layer_];
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (void) drawAtPoint:(CGPoint)point size:(CGSize)size color:(uint)color layer:(uint)_layer_
{
  float width  = size.width/2;
  float height = size.height/2;
  float points[12] = {
    -width + point.x, -height + point.y,
     width + point.x, -height + point.y,
    -width + point.x,  height + point.y,
     width + point.x, -height + point.y,
    -width + point.x,  height + point.y,
     width + point.x,  height + point.y,
  };
  
  [Layers drawSprite:self withPointArray:points color:color layer:_layer_];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) drawWithPoints:(CGPoint*)points alpha:(float)alpha 
{
  uint color = 0xffffff | ((uint)(alpha*0xff)<<24);
  [Layers drawSprite:self withPoints:points color:color layer:layer];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) drawWithPoints:(CGPoint*)points alpha:(float)alpha layer:(uint)_layer_
{
  uint color = 0xffffff | ((uint)(alpha*0xff)<<24);
  [Layers drawSprite:self withPoints:points color:color layer:_layer_];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) drawWithPoints:(CGPoint*)points layer:(uint)_layer_
{
  [Layers drawSprite:self withPoints:points color:0xffffffff layer:_layer_];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) addVertex:(sprite_vertex*)vert layer:(uint)_layer_
{
  [Layers addVertex:vert forSprite:self layer:_layer_];
}

//------------------------------------------------------------------------------------------------------------------------
- (float*) uv
{
  return uv;
}

@end


