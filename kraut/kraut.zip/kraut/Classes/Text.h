//
//  Text.h

#import "Sprite.h"

extern uint CHAR[123][5];
//------------------------------------------------------------------------------------------------------------------------
@interface NSString (TextDrawing)
//------------------------------------------------------------------------------------------------------------------------

- (void) drawAtPoint:(CGPoint)point height:(float)height;
- (void) drawAtPoint:(CGPoint)point height:(float)height alpha:(float)alpha;
- (void) drawAtPoint:(CGPoint)point height:(float)height color:(uint)color layer:(uint)_layer_;
- (void) drawAtCenter:(CGPoint)point height:(float)height color:(uint)color layer:(uint)_layer_;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface Font : Sprite
//------------------------------------------------------------------------------------------------------------------------
{
  NSString        * fontName;
  //NSString        * characters;
}

+ (Font*)   instance;
- (id)      initWithTextureId:(GLuint)texture;
- (void)    drawText:(NSString*)text atPoint:(CGPoint)point height:(float)height color:(uint)color layer:(uint)_layer_;
- (void)    colorText:(NSString*)text atPoint:(CGPoint)point height:(float)height layer:(uint)_layer_;
- (float)   widthOfText:(NSString*)text height:(float)height;

@end
