//
//  PrizeWheel.m
//  kraut

#import "PrizeWheel.h"
#import "Controller.h"
#import "Animation.h"
#import "Button.h"
#import "Timer.h"
#import "Stone.h"
#import "Bezier.h"
#import "Sprite.h"
#import "Sound.h"
#import "Layers.h"
#import "Awards.h"
#import "Challenge.h"
#import "ChallengeFlower.h"
#import "MenuCampaign.h"
#import "Particle.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation PrizeButton
//------------------------------------------------------------------------------------------------------------------------

@synthesize index;

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [animTimer stop];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeInWithDelay:(float)delay
{
  [animTimer stop];
  if (delay) animTimer = [Timer timerWithDuration:delay object:self tick:nil finish:@selector(startFadeIn:)];
  else [self startFadeIn:nil];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeOutWithDelay:(float)delay;
{
  [animTimer stop];
  if (delay) animTimer = [Timer timerWithDuration:delay object:self tick:nil finish:@selector(startFadeOut:)];
  else [self startFadeOut:nil];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) explodeWithDelay:(float)delay;
{
  [animTimer stop];
  if (delay) animTimer = [Timer timerWithDuration:delay object:self tick:nil finish:@selector(startExplode:)];
  else [self startExplode:nil];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startFadeIn:(Timer*)timer
{
  [animTimer stop];
  animTimer = [Timer timerWithDuration:1.0f object:self tick:@selector(fadeIn:) finish:@selector(fadedIn:)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeIn:(Timer*)timer
{
  float value = [Animation springValue:timer.fraction from:0 to:1 ratio:0.5f overshot:0.1f];
  if (timer.fraction >= 0.5f && timer.fraction - timer.delta < 0.5f) [Sound play:[NSString stringWithFormat:@"fl%02d", index+1]];
  [super fadeIn:value];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadedIn:(Timer*)timer
{
  [super fadeIn:1];
  animTimer = nil;  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startFadeOut:(Timer*)timer
{
  [animTimer stop];
  animTimer = [Timer timerWithDuration:1.0f object:self tick:@selector(fadeOut:) finish:@selector(fadedOut:)];
  
  [Sound play:[NSString stringWithFormat:@"fl%02d", index+1]];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeOut:(Timer*)timer
{
  [super fadeOut:(1-timer.fraction)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadedOut:(Timer*)timer
{
  [super fadeOut:0];
  animTimer = nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startExplode:(Timer*)timer
{
  [animTimer stop];
  [Pollen explosionAt:CGRectCenter(self.rect) radius:0.5f sprite:spriteinfo[2].sprite color:0xffffff00 layer:_finger_ speed:1.0f count:16];
  animTimer = [Timer timerWithDuration:1.0f object:self tick:@selector(explode:) finish:@selector(exploded:)];
  
  [Sound play:@"prizeexplode"];
}

//------------------------------------------------------------------------------------------------------------------------
- (void)  explode:(Timer*)timer
{
  for (int i = 0; i < 3; i++)
  {
    SpriteInfo * info = &spriteinfo[i];
    info->color = (uint)(0xff*(1-timer.fraction)) << 24 | (info->color & 0xffffff);
    info->rect = CGRectScale(info->rect, (1-timer.fraction));
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void)  exploded:(Timer*)timer
{
  animTimer = nil;
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation PrizeWheel
//------------------------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithParent:(MenuCampaign*)parent_
{
  if ((self = [super init]))
  {
    parent = parent_;
    prizeArray = [[NSMutableArray arrayWithCapacity:12] retain];
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [prizeArray release];
  [[Controller instance] removeEventReceiver:self type:@"frame"];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) showWithFlower:(ChallengeFlower*)flower_ count:(int)current total:(int)count
{
  [[Controller instance] addEventReceiver:self type:@"frame"];
  flower = flower_;
  prizeCount = current;
  totalCount = count;
  [prizeArray removeAllObjects];
  
  float radius = 0.65f;
  
  float circumference = clamp(count * 180/6, 120, 300);
  buttonSize = radius * 2 * M_PI * (circumference/360) / (totalCount-1);
  spriteSize = 0.9f * buttonSize;
  
  for (int i = 0; i < totalCount; i++)
  {
    NSDictionary * buttonDict = [[NSDictionary dictionaryWithObjectsAndKeys:
                                  [NSArray arrayWithObjects:
                                   [NSDictionary dictionaryWithObjectsAndKeys: @"extra_bg", @"sprite", 
                                    [NSString stringWithFormat:@"%f", buttonSize], @"spriteSize", 
                                    @"0.15 0.15 0.15", @"color", 
                                    @"50", @"layer", 
                                    nil],
                                   [NSDictionary dictionaryWithObjectsAndKeys: @"extra_add", @"sprite", 
                                    [NSString stringWithFormat:@"%f", buttonSize], @"spriteSize", 
                                    @"51", @"layer", 
                                    nil],
                                   [NSDictionary dictionaryWithObjectsAndKeys: @"award", @"sprite", 
                                    [NSString stringWithFormat:@"%f", spriteSize], @"spriteSize", 
                                    (i < prizeCount) ? @"1.0 1.0 1.0" : @"0.0 0.0 0.0", @"color",
                                    @"52", @"layer", 
                                    nil], nil], @"sprites", 
                                  [NSDictionary dictionaryWithObjectsAndKeys:  @"award", @"key", [NSString stringWithFormat:@"%d", index], @"value", nil], @"event",
                                  nil] retain];
    
    PrizeButton * prizeButton = [[PrizeButton alloc] initWithDictionary:buttonDict parent:nil];
    prizeButton.index = i;
    [prizeButton setSprite:[flower.challenge prizeSprite]];
    CGPoint prizePoint = CGPointScale(CGPointMakeAngle(circumference/2-i*circumference/(count-1)), radius);
    [prizeButton moveTo:prizePoint];
    prizeButton.fadeInOffset = CGPointScale(prizePoint, 3);
    prizeButton.fadeOutOffset = CGPointScale(prizePoint, 3);
    [prizeButton fadeIn:0];
    
    [prizeArray addObject:prizeButton];
    [prizeButton release];
  }
  
  [self startFadeIn];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startFadeIn
{
  int index = 0;
  for (PrizeButton * prize in prizeArray) [prize fadeInWithDelay:(index++)*1.5f/totalCount];
  [animTimer stop];
  animTimer = [Timer timerWithDuration:1.5f+1.0f object:self tick:nil finish:@selector(fadedIn:)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadedIn:(Timer*)timer
{
  [Pollen explosionAt:flower.center radius:0.65f sprite:flower.challenge.stoneType.sprite color:flower.challenge.stoneType.pollenColor layer:_challenge_ speed:0.8f count:24];
  [flower hidePrize];
  
  PrizeButton * prizeButton = [prizeArray objectAtIndex:prizeCount];  
  Bezier * bez = [Bezier from:flower.center over:CGPointAdd(flower.center, POINT(0,0.5f)) and:CGPointAdd(CGRectCenter(prizeButton.rect), POINT(0,0.5f)) to:CGRectCenter(prizeButton.rect)];  
  animTimer = [Timer timerWithDuration:2.0f object:self tick:@selector(collectPrize:) finish:@selector(prizeCollected:) info:bez];
  
  [Sound play:@"prizejump"];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) collectPrize:(Timer*)timer
{
  Bezier * bez = timer.info;
  float size = [flower prizeScale] + timer.fraction * (spriteSize-[flower prizeScale]);
  [[flower.challenge prizeSprite] drawAtPoint:[bez pointAtTime:timer.fraction] size:CGSizeMake(size, size) layer:_finger_];
}

//------------------------------------------------------------------------------------------------------------------------
- (void)prizeCollected:(Timer*)timer
{
  Bezier * bez = timer.info;
  PrizeButton * prizeButton = [prizeArray objectAtIndex:prizeCount];
  [[flower.challenge prizeSprite] drawAtPoint:[bez pointAtTime:1] size:CGSizeMake(spriteSize, spriteSize) layer:_finger_];
  [prizeButton setColor:0xffffffff forIndex:2];

  [Sound play:@"drag end"];

  if (prizeCount == totalCount-1)
  {
    [self startExplode];
  }
  else
  {
    [self startFadeOut];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startFadeOut
{
  int index = 0;
  for (PrizeButton * prize in prizeArray) [prize fadeOutWithDelay:(index++)*min(0.1f, 1.0f/totalCount)];
  [animTimer stop];
  [flower hidePrize];
  animTimer = [Timer timerWithDuration:(totalCount*min(0.1f, 1.0f/totalCount))+1.0f object:self tick:nil finish:@selector(fadedOut:)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadedOut:(Timer*)timer
{
  animTimer = nil;
  [parent startAnimationForOpenedChallenges];
  [[Controller instance] removeEventReceiver:self type:@"frame"];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startExplode
{
  int index = 0;
  for (PrizeButton * prize in prizeArray) 
  {
    [prize explodeWithDelay:(index++)*2.0f/totalCount];
  }
  [animTimer stop];
  animTimer = [Timer timerWithDuration:(2.0f)+1.0f object:self tick:nil finish:@selector(exploded:)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) exploded:(Timer*)timer
{
  animTimer = nil;
  
  [Pollen explosionAt:flower.center radius:1.2f sprite:flower.challenge.stoneType.sprite color:flower.challenge.stoneType.pollenColor layer:_challenge_ speed:0.8f count:32];
  [Pollen explosionAt:flower.center radius:1.5f sprite:flower.challenge.stoneType.sprite color:flower.challenge.stoneType.pollenColor layer:_challenge_ speed:1.5f count:24];
  animTimer = [Timer timerWithDuration:5.0f object:self tick:@selector(showPrize:) finish:@selector(prizeShown:)];
  
  [Sound play:@"prizewon"];
  
  [parent showInfoForPrize:flower.challenge.prize];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) showPrize:(Timer*)timer
{
  Sprite * prizeSprite = [[Awards instance] spriteForPrize:flower.challenge.prize];
  float size = 0.8f;
  float alpha = 1.0f;
  
  if (timer.elapsedTime < 2)
  {
    if (timer.elapsedTime >= 1 && timer.elapsedTime - timer.duration * timer.delta < 1.0f)
    {
      [Pollen explosionAt:flower.center radius:1.2f sprite:flower.challenge.stoneType.sprite color:flower.challenge.stoneType.pollenColor layer:_challenge_ speed:0.8f count:32];
      [Pollen explosionAt:flower.center radius:1.5f sprite:flower.challenge.stoneType.sprite color:flower.challenge.stoneType.pollenColor layer:_challenge_ speed:1.5f count:24];
    }
    
    size = [Animation springValue:timer.elapsedTime/2 from:0 to:size ratio:0.5f overshot:0.2f];
  }
  else if (timer.elapsedTime > 4)
  {
    size = 1-(timer.elapsedTime-4);
  }
  else 
  {
    if (timer.elapsedTime - timer.duration * timer.delta < 2.0f)
      [Pollen explosionAt:flower.center radius:1.2f sprite:flower.challenge.stoneType.sprite color:flower.challenge.stoneType.pollenColor layer:_challenge_ speed:1.0f count:24];
  }
  
  [prizeSprite drawAtPoint:flower.center size:CGSizeMake(size, size) alpha:alpha layer:_finger_];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) prizeShown:(Timer*)timer
{
  animTimer = nil;
  [parent startAnimationForOpenedChallenges];
  [[Controller instance] removeEventReceiver:self type:@"frame"];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onFrame:(double)delta
{
  for (PrizeButton * prize in prizeArray) [prize onFrame:delta];
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) onEvent:(Event*)event
{
  if ([event isKindOfClass:[FrameEvent class]]) [self onFrame:((FrameEvent*)event).delta];
  return YES;
}

@end
