//
//  Help.h
//  kraut

#import "Game.h"

@class HelpScript;
@class AnimBezierStatus;
@class TouchEvent;

//------------------------------------------------------------------------------------------------------------------------
@interface Help : Game 
//------------------------------------------------------------------------------------------------------------------------
{
  NSDictionary * helpDict;
  NSDictionary * topicDict;
  NSArray      * scriptDicts;
  HelpScript   * script;
  int            scriptIndex;
  BOOL           firstRun;
  
  AnimBezierStatus * handStatus;
}

@property (assign) AnimBezierStatus * handStatus;
@property (assign) BOOL firstRun;

+ (Help*)   instance;
- (id)      init;
- (void)    setup;
- (void)    finish;
- (void)    dealloc;
- (void)    cancelDrag;
- (void)    clearBoard;
- (void)    clearExtras;
- (void)    displayHelp:(NSString*)help;
- (void)    nextScript;
- (void)    startScript:(int)scriptIndex;
- (void)    nextTopic;
- (BOOL)    isGameOver;
- (void)    scriptFinished:(HelpScript*)script;
- (void)    actionWithKey:(NSString*)key;
- (void)    scriptedTouchEvent:(TouchEvent*)event;
- (void)    setBees:(int)bees bugs:(int)bugs buts:(int)buts;
- (void)    setScore:(int)score;
- (void)    clearScore;

@end
