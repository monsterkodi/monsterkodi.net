//
//  HelpScriptHandAction.m
//  kraut

#import "HelpScriptHandAction.h"
#import "AnimBezier.h"
#import "Timer.h"
#import "Sprite.h"
#import "Help.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation HelpScriptHandAction
//------------------------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithDictionary:(NSDictionary*)dict
{
  if ((self = [super initWithDictionary:dict]))
  {
    downBeziers = [[NSMutableArray arrayWithCapacity:2] retain];
    moveBeziers = [[NSMutableArray arrayWithCapacity:2] retain];
    upBeziers   = [[NSMutableArray arrayWithCapacity:2] retain];
        
    size = CGSizeMake([dict floatForKey:@"width" default:0.15f], 
                      [dict floatForKey:@"height" default:0.3f]);

    for (AnimBezier * bez in beziers) { bez.startSize = size; bez.endSize = size; }
    
    if ([dict valueForKey:@"beziers"])
    {
      for (int i = 0; i < [[dict valueForKey:@"beziers"] count]; i++)
      {
        NSDictionary * bezDict = [[dict valueForKey:@"beziers"] objectAtIndex:i];
        if ([bezDict valueForKey:@"down"]) [downBeziers addObject:[beziers objectAtIndex:i]];
        if ([bezDict valueForKey:@"move"]) [moveBeziers addObject:[beziers objectAtIndex:i]];
        if ([bezDict valueForKey:@"up"])   [upBeziers   addObject:[beziers objectAtIndex:i]];
      }
      
      AnimBezierStatus * startStatus = [[beziers objectAtIndex:0] statusAtTime:0];
      AnimBezier * bez = [AnimBezier from:[Help instance].handStatus to:startStatus];
      fadeInTime = [dict floatForKey:@"fadeIn" default:1];
      bez.duration = fadeInTime;
      [beziers insertObject:bez atIndex:0];
      fadeInBezierCount = 1;
    }
  }
  return self;  
}

//------------------------------------------------------------------------------------------------------------------------
- (CGPoint) spritePointForBezierStatus:(AnimBezierStatus*)status;
{
  return CGPointAdd(status.point, CGPointScale(CGPointMakeAngle(status.angle+13), -status.size.height/2));
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startAnimation:(AnimBezier*)bez
{
  if ([downBeziers containsObject:bez])
  {
    TouchEvent * event = [[TouchEvent alloc] init];
    
    AnimBezierStatus * status = [bez statusAtTime:0];
    event.point     = status.point;
    event.type      = @"down";
    event.direction = POINT(0,0);
    event.delta     = 0;
    event.finger    = 1;
    event.tapCount  = 1;
    
    lastTouchPoint = event.point;
    
    [[Help instance] scriptedTouchEvent:event];
    [event release];
  }

  [super startAnimation:bez];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) animation:(Timer*)timer
{
  if ([moveBeziers containsObject:timer.info])
  {
    AnimBezierStatus * status = [timer.info statusAtTime:timer.fraction];
    CGPoint touchPoint = status.point;
    [[Sprite withName:@"field_marker"] drawAtPoint:touchPoint size:CGSizeMake(0.2f, 0.2f) alpha:1.0 layer:_hand_];
    
    CGPoint direction = CGVector(lastTouchPoint, touchPoint);
    float delta = CGPointLength(direction);

    if (delta)
    {
      TouchEvent * event = [[TouchEvent alloc] init];
      
      event.point     = touchPoint;
      event.type      = @"move";
      event.direction = direction;
      event.delta     = delta;
      event.finger    = 1;
      event.tapCount  = 1;
      
      [[Help instance] scriptedTouchEvent:event];
      [event release];
    }
    
    lastTouchPoint  = touchPoint;
  }

  [super animation:timer];  
}

//------------------------------------------------------------------------------------------------------------------------
- (void)  animationEnd:(Timer*)timer
{
  if ([moveBeziers containsObject:timer.info])
  {
    AnimBezierStatus * status = [timer.info statusAtTime:timer.fraction];
    CGPoint touchPoint = status.point; 
    [[Sprite withName:@"field_marker"] drawAtPoint:touchPoint size:CGSizeMake(0.2f, 0.2f) alpha:1.0 layer:_hand_];
  }
  
  if ([upBeziers containsObject:timer.info])
  {
    TouchEvent * event = [[TouchEvent alloc] init];
    
    AnimBezierStatus * status = [timer.info statusAtTime:1];
    event.point     = status.point;
    event.type      = @"up";
    event.direction = POINT(0,0);
    event.delta     = 0;
    event.finger    = 1;
    event.tapCount  = 1;

    lastTouchPoint  = event.point;

    [[Help instance] scriptedTouchEvent:event];
    [event release];
  }
  
  [super animationEnd:timer];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [downBeziers release];
  [moveBeziers release];
  [upBeziers release];
  [super dealloc];
}

@end
