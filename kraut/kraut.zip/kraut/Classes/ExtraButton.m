//
//  ExtraButton.m
//  kraut

#import "ExtraButton.h"
#import "Controller.h"
#import "Extras.h"
#import "Bug.h"
#import "Bee.h"
#import "Butterfly.h"
#import "Letters.h"
#import "Sprite.h"
#import "Text.h"
#import "Timer.h"
#import "Game.h"
#import "Sound.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation ExtraButton
//------------------------------------------------------------------------------------------------------------------------

@synthesize extra;

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithDictionary:(NSDictionary*)dict_ parent:(MenuObject*)parent_
{
  if ((self = [super initWithDictionary:dict_ parent:parent_]))
  { 
    extraType = [dict valueForKey:@"extraType"];
    Game * game = ((GameMenu*)[self menu]).game;
    if      ([extraType isEqualToString:@"bug"]) game.bugButton = self;
    else if ([extraType isEqualToString:@"bee"]) game.beeButton = self;
    else if ([extraType isEqualToString:@"but"]) game.butButton = self;    
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [self clear];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) clear
{
  if (extra) { [extra hide]; [extra release]; extra = nil; }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fill
{
  if (count > 0)
  {
    if (extra) 
    {
      NSLog(@"[WARNING] filling extra button with extra set?");
      [extra release];
    }
    
    if      ([extraType isEqualToString:@"bug"]) extra = [[Bug alloc]  init];
    else if ([extraType isEqualToString:@"bee"]) extra = [[Bee alloc]  init];
    else if ([extraType isEqualToString:@"but"]) extra = [[Butterfly alloc] init];
    extra.point = CGRectCenter(rect);
    extra.extraButton = self;
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) isActive
{
  if      ([extraType isEqualToString:@"bug"]) return [Game current].levelInfo.bugs >= 0;
  else if ([extraType isEqualToString:@"bee"]) return [Game current].levelInfo.bees >= 0;
  else if ([extraType isEqualToString:@"but"]) return [Game current].levelInfo.buts >= 0;
  return NO;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) addExtraFromPoint:(CGPoint)point
{
  if (count < 99)
  {
    [self setCount:count+1];
    if (count == 1)
    {
      [extra jumpToPoint:CGRectCenter(rect) fromPoint:point];
    }
    else
    {      
      Extra * tmpExtra;
      if      ([extraType isEqualToString:@"bug"]) tmpExtra = [[Bug alloc]  init];
      else if ([extraType isEqualToString:@"bee"]) tmpExtra = [[Bee alloc]  init];
      else if ([extraType isEqualToString:@"but"]) tmpExtra = [[Butterfly alloc] init];
      
      [tmpExtra jumpToPoint:CGRectCenter(rect) fromPoint:point];
      [tmpExtra release];
    }
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) nextExtra
{
  if (extra) NSLog(@"[WARNING] next extra with extra set?");
  
  count = max(0, count-1);
  if (count && !extra)
  {
    [self fill];
    [extra show];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setCount:(int)count_
{
  if (count_ >= 0 && count < 0) offset = POINT(0,0);
  count = count_;
  if (count > 0 && !extra) [self fill];
  else if (count < 1) 
  {
    [self clear];
    
    if (count < 0) offset = POINT(-3,-3);
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeIn:(float)value
{
  if ([self isActive])
  {
    if (value == 0.0f)
      if (extra) [extra show];
    offset = CGPointMake(0,(1-value)*3);
    if (extra) [extra moveTo:CGPointAdd(offset, CGRectCenter(rect))];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeOut:(float)value
{
  if ([self isActive])
  {
    offset = CGPointMake(0,-3*(1-value));
    if (extra) 
    {
      [extra moveTo:CGPointAdd(offset, CGRectCenter(rect))];
      if (value == 0.0f) [extra hide];
    }
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onTouchDown:(TouchEvent*)event
{  
  touched = (CGRectContainsPoint(touchRect, event.point));
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onTouchUp:(TouchEvent*)event
{
  if (touched && extra && CGRectContainsPoint(touchRect, event.point)) 
  {
    [extra toggleWiggle];
  }
  touched = NO;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onTouchMove:(TouchEvent*)event
{
  // don't call super onTouchMove to prevent stopping of wiggling
  
  if (CGRectContainsPoint(touchRect, event.point))
  {
    if (extra && ![Controller instance].dragEvent)
    {
      [[Controller instance] startDrag:extra source:self point:event.point];
    }
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dragStarted:(DragEvent*)event
{
  [[Game current] stopWigglingExtra];
  [extra release];
  extra = nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dragMoved:(DragEvent*)event
{
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dragCanceled:(DragEvent*)event
{
  extra = event.object;
  [extra retain];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dragEnded:(DragEvent*)event
{
  [event.object stopWiggleSound];
}

@end
