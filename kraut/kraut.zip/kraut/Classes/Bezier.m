//
//  Bezier.m

#import "Bezier.h"
#import "Tools.h"
#import "Line.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation Bezier
//------------------------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------------------------
+ (Bezier*) bezierWithPoints:(CGPoint*)points
{
  Bezier * bezier = [[Bezier alloc] initWithPoints:points];
  return [bezier autorelease];
}

//------------------------------------------------------------------------------------------------------------------------
+ (Bezier*) from:(CGPoint)fromPoint over:(CGPoint)c1Point and:(CGPoint)c2Point to:(CGPoint)toPoint
{
  CGPoint points[4] = {fromPoint, c1Point, c2Point, toPoint};
  Bezier * bezier = [[Bezier alloc] initWithPoints:points];
  return [bezier autorelease];
}

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithPoints:(CGPoint*)points
{
  if ((self = [super init]))
  {
    pts[0] = points[0];
    pts[1] = points[1];
    pts[2] = points[2];
    pts[3] = points[3];
    vec[0] = CGVector(pts[0], pts[1]);
    vec[1] = CGVector(pts[1], pts[2]);
    vec[2] = CGVector(pts[2], pts[3]);
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (CGPoint) pointAtTime:(float)t
{
  CGPoint b1, b2, b3, c1, c2;
  b1 = CGPointAdd(pts[0], CGPointScale(vec[0], t));
  b2 = CGPointAdd(pts[1], CGPointScale(vec[1], t));
  b3 = CGPointAdd(pts[2], CGPointScale(vec[2], t));
  c1 = CGPointAdd(b1, CGPointScale(CGVector(b1, b2), t));
  c2 = CGPointAdd(b2, CGPointScale(CGVector(b2, b3), t));
    
  return CGPointAdd(c1, CGPointScale(CGVector(c1, c2), t));
}

//------------------------------------------------------------------------------------------------------------------------
- (void) draw
{
  [Line color:RGBCOLOR(1,1,0)];
  [Line from:pts[0] to:pts[1]];
  [Line from:pts[2] to:pts[3]];

  for (int i = 0; i < 4; i++)
  {
    float s = 0.05f;
    [Line from:POINT(pts[i].x-s, pts[i].y) to:POINT(pts[i].x+s, pts[i].y)];
    [Line from:POINT(pts[i].x, pts[i].y-s) to:POINT(pts[i].x, pts[i].y+s)];
  }
}

@end
