//
//  MenuText.m
//  kraut

#import "MenuHighscore.h"
#import "MenuSignature.h"
#import "Signature.h"
#import "Highscores.h"
#import "Letters.h"
#import "Sprite.h"
#import "Text.h"
#import "Tools.h"
#import "Timer.h"
#import "Menu.h"

#define HIGHSCORE_ENTRY_OFFSET            0.5f
#define HIGHSCORE_ENTRY_SIGNATURE_HEIGHT  (HIGHSCORE_ENTRY_OFFSET-0.02f)
#define HIGHSCORE_ENTRY_SIGNATURE_WIDTH   (HIGHSCORE_ENTRY_SIGNATURE_HEIGHT * GOLDEN_MEAN)
#define HIGHSCORE_ENTRY_YPOS              0.7f
#define HIGHSCORE_ENTRY_POINTS_X          0.95f
#define HIGHSCORE_ENTRY_POSITIONS_X      -0.95f

//------------------------------------------------------------------------------------------------------------------------
@implementation MenuHighscore
//------------------------------------------------------------------------------------------------------------------------

- (id) initWithDictionary:(NSDictionary*)dict_ parent:(MenuObject*)parent_
{  
  if ((self = [super initWithDictionary:dict_ parent:parent_]))
  {        
    scores     = [[NSMutableArray arrayWithCapacity:6] retain];
    signatures = [[NSMutableArray arrayWithCapacity:6] retain];
  }
  
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [signatures release];
  [scores     release];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) initHighscore
{  
  [signatures removeAllObjects];
  [scores removeAllObjects];

  for (int i = 0; i < (page == 0 ? 3 : 6); i++)
  {
    letters = [[Letters alloc] init];
    letters.layer = _text_;
    letters.sprite = [Sprite withName:@"shadow"];
    [scores addObject:letters];
    [letters release];
  }
  
  if (page == 0)
  {
    float w1 = 1.9f;
    float h1 = w1/GOLDEN_MEAN;
    float y1 = -0.35f;
    
    float xo = 0.025f;
    float yo = w1/(4*GOLDEN_MEAN);
    float w2 = w1/2-xo;
    float h2 = w2/GOLDEN_MEAN;
    float y2 = y1-h2-yo;
    
    CGRect rects[3] = {CGRectMake(-w1/2,y1,w1,h1), CGRectMake(-xo-w2,y2,w2,h2), CGRectMake(+xo,y2,w2,h2)};
    
    for (int i = 0; i < 3; i++)
    {
      letters = [scores objectAtIndex:i];
      letters.alignment = ALIGN_CENTER;
      
      [letters setString:[NSString stringWithFormat:@"%d: %d", i+1, [Highscores scoreForPlace:i]] withHeight:0.13f atPoint:POINT(CGRectGetMidX(rects[i]), CGRectGetMinY(rects[i])-yo/3)];
      
      Signature * signature = [Highscores entryForPlace:i].signature;
      signature.rect = rects[i];
      [signatures addObject:signature];
    }
  }
  else
  {    
    float y  = 0.5f;
    float xo = -0.9f;
    float w  = 0.64f;
    float h  = w/GOLDEN_MEAN;
    float yo = w/(4*GOLDEN_MEAN);
    
    for (int i = 0; i < 6; i++)
    {
      int place = i+3;
      Signature * signature = [Highscores entryForPlace:place].signature;
      signature.rect = CGRectMake(xo,y-i*h,w,h);

      letters = [scores objectAtIndex:i];
      letters.alignment = ALIGN_LEFT;
      [letters setString:[NSString stringWithFormat:@"%d: %d", place+1, [Highscores scoreForPlace:place]] withHeight:0.13f atPoint:POINT(CGRectGetMaxX(signature.rect)+yo, CGRectGetMidY(signature.rect))];
      
      [signatures addObject:signature];    
    }
  }
  
  letters = nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onTouchUp:(TouchEvent*)event
{
  if (fadeValue == 1 && event.point.y < 0.9f)
  {
    page = (page+1)%2;
    [self fadeOut:1];
    [Timer timerWithDuration:0.5f object:self tick:@selector(swapPageOut:) finish:@selector(pageSwappedOut:)];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) swapPageOut:(Timer*)timer
{
  [self fadeOut:1-timer.fraction];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) swapPageIn:(Timer*)timer
{
  [self fadeIn:timer.fraction];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) pageSwappedOut:(Timer*)timer
{
  [self fadeIn:0];
  [Timer timerWithDuration:0.7f object:self tick:@selector(swapPageIn:) finish:@selector(pageSwappedIn:)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) pageSwappedIn:(Timer*)timer
{
  fadeValue = 1;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeIn:(float)value
{
  fadeValue = value;
  if (value == 0) 
  { 
    [self initHighscore]; 
    for (Signature * s in signatures) [s startFadeIn]; 
  }
  for (Letters * l in scores) [l fade:value offset:self.menu.fadeInOffset];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeOut:(float)value
{
  fadeValue = value;
  for (Letters * l in scores) [l fade:value offset:self.menu.fadeOutOffset];
  if (value == 1) for (Signature * s in signatures) [s startFadeOut];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onFrame:(double)delta
{
  for (Letters * l in scores)       [l draw];
  for (Signature * s in signatures) [s draw];
}

@end
