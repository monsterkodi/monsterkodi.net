//
//  Block.m

#import "Block.h"
#import "Controller.h"
#import "Game.h"
#import "Jump.h"
#import "Sound.h"
#import "Timer.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation Block
//------------------------------------------------------------------------------------------------------------------------

@synthesize stones;
@synthesize orientation;

//------------------------------------------------------------------------------------------------------------------------
- (id) init
{
  if ((self = [super init]))
  {
    stones = [[NSMutableArray arrayWithCapacity:0] retain];
    orientation = UP;
  }
  
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithFirst:(StoneType*)f center:(StoneType*)c last:(StoneType*)l
{
  if ((self = [super init]))
  {
    stones = [[NSMutableArray arrayWithObjects:[Stone ofType:f], [Stone ofType:c], [Stone ofType:l], nil] retain];
    for (Stone * stone in stones) [stone release];
    orientation = UP;
  }
  
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  //NSLog(@"block dealloc %@", self);
  [cancelTimer stop];
  [stones release];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dragStarted:(DragEvent*)event
{
  [[Controller instance] addEventReceiver:self type:@"up"];
  for (Stone * stone in stones)
  {
    float scale;
    scale = (2.0f/[Game current].levelInfo.size) / FIELD_SIZE;
    stone.scale = 1.2f * scale;
    stone.above = YES;
  }
  [self setOrientation:orientation]; // reset orientation to adjust stone distance
  [Sound play:@"drag start"];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) dragMoved:(DragEvent*)event
{
  [self transform:CGAffineTransformMakeTranslation(event.delta.x, event.delta.y)]; 
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dragEnded:(DragEvent*)event
{
  [[Controller instance] removeEventReceiver:self type:@"up"];
  
  for (Stone * stone in stones)
  {
    stone.scale = 1.0f;
    stone.above = NO;
  }
}  

//------------------------------------------------------------------------------------------------------------------------

- (void) dragCanceled:(DragEvent*)event
{
  [[Controller instance] removeEventReceiver:self type:@"up"];
  for (Stone * stone in stones) 
  {
    stone.scale = 1.0f;
    stone.above = NO;
  }
  
  if (cancelTimer) [cancelTimer stop];
  cancelTimer = [Timer timerWithDuration:STONE_MOVE_TIME object:self tick:nil finish:@selector(movedBack:)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) movedBack:(Timer*)timer
{
  cancelTimer = nil;
  [Sound play:@"drag cancel"];
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) onEvent:(Event*)event_
{
  if ([event_ isKindOfClass:[TouchEvent class]]) 
  {
    TouchEvent * event = (TouchEvent*)event_;
    if ([event.type isEqualToString:@"up"])
    {
      if (event.finger > 1)
      {
        int dir = 1;
        if (event.delta != 0)
        {
          float angle = CGAngle(CGVector(CGRectCenter(self.center.rect), event.point), CGVector(CGRectCenter(self.center.rect), CGPointSub(event.point,event.direction)));
          dir = (angle > 0) ? 1 : -1;
        }
        [self rotate:dir];
      }
    }
  }
  
  return YES;
}
  
//------------------------------------------------------------------------------------------------------------------------
- (void) transform:(CGAffineTransform)trans
{
  for (Stone* stone in stones) [stone transform:trans];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) rotate:(int)steps
{
  self.orientation = (self.orientation + steps) % 4;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setOrientation:(Orientation)o
{
  if (orientation != o) 
  {
    [Sound play:@"block rotate"];
  }
  
  orientation = o;

  if ([self center].field && ((Jump*)[self center].field.board).block)
  {
    Board * board = [self center].field.board;
    Pos pos = [self center].field.pos;

    for (Stone * stone in self.stones) stone.field.stone = nil;
    
    [board setStonesForBlock:self atPos:pos];
  }
  else
  {
    float scale = (2.0f/[Game current].levelInfo.size) / (2.0f/7.0f);
    float size  = self.center.rect.size.width*scale;

    CGPoint d;
    d = CGVector(self.first.rect.origin, self.center.rect.origin);
    d = CGPointSub(d, CGPointMul(CGPointMakeArray(DIR[o]), CGPointMake(size,size)));
    [self.first transform:CGAffineTransformMakeTranslation(d.x, d.y)];
    d = CGVector(self.last.rect.origin, self.center.rect.origin);
    d = CGPointAdd(d, CGPointMul(CGPointMakeArray(DIR[o]), CGPointMake(size,size)));
    [self.last transform:CGAffineTransformMakeTranslation(d.x, d.y)];    
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (Stone*) first   { if ([stones count] > 0) return [stones objectAtIndex:0]; return nil; }
- (Stone*) center  { if ([stones count] > 1) return [stones objectAtIndex:1]; return nil; }
- (Stone*) last    { if ([stones count] > 2) return [stones objectAtIndex:2]; return nil; }
- (BOOL)   isEmpty { return ([stones count] == 0); }

//------------------------------------------------------------------------------------------------------------------------
- (Pos) indexPos:(int)stoneIndex
{ 
  if (stoneIndex == 0) return POS(-DIR[orientation][0], -DIR[orientation][1]);
  if (stoneIndex == 1) return POS(0,0);
  if (stoneIndex == 2) return POS( DIR[orientation][0],  DIR[orientation][1]);
  NSAssert1(0, @"wrong stone index: %d", stoneIndex); 
  return nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (NSString*) description
{
  return [NSString stringWithFormat:@"<Block orientation: %d stones:\n  %@\n  %@\n  %@\n>", self.orientation, self.first, self.center, self.last];
}

@end
