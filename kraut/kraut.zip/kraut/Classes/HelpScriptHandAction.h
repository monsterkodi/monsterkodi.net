//
//  HelpScriptHandAction.h
//  kraut

#import "HelpScriptSpriteAction.h"

//------------------------------------------------------------------------------------------------------------------------
@interface HelpScriptHandAction : HelpScriptSpriteAction
//------------------------------------------------------------------------------------------------------------------------
{
  NSMutableArray * downBeziers;
  NSMutableArray * moveBeziers;
  NSMutableArray * upBeziers;
  
  CGPoint lastTouchPoint;
}

- (id)      initWithDictionary:(NSDictionary*)dict;
- (CGPoint) spritePointForBezierStatus:(AnimBezierStatus*)status;
- (void)    startAnimation:(AnimBezier*)bez;
- (void)    animation:(Timer*)timer;
- (void)    animationEnd:(Timer*)timer;
- (void)    dealloc;

@end
