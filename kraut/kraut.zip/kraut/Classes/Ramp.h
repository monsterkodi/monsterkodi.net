//
//  Ramp.h

#import "Board.h"

@class StoneType;

//------------------------------------------------------------------------------------------------------------------------
@interface Ramp : Board
//------------------------------------------------------------------------------------------------------------------------
{
  NSMutableArray * blocks;
  int extraTargetCol;
  Pos extraTargetPos;
  StoneType * butTargetType;
}

@property (readonly) NSArray * blocks;

- (id)      initWithRect:(CGRect)rect size:(int)size name:(NSString*)name;
- (void)    layout;
- (void)    fill;
- (void)    clear;
- (void)    dealloc;
- (Block*)  insertNewBlock;
- (Block*)  insertBlock:(Block*)newBlock;
- (CGPoint) startPoint;
- (int)     numBlocks;
- (BOOL)    isEmpty;

- (Pos)     jumpPosForBugAtPoint:(CGPoint)point;
- (Pos)     jumpPosForButAtPoint:(CGPoint)point;

- (void)    setupWithDictionary:(NSDictionary*)dictionary;
- (NSDictionary*) dictionary;

@end
