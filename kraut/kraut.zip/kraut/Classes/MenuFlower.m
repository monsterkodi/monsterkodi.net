//
//  MenuFlower.m

#import "MenuFlower.h"
#import "Controller.h"
#import "Sprite.h"
#import "Timer.h"
#import "Signature.h"
#import "Menu.h"
#import "Screen.h"

int MENU_FLOWERS[NUM_MENU_FLOWERS] = {70,40,42,44,50,64,61,31,51,20,30,71,72,10,22,52,14,60,33,21,32};

//------------------------------------------------------------------------------------------------------------------------
@implementation MenuFlower
//------------------------------------------------------------------------------------------------------------------------

@synthesize sprite;
@synthesize rect;
@synthesize alpha;
@synthesize angle;
@synthesize speed;
@synthesize fadeValue;

#define SHADOW_SIZE 1.3f

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithIndex:(int)index_
{
  if ((self = [super init]))
  {    
    index         = index_;
    angle         = 0;
    alpha         = 1.0f;
    rotation      = DEG2RAD(6) * ((index%2) ? -1 : 1);
    layer         = _stone_+index*2;
    sprite        = [Sprite withName:[NSString stringWithFormat:@"flower%02d", MENU_FLOWERS[index]]];
    shadowSprite  = [Sprite withName:@"flower_shadow"];
        
    int rings[NUM_MENU_FLOWERS] = {1,1,1,1,1,2,2,2,2,2,2,2,3,3,3,3,3,3,3,3,3};
    float angles[NUM_MENU_FLOWERS] = {
      0*360/5, 1*360/5, 2*360/5, 3*360/5, 4*360/5,
      0*360/7, 1*360/7, 2*360/7, 3*360/7, 4*360/7, 5*360/7, 6*360/7, 
    -1.5f*360/11,-0.5f*360/11, 0.5*360/11, 1.5f*360/11, 3.5f*360/11, 4.5f*360/11, 5.5f*360/11, 6.5f*360/11, 7.5f*360/11 };
    float radius[4] = {0.0f, 0.23f, 0.75f, 1.3f};
    float sizes[4]  = {0.0f, 0.5f, 1.0f, 1.3f};
        
    float size    = sizes[rings[index]];

    CGPoint point = CGPointScale(CGPointMakeAngle(angles[index]), radius[rings[index]]);
    
    rect = CGRectMakeCenterSize(point, CGSizeMake(size, size));  
    shadowRect = CGRectScale(rect, SHADOW_SIZE);
    
    [[Controller instance] addEventReceiver:self type:@"frame"];
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) initRect:(float)y
{
  rotation    = DEG2RAD(5+RANDOMF(10)) * (RANDOMF(1.0f) < 0.5f ? -1 : 1);
  speed       = 0.5f+(1.0f+RANDOMF(1.0f))*index/NUM_MENU_FLOWERS;
  alpha       = 1.0f;
  angle       = 0.0f;
  
  float size  = 0.1f+speed*0.4f;
  
  rect        = CGRectMake(RANDOMF(2)-1.0f-size/2.0f, y, size, size);  
  shadowRect  = CGRectScale(rect, SHADOW_SIZE);
}

//------------------------------------------------------------------------------------------------------------------------
- (Sprite*) randomFlower
{
  return [Sprite withName:[NSString stringWithFormat:@"flower%02d", MENU_FLOWERS[RANDOMI(NUM_MENU_FLOWERS)]]];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startFadeIn
{  
  if (fadeValue) return;
  if (fadeTimer) [fadeTimer stop];

  if (![Controller instance].intro) 
  {
    [self initRect:RANDOMF(3.0f)+1.5f];
    
    alpha = [[MainMenu instance].currScreen.name isEqualToString:@"Campaign"] ? 0.25f : 1.0f;
    
    [[Controller instance] addEventReceiver:self type:@"frame"];
    fadeTimer = [Timer timerWithDuration:1.0f object:self tick:@selector(fadingIn:) finish:@selector(fadedIn:)];
  }
  else
  {
    fadeTimer = [Timer timerWithDuration:0.1f+RANDOMF(16.0f) object:self tick:@selector(introFadingIn:) finish:@selector(fadedIn:)];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) introFadingIn:(Timer*)timer
{
  fadeValue = timer.fraction;
  speed = timer.fraction * (1+1.0f*index/NUM_MENU_FLOWERS);
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadingIn:(Timer*)timer
{
  fadeValue = timer.fraction;
  [self moveBy:CGPointMake(0,-3*timer.delta/timer.duration)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadedIn:(Timer*)timer
{
  fadeTimer = nil;
  fadeValue = 1;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startFadeOut
{
  if (fadeTimer) [fadeTimer stop];
  fadeTimer = [Timer timerWithDuration:1.0f object:self tick:@selector(fadingOut:) finish:@selector(fadedOut:)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadingOut:(Timer*)timer
{
  fadeValue = timer.fraction;
  rotation *= 1+timer.fraction*0.2f;
  alpha     = 1.0f-max(0.0f, timer.fraction-0.5f)/0.5f;
  [self moveBy:CGPointMake(0,-3*timer.delta/timer.duration)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadedOut:(Timer*)timer
{
  fadeTimer = nil;
  fadeValue = 0;
  [[Controller instance] removeEventReceiver:self type:@"frame"];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) moveBy:(CGPoint)vector
{
  CGPoint p = CGPointAdd(rect.origin, vector);
  rect = CGRectMake(p.x, p.y, rect.size.width, rect.size.height);
  shadowRect = CGRectScale(rect, SHADOW_SIZE); 
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  //NSLog(@"Stone dealloc %@", self);
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) transform:(CGAffineTransform)trans
{
  rect.origin = CGPointApplyAffineTransform(rect.origin, trans);
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) onEvent:(Event*)event
{
  if ([event isKindOfClass:[FrameEvent class]])
  {
    [self onFrame:((FrameEvent*)event).delta];
  }
  
  return YES;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onFrame:(double)delta
{  
  [self moveBy:CGPointMake(0,-0.1f*delta*speed)];
  
  if (fadeValue == 1)
  {
    if (rect.origin.y < -1.5-SHADOW_SIZE*rect.size.height) 
    {
      [self initRect:1.5f+((SHADOW_SIZE-1)*rect.size.height)/2];
      
      sprite = [self randomFlower];
      
      alpha = [[MainMenu instance].currScreen.name isEqualToString:@"Campaign"] ? 0.25f : 1.0f;
    }
  }
  
  angle += delta * rotation;
  
  CGAffineTransform rot = CGAffineTransformMakeRotation(angle);
  float w = rect.size.width/2.0f;
  float h = rect.size.height/2.0f;
  CGPoint center = CGRectCenter(rect);
  CGPoint points[4] = { CGPointAdd(center, CGPointApplyAffineTransform(CGPointMake(-w,-h), rot)),
                        CGPointAdd(center, CGPointApplyAffineTransform(CGPointMake( w,-h), rot)),
                        CGPointAdd(center, CGPointApplyAffineTransform(CGPointMake(-w, h), rot)),
                        CGPointAdd(center, CGPointApplyAffineTransform(CGPointMake( w, h), rot)) };

  [shadowSprite drawWithRect:shadowRect alpha:alpha layer:layer];
  [sprite drawWithPoints:points alpha:alpha layer:layer+1];
}

@end
