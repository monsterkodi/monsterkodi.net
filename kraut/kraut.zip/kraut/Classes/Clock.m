//
//  Clock.m

#import "Clock.h"
#import "Game.h"
#import "Help.h"
#import "Sprite.h"
#import "Timer.h"
#import "Line.h"
#import "Quad.h"
#import "Text.h"
#import "Animation.h"
#import "Controller.h"
#import "Sound.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation Clock
//------------------------------------------------------------------------------------------------------------------------

@synthesize time;
@synthesize totalTime;
@synthesize duration;
@synthesize nextLevelTime;
@synthesize level;
@synthesize levelSequence;
@synthesize running;
@synthesize paused;
@synthesize active;
@synthesize rect;
@synthesize color;
@synthesize mode;

enum {SIDE_LEFT, SIDE_CENTER, SIDE_RIGHT}; 
enum {LAYER_BG,  LAYER_FG,    LAYER_ADD};

int   levelDurations[10] = {60, 50, 40, 30, 25, 20, 15, 10, 5, 3};
float levelTimes[9][9] = {
{180,180,120,120,120, 60, 60, 60, 60}, 
{180,180,180,120,120,120, 60, 60, 60},
{240,180,180,180,120,120, 60, 60, 60},
{300,240,180,180,120,120, 60, 60, 60},
{360,300,240,180,120,120, 60, 60, 60},
{420,360,300,240,180,120, 60, 60, 60},
{480,420,360,300,240,180,120, 60, 60},
{540,480,420,360,300,240,180,120, 60},
{600,540,480,420,360,300,240,180,120}
};
int   levelSequenceIndices[7][3] = {
{0,1,2}, // 5x5
{1,2,3}, // 6x6
{2,3,4}, // 7x7
{3,4,5}, // 8x8
{4,5,6}, // 9x9
{5,6,7}, // 10x10
{6,7,8}, // 11x11
}; 

//------------------------------------------------------------------------------------------------------------------------
+ (Clock*) instance
{
  return [Game current].clock;
}

//------------------------------------------------------------------------------------------------------------------------
- (id) init
{
  if ((self = [super init]))
  {
    sprite[0][0] = [Sprite withName:@"clock_bg_left"];
    sprite[0][1] = [Sprite withName:@"clock_fg_left"];
    sprite[0][2] = [Sprite withName:@"clock_ad_left"];    
    sprite[1][0] = [Sprite withName:@"clock_bg_center"];
    sprite[1][1] = [Sprite withName:@"clock_fg_center"];
    sprite[1][2] = [Sprite withName:@"clock_ad_center"];    
    sprite[2][0] = [Sprite withName:@"clock_bg_right"];
    sprite[2][1] = [Sprite withName:@"clock_fg_right"];
    sprite[2][2] = [Sprite withName:@"clock_ad_right"];    
        
    [[Controller instance] addEventReceiver:self type:@"sleep"];
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [[Controller instance] removeEventReceiver:self type:@"sleep"];

  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) layout
{
  BOOL lefty = [Game current].lefty;
  
  float width = 2-[Game current].score.rect.size.width;
  rect = CGRectMake((lefty?-1:(1-width)), 0.5f+SCORE_HEIGHT/4, width, SCORE_HEIGHT/2); 
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setupWithDictionary:(NSDictionary*)dictionary
{
  mode          = [[dictionary valueForKey:@"mode"] intValue];
  time          = [[dictionary valueForKey:@"time"] floatValue];
  duration      = [[dictionary valueForKey:@"duration"] floatValue];
  totalTime     = [[dictionary valueForKey:@"totalTime"] floatValue];
  nextLevelTime = [dictionary  floatForKey:@"nextLevelTime" default:0];
  level         = [dictionary intForKey:@"level" default:0];
  levelSequence = [dictionary intForKey:@"levelSequence" default:0];
  displaytime = time;
}

//------------------------------------------------------------------------------------------------------------------------
- (NSDictionary*) dictionary
{
  return [NSDictionary dictionaryWithObjectsAndKeys:
          [NSString stringWithFormat:@"%d", mode], @"mode",
          [NSString stringWithFormat:@"%f", time], @"time",
          [NSString stringWithFormat:@"%f", duration], @"duration",
          [NSString stringWithFormat:@"%f", totalTime], @"totalTime",
          [NSString stringWithFormat:@"%f", nextLevelTime], @"nextLevelTime",
          [NSString stringWithFormat:@"%d", levelSequence], @"levelSequence",          
          [NSString stringWithFormat:@"%d", level], @"level",          
           nil];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startWithLevelInfo:(LevelInfo*)levelInfo
{
  totalTime = 0;
  duration  = levelInfo.clockDuration;
  
  level = 0;
  levelSequence = 0;
  nextLevelTime = 0;
  
  //NSLog(@"Clock::startWithLevelInfo duration %f totalTime %f level %d nextLevelTime %f", duration, totalTime, level, nextLevelTime);
  
  if ([levelInfo.mode isEqualToString:@"move_time"]) 
  {
    mode = MOVE_TIME;

    levelSequence = levelSequenceIndices[levelInfo.size-5][levelInfo.difficulty];
    duration = levelDurations[level];
    nextLevelTime = levelTimes[levelSequence][level];
    
    if ([[Game current] isKindOfClass:[Help class]])
    {
      nextLevelTime = 21;
      duration = 7;
      level = 8;
      
      //NSLog(@"Clock::startWithLevelInfo help! duration %f level %d nextLevelTime %f", duration, level, nextLevelTime);
    }
    
    time = displaytime = duration;
  }
  else if ([levelInfo.mode isEqualToString:@"pollen"])
  {
    mode = POLLEN;
    time = displaytime = 0;
  }
  else if ([levelInfo.mode isEqualToString:@"pattern"])
  {
    mode = PATTERN;
    time = displaytime = 0;
  }
  else if ([levelInfo.mode isEqualToString:@"clear"]) 
  {
    mode = CLEAR;
    time = displaytime = 0;
  }
  else if ([levelInfo.mode isEqualToString:@"puzzle"]) 
  {
    mode = CLEAR;
    time = displaytime = 0;
  }
  else if ([levelInfo.mode isEqualToString:@"bestmove"]) 
  {
    mode = BESTMOVE;
    time = displaytime = 0;
  }
  else if ([levelInfo.mode isEqualToString:@"help"])
  {
    mode = HELP;
    time = displaytime = 0;
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) addCount:(int)count
{
  if (mode == POLLEN) time = clamp(time + count, 0, duration);
  else if (mode == BESTMOVE) time = clamp(max(time, count), 0, duration);
  if (time >= duration) [[Game current] clockCounterFinished];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setCount:(int)count
{
  if (mode == PATTERN || mode == CLEAR) time = clamp(count, 0, duration);
  if (time >= duration) [[Game current] clockCounterFinished];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) addTimeForPollen:(int)pollen
{
  if (mode == MOVE_TIME)
    time = clamp(time + max(5, (pollen+1)*duration/10), 0, duration);
  else if (mode == POLLEN || mode == BESTMOVE)
    [self addCount:pollen];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onTick:(double)delta
{
  if (running && mode == MOVE_TIME) 
  {
    nextLevelTime -= delta;
    if (level < 9 && nextLevelTime <= 0) [self levelUp];
  }
      
  if (running) totalTime += delta;
    
  if (mode == MOVE_TIME)
  {
    if (running)
    {
      time -= delta;
      
      displaytime = (time < displaytime) ? time : displaytime * (1-delta*2) + time * (delta*2);
      
      if (time < 10.0f)
      {
        float f = (1-time/10.0f); f = f * f; f = 1+f*3;
        countdown = 0.1f + 0.9f*(sin(M_PI_2 + 20*M_PI*f*(1-time/10.0f))+1.0f)*0.5f;
      }
      else
      {
        countdown = 1.0f;
      }
      
      // debug:
      /*
      [[Sprite withName:@"blank"] drawWithRect:CGRectMake(-1,-1.4f,0.4f,0.1f) color:0x44000000 layer:_debug_];
      [[NSString stringWithFormat:@"%d %d:%d (%d %d)", (int)duration, (int)totalTime/60, ((int)totalTime)%60, level, (int)nextLevelTime] 
       drawAtPoint:POINT(-1,-1.4f) height:0.1f color:0x88ffffff layer:_debug_];
       */
      
      if (time < 0) [self onTimeRanOut];
    }
  }
  else
  {
    displaytime = displaytime * (1-delta*2) + time * delta*2;
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onFrame:(double)delta
{
  [self onTick:delta];
    
  uint c[3] = {0xffffffff, ALPHASCALE(color, countdown), ALPHASCALE(GLOW_COLOR, countdown)};
  
  CGRect offsetRect = CGRectMove(rect, offset);
  
  for (int l = LAYER_BG; l <= LAYER_ADD; l++) // bg, fg, ad
  {
    for (int s = SIDE_LEFT; s <= SIDE_RIGHT; s++) // left, center, right
    {
      CGRect r = offsetRect;
      if (l > LAYER_BG) r.size.width = max(r.size.height+2*PIXELSIZE, r.size.width*displaytime/duration);

      switch (s) // set rect origin
      {
        case SIDE_CENTER: r.origin.x += r.size.height/2;                break; 
        case SIDE_RIGHT:  r.origin.x += r.size.width - r.size.height/2; break; 
        default: break;
      }
      
      switch (s) // set rect size
      {
        case SIDE_LEFT: 
        case SIDE_RIGHT:  r.size.width  = r.size.height/2;  break; 
        case SIDE_CENTER: r.size.width -= r.size.height;    break;
      }
                  
      [sprite[s][l] drawWithRect:r color:c[l]];
    }
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onTimeRanOut
{ 
  if (mode == MOVE_TIME)
  {
    [[Game current] arcadeTimeRanOut];
    time = duration;  
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) digitAdded:(int)index
{
}

//------------------------------------------------------------------------------------------------------------------------
- (void) levelUp
{
  level       = level+1;
  duration    = levelDurations[level];
  nextLevelTime = level < 9 ? levelTimes[levelSequence][level] : 0;
  //NSLog(@"levelUp level %d duration %f nextLevelTime %f", level, duration, nextLevelTime);
  time        = min(duration, time);
  displaytime = min(duration, displaytime);
  
  NSString * levelUpText = [NSString stringWithFormat:@"Level %d", level+1];
  [PopupDisplay displayString:levelUpText atPoint:POINT(0,0.6f) duration:3.0f];
  [Sound play:@"levelup"];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) start
{
  //NSLog(@"Clock::start duration %f totalTime %f level %d", duration, totalTime, level);
  
  running = TRUE;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) stop
{
  if (countdownTimer) { [countdownTimer stop]; countdownTimer = nil; }
  running = FALSE;
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) onEvent:(Event*)event
{
  if      ([event isKindOfClass:[FrameEvent class]]) [self onFrame:((FrameEvent*)event).delta];  
  else if ([event isKindOfClass:[SleepEvent class]]) 
  {
    if (active)
    {
      SleepEvent * sleepEvent = (SleepEvent*)event;
      if (!sleepEvent.wakeup)
      {
        paused = TRUE;
        if (countdownTimer) { [countdownTimer stop]; countdownTimer = nil; }
        [self stop];
      }
      else if (sleepEvent.wakeup)
      {
        paused = FALSE;
        countdown = 0;
        if (countdownTimer) [countdownTimer stop];
        if (mode == MOVE_TIME) [self startCountDown];
      }
    }
  }
  return YES;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) moveBy:(CGPoint)vector
{
  rect.origin = CGPointAdd(self.rect.origin, vector);
}

//------------------------------------------------------------------------------------------------------------------------
- (void) moveTo:(CGPoint)point
{
  [self moveBy:CGVector(rect.origin, point)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeIn
{
  active = TRUE;
  countdown = 0;
  [[Controller instance] addEventReceiver:self type:@"frame"];
  if (fadeTimer) [fadeTimer stop];
  fadeTimer = [Timer timerWithDuration:GAME_FADE_IN_TIME object:self tick:@selector(fadingIn:) finish:@selector(fadedIn:)];
  // layout is called by score
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadingIn:(Timer*)timer
{
  offset = CGPointMake(0,(1-timer.fraction)*3);
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadedIn:(Timer*)timer
{
  fadeTimer = nil;
  offset = CGPointMake(0,0);
  if (countdownTimer) [countdownTimer stop];
  if (mode == MOVE_TIME)
  {
    [self startCountDown];
  }
  else
  {
    countdown = 1.0f;
    [self start];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeOut
{
  active = FALSE;
  [self stop];
  if (fadeTimer) [fadeTimer stop];
  fadeTimer = [Timer timerWithDuration:GAME_FADE_OUT_TIME object:self tick:@selector(fadingOut:) finish:@selector(fadedOut:)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadingOut:(Timer*)timer
{
  offset = CGPointMake(0,-3*timer.fraction);
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadedOut:(Timer*)timer
{
  fadeTimer = nil;
  [[Controller instance] removeEventReceiver:self type:@"frame"];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startCountDown
{
  [countdownTimer stop];
  countdownTimer = [Timer timerWithDuration:3.0f object:self tick:@selector(countDown:) finish:@selector(countedDown:)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) countDown:(Timer*)timer
{
  countdown = 0.1f + 0.9f*timer.fraction*(sin(-M_PI_2 + 5*M_PI*timer.fraction)+1.0f)*0.5f;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) countedDown:(Timer*)timer
{
  countdownTimer = nil;
  countdown = 1.0f;
  [self start];
}


@end
