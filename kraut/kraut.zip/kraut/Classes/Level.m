//
//  Level.m

#import "Level.h"
#import "Controller.h"
#import "Text.h"
#import "Game.h"
#import "ExtraButton.h"
#import "Campaign.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation LevelInfo
//------------------------------------------------------------------------------------------------------------------------

@synthesize size;
@synthesize mode;
@synthesize prize;
@synthesize clockDuration;
@synthesize difficulty;
@synthesize flowers;
@synthesize numFlowers;
@synthesize bees;
@synthesize bugs;
@synthesize buts;
@synthesize extrasUsed;
@synthesize key;

//------------------------------------------------------------------------------------------------------------------------
- (id) init
{
  if ((self = [super init]))
  {
    flowers = [[NSMutableArray arrayWithCapacity:3] retain];
    
    bees        = 1;
    bugs        = 1;
    buts        = 1;    
    numFlowers  = 4;
    
    extrasUsed  = 0;
  }
  
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (id) copy
{
  LevelInfo * copyInfo = [[LevelInfo alloc] init];
  [copyInfo.flowers release];
  copyInfo.size           = size;
  copyInfo.bees           = bees;
  copyInfo.bugs           = bugs;
  copyInfo.buts           = buts;
  copyInfo.mode           = [mode copy];
  copyInfo.prize          = [prize copy];
  copyInfo.flowers        = [flowers copy];
  copyInfo.numFlowers     = numFlowers;
  copyInfo.difficulty     = difficulty;
  copyInfo.clockDuration  = clockDuration;
  return copyInfo;
}

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithDictionary:(NSDictionary*)dict
{
  if ((self = [super init]))
  {
    flowers     = [[NSMutableArray arrayWithCapacity:3] retain];
    bees        = [dict valueForKey:@"bees"] ? [[dict valueForKey:@"bees"] intValue] : 0;
    bugs        = [dict valueForKey:@"bugs"] ? [[dict valueForKey:@"bugs"] intValue] : 0;
    buts        = [dict valueForKey:@"buts"] ? [[dict valueForKey:@"buts"] intValue] : 0;
    size        = [dict valueForKey:@"size"] ? [[dict valueForKey:@"size"] intValue] : 7;
    
    NSAssert([dict valueForKey:@"clock"] != nil, @"no clock set?");
    mode                        = [[dict valueForKey:@"mode"] copy];
    clockDuration               = [[dict valueForKey:@"clock"] floatValue];
    
    if ([dict valueForKey:@"prize"])
    {
      prize = [[dict valueForKey:@"prize"] copy];
    }
    else
    {
           if ([mode isEqualToString:@"pattern"])  prize = @"9x9";
      else if ([mode isEqualToString:@"bestmove"]) prize = @"10x10";
      else if ([mode isEqualToString:@"pollen"])   prize = @"11x11";
      else prize = @"prize05";
    }
    
    numFlowers    = [dict valueForKey:@"flowers"] ? [[dict valueForKey:@"flowers"] intValue] : 3;
    
    difficulty    = [dict valueForKey:@"difficulty"] ? [[dict valueForKey:@"difficulty"] intValue] : 0;
    
    if ([dict valueForKey:@"flowerNames"])
    {
      for (NSString * flowerName in [dict valueForKey:@"flowerNames"])
      {
        [flowers addObject:[StoneType withName:flowerName]];
      }
    }
    else
    {
      for (int i = 0; i < numFlowers; i++)
      {
        NSString * prizeOrMode = prize ? prize : mode; 
        int flowerIndex = [[[[[Campaign instance].info valueForKey:@"modeflowers"] valueForKey:prizeOrMode] objectAtIndex:i] intValue];
        NSString * flowerName = [NSString stringWithFormat:@"flower%02d", flowerIndex];
        
        [flowers addObject:[StoneType withName:flowerName]];
      }
    }
  }
  
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (NSDictionary*) dictionary
{
  NSMutableDictionary * dict = [NSMutableDictionary dictionaryWithCapacity:10];
  [dict setValue:[NSString stringWithFormat:@"%d", bees] forKey:@"bees"];
  [dict setValue:[NSString stringWithFormat:@"%d", bugs] forKey:@"bugs"];
  [dict setValue:[NSString stringWithFormat:@"%d", buts] forKey:@"buts"];
  [dict setValue:[NSString stringWithFormat:@"%d", size] forKey:@"size"];
  [dict setValue:[NSString stringWithFormat:@"%d", difficulty] forKey:@"difficulty"];
  [dict setValue:[NSString stringWithFormat:@"%f", clockDuration] forKey:@"clock"];
  [dict setValue:[NSString stringWithFormat:@"%d", numFlowers] forKey:@"flowers"];
  [dict setValue:prize forKey:@"prize"];
  [dict setValue:mode forKey:@"mode"];
  NSMutableArray * flowerNames = [NSMutableArray arrayWithCapacity:4];
  for (StoneType * stoneType in flowers) [flowerNames addObject:stoneType.name];
  [dict setValue:flowerNames forKey:@"flowerNames"];
    
  return [NSDictionary dictionaryWithDictionary:dict];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [mode     release];
  [prize    release];
  [flowers  release];
  [super    dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (NSString*) key
{
  return [NSString stringWithFormat:@"arcade %dx%d %@", size, size, DIFFICULTY[difficulty]];
}

@end

