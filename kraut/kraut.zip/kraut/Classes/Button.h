//
//  Button.h

#import "MenuObject.h"
//#import "Event.h"

@class Sprite;
@class Letters;
@class Timer;
@class StoneType;

//------------------------------------------------------------------------------------------------------------------------
@interface Button : MenuObject 
//------------------------------------------------------------------------------------------------------------------------
{
  NSString    * type;
  int           status;
  
  Letters     * letters;        // name letters
  float         nameHeight;     // original height of name letters
  float         letterHeight;   // current height of name letters
  
  Sprite      * sprite;         // sprite
  float         spriteSize;     // current sprite size
  CGPoint       spriteOffset;   // sprite center offset
  float         spriteAlpha;    // sprite alpha
  float         spriteAngle;    // sprite angle 
  
  CGRect        touchRect;
  BOOL          touched;
  
  Timer       * wiggleTimer;  
  Timer       * wiggleSoundTimer;  
}

@property (assign) NSString * type;
@property (assign) int        status;
@property (assign) CGRect     touchRect;
@property (assign) Letters  * letters;

+ (Button*)   buttonWithDictionary:dict parent:parent;

- (id)        initWithDictionary:(NSDictionary*)dict parent:(MenuObject*)parent;
- (void)      dealloc;
- (void)      moveBy:(CGPoint)vector;
- (void)      moveTo:(CGPoint)point;
- (void)      onFrame:(double)delta;
- (void)      onPress;
- (void)      onTouchDown:(TouchEvent*)event;
- (void)      onTouchUp:(TouchEvent*)event;
- (void)      fadeIn:(float)value;
- (void)      fadeOut:(float)value;
- (void)      wiggle:(Timer*)timer;
- (void)      startWiggle;
- (void)      stopWiggle;
- (void)      toggleWiggle;
- (BOOL)      isWiggling;

- (NSString*) defaultsKey;
- (NSString*) defaultsValue;
- (void)      setDefaults;
- (NSString*) getDefaults;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface ToggleButton : Button
//------------------------------------------------------------------------------------------------------------------------
{
}

- (id)    initWithDictionary:(NSDictionary*)dict parent:(MenuObject*)parent;
- (void)  setStatus:(int)newStatus;
- (void)  onPress;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface RadioButton : ToggleButton
//------------------------------------------------------------------------------------------------------------------------
{
}

- (id)    initWithDictionary:(NSDictionary*)dict parent:(MenuObject*)parent;
- (void)  onPress;

@end

typedef struct SpriteInfo_ {

  Sprite    * sprite;
  float       alpha;
  float       angle;
  uint        color;
  uint        layer;
  NSString  * colorname;
  CGRect      rect;
} SpriteInfo; 

//------------------------------------------------------------------------------------------------------------------------
@interface RadialButton : Button
//------------------------------------------------------------------------------------------------------------------------
{
  NSArray * values;
  float     touchAngleStart;
  float     touchAngle;
  float     letterRadius;
  NSMutableArray * lettersArray;
  NSMutableArray * lockedStati;
}

@property (assign) NSArray * values;

- (id)    initWithDictionary:(NSDictionary*)dict parent:(MenuObject*)parent;
- (void)  dealloc;
- (void)  setStatus:(int)status;
- (void)  moveTo:(CGPoint)point;
- (void)  onTouchMove:(TouchEvent*)event;
- (void)  onTouchDown:(TouchEvent*)event;
- (void)  onTouchUp:(TouchEvent*)event;
- (void)  onFrame:(double)delta;
- (void)  setStatus:(int)newStatus;
- (void)  sendEvent;
- (void)  clearStatusLocks;
- (void)  lockStatus:(int)statusToLock;
- (BOOL)  isLockedStatus:(int)checkStatus;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface FlowerButton : Button
//------------------------------------------------------------------------------------------------------------------------
{
  int index;
  StoneType * stoneType;
  Sprite * shadowSprite;
}

@property (assign) int index;

- (id)    initWithDictionary:(NSDictionary*)dict parent:(MenuObject*)parent;
- (void)  fadeIn:(float)value;
- (void)  onPress;
- (void)  onFrame:(double)delta;

@end

