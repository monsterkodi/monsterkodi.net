//
//  Sound.m

#import "Sound.h"
#import "Controller.h"
#import "Tools.h"

struct SoundInfo {
  NSString * id;
  NSString * file;
  int numSources;
  float volume;
};

struct SoundInfo Sounds[] = {
{@"flower60",            @"flb01",           10,  0.1f},
{@"flower31",            @"flb02",           10,  0.1f}, 
{@"flower22",            @"flb03",           10,  0.1f}, 
{@"flower20",            @"flb04",           10,  0.1f}, 
{@"flower71",            @"flb05",           10,  0.1f}, 
{@"flower42",            @"flb06",           10,  0.1f}, // double
{@"flower54",            @"flb06",           10,  0.1f}, // double
{@"flower50",            @"flb07",           10,  0.1f}, 
{@"flower00",            @"flb01",           10,  0.1f}, 
{@"flower01",            @"flb02",           10,  0.1f}, 
{@"flower02",            @"flb03",           10,  0.1f}, 
{@"flower04",            @"flb05",           10,  0.1f}, // double
{@"flower62",            @"flb05",           10,  0.1f}, // double 
{@"flower03",            @"flb04",           10,  0.1f}, 
{@"flower33",            @"flb08",           10,  0.1f}, // double
{@"flower53",            @"flb08",           10,  0.1f}, // double
{@"flower52",            @"flb09",           10,  0.1f}, 
{@"flower51",            @"flb10",           10,  0.1f}, 
{@"flower61",            @"flb11",           10,  0.1f},
{@"flower24",            @"flb12",           10,  0.1f}, // double 
{@"flower30",            @"flb12",           10,  0.1f}, // double 
{@"flower73",            @"flb13",           10,  0.1f}, 
{@"flower72",            @"flb14",           10,  0.1f}, 
{@"flower10",            @"flb01",           10,  0.1f}, // double
{@"flower23",            @"flb01",           10,  0.1f}, // double
{@"flower43",            @"flb02",           10,  0.1f}, 
{@"flower14",            @"flb03",           10,  0.1f}, 
{@"flower32",            @"flb04",           10,  0.1f}, // double
{@"flower70",            @"flb04",           10,  0.1f}, // double 
{@"flower74",            @"flb05",           10,  0.1f}, 
{@"flower21",            @"flb06",           10,  0.1f}, // double
{@"flower34",            @"flb06",           10,  0.1f}, // double
{@"flower41",            @"flb07",           10,  0.1f}, 
{@"flower44",            @"flb08",           10,  0.1f}, 
{@"flower63",            @"flb09",           10,  0.1f}, 
{@"flower64",            @"flb10",           10,  0.1f}, 
{@"flower40",            @"flb11",           10,  0.1f}, 
{@"flower11",            @"pnlty1",          10,  0.1f}, // penalty
{@"flower12",            @"pnlty2",          10,  0.1f}, // penalty
{@"flower13",            @"pnlty3",          10,  0.1f}, // penalty

{@"fl01",                @"flb01",           10,  0.1f},
{@"fl02",                @"flb02",           10,  0.1f}, 
{@"fl03",                @"flb03",           10,  0.1f}, 
{@"fl04",                @"flb04",           10,  0.1f}, 
{@"fl05",                @"flb05",           10,  0.1f}, 
{@"fl06",                @"flb06",           10,  0.1f},
{@"fl07",                @"flb07",           10,  0.1f},
{@"fl08",                @"flb08",           10,  0.1f},
{@"fl09",                @"flb09",           10,  0.1f},
{@"fl10",                @"flb10",           10,  0.1f},
{@"fl11",                @"flb11",           10,  0.1f},
{@"fl12",                @"flb12",           10,  0.1f},
{@"fl13",                @"flb13",           10,  0.1f}, 
{@"fl14",                @"flb14",           10,  0.1f}, 
{@"fl15",                @"flb15",           10,  0.1f}, 

{@"block drop",          @"blockdrop",        1,  0.4f}, 
{@"block rotate",        @"blockrotate",      4,  0.1f}, 
{@"drag start",          @"dragstart",        2,  0.5f}, 
{@"drag cancel",         @"dragcancel",       2,  0.5f},
{@"drag move",           @"mouseover",       10,  0.03f},
{@"drag end",            @"dragend",          1,  1.0f},
{@"stone explode",       @"stoneexplode",     2,  1.0f},
{@"score",               @"score",           30,  0.1f},
{@"penalty",             @"penalty",          1,  0.5f}, 
{@"button wiggle",       @"beeloop",          1,  1.0f},
{@"button press",        @"buttonpress",      4,  0.4f},
{@"dial button rotate",  @"buttondial",      10,  0.25f},
{@"game over",           @"gameover",         1,  0.8f},
{@"failed",              @"failed",           1,  0.5f},
{@"end of help",         @"endofhelp",        1,  0.7f},
{@"bee loop",            @"beeloop",          1,  1.0f},
{@"bug loop",            @"bugloop",          1,  0.5f},
{@"but loop",            @"butloop",          1,  0.5f},
{@"bug jump",            @"bugjump",          1,  0.5f},
{@"but jump",            @"butjump",          1,  0.5f},
{@"challenge completed", @"completed",        1,  0.8f},
{@"challenge open",      @"swoosh",          10,  0.2f},
{@"challenge kids",      @"kids",             1,  0.5f},
{@"fade in",             @"fadein",           1,  0.65f},
{@"fade in 2",           @"fadein2",          1,  0.7f},
{@"fade out",            @"fadeout",          1,  0.5f},
{@"game fade in",        @"gamefadein",       1,  0.7f},
{@"game fade out",       @"gamefadeout",      1,  0.5f},
{@"score100",            @"completed",        1,  0.7f},
{@"score75",             @"kids",             1,  0.3f},
{@"score50",             @"kids",             1,  0.2f},
{@"score30",             @"score50",          1,  0.2f},
{@"score20",             @"score50",          1,  0.15f},
{@"levelup",             @"levelup",          1,  0.5f},
{@"prizejump",           @"prizejump",       10,  0.5f},
{@"prizewon",            @"prizewon",         1,  1.0f},
{@"prizeexplode",        @"score",           10,  1.0f},
{@"song",                @"song",             1,  0.4f},
{nil, nil, 0}};

//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------

#define	AssertNoError(inMessage)     if (result != noErr) { printf("%s: %d\n", inMessage, (int)result);	return result; }
#define	AssertNoOALError(inMessage)  { int err = (int)alGetError(); if (err != AL_NO_ERROR) { printf("%s: %d\n", inMessage, err);	} }

//------------------------------------------------------------------------------------------------------------------------

ALenum GetAudioFormat(AudioStreamBasicDescription inFileFormat)
{
  assert (inFileFormat.mFormatID == kAudioFormatLinearPCM);
  assert (inFileFormat.mBitsPerChannel == 16);
  assert (inFileFormat.mChannelsPerFrame == 2 || inFileFormat.mChannelsPerFrame == 1);
  return (inFileFormat.mChannelsPerFrame == 1) ? AL_FORMAT_MONO16 : AL_FORMAT_STEREO16;
}

//------------------------------------------------------------------------------------------------------------------------

OSStatus OpenFile(const char *inFilePath, AudioFileID * outAFID)
{
	CFURLRef theURL = CFURLCreateFromFileSystemRepresentation(kCFAllocatorDefault, (UInt8*)inFilePath, strlen(inFilePath), false);
  
#if TARGET_OS_IPHONE
	OSStatus result = AudioFileOpenURL(theURL, kAudioFileReadPermission, 0, outAFID);
#else
	OSStatus result = AudioFileOpenURL(theURL, fsRdPerm, 0, &outAFID);
#endif
	CFRelease(theURL);

  return result;
}

//------------------------------------------------------------------------------------------------------------------------

OSStatus LoadFileDataInfo(const char *inFilePath, AudioFileID * outAFID, AudioStreamBasicDescription * outFormat, UInt64 * outDataSize)
{
	UInt32 thePropSize = sizeof(*outFormat);				
	OSStatus result = OpenFile(inFilePath, outAFID);
  AssertNoError("Error opening file");
  
	result = AudioFileGetProperty(*outAFID, kAudioFilePropertyDataFormat, &thePropSize, outFormat);
  AssertNoError("Error getting file format");
	
	thePropSize = sizeof(UInt64);
	result = AudioFileGetProperty(*outAFID, kAudioFilePropertyAudioDataByteCount, &thePropSize, outDataSize);
  AssertNoError("Error getting file data size");
  
	return result;
}

//------------------------------------------------------------------------------------------------------------------------

void * LoadFileData(const char * inFilePath, UInt32 * outDataSize, ALuint * outBufferID)
{
  AudioFileID theAFID = 0;
  OSStatus result = noErr;
  UInt64 theFileSize = 0;
  AudioStreamBasicDescription theFileFormat;
  
  result = LoadFileDataInfo(inFilePath, &theAFID, &theFileFormat, &theFileSize);
  *outDataSize = (UInt32)theFileSize;
  void * data = malloc(*outDataSize);
  
  result = AudioFileReadBytes(theAFID, false, 0, outDataSize, data);
  if (result != AL_NO_ERROR) 
  { 
    free(data); 
    return 0; 
  }
  
  assert (TestAudioFormatNativeEndian(theFileFormat));
  
  alGenBuffers(1, outBufferID);
  //AssertNoOALError("Error generating buffer");
  
  ALenum format = GetAudioFormat(theFileFormat);
  ((ALvoid	AL_APIENTRY	(*) (const ALint, ALenum, ALvoid*, ALsizei, ALsizei))alcGetProcAddress(NULL, (const ALCchar*) "alBufferDataStatic"))(*outBufferID, format, data, *outDataSize, theFileFormat.mSampleRate);
  //AssertNoOALError("Error attaching data to buffer");
  
  AudioFileClose(theAFID);
  
  return data;
}

//------------------------------------------------------------------------------------------------------------------------
@implementation SoundSample
//------------------------------------------------------------------------------------------------------------------------

@synthesize volume;

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithFile:(NSString*)file numSources:(int)numSources_ volume:(float)volume_
{
  if ((self = [super init]))
  {
    initVolume = volume_;
    volume = initVolume;
    numSources = numSources_;
    sources = calloc(sizeof(ALuint),numSources);
    alGenSources(numSources, sources);
    UInt32 dataSize;
    data = LoadFileData([file UTF8String], &dataSize, &buffer);
    
    if (!data || !dataSize) { NSLog(@"[ERROR] failed to load audio sample '%@'", file); return nil; }
    
    for (int i = 0; i < numSources; i++)
    {
      alSourcei(sources[i], AL_BUFFER, buffer);
      if (alGetError() != AL_NO_ERROR) { /* NSLog(@"[ERROR] failed to bind buffer to sources '%@'", file); */ return nil; }
    }
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) shutdown
{
  for (int i = 0; i < numSources; i++) alSourceStop(sources[i]);
  alDeleteSources(numSources, sources);
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{  
  free(sources);
  free(data);
  
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) play
{
  alSourceStop(sources[sourceIndex]);
  AssertNoOALError("Error stopping source");  
  alSourcePlay(sources[sourceIndex]);
  AssertNoOALError("Error starting source");  
  sourceIndex = (sourceIndex+1) % numSources;  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) loop
{
  if ([self isLooping])
  {
    loopCount++;
  }
  else
  {
    alSourceStop(sources[sourceIndex]);
    AssertNoOALError("Error stopping source");  
    alSourcei(sources[sourceIndex], AL_LOOPING, 1);
    alSourcePlay(sources[sourceIndex]);
    AssertNoOALError("Error starting source");  
    sourceIndex = (sourceIndex+1) % numSources; 
    loopCount = 1;
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) isLooping
{
  return loopCount > 0;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) stop
{
  if ([self isLooping]) 
  {
    loopCount--;
    if (loopCount == 0) alSourceStop(sources[sourceIndex]);
  }
  else
  {
    alSourceStop(sources[sourceIndex]);
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) playWithVolume:(float)volume_
{
  alSourcef(sources[sourceIndex], AL_GAIN, volume_ * volume);
  [self play];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) loopWithVolume:(float)volume_
{
  alSourcef(sources[sourceIndex], AL_GAIN, volume_ * volume);
  [self loop];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setVolume:(float)volume_
{
  volume = initVolume * volume_;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setPitch:(float)pitch
{
  alSourcef(sources[sourceIndex], AL_PITCH, pitch);
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setGain:(float)gain
{
  alSourcef(sources[sourceIndex], AL_GAIN, gain * volume);
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation Sound
//------------------------------------------------------------------------------------------------------------------------

@synthesize samples;

+ (Sound*) instance
{
  return [Controller instance].sound;
}

//------------------------------------------------------------------------------------------------------------------------
+ (void) play:(NSString*)sound
{
  [Sound play:sound volume:1];
}

//------------------------------------------------------------------------------------------------------------------------
+ (void) loop:(NSString*)sound
{
  [Sound loop:sound volume:1];
}

//------------------------------------------------------------------------------------------------------------------------
+ (void) play:(NSString*)sound volume:(float)volume
{
  SoundSample * sample = [[Sound instance].samples valueForKey:sound];
  if (sample) [sample playWithVolume:volume];
}

//------------------------------------------------------------------------------------------------------------------------
+ (SoundSample*) sampleWithName:(NSString*)name
{
  return [[Sound instance].samples valueForKey:name];
}

//------------------------------------------------------------------------------------------------------------------------
+ (void) loop:(NSString*)sound volume:(float)volume
{
  SoundSample * sample = [[Sound instance].samples valueForKey:sound];
  if (sample) [sample loopWithVolume:volume];
}

//------------------------------------------------------------------------------------------------------------------------
+ (void) changeSample:(NSString*)sound volume:(float)volume
{
  SoundSample * sample = [[Sound instance].samples valueForKey:sound];
  [sample setGain:volume];
}

//------------------------------------------------------------------------------------------------------------------------
+ (void) stop:(NSString*)sound
{
  SoundSample * sample = [[Sound instance].samples valueForKey:sound];
  if (sample) [sample stop];
}

//------------------------------------------------------------------------------------------------------------------------
+ (void) setVolume:(int)volume
{
  for (SoundSample * sample in [[Sound instance].samples allValues])
  {
    [sample setVolume:volume/10.0f];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) shutdown
{
  [[Controller instance] removeEventReceiver:self type:@"button"];
  
  for (SoundSample * sample in [samples allValues]) [sample shutdown];
    
  alcMakeContextCurrent(nil);
  alcDestroyContext(context);  
  alcCloseDevice(device);

  [samples release];
  samples = nil;

  context = nil;
  device = nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc 
{
  [self shutdown];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setup
{
  [[Controller instance] addEventReceiver:self type:@"button"];
  
  if (!(device = alcOpenDevice(NULL))) NSLog(@"[ERROR] unable to open sound device!");  
	((ALvoid	AL_APIENTRY	(*) (const ALdouble value))alcGetProcAddress(NULL, (const ALCchar*) "alcMacOSXMixerOutputRate"))(44100);
  if (!(context = alcCreateContext(device, NULL))) NSLog(@"[ERROR] unable to create sound context!");    
  alcMakeContextCurrent(context);
  
  samples = [[NSMutableDictionary dictionaryWithCapacity:64] retain];
  int i = 0;
  while (Sounds[i].id) 
  {
    NSString * file = [NSString stringWithFormat:@"Sounds/%@.caf", Sounds[i].file];
    SoundSample * sample = [[SoundSample alloc] initWithFile:file numSources:Sounds[i].numSources volume:Sounds[i].volume];
    [samples setValue:sample forKey:Sounds[i].id];
    [sample release];
    i++;
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) onEvent:(Event*)event
{
  if ([event isKindOfClass:[ButtonEvent class]])
  {
    ButtonEvent * buttonEvent = (ButtonEvent*)event;
    if ([buttonEvent.key isEqualToString:@"volume"])
    {
      [Sound setVolume:buttonEvent.status];
    }
  }
  return YES;
}

@end
