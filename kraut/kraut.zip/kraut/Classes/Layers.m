//
//  Layers.m

#import "Layers.h"
#import "Sprite.h"
#import "Text.h"

Layer layers[__layers__];

//------------------------------------------------------------------------------------------------------------------------
@implementation Layers
//------------------------------------------------------------------------------------------------------------------------

+ (batch*) batchForLayer:(int)layer texture:(uint)texid blend:(uint)blend
{
  NSAssert(texid, @"no texture id?");
  uint type = DATA_SPRITE|blend;
  Layer * l = &layers[layer];
  batch * b;
  for (int batchIndex = 0; batchIndex < l->count; batchIndex++)
  {
    b = &l->batches[batchIndex];
    //NSLog(@"FOUND batch for layer %d texture %d type %04x", layer, b->texid, b->type);
    if ((b->type == type) && (b->texid == texid)) 
      return b;
  }

  //NSLog(@"new batch for layer %d texture %d blend %04x (type %04x)", layer, texid, blend, type);

  b = [Layers newBatchOfType:type layer:layer];
  b->texid = texid;
  return b;
}

//------------------------------------------------------------------------------------------------------------------------

+ (void) drawSprite:(Sprite*)sprite withPoints:(CGPoint*)points_ color:(uint)color
{
  [Layers drawSprite:(Sprite*)sprite withPoints:(CGPoint*)points_ color:(uint)color layer:(uint)sprite.layer];
}

//------------------------------------------------------------------------------------------------------------------------

+ (void) drawSprite:(Sprite*)sprite withPoints:(CGPoint*)points_ color:(uint)color layer:(uint)_layer_
{
  batch * b = [Layers batchForLayer:_layer_ texture:sprite.texid blend:sprite.blend];
  if (b->count+6 > b->alloc)
  {
    b->alloc += 64;
    b->verts  = reallocf(b->verts, b->alloc * b->vsize);
    if (b->verts == 0) { b->count = 0; b->alloc = 0; return; }
  }
  float * points = (float*)points_;
  sprite_vertex * v = &((sprite_vertex*)b->verts)[b->count];
  v->x = points[0];  v->u = sprite.uv[0]; 
  v->y = points[1];  v->v = sprite.uv[3]; v->c = color; v++; b->count++;
  v->x = points[2];  v->u = sprite.uv[2]; 
  v->y = points[3];  v->v = sprite.uv[3]; v->c = color; v++; b->count++;

  v->x = points[4];  v->u = sprite.uv[0]; 
  v->y = points[5];  v->v = sprite.uv[1]; v->c = color; v++; b->count++;

  v->x = points[2];  v->u = sprite.uv[2]; 
  v->y = points[3];  v->v = sprite.uv[3]; v->c = color; v++; b->count++;

  v->x = points[4];  v->u = sprite.uv[0]; 
  v->y = points[5];  v->v = sprite.uv[1]; v->c = color; v++; b->count++;
  v->x = points[6];  v->u = sprite.uv[2]; 
  v->y = points[7];  v->v = sprite.uv[1]; v->c = color; v++; b->count++;
}

//------------------------------------------------------------------------------------------------------------------------
+ (void) drawSprite:(Sprite*)sprite withPointArray:(float*)points color:(uint)color;
{
  [Layers drawSprite:sprite withPointArray:points color:color layer:sprite.layer];
}

//------------------------------------------------------------------------------------------------------------------------
+ (void) drawSprite:(Sprite*)sprite withPointArray:(float*)points color:(uint)color layer:(uint)_layer_
{
    
  batch * b = [Layers batchForLayer:_layer_ texture:sprite.texid blend:sprite.blend];
  if (b->count+6 > b->alloc)
  {
    b->alloc += 64;
    b->verts  = reallocf(b->verts, b->alloc * b->vsize);
    if (b->verts == 0) { b->count = 0; b->alloc = 0; return; }
  }

  sprite_vertex * v = &((sprite_vertex*)b->verts)[b->count];
  v->x = points[0];  v->u = sprite.uv[0]; 
  v->y = points[1];  v->v = sprite.uv[3]; v->c = color; v++; b->count++;
  v->x = points[2];  v->u = sprite.uv[2]; 
  v->y = points[3];  v->v = sprite.uv[3]; v->c = color; v++; b->count++;
  v->x = points[4];  v->u = sprite.uv[0];
  v->y = points[5];  v->v = sprite.uv[1]; v->c = color; v++; b->count++;
  v->x = points[6];  v->u = sprite.uv[2]; 
  v->y = points[7];  v->v = sprite.uv[3]; v->c = color; v++; b->count++;
  v->x = points[8];  v->u = sprite.uv[0]; 
  v->y = points[9];  v->v = sprite.uv[1]; v->c = color; v++; b->count++;
  v->x = points[10]; v->u = sprite.uv[2]; 
  v->y = points[11]; v->v = sprite.uv[1]; v->c = color; v++; b->count++;
}

//------------------------------------------------------------------------------------------------------------------------
+ (void) addVertex:(sprite_vertex*)vert forSprite:(Sprite*)sprite layer:(uint)_layer_
{
  batch * b = [Layers batchForLayer:_layer_ texture:sprite.texid blend:sprite.blend];
  if (b->count+1 > b->alloc)
  {
    b->alloc += 64;
    b->verts  = reallocf(b->verts, b->alloc * b->vsize);
    if (b->verts == 0) { b->count = 0; b->alloc = 0; return; }
  }
  
  memcpy(&((sprite_vertex*)b->verts)[b->count++], vert, sizeof(sprite_vertex));
}  

//------------------------------------------------------------------------------------------------------------------------

- (void) dealloc
{
  for (int layerIndex = 0; layerIndex < __layers__; layerIndex++)
  {
    Layer * l = &layers[layerIndex];
    for (int batchIndex = 0; batchIndex < l->count; batchIndex++)
    {
      batch * b = &l->batches[batchIndex];
      glDeleteTextures(1, &b->texid);  
      free(b->verts);
    }
  }
  
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------

+ (batch*) newBatchOfType:(uint)type layer:(uint)layer
{
  Layer * l = &layers[layer];

  if (l->count+1 > l->alloc)
  {
    l->alloc += 8;
    l->batches = reallocf(l->batches, l->alloc * sizeof(batch));
    if (l->batches == 0) { l->count = 0; l->alloc = 0; return 0; }
  }
  
  batch * b = &l->batches[l->count++];
  b->alloc = 80;
  b->count = 0;
  b->type = type;
  
  b->vsize = (2 * sizeof(GLfloat) + 4 * sizeof(GLubyte));
  if (type & DATA_SPRITE) b->vsize += 2 * sizeof(GLfloat);
  
  b->verts = malloc(b->alloc * b->vsize);
  
  return b;
}  

//------------------------------------------------------------------------------------------------------------------------

+ (void) flush
{
  glEnableClientState(GL_VERTEX_ARRAY);
  glEnableClientState(GL_COLOR_ARRAY);
  
  uint tex   = 0;
  uint blend = 0;

  for (int layerIndex = 0; layerIndex < __layers__; layerIndex++)
  {
    Layer * l = &layers[layerIndex];
    for (int batchIndex = 0; batchIndex < l->count; batchIndex++)
    {
      batch * b = &l->batches[batchIndex];
      
      if (b->count == 0) continue;
      
      if (b->type & DATA_SPRITE) 
      {
        if (!tex)
        {
          glEnable(GL_TEXTURE_2D);
          glEnableClientState(GL_TEXTURE_COORD_ARRAY);
          tex = -1;
        }
      }
      else
      {
        if (tex) 
        {
          glDisable(GL_TEXTURE_2D);
          glDisableClientState(GL_TEXTURE_COORD_ARRAY);
          tex = 0;
        }
      }
      
      if (b->type & BLEND_MASK) 
      {
        if (!blend) { glEnable(GL_BLEND); blend = (b->type & BLEND_MASK); }
        if (b->type & BLEND_ADD)  glBlendFunc(GL_SRC_ALPHA, GL_ONE);
        else                      glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
      }
      else
      {
        if (blend) { glDisable(GL_BLEND); blend = 0; }
      }
      
      glVertexPointer  (2, GL_FLOAT,         b->vsize, b->verts);
      glColorPointer   (4, GL_UNSIGNED_BYTE, b->vsize, &(((vertex*)(b->verts))[0].c));
      
      if (tex)
      {
        glTexCoordPointer(2, GL_FLOAT, b->vsize, &((sprite_vertex*)(b->verts))->u);
        
        if (tex != b->texid)
        {
          glBindTexture(GL_TEXTURE_2D, b->texid);
          tex = b->texid;
        }
      }
      
      glDrawArrays(GL_TRIANGLES, 0, b->count);
            
      b->count = 0;
    }
  }
  
  glDisableClientState(GL_TEXTURE_COORD_ARRAY);  
  glDisableClientState(GL_VERTEX_ARRAY);
  glDisableClientState(GL_COLOR_ARRAY);
  glDisable(GL_TEXTURE_2D);
  glDisable(GL_BLEND); 
}

@end
