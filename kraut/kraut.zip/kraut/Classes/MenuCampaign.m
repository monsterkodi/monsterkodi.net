//
//  MenuCampaign.m
//  kraut

#import "MenuCampaign.h"
#import "Challenge.h"
#import "ChallengeFlower.h"
#import "Game.h"
#import "Timer.h"
#import "Sound.h"
#import "MenuText.h"
#import "Campaign.h"
#import "Awards.h"
#import "PrizeWheel.h"
#import "Controller.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation MenuCampaign
//------------------------------------------------------------------------------------------------------------------------

@synthesize scale;
@synthesize targetScale;
@synthesize wiggleAngle;
@synthesize offset;
@synthesize targetOffset;

//------------------------------------------------------------------------------------------------------------------------

- (id) initWithDictionary:(NSDictionary*)dict_ parent:(MenuObject*)parent_
{
  if ((self = [super initWithDictionary:dict_ parent:parent_]))
  {
    scale = 1.0f;
    targetScale = 1.0f;
        
    flowers = [[NSMutableArray arrayWithCapacity:64] retain];
    [self setupChallenges];
    prizeWheel = [[PrizeWheel alloc] initWithParent:self];
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  if (activeInfo)   [activeInfo   release];
  if (inactiveInfo) [inactiveInfo release];
  [prizeWheel release];
  [flowers release];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setupChallenges
{
  for (Challenge * challenge in [Campaign instance].challenges)
  {
    ChallengeFlower * flower = [[ChallengeFlower alloc] initWithChallenge:challenge];
    flower.point = [self pointForChallenge:challenge];
    flower.screen = self;
    [flowers addObject:flower];
    [flower release];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (ChallengeFlower*) flowerForChallenge:(Challenge*)challenge
{
  for (ChallengeFlower * flower in flowers)
    if (flower.challenge == challenge) return flower;
  return nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (CGPoint) pointForChallenge:(Challenge*)challenge
{
  if (challenge) return CGPointScale(CGPointMakeAngle(challenge.angle), challenge.ring * CAMPAIGN_RADIUS);
  return POINT(0,0);
}

//------------------------------------------------------------------------------------------------------------------------
- (void) animateZoom:(Timer*)timer
{
  float newScale = clamp(CGFade(scale, [timer.info floatValue], timer.fraction), CAMPAIGN_MIN_SCALE, CAMPAIGN_MAX_SCALE);
  targetOffset = CGPointScale(targetOffset, newScale/targetScale);
  targetScale = newScale;  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) zoomAnimated:(Timer*)timer
{
  targetScale = [timer.info floatValue];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startAnimationForSolvedChallenge:(Challenge*)challenge
{
  [prizeWheel showWithFlower:[self flowerForChallenge:challenge] 
                       count:[[Awards instance] countForPrize:challenge.levelInfo.prize]-1 
                       total:[[Awards instance] totalForPrize:challenge.levelInfo.prize]];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) playOpenChallengeSound:(Timer*)timer
{
  [Sound play:@"challenge kids"];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startAnimationForOpenedChallenges
{
  Campaign * campaign = [Campaign instance];
  if (fadeValue == 1)
  {
    int index = 0;
    if ([campaign.openedChallenges count])
    {
      for (Challenge * openedChallenge in campaign.openedChallenges) 
      {
        ChallengeFlower * openedFlower = [self flowerForChallenge:openedChallenge];
        [openedFlower startOpenAnimationWithDelay:index*0.5f];
        index++;
      }
      
      [Timer timerWithDuration:index*0.5f object:self tick:nil finish:@selector(playOpenChallengeSound:)];
    }
    [campaign.openedChallenges removeAllObjects];
  }
  else
  {
    for (Challenge * openedChallenge in campaign.openedChallenges) 
    {
      [[self flowerForChallenge:openedChallenge] openAnimated:nil];
      if (openedChallenge.status == LOCKED) openedChallenge.status = OPEN;
    }
    [campaign.openedChallenges removeAllObjects];
  }
  
  selectedFlower.selected = NO;
  selectedFlower = nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeIn:(float)value
{
  Campaign * campaign = [Campaign instance];
  
  fadeValue = value;

  if (value == 0)
  {
    Challenge * currentChallenge = campaign.currentChallenge;
    if (currentChallenge == nil) currentChallenge = campaign.solvedChallenge;
        
    if ([campaign.openedChallenges count] || campaign.solvedChallenge)
    {
      scale = targetScale = 2.0f;
    } 
    else if (!campaign.solvedChallenge && currentChallenge)
    {
      targetScale = scale = CAMPAIGN_MAX_SCALE;
      [self showInfo];
      [self selectFlower:[self flowerForChallenge:currentChallenge]];
    }
    targetOffset = CGPointScale([self pointForChallenge:currentChallenge], -scale);    
  }
  else if (value == 1)
  {        
    if (campaign.solvedChallenge)
    {
      if (campaign.solvedChallenge.isSolved)
        [self startAnimationForSolvedChallenge:campaign.solvedChallenge];
      else if (campaign.solvedChallenge.isPassed)
        [self startAnimationForOpenedChallenges];
      
      [Campaign instance].solvedChallenge = nil;
    }
  }
  
  offset = CGPointAdd(targetOffset, CGPointScale(self.menu.fadeInOffset, 1-value));
  for (ChallengeFlower * flower in flowers) flower.fadeValue = value;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeOut:(float)value
{
  if (value == 1) 
  {
    targetOffset = offset;
    [self hideInfo];
    [prizeWheel startFadeOut];
  }
  fadeValue = value;
  offset = CGPointAdd(targetOffset, CGPointScale(self.menu.fadeOutOffset, 1-value));
  for (ChallengeFlower * flower in flowers) flower.fadeValue = value;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onFrame:(double)delta
{
  time += delta;
  wiggleAngle = (1.0f+CAMPAIGN_MAX_SCALE/scale) * 10*sin( ((time)-(int)(time)) * M_PI * 2 );

  offset = CGPointFade(offset, targetOffset, offsetSpeed);
  scale  = CGFade(scale, targetScale, scaleSpeed);
  for (ChallengeFlower * flower in flowers) [flower draw];
  
  [activeInfo   draw];
  [inactiveInfo draw];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) showInfo
{
  if (activeInfo) [activeInfo release];
  activeInfo          = [[MenuText alloc] init];  
  activeInfo.point    = POINT(0,-0.7f);
  activeInfo.textSize = 0.09f;
  activeInfo.headSize = 0.12f;
  NSString * text;
  if      (selectedFlower.challenge.isLocked)  text = [NSString stringWithFormat:@"%@\n<red>Challenge is locked!\n<dark>(solve a nearby challenge first)", selectedFlower.challenge.title];
  else if (selectedFlower.challenge.isSolved)  text = [NSString stringWithFormat:@"%@\n<green>Challenge solved!", selectedFlower.challenge.text];
  else if (selectedFlower.challenge.isPassed)  text = [NSString stringWithFormat:@"%@\n<green>Passed. Clear without\n<green>using aides to solve!", selectedFlower.challenge.text];
  else                                         text = [NSString stringWithFormat:@"%@\n<dark>(double-tap the flower to start)", selectedFlower.challenge.text];
  [activeInfo setText:text];
  [activeInfo fadeIn:0 offset:POINT(-2, 0)];

  if (showInfoTimer) [showInfoTimer stop];
  showInfoTimer = [Timer timerWithDuration:1.0f object:self tick:@selector(showingInfo:) finish:@selector(infoShown:)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) showInfoForPrize:(NSString*)prize
{
  if (activeInfo) [activeInfo release];
  activeInfo          = [[MenuText alloc] init];  
  activeInfo.point    = POINT(0,-0.7f);
  activeInfo.textSize = 0.09f;
  activeInfo.headSize = 0.12f;
  NSString * text = [NSString stringWithFormat:@"[Prize won!]\n%@", [[Awards instance] textForPrize:prize]];
  [activeInfo setText:text];
  [activeInfo fadeIn:0 offset:POINT(-2, 0)];
  
  if (showInfoTimer) [showInfoTimer stop];
  showInfoTimer = [Timer timerWithDuration:1.0f object:self tick:@selector(showingInfo:) finish:@selector(infoShown:)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) showingInfo:(Timer*)timer
{
  [activeInfo fadeIn:timer.fraction offset:POINT(-2, 0)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) infoShown:(Timer*)timer
{
  showInfoTimer = nil;
  [activeInfo fadeIn:1 offset:POINT(-2, 0)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) hideInfo
{
  if (inactiveInfo) [inactiveInfo release];
  inactiveInfo = activeInfo;
  activeInfo = nil;
  if (hideInfoTimer) [hideInfoTimer stop];
  hideInfoTimer = [Timer timerWithDuration:1.0f object:self tick:@selector(hidingInfo:) finish:@selector(infoHidden:)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) hidingInfo:(Timer*)timer
{
  [inactiveInfo fadeOut:(1-timer.fraction) offset:POINT(2, 0)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) infoHidden:(Timer*)timer
{
  hideInfoTimer = nil;
  [inactiveInfo fadeOut:0 offset:POINT(2, 0)];
  [inactiveInfo release];
  inactiveInfo = nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) selectFlower:(ChallengeFlower*)flower
{
  //NSLog(@"selectFlower new %@ old %@", flower, selectedFlower);
  
  if (flower != selectedFlower)
  {
    if (selectedFlower)
    {
      [self hideInfo];
      selectedFlower.selected = NO;
    }
    selectedFlower = flower;
    
    if (selectedFlower) 
    {
      selectedFlower.selected = YES;
      [selectedFlower.type playSound];
      [self showInfo];
      
      [selectedFlower startAnimateSelection];
      
      [Campaign instance].currentChallenge = selectedFlower.challenge;
    }
    else
    {
      [Campaign instance].currentChallenge = selectedFlower.challenge;
    }
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onTouchDown:(TouchEvent*)event
{
  touchedFlower = nil;
  for (ChallengeFlower * flower in flowers) 
  {
    if ([flower containsPoint:event.point])
    {
      touchedFlower = flower;
      break;
    }
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onTouchUp:(TouchEvent*)event
{
  if (event.finger == 1 && !CGRectContainsPoint(((Button*)[self.parent.children lastObject]).touchRect, event.point))
  {
    if (selectedFlower && event.tapCount == 2 && [selectedFlower containsPoint:event.point] && [selectedFlower.challenge isOpen])
    {
      // debug:
      if ([[Controller instance] debug])
      {
        [selectedFlower.challenge solved];
        [[Awards instance] increaseCountForPrize:selectedFlower.challenge.prize];
        [self startAnimationForSolvedChallenge:selectedFlower.challenge];
      }
      else
      {
        [[Game instance] startChallenge:selectedFlower.challenge];
      }
    }
    else if (touchedFlower && [touchedFlower containsPoint:event.point])
    {
      targetOffset = CGPointScale(touchedFlower.point, -CAMPAIGN_MAX_SCALE);
      targetScale  = CAMPAIGN_MAX_SCALE;
      scaleSpeed   = 0.03f;
      offsetSpeed  = 0.05f;
      
      [self selectFlower:touchedFlower];
    }
    else
    {
      [self selectFlower:nil];
    }
  }
  touchedFlower = nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onTouchMove:(TouchEvent*)event
{
  if (event.finger == 1)
  {
    targetOffset = CGPointAdd(event.direction, targetOffset);
    float length = CGPointLength(targetOffset);
    targetOffset = CGPointScale(CGVectorNorm(targetOffset), min(scale*(CAMPAIGN_RINGS-1)*CAMPAIGN_RADIUS,length));
    
    offsetSpeed  = 0.2f;
    
    if (event.delta > 0.05f) touchedFlower = nil;
  }
  else if (event.finger == 2)
  {
    float newScale = clamp(targetScale * (1.0+event.distanceDelta/320.0f), CAMPAIGN_MIN_SCALE, CAMPAIGN_MAX_SCALE);
    targetOffset = CGPointScale(targetOffset, newScale/targetScale);
    targetScale = newScale;
    scaleSpeed   = 0.15f;
    offsetSpeed  = 0.2f;
  }
}

@end
