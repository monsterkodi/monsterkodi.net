//
//  HelpScriptAction.m
//  kraut

#import "HelpScriptAction.h"
#import "HelpScriptHandAction.h"
#import "HelpScriptSpriteAction.h"
#import "HelpScript.h"
#import "Help.h"
#import "MenuText.h"
#import "Timer.h"
#import "Bezier.h"
#import "Tools.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation HelpScriptAction
//------------------------------------------------------------------------------------------------------------------------

@synthesize script;

//------------------------------------------------------------------------------------------------------------------------
+ (HelpScriptAction*) withDict:(NSDictionary*)dict
{
  if ([dict valueForKey:@"ramp"] || [dict valueForKey:@"score"] || [dict valueForKey:@"bees"]) 
                                    return [[[HelpScriptSetupAction  alloc] initWithDictionary:dict] autorelease];
  if ([dict valueForKey:@"text"])   return [[[HelpScriptTextAction   alloc] initWithDictionary:dict] autorelease];
  if ([dict valueForKey:@"key"])    return [[[HelpScriptKeyAction    alloc] initWithDictionary:dict] autorelease];
  if ([dict valueForKey:@"sprite"]) 
  {
    if ([[dict valueForKey:@"sprite"] isEqualToString:@"hand"])
      return [[[HelpScriptHandAction alloc] initWithDictionary:dict] autorelease];
    else  
      return [[[HelpScriptSpriteAction alloc] initWithDictionary:dict] autorelease];
  }
  
  return [[[HelpScriptAction alloc] initWithDictionary:dict] autorelease];
}

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithDictionary:(NSDictionary*)dict
{
  if ((self = [super init]))
  {
    delay       = [dict floatForKey:@"delay" default:0];
    fadeInTime  = [dict floatForKey:@"fadeIn" default:0];
    fadeOutTime = [dict floatForKey:@"fadeOut" default:0];
    
    initDict = dict;
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  if (actionTimer) [actionTimer stop];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) play 
{
  if (delay) actionTimer = [Timer timerWithDuration:delay object:self tick:@selector(delayAction:) finish:@selector(delayFinished:)];
  else [self delayFinished:nil];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startAction { }

//------------------------------------------------------------------------------------------------------------------------
- (void) stop 
{
  if (actionTimer) { [actionTimer stop]; actionTimer = nil; }
  if (fadeOutTime)
    actionTimer = [Timer timerWithDuration:1.0f object:self tick:@selector(fadeOut:) finish:@selector(fadedOut:)];
  else [script actionFadedOut:self];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) delayAction:(Timer*)timer { }

//------------------------------------------------------------------------------------------------------------------------
- (void) delayFinished:(Timer*)timer 
{ 
  if (fadeInTime)
    actionTimer = [Timer timerWithDuration:fadeInTime object:self tick:@selector(fadeIn:) finish:@selector(fadedIn:)];
  else
    [self startAction]; 
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeIn:(Timer*)timer { fadeValue = timer.fraction; }
- (void) fadedIn:(Timer*)timer { fadeValue = 1; actionTimer = nil; [self startAction]; }

- (void) fadeOut:(Timer*)timer { fadeValue = 1-timer.fraction; }
- (void) fadedOut:(Timer*)timer { fadeValue = 0; actionTimer = nil; [script actionFadedOut:self]; }

//------------------------------------------------------------------------------------------------------------------------
- (NSString*) description
{
  return [NSString stringWithFormat:@"<HelpScriptAction initDict: %@>", initDict];
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation HelpScriptSetupAction
//------------------------------------------------------------------------------------------------------------------------

- (id) initWithDictionary:(NSDictionary*)dict
{
  if ((self = [super initWithDictionary:dict]))
  {
    ramp  = [dict valueForKey:@"ramp"];
    board = [dict valueForKey:@"board"];
    bees  = [dict valueForKey:@"bees"];
    bugs  = [dict valueForKey:@"bugs"];
    buts  = [dict valueForKey:@"buts"];
    score = [dict valueForKey:@"score"];
    // TODO? board = [dict valueForKey:@"board"];
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startAction
{
  //NSLog(@"startAction %@", self);
  Help * help = [Help instance];
  
  if (ramp || board)
  {
    [help.ramp explodeStones];  [help.ramp clear];
    [help.jump explodeStones];  [help.jump clear];
    [help.board explodeStones]; [help.board clear];        
  }

  [help.blockList release];
  help.blockList = nil;

  if (ramp)
  {
    if ([ramp count])
    {
      help.blockList = [[NSMutableArray arrayWithArray:ramp] retain];
      [help.ramp fill];
      [help nextBlock];
    }
  }
  if (board)
  {
    for (NSArray * fieldInfo in board)
    {
      NSString * str = [fieldInfo objectAtIndex:0];
      int col = [[str substringWithRange:NSMakeRange(1, 1)] intValue]-1;
      int row = [[str substringWithRange:NSMakeRange(2, 1)] intValue]-1;
      Field * field = [help.board fieldAtCol:col row:row];
      Stone * stone = [Stone ofType:[help.levelInfo.flowers objectAtIndex:[[fieldInfo objectAtIndex:1] intValue]]];
      [field setStone:stone];
      [stone fadeIn];
      [stone release];
    }
  }
  if (bees)  [help setBees:[bees intValue] bugs:[bugs intValue] buts:[buts intValue]];
  if (score) [help setScore:[score intValue]]; 
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation HelpScriptKeyAction
//------------------------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithDictionary:(NSDictionary*)dict
{
  if ((self = [super initWithDictionary:dict]))
  {
    key = [dict valueForKey:@"key"];
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startAction
{
  [script actionWithKey:key];
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation HelpScriptTextAction
//------------------------------------------------------------------------------------------------------------------------

- (id) initWithDictionary:(NSDictionary*)dict
{
  if ((self = [super initWithDictionary:dict]))
  {
    [dict setDefaultFloat:0     forKey:@"x"];
    [dict setDefaultFloat:0.4f  forKey:@"y"];
    [dict setDefaultFloat:0.1f  forKey:@"textHeight"];
    [dict setDefaultFloat:0.13f forKey:@"titleHeight"];
    
    fadeInTime  = [dict floatForKey:@"fadeIn"  default:1.0];
    fadeOutTime = [dict floatForKey:@"fadeOut" default:1.0];
    
    text = [[MenuText alloc] initWithDictionary:dict parent:nil];  
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [text release];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeIn:(Timer*)timer
{
  [text fadeIn:timer.fraction offset:POINT(2, 0)];
  [text draw];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startAction
{
  [text fadeIn:1 offset:POINT(2, 0)];
  [text draw];
  actionTimer = [Timer timerWithObject:self tick:@selector(display:)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) display:(Timer*)timer
{
  [text draw];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeOut:(Timer*)timer
{
  [text fadeOut:1-timer.fraction offset:POINT(-2, 0)];
  [text draw];
}


@end
