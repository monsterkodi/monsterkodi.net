//
//  Screen.h

#import "MenuObject.h"

@class Letters;
@class TouchEvent;
@class Timer;

#define SCREEN_FADE_IN_TIME   0.7f
#define SCREEN_FADE_OUT_TIME  1.0f

//------------------------------------------------------------------------------------------------------------------------
@interface Layout : MenuObject 
//------------------------------------------------------------------------------------------------------------------------
{
  NSString * layoutType;
}

- (id)    initWithDictionary:(NSDictionary*)dict parent:(MenuObject*)parent_;
- (void)  layout;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface Screen : Layout
//------------------------------------------------------------------------------------------------------------------------
{
  Timer   * fadeTimer;
  float     fadeInTime;
  float     fadeOutTime;
}

@property (assign) float fadeInTime;
@property (assign) float fadeOutTime;

- (id)        initWithDictionary:(NSDictionary*)dict parent:(MenuObject*)parent_;
- (void)      startFadeIn;
- (void)      startFadeOut;
- (void)      fadingIn:(Timer*)timer;
- (void)      fadedIn:(Timer*)timer;
- (void)      fadingOut:(Timer*)timer;
- (void)      fadedOut:(Timer*)timer;
- (BOOL)      isVisible;
- (void)      onTouchDown:(TouchEvent*)event;
- (void)      onTouchUp:(TouchEvent*)event;
- (void)      onTouchMove:(TouchEvent*)event;
- (NSString*) description;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface MenuScreen : Screen
//------------------------------------------------------------------------------------------------------------------------
{
  Letters      * letters;
  NSDictionary * backButtonDict;
}

- (id)    initWithDictionary:(NSDictionary*)dict parent:(MenuObject*)parent_;
- (void)  dealloc;
- (void)  startFadeIn;
- (void)  fadingIn:(Timer*)timer;
- (void)  fadedIn:(Timer*)timer;
- (void)  fadingOut:(Timer*)timer;
- (void)  fadedOut:(Timer*)timer;
- (void)  onFrame:(double)delta;

@end
