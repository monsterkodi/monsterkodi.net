//
//  Resources.h

#import <OpenGLES/EAGL.h>
#import <OpenGLES/ES1/gl.h>
#import <OpenGLES/ES1/glext.h>

@class Sprite;

//------------------------------------------------------------------------------------------------------------------------
@interface Resources : NSObject
//------------------------------------------------------------------------------------------------------------------------
{
  NSMutableDictionary * sprites;
  NSMutableArray      * layers;
}

@property(readonly) NSMutableDictionary * sprites;
@property(readonly) NSMutableArray      * layers;

- (id)      init;
- (void)    dealloc;
+ (id)      instance;

- (void)    loadSprites;
- (void)    loadFont;

- (Sprite*) sprite:(NSString*)imageName;
- (void)    move:(NSString*)image above:(NSString*)anotherImage;

+ (GLuint)  loadTexture:(NSString*)textureFile info:(struct TextureInfo*)info;

@end
