//
//  MenuAwards.h
//  kraut

#import "Button.h"
#import "Event.h"
#import "Awards.h"

//------------------------------------------------------------------------------------------------------------------------
typedef struct 
{
  float height;
  BOOL  open;
} AwardButtonInfo;

//------------------------------------------------------------------------------------------------------------------------
@interface MenuAwards : Button <EventReceiver>
//------------------------------------------------------------------------------------------------------------------------
{
  NSMutableArray * awards;
  int openAward;
  
  float minScrollOffset;
  float maxScrollOffset;
  float scrollValue;
  float scrollDelta;
  
  AwardButtonInfo * buttonInfos[NumAwards];
}

- (id)      initWithDictionary:(NSDictionary*)dict parent:(MenuObject*)parent;
- (void)    layout;
- (void)    fadeIn:(float)value;
- (void)    fadeOut:(float)value;
- (void)    onFrame:(double)delta;
- (void)    onTouchUp:(TouchEvent*)event;
- (void)    onTouchDown:(TouchEvent*)event;
- (void)    onTouchMove:(TouchEvent*)event;
- (BOOL)    onEvent:(Event*)event;
- (void)    toggleAwardAtIndex:(int)index;

@end
