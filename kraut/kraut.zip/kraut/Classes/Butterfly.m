//
//  Bug.m
//  kraut

#import "Butterfly.h"
#import "Sprite.h"
#import "ExtraButton.h"
#import "Bezier.h"
#import "Timer.h"
#import "Controller.h"
#import "Stone.h"
#import "Board.h"
#import "Sound.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation Butterfly
//------------------------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------------------------
- (id) init
{
  if ((self = [super init]))
  {
    layer = _extra_;
    sprite = [Sprite withName:@"but"];
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  //NSLog(@"dealloc %@", self);
  [stones release];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) goHome:(Timer*)timer
{
  point = [((Bezier*)(timer.info)) pointAtTime:timer.fraction];
  size = [Game current].fieldSize+0.15f*sin(timer.fraction*M_PI);
}

//------------------------------------------------------------------------------------------------------------------------
- (void) wentHome:(Timer*)timer
{
  moveTimer = nil;
  layer = _extra_;
  extraButton.extra = self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) goAway
{
  Orientation o = [Controller instance].orientation;
  CGPoint target, c1, c2;
  if (o == UP || o == DOWN) 
  {
    target = POINT(point.x + ((point.x > 0) ? -0.5f : 0.5f), -2.0f * DIR[o][1]);
    c1     = POINT(target.x, point.y + DIR[o][1]*0.75f);
    c2     = POINT(target.x, point.y - DIR[o][1]*0.75f);
    targetAngle = (point.x > 0) ? 180 : -180;
  }
  else
  {
    target = POINT(-DIR[o][0], point.y + ((point.y > -0.25f) ? -0.5f : 0.5f));
    c1     = POINT(point.x + DIR[o][0]*0.75f, target.y);
    c2     = POINT(point.x - DIR[o][0]*0.75f, target.y);      
    targetAngle = ((o == RIGHT) ? ((point.y > -0.25f) ? -180 : 180) : ((point.y > -0.25f) ? 180 : -180));
  }
  bezier = [Bezier from:point over:c1 and:c2 to:target];
  [self stopWiggle];
  
  [Sound stop:@"but loop"];
  [Sound play:@"but jump"];
  
  if (moveTimer) [moveTimer stop];
  moveTimer = [Timer timerWithDuration:1.5f object:self tick:@selector(goingAway:) finish:@selector(wentAway:) info:bezier];  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) goingAway:(Timer*)timer
{
  point = [((Bezier*)(timer.info)) pointAtTime:timer.fraction];
  size  = [Game current].fieldSize+0.10f*sin(timer.fraction*M_PI);
  angle = timer.fraction*targetAngle;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) wentAway:(Timer*)timer
{
  //NSLog(@"went away %@", self);
  moveTimer = nil;
  [self vanish];
  [[Game current] checkGameOver];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) goToStone:(Timer*)timer
{
  point = [((Bezier*)(timer.info)) pointAtTime:timer.fraction];
  size = [Game current].fieldSize+0.15f*sin(timer.fraction*M_PI);
}

//------------------------------------------------------------------------------------------------------------------------
- (void) eatStone
{
  if (stones && [stones count])
  {
    stone = [stones objectAtIndex:RANDOMI([stones count])];
    [stones removeObject:stone];
    if ([stones count] == 0) { [stones release]; stones = nil; }

    [self eat];
  }
  else 
  {
    [[Extras instance] removeActiveExtra:self];
    [self goAway];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) eat
{
  CGPoint target = CGRectCenter(stone.rect);
  CGPoint pointToTarget = CGVector(point, target);
  CGPoint pointToTargetNorm = CGVectorNorm(pointToTarget);
  CGPoint c1 = CGPointAdd(point,  CGPointScale(pointToTargetNorm, -0.5f));
  CGPoint c2 = CGPointAdd(target, CGPointScale(pointToTargetNorm,  0.5f));
  bezier = [Bezier from:point over:c1 and:c2 to:target];
  
  float time = max(0.8f, CGPointLength(pointToTarget));
  if (eatTimer) [eatTimer stop];
  eatTimer = [Timer timerWithDuration:time object:self tick:@selector(goToStone:) finish:@selector(arrivedAtStone:) info:bezier];  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) arrivedAtStone:(Timer*)timer
{
  //NSLog(@"arrived at stone %@ %@", self, stone);
  eatTimer = nil;
  [stone playSound];
  [stone explode];
  [self eatStone];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) deactivate
{
  //NSLog(@"deactivate %@", self);
  [super deactivate];
  [stone explode];
  for (stone in stones) [stone explode];
  [stones removeAllObjects];
  [stones release];
  stones = nil;
  stone = nil;
  
  [self goAway];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dragEnded:(DragEvent*)event
{
  [super dragEnded:event];

  Board * board = (Board*)event.target;
  Pos pos = [board posForPoint:point];
  
  [self jumpToPos:pos onBoard:board];
}

- (void) playWiggleSound { [Sound loop:@"but loop" volume:0.5f]; }
- (void) stopWiggleSound { [Sound stop:@"but loop"]; }

//------------------------------------------------------------------------------------------------------------------------
- (void) jumpToPos:(Pos)pos onBoard:(Board*)board
{
  //NSLog(@"jumpToPos %@", self);
  [Sound loop:@"but loop"];
  
  BOOL mainBoard = (board == [Game current].board);
  [super jumpToPos:pos onBoard:board];
  [Game current].levelInfo.buts--;

  if (mainBoard)
  {
    [[Extras instance] addActiveExtra:self];
    
    stones = [[NSMutableArray arrayWithCapacity:16] retain];
    stone  = [board fieldAtPos:pos].stone;
    stone.field.stone = nil;
    StoneType * type = stone.type;
    
    for (int col = pos.x - 1; col <= pos.x + 1; col++)
      for (int row = pos.y - 1; row <= pos.y + 1; row++)  
      {
        Stone * s = [board fieldAtCol:col row:row].stone;
        if (s.type == type && s != stone)
        {
          [stones addObject:s];
          s.field.stone = nil;
        }
      }

   [self eat];
  }
  else 
  {
    [self goAway];
  }
}

@end
