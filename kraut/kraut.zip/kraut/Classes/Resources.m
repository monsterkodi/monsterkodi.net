//
//  Resources.m

#import "Resources.h"
#import "Controller.h"
#import "Sprite.h"
#import "Layers.h"
#import "Text.h"

struct TextureInfo 
{
  NSString * file;
  int width, height;
  uint texid;
};

struct TextureInfo Textures[] = {
{@"font.png",      0,0,0}, // 0
{@"flowers.png",   0,0,0}, // 1
{@"kraut.png",     0,0,0}, // 2
{@"dial.png",      0,0,0}, // 3
{nil, 0,0,0}
};

struct SpriteInfo 
{
  NSString * name;
  int  texture;
  uint layer;
  uint blend;
  float uv[4];
};

struct SpriteInfo Sprites[] = {                  //  x0  y0  x1  y1
{@"blank",              2,  _text_,   BLEND_ALPHA, { 12, 12, 14, 14}},
{@"field",              2,  _field_,  BLEND_NONE,  {192,128,256,192}},
{@"field_highlight",    2,  _field_,  BLEND_ADD,   { 24,  0, 88, 64}},
{@"field_marker",       2,  _challenge_shadow_,  BLEND_ADD,   {192, 64,255,128}},
{@"button",             2,  _field_,  BLEND_ALPHA, { 88,  0,152, 64}},
{@"shadow",             2,  _shadow_, BLEND_ALPHA, {152,  0,216, 64}},
{@"flower_shadow",      2,  _shadow_, BLEND_ALPHA, { 24,  0, 88, 64}},
{@"pollen",             2,  _pollen_, BLEND_ADD,   {  0, 24, 16, 40}},
{@"score",              2,  _menu_,   BLEND_ADD,   {  1,  1, 23, 23}},
{@"debug.png",          2,  _debug_,  BLEND_ALPHA, {280,  0,344,128}},
{@"clock_bg_left",      2,  _field_,  BLEND_ALPHA, { 88,  0,120, 64}},
{@"clock_bg_center",    2,  _field_,  BLEND_ALPHA, {120,  0,121, 64}},
{@"clock_bg_right",     2,  _field_,  BLEND_ALPHA, {120,  0,152, 64}},
{@"clock_fg_left",      2,  _field_,  BLEND_ADD,   {  1,  1, 12, 23}},
{@"clock_fg_center",    2,  _field_,  BLEND_ADD,   { 12,  1, 13, 23}},
{@"clock_fg_right",     2,  _field_,  BLEND_ADD,   { 13,  1, 23, 23}},
{@"clock_ad_left",      2,  _field_,  BLEND_ADD,   {  0, 24,  8, 40}},
{@"clock_ad_center",    2,  _field_,  BLEND_ADD,   {  8, 24,  9, 40}},
{@"clock_ad_right",     2,  _field_,  BLEND_ADD,   {  9, 24, 16, 40}},
{@"extra_bg",           2,  _field_,  BLEND_ALPHA, {128, 64,192,128}},
{@"extra_add",          2,  _glow_,   BLEND_ADD,   {  0, 64, 64,128}},
{@"bug",                2,  _extra_,  BLEND_ALPHA, { 64, 64,128,128}},
{@"but",                2,  _extra_,  BLEND_ALPHA, {  0,128, 64,192}},
{@"bee",                2,  _extra_,  BLEND_ALPHA, { 64,128,128,192}},
{@"cup",                2,  _extra_,  BLEND_ALPHA, {255, 64,319,128}},
{@"award",              2,  _extra_,  BLEND_ALPHA, {319, 64,382,128}},
{@"egg",                2,  _extra_,  BLEND_ALPHA, {  0,188,168,403}},
{@"11x11",              2,  _extra_,  BLEND_ALPHA, {319,  0,382,64}},
{@"10x10",              2,  _extra_,  BLEND_ALPHA, {382,  0,446,64}},
{@"9x9",                2,  _extra_,  BLEND_ALPHA, {382, 64,446,128}},
{@"8x8",                2,  _extra_,  BLEND_ALPHA, {382,128,446,192}},
{@"dotscore",           2,  _extra_,  BLEND_ALPHA, {319,128,382,192}},
{@"hand",               2,  _hand_,   BLEND_ALPHA, {255,128,319,255}},
{@"dial",               3,  _menu_,   BLEND_ALPHA, {-1,-1,-1,-1}},
{nil, -1, 0, 0, {0,0,0,0}}};

//------------------------------------------------------------------------------------------------------------------------
@implementation Resources
//------------------------------------------------------------------------------------------------------------------------

@synthesize sprites;
@synthesize layers;

//------------------------------------------------------------------------------------------------------------------------
- (id) init
{
  if ((self = [super init]))
  {
    //NSLog(@"Resources::init");
        
    sprites = [[NSMutableDictionary dictionaryWithCapacity:64] retain];
    layers  = [[NSMutableArray arrayWithCapacity:64] retain];
  }
  
  return self;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) dealloc
{
  //NSLog(@"Resources::dealloc");
  
  [sprites release];
  [layers  release];
  
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
+ (id) instance
{
  return [[Controller instance] resources];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) loadSprites
{
  int i = 0;  
  while (Textures[i].file) 
  {
    NSString * imageFile = [NSString stringWithFormat:@"Images/%@", Textures[i].file];  
    [Resources loadTexture:imageFile info:&Textures[i]];
    i++;
  }
  
  float uv[4];

  i = 0;
  while (Sprites[i].name)
  {
    struct TextureInfo * texinfo = &Textures[Sprites[i].texture];
    int width = texinfo->width, height = texinfo->height;

    if (Sprites[i].uv[0] < 0) { uv[0] = 0.0f; uv[1] = 1.0f; uv[2] = 1.0f; uv[3] = 0.0f; }
    else                      { uv[0] = Sprites[i].uv[0]/width; uv[1] = Sprites[i].uv[1]/height; uv[2] = Sprites[i].uv[2]/width; uv[3] = Sprites[i].uv[3]/height; }

    Sprite * sprite = [[[Sprite alloc] initWithTextureId:texinfo->texid uv:uv] autorelease];
    sprite.layer = Sprites[i].layer;
    sprite.blend = Sprites[i].blend;
    [sprites setObject:sprite forKey:Sprites[i].name];
    [layers  addObject:sprite];
    i++;
  }
  
  for (int x = 0; x < 8; x++)
  {
    for (int y = 0; y < 5; y++)
    {
      struct TextureInfo * texinfo = &Textures[1];
      int width = texinfo->width, height = texinfo->height;
            
      uv[0] = x*128.0f/width; uv[2] = (x+1)*128.0f/width; uv[1] = y*128.0f/height;  uv[3] = (y+1)*128.0f/height;
      
      Sprite * sprite = [[[Sprite alloc] initWithTextureId:texinfo->texid uv:uv] autorelease];
      sprite.layer = _stone_;
      sprite.blend = BLEND_ALPHA;
      [sprites setObject:sprite forKey:[NSString stringWithFormat:@"flower%d%d", x, y]];
      [layers  addObject:sprite];
    }
  }
}

//------------------------------------------------------------------------------------------------------------------------

-(void) loadFont
{
  id font = [[[Font alloc] initWithTextureId:Textures[0].texid] autorelease];
  [sprites setObject:font forKey:@"font"];
  [layers  addObject:font];
}

//------------------------------------------------------------------------------------------------------------------------

- (Sprite*) sprite:(NSString*)imageName
{
  id sprite = [sprites objectForKey:imageName];
  if (!sprite) 
    NSLog(@"[WARNING] sprite %@ not found!", imageName);
  return sprite;
}

//------------------------------------------------------------------------------------------------------------------------

- (int) layerIndex:(NSString*)image
{
  id sprite = [self sprite:image];
  if (sprite) return [layers indexOfObject:sprite];
  return -1;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) move:(NSString*)image above:(NSString*)anotherImage
{
  id sprite = [self sprite:image];
  if (sprite)
  {
    [layers removeObject:sprite];
    [layers insertObject:sprite atIndex:[self layerIndex:anotherImage]+1];
  }
  else
  {
    NSLog(@"[WARNING] image layer not found: %@", image);
  }
}

//------------------------------------------------------------------------------------------------------------------------
+ (GLuint) loadTexture:(NSString*)textureFile info:(struct TextureInfo*)info
{
  CGImageRef    spriteImage;
	CGContextRef  spriteContext;
	GLubyte     * spriteData;
	size_t        width, height;
  GLuint        textureId = 0;
  
  glEnable(GL_TEXTURE_2D);
  
  //NSLog(@"creating texture for file %@", textureFile);
  
  spriteImage = [UIImage imageNamed:textureFile].CGImage;
  width = CGImageGetWidth(spriteImage);
  height = CGImageGetHeight(spriteImage);
  
  //NSLog(@"sprite image: %@ size: %dx%d", spriteImage, width, height);
  
  if (spriteImage)
  {
    spriteData = (GLubyte *) malloc(width * height * 4); // Allocated memory for the bitmap context
    spriteContext = CGBitmapContextCreate(spriteData, width, height, 8, width * 4, CGImageGetColorSpace(spriteImage), kCGImageAlphaPremultipliedLast);
    CGContextDrawImage(spriteContext, CGRectMake(0.0, 0.0, (CGFloat)width, (CGFloat)height), spriteImage); // draw the sprite image to the context
    CGContextRelease(spriteContext); // release context
    glGenTextures(1, &textureId); // generate a name for the texture
    glBindTexture(GL_TEXTURE_2D, textureId); // bind the texture name
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, spriteData); // create a 2D texture image
    free(spriteData); // Release the image data      
    //NSLog(@"texture created: %d %d", textureId, glGetError());
  }
  
  info->width = width;
  info->height = height;
  info->texid = textureId;
  return textureId;
}

@end
