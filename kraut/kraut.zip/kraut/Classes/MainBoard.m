//
//  MainBoard.m

#import "MainBoard.h"
#import "Controller.h"
#import "Game.h"
#import "Line.h"
#import "Extras.h"
#import "ExtraButton.h"
#import "Bug.h"
#import "Bee.h"
#import "Butterfly.h"
#import "Sound.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation MainBoard
//------------------------------------------------------------------------------------------------------------------------

@synthesize wigglingExtra;

- (id) init
{
  if ((self = [super init]))
  {    
    targetFields = [[NSMutableArray arrayWithCapacity:3] retain];
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeIn
{
  for (Field * field in fields) field.marked = NO;
  
  [super fadeIn];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadedOut:(Timer*)timer
{
  [super fadedOut:timer];
  
  for (id rec in [[[Controller instance] frameReceivers] copy])
  {
    if ([rec isKindOfClass:[Stone class]] || [rec isKindOfClass:[Extra class]])
    {
      //NSLog(@"clean up stone %@", rec);
      [[Controller instance] removeEventReceiver:rec type:@"frame"];
    }
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [targetFields release];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (NSMutableArray *) neighborsOfStone:(Stone*)stone
{
  NSMutableArray * neighbors = [NSMutableArray arrayWithCapacity:4];
  for (int i = 0; i < 4; i++)
  {
    Stone * n = [self stoneAtPos:[stone.field.pos sum:POS(DIR[i][0],DIR[i][1])]];
    if (n) [neighbors addObject:n];
  }
  return neighbors;
}

//------------------------------------------------------------------------------------------------------------------------
- (NSArray *) chainAtPos:(Pos)pos
{
  NSMutableArray * chain = [NSMutableArray arrayWithCapacity:6];
  NSMutableArray * check = [NSMutableArray arrayWithCapacity:12];
  Stone * stone = [self stoneAtPos:pos];
  StoneType * type = stone.type;
  [check addObject:stone];
    
  while ([check count])
  {
    stone = [check objectAtIndex:0];
    [check removeObjectAtIndex:0];
    [chain addObject:stone];
        
    NSMutableArray * neighbors = [self neighborsOfStone:stone];
    
    for (Stone * n in neighbors)
    {
      if (n.type == type || n.type == nil)
      {
        if (![chain containsObject:n] && ![check containsObject:n])
        {
          [check addObject:n];
        }
      }
    }
  }
  return (([chain count] > 3) ? chain : nil);
}

//------------------------------------------------------------------------------------------------------------------------
- (NSArray*) groupAtPos:(Pos)pos
{  
  NSMutableArray * group = [NSMutableArray arrayWithCapacity:6];
  NSMutableArray * check = [NSMutableArray arrayWithCapacity:12];
  Stone * stone = [self stoneAtPos:pos];
  StoneType * type = stone.type;
  [check addObject:[self stoneAtPos:pos]];
  
  while ([check count])
  {
    stone = [check objectAtIndex:0];
    [check removeObjectAtIndex:0];
    [group addObject:stone];
    
    NSMutableArray * neighbors = [self neighborsOfStone:stone];
    
    for (Stone * n in neighbors)
    {
      if (n.type == type)
      {
        if (![group containsObject:n] && ![check containsObject:n])
        {
          [check addObject:n];
        }
      }
    }
  }
  return group;
}

//------------------------------------------------------------------------------------------------------------------------
- (NSArray *) neighborsOfGroup:(NSArray*)group
{
  NSMutableArray * neighbors = [NSMutableArray arrayWithCapacity:12];
  for (Stone * stone in group)
  {
    NSMutableArray * stoneNeighbors = [self neighborsOfStone:stone];
    for (Stone * neighbor in stoneNeighbors)
      if (![neighbors containsObject:neighbor]) [neighbors addObject:neighbor];
  }
  return neighbors;
}

//------------------------------------------------------------------------------------------------------------------------
- (NSArray *) beeChainAtPos:(Pos)pos
{
  NSArray * beeGroup = [self groupAtPos:pos];
  NSArray * beeGroupNeighbors = [self neighborsOfGroup:beeGroup];
  
  NSMutableArray * chain = [NSMutableArray arrayWithCapacity:12];
  for (Stone * neighbor in beeGroupNeighbors)
  {
    Pos npos = neighbor.field.pos;
    NSArray * neighborChain = [self chainAtPos:npos];
    if ([neighborChain count] > 3) 
    {
      for (Stone * stone in neighborChain)
        if (![chain containsObject:stone]) [chain addObject:stone];
    }
  }
  return (([chain count] > 3) ? chain : nil);
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dropBlock:(Block*)block atPos:(Pos)pos
{
  [self setStonesForBlock:block atPos:pos];
  
  NSMutableArray * chains = [NSMutableArray arrayWithCapacity:3];
  NSArray        * poses  = [NSArray arrayWithObjects:[pos sum:[block indexPos:0]], pos, [pos sum:[block indexPos:2]], nil];
  
  for (int i = 0; i < 3; i++)
  {
    Pos stonePos = [poses objectAtIndex:i];
    
    Stone * stone = [self stoneAtPos:stonePos];
    NSAssert1(stone, @"no stone at pos %@?", stonePos);
    BOOL skip = NO;
    for (NSArray * chain in chains) if ([chain containsObject:stone]) skip = YES;
    if (!skip)
    {
      NSArray * chain = [self chainAtPos:stonePos]; 
      if (chain) [chains addObject:chain];
    }
  }
  
  [Sound play:@"block drop"];
  
  [game explodeChains:chains reason:EXPLODE_REASON_STONE_DROPPED];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) penaltyStone:(Stone*)stone arrivedAtPoint:(CGPoint)point
{
  Field * field = [self fieldAtPos:[self posForPoint:point]];
  if ([field isEmpty])
  {
    field.stone = stone;
    
    [stone playSound];
    
    NSMutableArray * chains = [NSMutableArray arrayWithCapacity:3];
    NSArray * chain = [self chainAtPos:[self posForPoint:point]]; 
    if (chain) [chains addObject:chain];
    
    [game explodeChains:chains reason:EXPLODE_REASON_PENALTY_STONE];
  }
  else
  {
    [stone explode];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) bee:(Bee*)bee arrivedAtPoint:(CGPoint)point
{
  Field * field = [self fieldAtPos:[self posForPoint:point]];
  if (![field isEmpty]) [field.stone explode];

  field.stone = (Stone*)bee;
    
  NSMutableArray * chains = [NSMutableArray arrayWithCapacity:3];
  NSArray * chain = [self beeChainAtPos:[self posForPoint:point]]; 
  if (chain) [chains addObject:chain];
  
  [game explodeChains:chains reason:EXPLODE_REASON_BEE_DROPPED];
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) retainStones { return YES; }

//------------------------------------------------------------------------------------------------------------------------
- (void) resetTargetFields
{
  for (Field * field in targetFields) 
  {
    field.highlight = NO;
    if (field.stone) field.stone.alpha = 1.0f;
  }
  [targetFields removeAllObjects];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) displayTargetForBlock:(Block*)block atPos:(Pos)pos
{
  if ([self isValidPos:pos] && [self hasSpaceForBlock:block atPos:pos])
  {
    for (int i = 0; i < [block.stones count]; i++)
    {
      Pos stonePos = [pos sum:[block indexPos:i]];
      Field * field = [self fieldAtPos:stonePos];
      field.highlight = YES;
      [targetFields addObject:field];
    }    
  }    
}

//------------------------------------------------------------------------------------------------------------------------
- (void) displayTargetForExtra:(Extra*)extra atPos:(Pos)pos
{  
  if ([self isValidPos:pos] && [self hasSpaceForExtra:extra atPos:pos])
  {
    if ([extra isKindOfClass:[Bee class]])
    {
      Field * field = [self fieldAtPos:pos];
      field.highlight = YES;
      if (field.stone) field.stone.alpha = 0.2f;
      [targetFields addObject:field];
    }
    else if ([extra isKindOfClass:[Bug class]])
    {
      for (int col = -1; col <= 1; col++)
        for (int row = -1; row <= 1; row++)
        {
          Pos offpos = [pos sum:POS(col, row)];
          Field * field = [self fieldAtPos:offpos];
          if (field)
          {
            [targetFields addObject:field];
            if (field.stone) field.stone.alpha = 0.2f;
          }
        }
    }
    else if ([extra isKindOfClass:[Butterfly class]])
    {
      StoneType * type = [self fieldAtPos:pos].stone.type;
      for (int col = pos.x-1; col <= pos.x+1; col++)
        for (int row = pos.y-1; row <= pos.y+1; row++)  
        {
          Stone * stone = [self stoneAtCol:col row:row]; 
          if ([stone isKindOfClass:[Stone class]] && stone.type == type)
          {
            Field * field = stone.field;
            [targetFields addObject:field];
            field.stone.alpha = 0.2f;
          }
        }
    }
  }

  int targetIndex = [self indexForPos:pos];
  if (targetIndex != extraTargetIndex && [targetFields count]) [Sound play:@"drag move"];
  extraTargetIndex = targetIndex;
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) hasSpaceForExtra:(Extra*)extra atPos:(Pos)pos
{
  if ([extra isKindOfClass:[Bee class]])
  {
    if ([[self fieldAtPos:pos] isEmpty]) return YES;
    if ([[self fieldAtPos:pos].stone isKindOfClass:[Bee class]]) return NO;
    return YES;
  }
  else if ([extra isKindOfClass:[Butterfly class]])
  {
    Field * field = [self fieldAtPos:pos];
    return (![field isEmpty] && [field.stone isKindOfClass:[Stone class]]);
  }
  else if ([extra isKindOfClass:[Bug class]])
  {
    for (int col = -1; col <= 1; col++)
      for (int row = -1; row <= 1; row++)
      {
        Field * field = [self fieldAtPos:[pos sum:POS(col, row)]];
        if (field.stone && [field.stone isKindOfClass:[Stone class]]) return YES;
      }
  }
  return NO;
}

//------------------------------------------------------------------------------------------------------------------------
// drag events

- (void) dragStarted:(DragEvent*)event
{
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dragMoved:(DragEvent*)event
{
  [self resetTargetFields];
  
  if ([event.object isKindOfClass:[Block class]])
  {
    Block * block = (Block*)event.object;
    Pos pos = [self posForPoint:CGRectCenter(block.center.rect)];
    [self displayTargetForBlock:block atPos:pos];
  }
  else if ([event.object isKindOfClass:[Extra class]])
  {
    Extra * extra = (Extra*)event.object;
    Pos pos = [self posForPoint:extra.point];
    [self displayTargetForExtra:extra atPos:pos];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dragCanceled:(DragEvent*)event
{
  extraTargetIndex = -1;
  [self resetTargetFields];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dragEnded:(DragEvent*)event
{ 
  extraTargetIndex = -1;
  [self resetTargetFields];
  
  if ([event.object isKindOfClass:[Block class]])
  {
    Block * block = (Block*)event.object;
    
    Pos pos = [self posForPoint:CGRectCenter(block.center.rect)];
    
    [self dropBlock:block atPos:pos];
  }
}

//------------------------------------------------------------------------------------------------------------------------
// touch events

- (void) onDown:(TouchEvent*)event
{
  Pos pos = [self posForPoint:event.point];
  if (wigglingExtra)
    [self displayTargetForExtra:wigglingExtra atPos:pos];
  else if (game.jump.block)
    [self displayTargetForBlock:game.jump.block atPos:pos];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onMove:(TouchEvent*)event
{
  if (![Controller instance].dragEvent)
  {
    [self resetTargetFields];
    Pos pos = [self posForPoint:event.point];
    if (wigglingExtra) 
      [self displayTargetForExtra:wigglingExtra atPos:pos];    
    else if (game.jump.block)
      [self displayTargetForBlock:game.jump.block atPos:pos];    
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onUp:(TouchEvent*)event
{
  if ([targetFields count])
  {
    Pos pos = [self posForPoint:event.point];
    if (wigglingExtra)
    {
      if ([self hasSpaceForExtra:wigglingExtra atPos:pos])
      {
        [wigglingExtra release];
        [wigglingExtra jumpToPos:pos onBoard:self];
      }
      [self resetTargetFields];
    }
    else
    {
      [self resetTargetFields];
      Block * block = game.jump.block;      
      if ([self hasSpaceForBlock:block atPos:pos])
      {
        [block retain];
        [game.jump setBlock:nil];
        [self dropBlock:block atPos:pos];
        [block release];
      }
    }
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onFrame:(double)delta
{
}

//------------------------------------------------------------------------------------------------------------------------
- (void) handleDragEvent:(DragEvent*)dragEvent
{
  if ([dragEvent.object isKindOfClass:[Block class]])
  {
    if (dragEvent.target == self) 
    {
      dragEvent.target = nil;
    }
    if ([self hasSpaceForBlock:dragEvent.object])
    {
      dragEvent.target = self;
    }
    else
    {
      [self resetTargetFields];
    }
  }
  else if ([dragEvent.object isKindOfClass:[Extra class]])
  {
    if (dragEvent.target == self)
    {
      dragEvent.target = nil;
    }
    Pos pos = [self posForPoint:dragEvent.point];
    if ([self isValidPos:pos] && [self hasSpaceForExtra:dragEvent.object atPos:pos])
    {
      dragEvent.target = self;
    }
    else
    {
      [self resetTargetFields];
    }      
  }  
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) onEvent:(Event*)event
{
  if ([event isKindOfClass:[DragEvent class]])
  {
    [self handleDragEvent:(DragEvent*)event];
    return YES;
  }
  else if ([event isKindOfClass:[TouchEvent class]])
  {
    TouchEvent * touchEvent = (TouchEvent*)event;
    if (CGRectContainsPoint(rect, touchEvent.point) && touchEvent.finger == 1)
    {
      if ([touchEvent.type isEqualToString:@"up"])
      {
        [self onUp:touchEvent];
      }
      else if ([touchEvent.type isEqualToString:@"down"])
      {
        [self onDown:touchEvent];
      }
      else if ([touchEvent.type isEqualToString:@"move"])
      {
        [self onMove:touchEvent];
      }
    }
  }
  
  return [super onEvent:event];
}

@end
