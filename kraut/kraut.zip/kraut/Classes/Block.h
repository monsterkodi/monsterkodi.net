//
//  Block.h

#import "Tools.h"
#import "Event.h"

@class StoneType;
@class Stone;
@class Timer;

//------------------------------------------------------------------------------------------------------------------------
@interface Block : NSObject <EventReceiver, DragObject>
//------------------------------------------------------------------------------------------------------------------------
{
  Orientation       orientation;
  NSMutableArray  * stones;
  Timer           * cancelTimer;
}

@property (assign)   NSMutableArray * stones;
@property (assign)   Orientation orientation;

- (id)      initWithFirst:(StoneType*)f center:(StoneType*)c last:(StoneType*)l;

- (void)    rotate:(int)steps;
- (void)    setOrientation:(Orientation)orientation;

- (BOOL)    onEvent:(Event*)event;

- (void)    dragStarted:(DragEvent*)event;
- (void)    dragMoved:(DragEvent*)event;
- (void)    dragEnded:(DragEvent*)event;
- (void)    dragCanceled:(DragEvent*)event;
- (void)    movedBack:(Timer*)timer;

- (void)    transform:(CGAffineTransform)trans;

- (Stone*)  center;
- (Stone*)  first;
- (Stone*)  last;

- (Pos)     indexPos:(int)stoneIndex;
- (BOOL)    isEmpty;

@end
