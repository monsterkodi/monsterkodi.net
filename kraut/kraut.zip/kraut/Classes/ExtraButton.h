//
//  ExtraButton.h
//  kraut

#import "SpriteButton.h"
#import "Event.h"

@class Extra;

//------------------------------------------------------------------------------------------------------------------------
@interface ExtraButton : SpriteButton <DragObject>
//------------------------------------------------------------------------------------------------------------------------
{
  NSString    * extraType;
  Extra       * extra;
}

@property (assign) Extra * extra;

- (id)    initWithDictionary:(NSDictionary*)dict parent:(MenuObject*)parent;
- (void)  dealloc;
- (void)  clear;
- (void)  addExtraFromPoint:(CGPoint)point;
- (void)  fill;
- (void)  nextExtra;

@end
