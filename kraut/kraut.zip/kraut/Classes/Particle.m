//
//  Particle.m

#import "Particle.h"
#import "Resources.h"
#import "Stone.h"
#import "Sprite.h"
#import "Score.h"
#import "Line.h"
#import "Timer.h"
#import "Tools.h"
#import "Controller.h"
#import "ChallengeFlower.h"
#import "MenuCampaign.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation Particle
//------------------------------------------------------------------------------------------------------------------------

@synthesize sprite;
@synthesize start;
@synthesize point;
@synthesize layer;
@synthesize target;
@synthesize speed;
@synthesize color;

//------------------------------------------------------------------------------------------------------------------------

+ (Particle *) withSprite:(Sprite*)sprite duration:(float)duration atPoint:(CGPoint)point to:(CGPoint)target speed:(CGPoint)speed color:(uint)color
{
  Particle * particle = [[Particle alloc] initWithTime:duration];
  
  particle.sprite = sprite;
  particle.start  = point;
  particle.point  = particle.start;
  particle.target = target;
  particle.speed  = speed;
  particle.color  = color;
  particle.layer  = sprite.layer;
  
  return particle;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) dealloc
{
  //NSLog(@"particle dealloc");
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithTime:(float)time
{
  if ((self = [super init]))
  {
    lifeTimer = [Timer timerWithDuration:time object:self tick:@selector(move:) finish:@selector(moved:)];
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) move:(Timer*)timer
{
  float sinus = sin(lifeTimer.fraction*M_PI);
  point = CGPointAdd(start, CGPointScale(CGVector(start, target), lifeTimer.fraction));
  point = CGPointAdd(point, CGPointScale(speed, sinus));
  float s = 0.05f+0.05f*sinus;
  float cosinus = (cos(lifeTimer.fraction*M_PI)+1)/2.0f;
  uint colr = ((uint)(cosinus * ((color & 0xff000000) >> 24)) << 24) | (color & 0xffffff);
  [sprite drawAtPoint:point size:CGSizeMake(s,s) color:colr layer:layer];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) moved:(Timer*)timer
{
  //[[Trail key:[self description]] delete];
  [self release];
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation Pollen
//------------------------------------------------------------------------------------------------------------------------

@synthesize radius;
@synthesize score;
@synthesize siblingCount;
@synthesize emitpollen;
@synthesize angle;
@synthesize switchangle;
@synthesize targetangle;
@synthesize pollenColor;
@synthesize speedfactor;

//------------------------------------------------------------------------------------------------------------------------
+ (void) explosionAt:(CGPoint)center radius:(float)radius sprite:(Sprite*)sprite color:(uint)color layer:(uint)layer speed:(float)speed count:(int)count
{
  Pollen * pollen;
  for (int i = 0; i < count; i++)
  {
    pollen = [[Pollen alloc] init];
    
    pollen.layer        = layer;
    pollen.sprite       = sprite;
    pollen.pollenColor  = color;
    
    pollen.start        = center;
    pollen.target       = CGPointAdd(pollen.start, CGPointScale(CGPointMakeAngle((i+1)*360/count), radius));
    
    pollen.radius       = 0.01f;
    pollen.targetangle  = CGPointAngle(CGVector(pollen.start, pollen.target));
    pollen.switchangle  = pollen.targetangle-90;
    pollen.angle        = pollen.switchangle-1;
    
    pollen.speed        = CGPointMake(RANDOMF(0.5f)-0.25f, RANDOMF(0.5f)-0.25f);    
    pollen.siblingCount = count;
    pollen.score        = 0;
    pollen.speedfactor  = speed;
    pollen.emitpollen   = YES;
  }
}

//------------------------------------------------------------------------------------------------------------------------
+ (void) forChallengeFlower:(ChallengeFlower*)flower speed:(float)speed count:(int)count
{
  [Pollen explosionAt:flower.targetCenter radius:0.75f sprite:flower.type.sprite color:flower.type.pollenColor layer:_challenge_ speed:speed count:count];
}

//------------------------------------------------------------------------------------------------------------------------

+ (void) forStone:(Stone*)stone count:(int)count score:(int)score
{
  int scorePerPollen = score/count;
  Pollen * pollen;
  for (int i = 0; i < count; i++)
  {
    pollen = [[Pollen alloc] init];

    pollen.sprite       = stone.type.sprite;
    pollen.pollenColor  = stone.type.pollenColor;

    pollen.start        = CGRectCenter(stone.field.rect);
    pollen.target       = [Score pollenTarget];
    
    pollen.radius       = 0.01f;
    pollen.targetangle  = CGPointAngle(CGVector(pollen.start, pollen.target));
    pollen.switchangle  = pollen.targetangle-90;
    pollen.angle        = pollen.switchangle-360 -i*360.0f/count;
    
    pollen.speed        = CGPointMake(RANDOMF(0.5f)-0.25f, RANDOMF(0.5f)-0.25f);    
    pollen.siblingCount = count;
    pollen.score        = scorePerPollen;
    pollen.speedfactor  = 1.3f;
    pollen.emitpollen   = ((count <= 2) || (i == count-1));
  }
  pollen.score += score - scorePerPollen * count;  
}

//------------------------------------------------------------------------------------------------------------------------
- (id) init
{
  if ((self = [super init]))
  {
    pollenSprite = [Sprite withName:@"pollen"];
    lifeTimer = [Timer timerWithObject:self tick:@selector(move:)];
    layer = _pollen_;
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) move:(Timer*)timer_
{
  float   delta = min(0.05f, lifeTimer.delta);
  
  CGPoint oldPoint = point;
  CGPoint pointToTarget = CGVector(point, target);
  float   pointToTargetDistance = CGPointLength(pointToTarget);
  
  if (angle <= switchangle) // first phase: rotate around target
  {
    angle  += clamp( speedfactor * delta * 360.0f, 0, 10.0f);
    radius +=        speedfactor * delta * 0.1f;
    
    float radAngle = DEG2RAD(angle);
    point = CGPointAdd(start, CGPointMake(-sin(radAngle)*radius, cos(radAngle)*radius));
  }
  else // second phase: aproach target
  {
    point = CGPointAdd(point, CGPointScale(CGVectorNorm(CGVector(point, target)), delta * speedfactor));
  }
  
  float finishfactor = clamp(pointToTargetDistance/0.4f, 0, 1);

  float s = 0.1f;

  distsum += max(absf(point.x-oldPoint.x), absf(point.y-oldPoint.y));
  if (emitpollen && distsum > s/2.0)
  {
    Orientation o = [Controller instance].orientation;
    
    Particle * p = [Particle withSprite:pollenSprite 
                               duration:1.5f-(1-finishfactor)
                                atPoint:point 
                                     to:CGPointMake(point.x-DIR[o][0]*0.2f, point.y-DIR[o][1]*0.2f) 
                                  speed:CGPointMake(DIR[o][0]*0.2f*finishfactor,DIR[o][1]*0.2f*finishfactor) 
                                  color:pollenColor];
    p.layer = layer;
    distsum = 0;
  }
    
  float ss = s*finishfactor;
  [sprite drawAtPoint:point size:CGSizeMake(ss,ss) alpha:finishfactor layer:layer];

  if (pointToTargetDistance < s) [self vanish];
  
  //[Trail key:[self description]]; [Trail color:0x4400ffff];
  //[Trail addPoint:point];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) vanish
{
  [lifeTimer stop];
  //[[Trail key:[self description]] delete];
  
  if (score) [[Score instance] pollenArrivedWithScore:score];
  [self release];
}

@end
