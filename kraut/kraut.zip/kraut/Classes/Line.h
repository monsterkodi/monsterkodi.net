//
//  Line.h

#import <OpenGLES/EAGL.h>
#import <OpenGLES/ES1/gl.h>
#import <OpenGLES/ES1/glext.h>

typedef struct line_data {
  GLfloat x, y;
  GLuint  c;
} line;

//------------------------------------------------------------------------------------------------------------------------
@interface Line : NSObject
//------------------------------------------------------------------------------------------------------------------------
{
  line   * lines; // line data buffer
  uint     alloc; // number of allocated lines
  uint     count; // number of used lines
  uint     lsize; // size of line data in bytes 
  uint     color; // color 
  NSString * key;
}

@property (assign) uint color;
@property (assign) NSString * key;

+ (void)  flushLines;
+ (Line*) instance;
+ (Line*) key:(NSString*)key;
+ (void)  from:(CGPoint)point to:(CGPoint)toPoint;
+ (void)  rect:(CGRect)rect;
+ (void)  color:(uint)color;

- (void)  from:(CGPoint)point to:(CGPoint)toPoint;
- (id)    init;
- (void)  initBuffer;
- (BOOL)  growBuffer:(uint)num;
- (void)  dealloc;
- (void)  delete;
- (void)  flush;
- (void)  flushed;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface Vector : Line
//------------------------------------------------------------------------------------------------------------------------
{
}

+ (void)    color:(uint)color;
+ (void)    from:(CGPoint)point dir:(CGPoint)vector;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface Trail : Line
//------------------------------------------------------------------------------------------------------------------------
{
}

+ (Trail*)  key:(NSString*)key;
+ (void)    color:(uint)color;
+ (void)    addPoint:(CGPoint)point;
+ (void)    clear;
- (void)    clear;
- (void)    flushed;
- (void)    addPoint:(CGPoint)point;

@end
