//
//  AnimBezier.m
//  kraut

#import "AnimBezier.h"
#import "Animation.h"
#import "Controller.h"
#import "Bezier.h"
#import "Sprite.h"
#import "Tools.h"
#import "Event.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation AnimBezierStatus
//------------------------------------------------------------------------------------------------------------------------

@synthesize point;
@synthesize angle;
@synthesize size;

//------------------------------------------------------------------------------------------------------------------------
+ (AnimBezierStatus*) withFloatArray:(NSArray*)array
{
  AnimBezierStatus * status = [[AnimBezierStatus alloc] init];
  
  status.point = CGPointMake([[array objectAtIndex:0] floatValue], [[array objectAtIndex:1] floatValue]);
  status.angle = [array count] > 2 ? [[array objectAtIndex:2] floatValue] : 0; 
  if ([array count] > 3)
  {
    NSArray * sizeArray = [array objectAtIndex:3];
    status.size = CGSizeMake([[sizeArray objectAtIndex:0] floatValue], [[sizeArray objectAtIndex:1] floatValue]);  
  }
  return [status autorelease];
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation AnimBezier
//------------------------------------------------------------------------------------------------------------------------

@synthesize bezier;
@synthesize duration;
@synthesize interpolation;
@synthesize startSize;
@synthesize endSize;
@synthesize startAngle;
@synthesize endAngle;
@synthesize startEvent;
@synthesize endEvent;

//------------------------------------------------------------------------------------------------------------------------
+ (AnimBezier*) withPoints:(CGPoint*)points
{
  AnimBezier * bez = [[AnimBezier alloc] init];
  bez.bezier = [[Bezier bezierWithPoints:points] retain];
  return [bez autorelease];
}

//------------------------------------------------------------------------------------------------------------------------
+ (AnimBezier*) from:(AnimBezierStatus*)start to:(AnimBezierStatus*)end
{
  CGPoint p[4];
  p[0] = start.point;
  p[3] = end.point;
  p[1] = CGPointAdd(p[0], CGPointScale(CGVector(p[0], p[3]),  0.33f));
  p[2] = CGPointAdd(p[3], CGPointScale(CGVector(p[0], p[3]), -0.33f));
  AnimBezier * bez = [AnimBezier withPoints:p];
  bez.startSize  = start.size;
  bez.endSize    = end.size;
  bez.startAngle = start.angle; 
  bez.endAngle   = end.angle; 
  return bez;
}

//------------------------------------------------------------------------------------------------------------------------
- (id) init
{
  if ((self = [super init]))
  {
    interpolation = SMOOTH;
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [startEvent release];
  [endEvent release];
  [bezier release];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) sendStartEvent
{
  if (startEvent) [[Controller instance] sendEvent:startEvent];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) sendEndEvent
{
  if (endEvent) [[Controller instance] sendEvent:endEvent];
}

//------------------------------------------------------------------------------------------------------------------------
- (float) valueForTime:(float)time
{
  float value = time;
  if      (interpolation == SMOOTH) value = -2*time*time*time+3*time*time;
  else if (interpolation == SPRING) value = [Animation springValue:time from:0 to:1 ratio:0.5f overshot:0.1f];
  return value;
}

//------------------------------------------------------------------------------------------------------------------------
- (CGPoint) pointAtTime:(float)time
{
  return [bezier pointAtTime:[self valueForTime:time]];
}

//------------------------------------------------------------------------------------------------------------------------
- (AnimBezierStatus*) statusAtTime:(float)time
{
  AnimBezierStatus * status = [[AnimBezierStatus alloc] init];
  float value   = [self valueForTime:time];
  status.point  = [bezier pointAtTime:value];
  status.size   = CGSizeMake(CGFade(startSize.width, endSize.width, value), CGFade(startSize.height, endSize.height, value));
  status.angle  = CGAngleFade(startAngle, endAngle, value);
  return [status autorelease];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) drawSprite:(Sprite*)sprite atTime:(float)time
{
  float value = [self valueForTime:time];
  CGPoint point = [bezier pointAtTime:value];
  CGSize size = CGSizeMake(CGFade(startSize.width, endSize.width, value), CGFade(startSize.height, endSize.height, value));
  float angle = CGAngleFade(startAngle, endAngle, value);
  [sprite drawAtPoint:point angle:angle size:size color:0xffffffff layer:sprite.layer];
}

@end

