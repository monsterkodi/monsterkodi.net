//
//  Console.m

#import "Console.h"
#import "Text.h"

NSMutableArray * LogBufferLines;

#define CONSOLE_LINES_COUNT 32

@implementation Console

+ (NSMutableArray *) logBufferLines
{
  if (!LogBufferLines) LogBufferLines = [[NSMutableArray arrayWithCapacity:CONSOLE_LINES_COUNT] retain];
  return LogBufferLines;
}

+ (void)log:(NSString *) string
{
  NSLog(string);
  [[Console logBufferLines] addObject:string];
  if ([[Console logBufferLines] count] > CONSOLE_LINES_COUNT) [[Console logBufferLines] removeObjectAtIndex:0];
}

+ (void) drawAtPoint:(CGPoint)point
{
  uint li = 0;
  for (NSString * line in [Console logBufferLines])
    [line drawAtPoint:CGPointMake(point.x, point.y-(li++)*3.0f/CONSOLE_LINES_COUNT) height:3.0f/CONSOLE_LINES_COUNT];
}

@end
