//
//  Animation.m

#import "Animation.h"
#import "Controller.h"
#import "Layers.h"
#import "Text.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation Animation
//------------------------------------------------------------------------------------------------------------------------

@synthesize fps_min;
@synthesize fps_avg;
@synthesize lastDate;

//------------------------------------------------------------------------------------------------------------------------
+ (float) springValue:(float)value from:(float)start to:(float)end ratio:(float)ratio overshot:(float)overshot
{
  if (value < ratio)
  {
    return start + sin(value/ratio * M_PI_2) * (end-start+overshot);
  }
  else
  {
    float f = (value-ratio)/(1.0f-ratio);
    return end + cos(f * M_PI * 8) * overshot * (1-f) * (1-f);
  }
}

//------------------------------------------------------------------------------------------------------------------------
+ (NSDate*) now
{
  return [Controller instance].animation.lastDate;
}

//------------------------------------------------------------------------------------------------------------------------
+ (float) timeSince:(NSDate*)date
{
  return [[Animation now] timeIntervalSinceDate:date];
}

//------------------------------------------------------------------------------------------------------------------------
- (id) init
{
  if ((self = [super init]))
  {
    frameInterval = 1.0f / 60.0f;
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) start
{
  [self stop];

  lastDate  = [[NSDate date] retain];

	frameTimer = [NSTimer scheduledTimerWithTimeInterval:frameInterval target:self selector:@selector(onFrame) userInfo:nil repeats:YES];
  [self onFrame];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) stop
{
  if (frameTimer != nil && [frameTimer isValid])
  {
    [frameTimer invalidate];
  }
  [lastDate release];
  lastDate   = nil;
	frameTimer = nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onFrame
{
  NSDate * date = [[NSDate date] retain];
  NSTimeInterval delta = [date timeIntervalSinceDate:lastDate];

  if (0) // fps display
  {
    fps_history[fps_index++] = (int)(1.0f/delta);
    fps_index = fps_index % FPS_HISTORY;
    fps_min = 1000;
    fps_avg = 0;
    for (int i = 0; i < FPS_HISTORY; i++)
    {
      fps_min = min(fps_min, fps_history[i]);
      fps_avg += fps_history[i];
    }
    fps_avg /= FPS_HISTORY;
      
    [[NSString stringWithFormat:@"%d %d", fps_min, fps_avg] drawAtPoint:POINT(-1,-1.4) height:0.1f color:0x88ffffff layer:_debug_];
  }
  
  [[Controller instance] drawFrame:delta];
  
  [lastDate release];
  lastDate = date;
}

@end
