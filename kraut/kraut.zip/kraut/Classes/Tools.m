//
//  Tools.m

#import "Tools.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation NSDictionary (Tools)
//------------------------------------------------------------------------------------------------------------------------

- (float)     floatForKey:(NSString*)key  default:(float)defaultValue      { if ([self valueForKey:key]) return [[self valueForKey:key] floatValue];  return defaultValue; }
- (int)       intForKey:(NSString*)key    default:(int)defaultValue        { if ([self valueForKey:key]) return [[self valueForKey:key] intValue];    return defaultValue; }
- (NSString*) stringForKey:(NSString*)key default:(NSString*)defaultValue  { if ([self valueForKey:key]) return [[self valueForKey:key] stringValue]; return defaultValue; }
- (void)      setDefaultFloat:(float)defaultValue forKey:(NSString*)key    { if (![self valueForKey:key]) [self setValue:[NSString stringWithFormat:@"%f", defaultValue] forKey:key]; }  

@end

//------------------------------------------------------------------------------------------------------------------------
id LoadPropertyList(NSString * path)
{
  NSString * errorString;
  id plist = (id)CFPropertyListCreateFromXMLData(kCFAllocatorDefault,
                                               (CFDataRef)[NSData dataWithContentsOfFile:path], 
                                               kCFPropertyListMutableContainers,
                                               (CFStringRef *)&errorString);
  if (!plist) NSLog(@"[ERROR] unable to load property list: %@", errorString);
  return plist;
}

Pos POS(int x, int y) { return [Posn x:x y:y]; }

//------------------------------------------------------------------------------------------------------------------------
@implementation Posn
//------------------------------------------------------------------------------------------------------------------------

@synthesize x;
@synthesize y;

+ (Pos) x:(int)x y:(int)y { Pos p = [[Posn alloc] init]; p.x = x; p.y = y; return [p autorelease]; }
- (Pos) copy:(Pos)p { return [POS(p.x,p.y) retain]; }
- (Pos) add:(Pos)p { x += p.x; y += p.y; return self; }
- (Pos) sum:(Pos)p { return POS(x+p.x, y+p.y); }
- (NSString*) description { return [NSString stringWithFormat:@"(%d,%d)", x, y]; }

@end

//------------------------------------------------------------------------------------------------------------------------
float CGPointAngle (CGPoint a) // returns angle of vector in degrees
{
  float l = CGPointLength(a);
  assert(l);
  float nx =  a.x/l;
  float ny = -a.y/l;
  float result; 
  if (nx >= 0)  result = (-90 -RAD2DEG(atan(ny/nx)));
  else          result = ( 90 -RAD2DEG(atan(ny/nx)));
  //NSLog(@"%f %f norm %f %f -> angle %f", a.x, a.y, nx, ny, result);
  return result;
}

//------------------------------------------------------------------------------------------------------------------------
float CGAngle (CGPoint a, CGPoint b)
{
  float deg1 = CGPointAngle(a);
  float deg2 = CGPointAngle(b);
  float diff = deg2-deg1;
  if (abs(diff) > 180)
  {
    if (diff > 180) diff -= 360;
    else if (diff < -180) diff += 360;
  }
  return diff;
}
