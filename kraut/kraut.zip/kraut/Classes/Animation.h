//
//  Animation.h

#define FPS_HISTORY 200

//------------------------------------------------------------------------------------------------------------------------
@interface Animation : NSObject 
//------------------------------------------------------------------------------------------------------------------------
{  
  NSTimer * frameTimer;         // frame timer
	NSTimeInterval frameInterval; // frame timer interval
  NSDate  * lastDate;
  
  int fps_min;
  int fps_avg;
  int fps_history[FPS_HISTORY];
  int fps_index;
}

@property (readonly) int fps_min;
@property (readonly) int fps_avg;
@property (readonly) NSDate * lastDate;

+ (NSDate*) now;
+ (float)   springValue:(float)value from:(float)start to:(float)end ratio:(float)ratio overshot:(float)overshot;
+ (float)   timeSince:(NSDate*)date;

- (void)    start;
- (void)    stop;
- (void)    onFrame;

@end
