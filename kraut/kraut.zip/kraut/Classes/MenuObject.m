//
//  MenuObject.m

#import "MenuObject.h"
#import "Menu.h"
#import "Tools.h"
#import "Text.h"
#import "Screen.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation MenuObject
//------------------------------------------------------------------------------------------------------------------------

@synthesize name;
@synthesize dict;
@synthesize parent;
@synthesize children;
@synthesize rect;
@synthesize menu;
@synthesize fadeValue;

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithDictionary:(NSDictionary*)dict_ parent:(MenuObject*)parent_
{
  if ((self = [super init]))
  {
    dict       = dict_;
    parent     = parent_;
    name       = [dict valueForKey:@"name"];
    
    children   = [[NSMutableArray arrayWithCapacity:4] retain];    
  }
  
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [children release];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (Menu*) menu
{
  NSAssert(parent, @"no menu for menu object without parent?");
  return parent.menu;
}

//------------------------------------------------------------------------------------------------------------------------
- (Screen*) screenWithName:(NSString*)screenName
{
  for (MenuObject * child in children)
  {
    if ([child isKindOfClass:[Screen class]]) 
      if ([child.name isEqualToString:screenName]) return (Screen*)child;
    Screen * screen = [child screenWithName:screenName];
    if (screen) return screen;
  }
  return nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) moveBy:(CGPoint)vector
{
  CGPoint p = CGPointAdd(rect.origin, vector);
  rect = CGRectMake(p.x, p.y, rect.size.width, rect.size.height);
}

//------------------------------------------------------------------------------------------------------------------------
- (void) moveTo:(CGPoint)point
{
  rect = CGRectMake(point.x-rect.size.width/2, point.y-rect.size.height/2, rect.size.width, rect.size.height);
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onFrame:(double)delta
{
  for (MenuObject * child in children) 
  {
    [child onFrame:delta];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (NSString*) description
{
  return [NSString stringWithFormat:@"<%@ '%@' children %@>", [self class], name, children];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeIn:(float)value {}
- (void) fadeOut:(float)value {}
//------------------------------------------------------------------------------------------------------------------------
- (void)  onTouchUp:(TouchEvent*)event {}
- (void)  onTouchDown:(TouchEvent*)event {}
- (void)  onTouchMove:(TouchEvent*)event {}

@end
