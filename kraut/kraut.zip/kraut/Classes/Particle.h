//
//  Particle.h

@class Sprite;
@class Stone;
@class ChallengeFlower;
@class Timer;

//------------------------------------------------------------------------------------------------------------------------
@interface Particle : NSObject
//------------------------------------------------------------------------------------------------------------------------
{
  Sprite * sprite;
  Timer  * lifeTimer;
  CGPoint point;
  CGPoint start;
  CGPoint target;
  CGPoint speed;
  uint    color;
  uint    layer;
}

@property (assign) CGPoint  point;
@property (assign) CGPoint  start;
@property (assign) CGPoint  target;
@property (assign) CGPoint  speed;
@property (assign) Sprite * sprite;
@property (assign) uint     color;
@property (assign) uint     layer;

+ (Particle *) withSprite:(Sprite*)sprite duration:(float)duration atPoint:(CGPoint)point to:(CGPoint)target speed:(CGPoint)speed color:(uint)color;

- (id)   initWithTime:(float)time;
- (void) dealloc;
- (void) move:(Timer*)timer;
- (void) moved:(Timer*)timer;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface Pollen : Particle
//------------------------------------------------------------------------------------------------------------------------
{
  float     radius;       // distance from start point
  float     angle;        // current angle 
  float     switchangle;  // angle where rotation around start switches into movement towards target
  float     targetangle;  // angle of vector from start to target
  
  float     distsum;
  float     speedfactor;
  Sprite  * pollenSprite;
  uint      pollenColor;
  bool      emitpollen;
  int       siblingCount;
  int       score;
}

@property (assign) float    radius;
@property (assign) int      score;
@property (assign) int      siblingCount;
@property (assign) bool     emitpollen;
@property (assign) float    angle;
@property (assign) float    switchangle;
@property (assign) float    targetangle;
@property (assign) float    speedfactor;
@property (assign) uint     pollenColor;

+ (void) forChallengeFlower:(ChallengeFlower*)flower speed:(float)speed count:(int)count;
+ (void) explosionAt:(CGPoint)center radius:(float)radius sprite:(Sprite*)sprite color:(uint)color layer:(uint)layer speed:(float)speed count:(int)count;
+ (void) forStone:(Stone*)stone count:(int)count score:(int)score;

- (id)   init;
- (void) move:(Timer*)timer;
- (void) vanish;

@end
