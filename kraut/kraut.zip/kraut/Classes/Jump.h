//
//  Jump.h

#import "Board.h"

@class StoneType;

//------------------------------------------------------------------------------------------------------------------------
@interface Jump : Board <DragObject>
//------------------------------------------------------------------------------------------------------------------------
{
  Block     * block;
  BOOL        draggedOutside; // true, if block was dragged outside of jump area
  StoneType * butTargetType;
  Pos         extraTargetPos;
}

@property (assign) Block * block;
@property (assign) BOOL    draggedOutside;

- (void)          setBlock:(Block*)block;
- (void)          layout;
- (void)          clear;
- (void)          dragStarted:(DragEvent*)event;
- (void)          dragMoved:(DragEvent*)event;
- (void)          dragEnded:(DragEvent*)event;
- (void)          dragCanceled:(DragEvent*)event;
- (Pos)           jumpPosForBugAtPoint:(CGPoint)point;
- (BOOL)          onEvent:(Event*)event;
- (BOOL)          isEmpty;
- (void)          setupWithDictionary:(NSDictionary*)dictionary;
- (NSDictionary*) dictionary;

@end
