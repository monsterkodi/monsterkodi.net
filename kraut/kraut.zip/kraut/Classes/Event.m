//
//  Event.m

#import "Event.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation Event
//------------------------------------------------------------------------------------------------------------------------
@synthesize type;

//------------------------------------------------------------------------------------------------------------------------
- (NSString *) description
{
  return [NSString stringWithFormat:@"<Event: '%@'>", type];
}
@end

//------------------------------------------------------------------------------------------------------------------------
@implementation OrientationEvent
//------------------------------------------------------------------------------------------------------------------------
@synthesize orientation;

//------------------------------------------------------------------------------------------------------------------------
- (NSString *) description
{
  return [NSString stringWithFormat:@"<Event: '%@' orientation %d>", type, orientation];
}
@end

//------------------------------------------------------------------------------------------------------------------------
@implementation SleepEvent
//------------------------------------------------------------------------------------------------------------------------
@synthesize wakeup;

//------------------------------------------------------------------------------------------------------------------------
- (NSString *) description
{
  return [NSString stringWithFormat:@"<Event: '%@' wakeup %d>", type, wakeup];
}
@end

//------------------------------------------------------------------------------------------------------------------------
@implementation KeyValueEvent
//------------------------------------------------------------------------------------------------------------------------
@synthesize key;
@synthesize value;

- (NSString *) description
{
  return [NSString stringWithFormat:@"<KeyValueEvent: key %@ value %@>", key, value];
}
@end

//------------------------------------------------------------------------------------------------------------------------
@implementation ButtonEvent
//------------------------------------------------------------------------------------------------------------------------
@synthesize status;

- (NSString *) description
{
  return [NSString stringWithFormat:@"<ButtonEvent: key %@ value %@ status %d>", key, value, status];
}
@end

//------------------------------------------------------------------------------------------------------------------------
@implementation FrameEvent
//------------------------------------------------------------------------------------------------------------------------
@synthesize delta;

- (NSString *) description
{
  return [NSString stringWithFormat:@"<FrameEvent: delta %0.4f>", delta];
}
@end

//------------------------------------------------------------------------------------------------------------------------
@implementation DragEvent
//------------------------------------------------------------------------------------------------------------------------
@synthesize object;
@synthesize source;
@synthesize target;
@synthesize point;
@synthesize delta;

- (NSString *) description
{
  return [NSString stringWithFormat:@"<DragEvent: pos %0.2f %0.2f (%0.2f %0.2f) object %@ source %@ target %@>", point.x, point.y, delta.x, delta.y, object, source, target];
}
@end

//------------------------------------------------------------------------------------------------------------------------
@implementation TouchEvent
//------------------------------------------------------------------------------------------------------------------------
@synthesize point;
@synthesize event;
@synthesize finger;
@synthesize tapCount;
@synthesize delta;
@synthesize distanceDelta;
@synthesize direction;

- (NSString *) description
{
  return [NSString stringWithFormat:@"<TouchEvent: pos %0.2f %0.2f finger %d delta %0.2f direction (%0.2f,%0.2f) distanceDelta %f>", point.x, point.y, finger, delta, direction.x, direction.y, distanceDelta];
}
@end
