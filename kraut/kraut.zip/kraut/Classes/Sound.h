//
//  Sound.h

#import "Event.h"

#include <CoreAudio/CoreAudioTypes.h>
#include <AudioToolbox/AudioToolbox.h>
#include <OpenAL/al.h>
#include <OpenAL/alc.h>

//------------------------------------------------------------------------------------------------------------------------
@interface SoundSample : NSObject
//------------------------------------------------------------------------------------------------------------------------
{
  ALuint  * sources;
  ALuint    buffer;
  void    * data;
  
  int       numSources;
  int       sourceIndex;
  float     volume;
  float     initVolume;
  
  int       loopCount;
}

@property (assign) float volume;

- (id)    initWithFile:(NSString*)file numSources:(int)numSources volume:(float)volume;
- (void)  dealloc;
- (void)  shutdown;
- (void)  stop;
- (void)  play;
- (void)  loop;
- (BOOL)  isLooping;
- (void)  playWithVolume:(float)volume;
- (void)  loopWithVolume:(float)volume;

- (void) setPitch:(float)pitch;
- (void) setGain:(float)volume;

@end


//------------------------------------------------------------------------------------------------------------------------
@interface Sound : NSObject <EventReceiver>
//------------------------------------------------------------------------------------------------------------------------
{
  NSMutableDictionary * samples;
  ALCcontext          * context;
  ALCdevice           * device;
}

@property (readonly) NSDictionary * samples;

+ (Sound*)  instance;
+ (void)    stop:(NSString*)sound;
+ (void)    play:(NSString*)sound;
+ (void)    loop:(NSString*)sound;
+ (void)    play:(NSString*)sound volume:(float)volume;
+ (void)    loop:(NSString*)sound volume:(float)volume;
+ (void)    setVolume:(int)volume;
+ (void)    changeSample:(NSString*)sound volume:(float)volume;
+ (SoundSample*) sampleWithName:(NSString*)name;
- (void)    dealloc;
- (void)    shutdown;
- (void)    setup;
- (BOOL)    onEvent:(Event*)event;

@end
