//
//  AnimBezier.h
//  kraut

@class Bezier;
@class Sprite;
@class KeyValueEvent;

enum BezierInterpolation {
  LINEAR, SMOOTH, SPRING, 
};

//------------------------------------------------------------------------------------------------------------------------
@interface AnimBezierStatus : NSObject
//------------------------------------------------------------------------------------------------------------------------
{
  float angle;
  CGSize size;
  CGPoint point;
}

@property (assign) CGPoint  point;
@property (assign) float    angle;
@property (assign) CGSize   size;

+ (AnimBezierStatus*) withFloatArray:(NSArray*)array;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface AnimBezier : NSObject
//------------------------------------------------------------------------------------------------------------------------
{
  Bezier        * bezier;
  float           duration;
  int             interpolation;
  float           startAngle;
  float           endAngle;
  CGSize          startSize;
  CGSize          endSize;
  KeyValueEvent * startEvent;
  KeyValueEvent * endEvent;
}

@property (assign) Bezier * bezier;
@property (assign) float    duration;
@property (assign) int      interpolation;
@property (assign) float    startAngle;
@property (assign) float    endAngle;
@property (assign) CGSize   startSize;
@property (assign) CGSize   endSize;
@property (assign) KeyValueEvent * startEvent;
@property (assign) KeyValueEvent * endEvent;

+ (AnimBezier*)         withPoints:(CGPoint*)points;
+ (AnimBezier*)         from:(AnimBezierStatus*)start to:(AnimBezierStatus*)end;

- (CGPoint)             pointAtTime:(float)time;
- (AnimBezierStatus*)   statusAtTime:(float)time;
- (void)                drawSprite:(Sprite*)sprite atTime:(float)time;
- (void)                sendStartEvent;
- (void)                sendEndEvent;

@end
