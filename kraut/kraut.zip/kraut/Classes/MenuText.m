//
//  MenuText.m
//  kraut

#import "MenuText.h"
#import "Letters.h"
#import "Sprite.h"
#import "Text.h"
#import "Tools.h"
#import "Timer.h"
#import "Menu.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation MenuText
//------------------------------------------------------------------------------------------------------------------------

@synthesize   point;
@synthesize   lineSpace;
@synthesize   preHeadSpace;
@synthesize   postHeadSpace;
@synthesize   textSize;
@synthesize   headSize;
@synthesize   textColor;
@synthesize   headColor;
@synthesize   alignment;
@synthesize   layer;

//------------------------------------------------------------------------------------------------------------------------
- (id) init
{
  if ((self = [super init]))
  {
    lines       = [[NSMutableArray arrayWithCapacity:10] retain];
    lineOffsets = [[NSMutableArray arrayWithCapacity:10] retain];
    layer = _text_;
    point = POINT(0, 0);
    
    textSize  = 0.12f;
    headSize  = 0.14f;
    lineSpace = 0.04f;
    preHeadSpace = 0.05f;
    postHeadSpace = 0.02f;    
    
    alignment = ALIGN_CENTER;
    
    headColor = 0;
    textColor = 0xffffffff;
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithDictionary:(NSDictionary*)dict_ parent:(MenuObject*)parent_
{  
  if ((self = [super initWithDictionary:dict_ parent:parent_]))
  {
    lines = [[NSMutableArray arrayWithCapacity:10] retain];
    lineOffsets = [[NSMutableArray arrayWithCapacity:10] retain];

    float y = ([dict valueForKey:@"y"] ? [[dict valueForKey:@"y"] floatValue] : 0.7f);
    float x = ([dict valueForKey:@"x"] ? [[dict valueForKey:@"x"] floatValue] : 0.0f); 
    point = POINT(x, y);
    
    layer         = [dict intForKey:@"layer" default:_text_];    
    textSize      = [dict floatForKey:@"textHeight"     default:0.12f];
    headSize      = [dict floatForKey:@"titleHeight"    default:0.14f];
    lineSpace     = [dict floatForKey:@"lineSpace"      default:0.04f];
    preHeadSpace  = [dict floatForKey:@"preTitleSpace"  default:0.05f];
    postHeadSpace = [dict floatForKey:@"postTitleSpace" default:0.02f];
    textColor     = 0xffffffff;
    if ([dict valueForKey:@"textColor"])
    {
      NSArray * colors = [[dict valueForKey:@"textColor"] componentsSeparatedByString:@" "];
      textColor = RGBCOLOR([[colors objectAtIndex:0] floatValue], [[colors objectAtIndex:1] floatValue], [[colors objectAtIndex:2] floatValue]);
    }
    headColor     = 0;
    if ([dict valueForKey:@"titleColor"])
    {
      NSArray * colors = [[dict valueForKey:@"titleColor"] componentsSeparatedByString:@" "];
      headColor = RGBCOLOR([[colors objectAtIndex:0] floatValue], [[colors objectAtIndex:1] floatValue], [[colors objectAtIndex:2] floatValue]);
    }
    [self setText:[dict valueForKey:@"text"]];
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [lines       release];
  [lineOffsets release];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setText:(NSString*)text
{
  [lines       removeAllObjects];
  [lineOffsets removeAllObjects];
    
  NSArray * lineStrings = [[text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] componentsSeparatedByString:@"\n"];
    
  float y = point.y;
  float offset = 0;
  
  for (NSString * line in lineStrings)
  {
    BOOL head = NO;
    float height = textSize;
    uint color = textColor;
    letters = [[Letters alloc] init];
    NSString * str = [line stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    
    if (![str length]) str = @" ";
    
    if ([str characterAtIndex:0] == '[')
    {
      head    = YES;
      str     = [str stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"[]"]];
      height  = headSize;
      y      -= preHeadSpace;
      offset -= preHeadSpace; 
      color   = headColor;
    }
    else if ([str characterAtIndex:0] == '<')
    {
      int index = [str rangeOfString:@">"].location+1;
      NSString * tag = [str substringToIndex:index];
      str = [str substringFromIndex:index];
      if      ([tag isEqualToString:@"<yellow>"]) color = RGBACOLOR(1,1,0,1);
      else if ([tag isEqualToString:@"<red>"])    color = RGBACOLOR(1,0,0,1);
      else if ([tag isEqualToString:@"<green>"])  color = RGBACOLOR(0,0.7f,0,1);
      else if ([tag isEqualToString:@"<dark>"])   color = RGBACOLOR(0.4f,0.4f,0.4f,1);
      else if ([tag isEqualToString:@"<small>"])  { color = RGBACOLOR(0.4f,0.4f,0.4f,1); y -= 0.25f*height; height *= 0.75f; }
    }
    
    y      -= height + lineSpace;
    offset -= height + lineSpace;
    
    letters.layer = layer;
    letters.alignment = alignment;
    letters.sprite = [Sprite withName:@"shadow"];
    
    [lineOffsets addObject:[NSNumber numberWithFloat:offset]];
    
    [letters setString:str withHeight:height atPoint:POINT(point.x, y)];
    if (color) letters.color = color;
    if (head)  { y -= postHeadSpace; offset -= preHeadSpace; }
    [lines addObject:letters];
    [letters release];
  }
  letters = nil;  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeIn:(float)value // this is called automatically from parent menu, for manual trigger, use below!
{
  NSAssert(self.menu, @"fadeIn without menu? use fadeIn: offset: ?");
  [self fadeIn:value offset:self.menu.fadeInOffset];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeIn:(float)value offset:(CGPoint)offset // this is called from code
{
  for (Letters * l in lines) [l fade:value offset:offset];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeOut:(float)value
{
  [self fadeOut:value offset:self.menu.fadeOutOffset];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeOut:(float)value offset:(CGPoint)offset
{
  for (Letters * l in lines) [l fade:value offset:offset];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onFrame:(double)delta
{
  [self draw];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) draw
{
  for (Letters * l in lines) [l draw];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) moveBy:(CGPoint)vector
{
  [super moveBy:vector];
  for (Letters * l in lines) [l moveBy:vector];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) moveTo:(CGPoint)point_
{
  point = point_;
  int i = 0;
  for (Letters * l in lines) [l moveTo:POINT(point.x, point.y + [[lineOffsets objectAtIndex:i++] floatValue])];
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation MenuScrollText
//------------------------------------------------------------------------------------------------------------------------

@synthesize autoScrollDelay;
@synthesize minScrollOffset;
@synthesize maxScrollOffset;

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithDictionary:(NSDictionary*)dict_ parent:(MenuObject*)parent_
{  
  if ((self = [super initWithDictionary:dict_ parent:parent_]))
  {
    autoScrollDelay = [dict floatForKey:@"autoScrollDelay" default:-1];
    minScrollOffset = [dict floatForKey:@"minScrollOffset" default:0];
    maxScrollOffset = [dict floatForKey:@"maxScrollOffset" default:2];    
    
    scrollValue = minScrollOffset;
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeIn:(float)value
{
  if (value == 0 && autoScrollDelay > 0)
  {
    scrollDelta = 0.01f;
    for (Letters * l in lines) [l moveBy:POINT(0, -scrollValue)];
    scrollValue = minScrollOffset;
    scrollTimer = [Timer timerWithDuration:autoScrollDelay object:self tick:nil finish:@selector(startAutoScroll:)];
  }
  [super fadeIn:value];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeOut:(float)value
{
  if (value == 1.0f) [self stopAutoScroll];
  [super fadeOut:value];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startAutoScroll:(Timer*)timer
{  
  scrollTimer = [Timer timerWithObject:self tick:@selector(scroll:)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) scroll:(Timer*)timer
{
  if (scrollValue+scrollDelta > maxScrollOffset || scrollValue+scrollDelta < minScrollOffset) 
  {
    scrollDelta *= -1;
    [self stopAutoScroll];
    scrollTimer = [Timer timerWithDuration:autoScrollDelay object:self tick:nil finish:@selector(startAutoScroll:)];
  }
  else
  {
    scrollValue += scrollDelta;
    for (Letters * l in lines) [l moveBy:POINT(0, scrollDelta)];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) stopAutoScroll
{
  [scrollTimer stop];
  scrollTimer = nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onTouchDown:(TouchEvent*)event
{
  [self stopAutoScroll];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onTouchMove:(TouchEvent*)event
{
  scrollDelta = event.direction.y;
  if (scrollValue+scrollDelta > maxScrollOffset) scrollDelta = maxScrollOffset-scrollValue;
  else if (scrollValue+scrollDelta < minScrollOffset) scrollDelta = minScrollOffset-scrollValue;
  scrollValue += scrollDelta;
  
  for (Letters * l in lines) [l moveBy:POINT(0, scrollDelta)];
}

@end
