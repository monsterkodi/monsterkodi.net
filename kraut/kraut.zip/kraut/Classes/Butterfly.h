//
//  Worm.h
//  kraut

#import "Extra.h"

@class Bezier;
@class Stone;
@class Timer;

//------------------------------------------------------------------------------------------------------------------------
@interface Butterfly : Extra
//------------------------------------------------------------------------------------------------------------------------
{
  Bezier          * bezier;
  NSMutableArray  * stones;
  Stone           * stone;
  
  Timer           * eatTimer;
  float             targetAngle;
}

- (id)   init;
- (void) dealloc;
- (void) eat;
- (void) eatStone;
- (void) deactivate;
- (void) jumpToPos:(Pos)pos onBoard:(Board*)board;

@end
