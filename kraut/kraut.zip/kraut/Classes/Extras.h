//
//  Extras.h

@class Extra;

//------------------------------------------------------------------------------------------------------------------------
@interface Extras : NSObject 
//------------------------------------------------------------------------------------------------------------------------
{
  NSMutableArray * activeExtras;
}

+ (Extras*) instance;
+ (void)    extraForPollen:(int)pollen score:(int)score point:(CGPoint)point;
- (id)      init;
- (void)    dealloc;
- (void)    addActiveExtra:(Extra*)extra;
- (void)    removeActiveExtra:(Extra*)extra;
- (void)    deactivateAllExtras;
- (int)     numberOfActiveExtras;

@end

