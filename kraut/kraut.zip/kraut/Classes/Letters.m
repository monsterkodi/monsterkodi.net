//
//  Letters.m

#import "Letters.h"
#import "Text.h"
#import "Line.h"
#import "Tools.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation Letter
//------------------------------------------------------------------------------------------------------------------------

@synthesize rect;
@synthesize alpha;
@synthesize height;
@synthesize angle;
@synthesize baseangle;
@synthesize offset;
@synthesize color;
@synthesize character;
@synthesize layer;
@synthesize sprite;
@synthesize spritealpha;

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithCharacter:(unichar)c color:(uint)color_
{
  if ((self = [super init]))
  {
    character = c;
    if (character == 223) 
      character = 3;
    color     = color_;
    alpha     = 1.0f;
    offset    = CGPointMake(0,0);
    angle     = 0.0f;
    layer     = _text_;
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setNumber:(int)number
{
  NSAssert1(number >= 0 && number <= 9, @"wrong number (%d)?", number);
  character = 48+number;
  float us = CHAR[character][0]/512.0f;
  float uw = CHAR[character][1]/512.0f-us;

  float vs = (CHAR[character][2]-CHAR[character][3])/256.0f;
  float vh = (CHAR[character][3]+CHAR[character][4])/256.0f;
  [self setUVRect:(CGRectMake(us, vs, uw, vh))];
}

//------------------------------------------------------------------------------------------------------------------------
- (float) getWidth
{
  return (CHAR[character][1]-CHAR[character][0]) * rect.size.height * 0.025f;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) moveBy:(CGPoint)vector
{
  [self setRect:CGRectMove(rect, vector)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) moveTo:(CGPoint)point
{
  [self moveBy:CGVector(CGRectCenter(rect), point)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setRect:(CGRect)rect_
{
  rect = rect_;
  [self updatePoints];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setOffset:(CGPoint)offset_
{
  offset = offset_;
  [self updatePoints];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setAngle:(float)angle_
{
  angle = angle_;
  [self updatePoints];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) updatePoints
{
  CGAffineTransform rot = CGAffineTransformMakeRotation(baseangle+angle);
  CGPoint center = CGPointAdd(CGRectCenter(rect), offset);
  float w = rect.size.width/2.0f;
  float h = rect.size.height/2.0f;
  
  points[0] = CGPointAdd(center, CGPointApplyAffineTransform(CGPointMake(-w,-h), rot));
  points[1] = CGPointAdd(center, CGPointApplyAffineTransform(CGPointMake( w,-h), rot));
  points[2] = CGPointAdd(center, CGPointApplyAffineTransform(CGPointMake(-w, h), rot));
  points[3] = CGPointAdd(center, CGPointApplyAffineTransform(CGPointMake( w, h), rot));

  if (sprite)
  {
    float sw = max(w*3.0f, h*1.5f);
    float sh = max(w*1.5f, h*3.0f);
    mpoints[0] = CGPointAdd(center, CGPointMake(-sw,-sh));
    mpoints[1] = CGPointAdd(center, CGPointMake( sw,-sh));
    mpoints[2] = CGPointAdd(center, CGPointMake(-sw, sh));
    mpoints[3] = CGPointAdd(center, CGPointMake( sw, sh));
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setLayer:(uint)_layer_
{
  layer = _layer_;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setUVRect:(CGRect)uv
{
  uvrect[0] = CGPointAdd(uv.origin, CGPointMake(0, uv.size.height));
  uvrect[1] = CGPointAdd(uv.origin, CGPointMake(uv.size.width, uv.size.height));    
  uvrect[2] = uv.origin;
  uvrect[3] = CGPointAdd(uv.origin, CGPointMake(uv.size.width,0));
}

//------------------------------------------------------------------------------------------------------------------------
- (void) draw
{
  if (character == 32) return;
  Font * font = [Font instance];
  sprite_vertex lv;
  lv.c = ((color & 0xffffff) | (((uint)(alpha*0xff))<<24));
  
  uint il[6]={0,1,2,1,2,3};
  for (int vi = 0; vi < 6; vi++)
  {
    int i = il[vi];
    lv.x = points[i].x;
    lv.y = points[i].y;
    lv.u = uvrect[i].x;
    lv.v = uvrect[i].y;
    
    [font addVertex:&lv layer:layer];
  }
  
  if (sprite) [sprite drawWithPoints:mpoints alpha:spritealpha layer:layer-1];  
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation Letters
//------------------------------------------------------------------------------------------------------------------------

@synthesize letters;
@synthesize string;
@synthesize sprite;
@synthesize color;
@synthesize randomangle;
@synthesize point;
@synthesize layer;
@synthesize height;
@synthesize width;
@synthesize angle;
@synthesize alpha;
@synthesize alignment;

static uint COLORS[8] = 
{
0x7d45c1, // pink
0xff4444, // light blue
0x007700, // dark green
0x00ff00, // green
0xff00ff, // liac
0xff0000, // blue
0x0000ff, // red
0x00ffff, // yellow
};

//------------------------------------------------------------------------------------------------------------------------

- (id) init
{
  if ((self = [super init]))
  {
    letters     = [[NSMutableArray arrayWithCapacity:5] retain];
    randomangle = 20.0f;
    layer       = _text_;
    alpha       = 1.0f;
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) dealloc
{
  [letters release];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setColor:(uint)color_
{
  color = color_;
  //for (Letter * letter in letters) letter.color = color;
  [self setString:string withHeight:height atPoint:point];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setLayer:(uint)_layer_
{
  layer = _layer_;
  for (Letter * letter in letters) letter.layer = layer;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setAlpha:(float)alpha_
{
  alpha = alpha_;
  for (Letter * letter in letters) letter.alpha = alpha;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) draw
{
  for (Letter * letter in letters) [letter draw];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fade:(float)value offset:(CGPoint)offset
{
  int i = 0;
  
  for (Letter * letter in letters)
  {
    letter.alpha  = value;
    letter.spritealpha = value * value * value * value * value;
    letter.offset = CGPointScale(offset, 1-value);
    letter.angle  = DEG2RAD((value)*((i%2) ? 360 : -360));
    i++;
  }  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) moveTo:(CGPoint)point_
{
  [self moveBy:CGVector(point, point_)];
}  

//------------------------------------------------------------------------------------------------------------------------
- (void) moveBy:(CGPoint)vector
{
  point = CGPointAdd(point, vector);
  for (Letter * letter in letters) [letter moveBy:vector];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setHeight:(float)height_
{
  height = height_;
  [self setString:string withHeight:height atPoint:point];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setString:(NSString*)string_
{
  [self setString:string_ withHeight:height atPoint:point];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setString:(NSString*)string_ withHeight:(float)height_ atPoint:(CGPoint)point_
{  
  string = string_;
  point  = point_;
  height = height_;
  
  //NSLog(@"setString");

  [letters removeAllObjects];
  
  Font * font = [Font instance];
  width = [font widthOfText:string height:height];
 
  int colorIndex = ([string characterAtIndex:0] + [string characterAtIndex:min(1,[string length]-1)]) % 8;
  
  GLfloat us, uw, vs, vh;
  float w, h;
  CGPoint right  = CGVectorRotate(POINT(width/2.0f,0),  angle);
  CGPoint up     = CGVectorRotate(POINT(0,height/2.0f), angle);
  CGPoint origin = CGPointSub(point, right);
  
  if      (alignment == ALIGN_LEFT)  origin = point;
  else if (alignment == ALIGN_RIGHT) origin = CGPointSub(origin, right);;
  
  CGPoint dir    = CGVectorNorm(right);
  CGPoint upnorm = CGVectorNorm(up);
  
  CGPoint pos    = origin;
  
  for (uint ci = 0; ci < [string length]; ci++)
  {    
    unichar c = [string characterAtIndex:ci];
    
    if (c == 223) 
      c = 3;

    h  = (CHAR[c][3]+CHAR[c][4]) * height * 0.025f;
    w  = (CHAR[c][1]-CHAR[c][0]) * height * 0.025f;

    CGPoint opos = CGPointSub(pos, CGPointScale(upnorm, CHAR[c][4]/256.0f * 5 * height));
    opos = CGPointAdd(opos, CGPointScale(dir, w/2));
    
    us = CHAR[c][0]/512.0f;
    uw = CHAR[c][1]/512.0f-us;
    
    vs = (CHAR[c][2]-CHAR[c][3])/256.0f;
    vh = (CHAR[c][3]+CHAR[c][4])/256.0f;
        
    Letter * letter = [[Letter alloc] initWithCharacter:c color:(color ? color : COLORS[colorIndex])];
    letter.sprite = sprite;
    letter.spritealpha = alpha;
    letter.layer = layer;
    letter.baseangle = DEG2RAD(angle) + (randomangle ? DEG2RAD(RANDOMF(randomangle)-randomangle/2) : 0);    
    [letter  setRect:CGRectMakeCenterSize(opos, CGSizeMake(w, h))];
    [letter  setUVRect:CGRectMake(us, vs, uw, vh)];
    [letters addObject:letter];
    [letter  release];
    
    pos = CGPointAdd(pos, CGPointScale(dir, w));
    colorIndex = (colorIndex + 1) % 8;
  }
}

@end
