//
//  ChallengeFlower.h
//  kraut

@class StoneType;
@class MenuCampaign;
@class Challenge;
@class Sprite;
@class Timer;

#define CHALLENGE_FLOWER_SIZE 0.3f

//------------------------------------------------------------------------------------------------------------------------
@interface ChallengeFlower : NSObject 
//------------------------------------------------------------------------------------------------------------------------
{
  float           fadeValue;
  CGPoint         point;
  StoneType     * type;
  Challenge     * challenge;
  
  float           alpha;
  float           prizeSize;
  BOOL            open;
  BOOL            prize;
  
  Timer         * animTimer;

  BOOL            selected;

  MenuCampaign  * screen;
  Sprite        * shadowSprite;
}

@property (assign)    BOOL            selected;
@property (assign)    float           fadeValue;
@property (assign)    CGPoint         point;
@property (assign)    Challenge     * challenge;
@property (assign)    MenuCampaign  * screen;
@property (assign)    StoneType     * type;
@property (readonly)  CGPoint         center;
@property (readonly)  CGPoint         targetCenter;
@property (readonly)  CGRect          rect;
@property (readonly)  float           size;

- (id)    initWithChallenge:(Challenge*)challenge;
- (BOOL)  containsPoint:(CGPoint)point;

- (void)  startOpenAnimationWithDelay:(float)delay;

- (void)  startAnimateSelection;
- (void)  startAnimateOpen;
- (void)  openAnimated:(Timer*)timer;
- (void)  hidePrize;
- (float) prizeScale;

- (void)  draw;

@end
