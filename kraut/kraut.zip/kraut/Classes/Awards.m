//
//  Awards.m
//  kraut

#import "Awards.h"
#import "Game.h"
#import "Clock.h"
#import "Level.h"
#import "Campaign.h"
#import "Challenge.h"
#import "Sprite.h"

AwardInfo Award[] = {  
{ @"Bee Master",         @"All Bee Challenges completed.",                @"Complete all Bee Challenges!\n%d of %d completed.",                @"bee",      }, 
{ @"Bug Master",         @"All Bug Challenges completed.",                @"Complete all Bug Challenges!\n%d of %d completed.",                @"bug",      }, 
{ @"Butterfly Master",   @"All Butterfly Challenges\ncompleted.",         @"Complete all\nButterfly Challenges!\n%d of %d completed.",         @"but",      }, 
{ @"Score Master",       @"All Pollen Score Challenges\ncompleted.",      @"Complete all\nPollen Score Challenges!\n%d of %d completed.",      @"11x11",    }, 
{ @"Pattern Master",     @"All Pattern Challenges\ncompleted.",           @"Complete all\nPattern Challenges!\n%d of %d completed.",           @"9x9",      },
{ @"Best Move Master",   @"All Best Move Challenges\ncompleted.",         @"Complete all\nBest Move Challenges!\n%d of %d completed.",         @"10x10",    }, 
{ @"Pollen Millionaire", @"%d pollen collected.",                         @"Collect 1.000.000 pollen!\n%d pollen collected.",                  @"dotscore", },
{ @"Aspirant Addict",    @"%d minutes played.",                           @"Play for more than\n100 minutes!\n%d minutes played.",             @"8x8",      },
{ @"Serious Addict",     @"%d hours played.",                             @"Play for more than 10 hours!\n%d hours played.",                   @"serious",  },
{ @"Campaign Hero",      @"All campaign challenges unlocked.",            @"Unlock all campaign challenges!\n%d of %d unlocked.",              @"hero",     },
{ @"Aide Tamer",         @"%d aides used.",                               @"Use 1000 aides!\n%d aides used.",                                  @"tamer",    },
{ @"Arcade King",        @"Survived for %d seconds\non arcade level 10.", @"Survive for 100 seconds\non arcade level 10!\n%d seconds survived.", @"survivor", },
{ @"Puzzle Master",      @"All campaign puzzles solved.",                 @"Solve all campaign puzzles!\n%d of %d solved.",                    @"puzzles",  },
{ @"Highscore Painter",  @"All highscore entries filled.",                @"Fill all highscore entries!\n%d of %d filled.",                    @"painter",  },
};

PrizeData Prize[] = {
{ @"bee",             0, @"bee",        @"Bees available\nin the campaign",             @"Prize:\nbees" }, 
{ @"bug",             0, @"bug",        @"Bugs available\nin the campaign",             @"Prize:\nbug" }, 
{ @"but",             0, @"but",        @"Butterflies available\nin the campaign",      @"Prize:\nbutterflies" }, 
{ @"11x11",           0, @"11x11",      @"11x11 board available\nin arcade mode",       @"Prize:\n11x11 board" }, 
{ @"9x9",             0, @"9x9",        @"9x9 board available\nin arcade mode",         @"Prize:\n9x9 board" },
{ @"10x10",           0, @"10x10",      @"10x10 board available\nin arcade mode",       @"Prize:\n10x10 board" },
{ @"dotscore",  1000000, @"dotscore",   @"Dot score display\nTap score to toggle",      @"Prize:\nDot score display" },
{ @"8x8",          6000, @"8x8",        @"8x8 board available\nin arcade mode",         @"Prize:\n8x8 board" },
{ @"serious",     36000, @"flower04",   @"New flower available\nin arcade games",       @"Prize:\nnew flower" },  
{ @"hero",           90, @"flower64",   @"New flower available\nin arcade games",       @"Prize:\nnew flower" },     
{ @"tamer",        1000, @"flower14",   @"New flower available\nin arcade games",       @"Prize:\nnew flower" },   
{ @"survivor",      100, @"flower63",   @"New flower available\nin arcade games",       @"Prize:\nnew flower" },   
{ @"puzzles",        50, @"flower02",   @"New flower available\nin arcade games",       @"Prize:\nnew flower" },     
{ @"painter",        70, @"flower20",   @"New flower available\nin arcade games",       @"Prize:\nnew flower" },     
{ @"prize00",         0, @"flower01",   @"New flower available\nin arcade games",       @"Prize:\nnew flower" },
{ @"prize01",         0, @"flower00",   @"New flower available\nin arcade games",       @"Prize:\nnew flower" },
{ @"prize02",         0, @"flower52",   @"New flower available\nin arcade games",       @"Prize:\nnew flower" },
{ @"prize03",         0, @"flower72",   @"New flower available\nin arcade games",       @"Prize:\nnew flower" },
{ @"prize04",         0, @"flower73",   @"New flower available\nin arcade games",       @"Prize:\nnew flower" },
{ @"prize05",         0, @"flower74",   @"New flower available\nin arcade games",       @"Prize:\nnew flower" },
{ @"prize06",         0, @"flower03",   @"New flower available\nin arcade games",       @"Prize:\nnew flower" },
{ @"prize07",         0, @"flower20",   @"New flower available\nin arcade games",       @"Prize:\nnew flower" },
{ @"prize08",         0, @"flower22",   @"New flower available\nin arcade games",       @"Prize:\nnew flower" },
{ @"prize09",         0, @"flower23",   @"New flower available\nin arcade games",       @"Prize:\nnew flower" },
{ nil, 0, nil, nil}
};

//------------------------------------------------------------------------------------------------------------------------
@implementation PrizeInfo
//------------------------------------------------------------------------------------------------------------------------
@synthesize name;
@synthesize sprite;
@synthesize spriteName;
@synthesize text;
@synthesize prize;
@synthesize count;
@synthesize total;
@synthesize printValue;

- (NSString*) description
{
  return [NSString stringWithFormat:@"<Prize %@ %d/%d>", name, count, total];
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation Awards
//------------------------------------------------------------------------------------------------------------------------

+ (Awards*) instance
{
  return [Game instance].awards;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [prizeInfos release];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setup
{  
  prizeInfos = [[NSMutableDictionary dictionaryWithCapacity:10] retain];
  int i = 0;
  while (Prize[i].name)
  {
    PrizeInfo * info = [[PrizeInfo alloc] init];
    info.name   = Prize[i].name;
    info.text   = Prize[i].text;
    info.prize  = Prize[i].prize;
    info.sprite = [Sprite withName:Prize[i].sprite];
    info.spriteName = Prize[i].sprite;
    info.count  = 0; 
    info.total  = Prize[i].total;
        
    [prizeInfos setValue:info forKey:Prize[i].name];
    [info release];
    i++;
  }
  
  NSArray * awardData = [[NSUserDefaults standardUserDefaults] valueForKey:@"awardData"];
  for (int i = 0; i < NumAwards; i++)
    [self setValue:[[awardData objectAtIndex:i] intValue] forAward:i];  
}

//------------------------------------------------------------------------------------------------------------------------
- (Sprite*)   spriteForPrize:(NSString*)prize { return [self infoForPrize:prize].sprite; }
- (int)       countForPrize:(NSString*)prize  { return [self infoForPrize:prize].count; }
- (int)       totalForPrize:(NSString*)prize  { return [self infoForPrize:prize].total; }
- (int)       printValueForPrize:(NSString*)prize  { return [self infoForPrize:prize].printValue; }
- (NSString*) textForPrize:(NSString*)prize   { return [self infoForPrize:prize].text; }
- (NSString*) prizeForPrize:(NSString*)prize  { return [self infoForPrize:prize].prize; }

//------------------------------------------------------------------------------------------------------------------------
- (NSString*) flowerForPrize:(NSString*)prize 
{ 
  if ([[self infoForPrize:prize].spriteName hasPrefix:@"flower"]) 
    return [self infoForPrize:prize].spriteName; 
  return nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (NSArray*) prizeFlowers
{
  NSMutableArray * array = [NSMutableArray arrayWithCapacity:16];
  int i = 0;
  while (Prize[i].name) { if ([Prize[i].sprite hasPrefix:@"flower"]) [array addObject:Prize[i].sprite]; i++; }
  return array;
}

//------------------------------------------------------------------------------------------------------------------------
- (NSArray*) flowerPrizes
{
  NSMutableArray * array = [NSMutableArray arrayWithCapacity:16];
  int i = 0;
  while (Prize[i].name) { if ([Prize[i].sprite hasPrefix:@"flower"]) [array addObject:Prize[i].name]; i++; }
  return array;
}

//------------------------------------------------------------------------------------------------------------------------
- (NSArray*) wonFlowers
{
  NSMutableArray * array = [NSMutableArray arrayWithCapacity:16];
  for (NSString * prize in [self flowerPrizes]) 
  {
    if ([self isPrizeWon:prize]) [array addObject:[self infoForPrize:prize].spriteName];
  }
  return array;
}  

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) isPrizeWon:(NSString*)prize
{
  //NSLog(@"isPrizeWon %@ %d/%d", prize, [self countForPrize:prize], [self totalForPrize:prize]);
  return ([self countForPrize:prize] >= [self totalForPrize:prize]);
}

//------------------------------------------------------------------------------------------------------------------------
- (PrizeInfo*) infoForPrize:(NSString*)prize
{
  PrizeInfo * info = [prizeInfos valueForKey:prize];
  if (!info)
    NSAssert1(info, @"info for prize '%@'?", prize);
  return info;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) increaseTotalForPrize:(NSString*)prize
{
  [self infoForPrize:prize].total++;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) increaseCountForPrize:(NSString*)prize
{
  [self setCount:[self infoForPrize:prize].count+1 forPrize:prize];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setCount:(int)value forPrize:(NSString*)prize
{
  PrizeInfo * info = [self infoForPrize:prize];
  info.count = value;
  if      ([info.name isEqualToString:Award[SeriousAddict].prize])  info.printValue = value/3600;
  else if ([info.name isEqualToString:Award[AspirantAddict].prize]) info.printValue = value/60;
  else                                                              info.printValue = value;  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setValue:(int)value forAward:(int)index
{
  [self setCount:value forPrize:Award[index].prize];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) addValue:(int)value forAward:(int)index
{
  [self setValue:[self countForPrize:Award[index].prize]+value forAward:index];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) highscoreAdded
{
  [self setValue:[[Highscores instance] numberOfEntries] forAward:HighscorePainter];
  
  if ([self isPrizeWon:Award[HighscorePainter].prize]) [[Game instance] addArcadeFlower:[self flowerForPrize:Award[HighscorePainter].prize]];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) extraUsed
{
  [self addValue:1 forAward:AideTamer];
  
  [Game instance].levelInfo.extrasUsed++;
  
  if ([self isPrizeWon:Award[AideTamer].prize]) [[Game instance] addArcadeFlower:[self flowerForPrize:Award[AideTamer].prize]];
  
  //NSLog(@"extras used %d", [Game instance].levelInfo.extrasUsed);
  //NSLog(@"Awards::extraUsed AideTamer %d", Award[AideTamer].value);
}

//------------------------------------------------------------------------------------------------------------------------
- (void) gameFinished
{
  Game * game = [Game instance];
  
  //NSLog(@"Awards::gameFinished");
  
  [self addValue:game.score.pollen    forAward:PollenMillionaire];
  [self addValue:game.clock.totalTime forAward:SeriousAddict];
  [self addValue:game.clock.totalTime forAward:AspirantAddict];

  //NSLog(@"Awards::gameFinished PollenMillionaire %d", Award[PollenMillionaire].value);
  //NSLog(@"Awards::gameFinished SeriousAddict %d",     Award[SeriousAddict].value);
  
  if ([self isPrizeWon:Award[PollenMillionaire].prize]) [[Game instance] addArcadeFlower:[self flowerForPrize:Award[PollenMillionaire].prize]];
  if ([self isPrizeWon:Award[AspirantAddict].prize])    [[Game instance] addArcadeFlower:[self flowerForPrize:Award[AspirantAddict].prize]];
  if ([self isPrizeWon:Award[SeriousAddict].prize])     [[Game instance] addArcadeFlower:[self flowerForPrize:Award[SeriousAddict].prize]];
  
  if (![game challenge]) // arcade game
  {
    if ([Clock instance].nextLevelTime < 0)
      [self setValue:max([self countForPrize:Award[ArcadeKing].prize], -(int)[Clock instance].nextLevelTime) forAward:ArcadeKing];

    if ([self isPrizeWon:Award[ArcadeKing].prize])        [[Game instance] addArcadeFlower:[self flowerForPrize:Award[ArcadeKing].prize]];
  }
  else
  {
    Campaign * campaign = [Campaign instance];
    NSDictionary * counts = [campaign solvedChallengesCounts];
    [self setValue:[[counts valueForKey:@"open"]     intValue] forAward:CampaignHero];
    [self setValue:[[counts valueForKey:@"puzzle"]   intValue] forAward:PuzzleMaster];
    
    if ([self isPrizeWon:Award[CampaignHero].prize]) [[Game instance] addArcadeFlower:[self flowerForPrize:Award[CampaignHero].prize]];
    if ([self isPrizeWon:Award[PuzzleMaster].prize]) [[Game instance] addArcadeFlower:[self flowerForPrize:Award[PuzzleMaster].prize]];
    
    if ([Campaign instance].solvedChallenge)
    {
      NSString * prize = [Campaign instance].solvedChallenge.prize;
      [self increaseCountForPrize:prize];
      //NSLog(@"Awards::gameFinished solvedChallenge %@", [self infoForPrize:prize]);
      if ([self isPrizeWon:prize]) [[Game instance] addArcadeFlower:[self flowerForPrize:prize]];
      
      //[[[Menu instance] screenWithName:@"Size"] layout];
    }
  }
  
  [self save];
  [[NSUserDefaults standardUserDefaults] synchronize];
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) gotAwardAtIndex:(int)index
{
  return [self isPrizeWon:Award[index].prize];
}

//------------------------------------------------------------------------------------------------------------------------
- (AwardInfo*) awardAtIndex:(int)index
{
  return &(Award[index]);
}

//------------------------------------------------------------------------------------------------------------------------
- (void) save
{
  NSMutableArray * awardData = [NSMutableArray arrayWithCapacity:NumAwards];
  
  for (int i = 0; i < NumAwards; i++)
    [awardData addObject:[NSString stringWithFormat:@"%d", [self countForPrize:Award[i].prize]]];
     
  [[NSUserDefaults standardUserDefaults] setValue:awardData forKey:@"awardData"];
  //NSLog(@"award data saved %@", [[NSUserDefaults standardUserDefaults] valueForKey:@"awardData"]);
}

@end
