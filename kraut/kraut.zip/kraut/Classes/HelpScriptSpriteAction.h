//
//  HelpScriptSpriteAction.h
//  kraut

#import "HelpScriptAction.h"

//------------------------------------------------------------------------------------------------------------------------
@interface HelpScriptSpriteAction : HelpScriptAction
//------------------------------------------------------------------------------------------------------------------------
{
  NSMutableArray  * beziers;
  int               fadeInBezierCount;
  int               bezierIndex;
  float             bezierTime;
  Sprite          * sprite;
  CGSize            size;
  float             loop;
  CGPoint           point;
}

- (id)      initWithDictionary:(NSDictionary*)dict;
- (void)    dealloc;
- (void)    startAction;
- (void)    delayFinished:(Timer*)timer;
- (void)    startAnimation:(AnimBezier*)bez;
- (void)    animation:(Timer*)timer;
- (void)    animationEnd:(Timer*)timer;
- (void)    fadeIn:(Timer*)timer;
- (void)    fadeOut:(Timer*)timer;
- (CGPoint) spritePointForBezierStatus:(AnimBezierStatus*)status;
- (void)    drawSpriteWithBezier:(AnimBezier*)bez atTime:(float)time;
- (AnimBezierStatus*) bezierStatus;


@end

