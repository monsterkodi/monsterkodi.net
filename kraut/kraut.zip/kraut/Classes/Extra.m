//
//  Extra.m
//  kraut

#import "Extra.h"
#import "ExtraButton.h"
#import "Sprite.h"
#import "Controller.h"
#import "Timer.h"
#import "Sound.h"
#import "Bezier.h"
#import "Game.h"
#import "Awards.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation Extra
//------------------------------------------------------------------------------------------------------------------------

@synthesize layer;
@synthesize size;
@synthesize angle;
@synthesize point;
@synthesize sprite;
@synthesize targetPoint;
@synthesize extraButton;

//------------------------------------------------------------------------------------------------------------------------
- (id) init
{
  if ((self = [super init]))
  {
    layer = _extra_;
    point = POINT(-10,-10);
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  //NSLog(@"dealloc extra");
  [wiggleTimer stop];
  [fadeTimer stop];
  [moveTimer stop];
  
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) show
{
  size = 0;
  [[Controller instance] addEventReceiver:self type:@"frame"];
  if (fadeTimer) [fadeTimer stop];
  fadeTimer = [Timer timerWithDuration:EXTRA_FADE_IN_TIME object:self tick:@selector(fadeIn:) finish:@selector(fadedIn:)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeIn:(Timer*)timer
{
  size = EXTRA_SIZE*timer.fraction;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadedIn:(Timer*)timer
{
  fadeTimer = nil;
  size = EXTRA_SIZE;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) deactivate
{
  [self stopWiggle];
  if (fadeTimer) [fadeTimer stop];
  fadeTimer = nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) hide
{
  //NSLog(@"hide extra %d", [self retainCount]);
  [[Controller instance] removeEventReceiver:self type:@"frame"];  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) vanish
{
  //NSLog(@"vanish extra %d", [self retainCount]);
  [[Controller instance] removeEventReceiver:self type:@"frame"];  
}

- (void) playWiggleSound {}
- (void) stopWiggleSound {}

//------------------------------------------------------------------------------------------------------------------------
- (void) toggleWiggle
{
  if (!wiggleTimer)
  {
    [self playWiggleSound];
    [self startWiggle];
    Extra * oldWiggler = [Game current].board.wigglingExtra;
    [Game current].board.wigglingExtra = self;
    if (oldWiggler) [oldWiggler toggleWiggle];
  }
  else              
  {
    [self stopWiggleSound];
    [self stopWiggle];
    if ([Game current].board.wigglingExtra == self)
      [Game current].board.wigglingExtra = nil;
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) stopWigglingAndSound
{
  if (wiggleTimer)
  {
    [self stopWiggleSound];
    [self stopWiggle];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) wiggle:(Timer*)timer
{
  angle = sin(timer.time*30.0f)*20.0f;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startWiggle
{
  if (!wiggleTimer)
  {
    wiggleTimer = [Timer timerWithObject:self tick:@selector(wiggle:)];
  }  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) stopWiggle
{
  if (wiggleTimer)
  {
    [wiggleTimer stop];
    wiggleTimer = nil;
    angle = 0;
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) moveTo:(CGPoint)point_
{
  point = point_;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) moveBack:(Timer*)timer
{
  point = CGPointFade(point, targetPoint, timer.fraction);
  size  = CGFade(size, EXTRA_SIZE, timer.fraction);
}

//------------------------------------------------------------------------------------------------------------------------
- (void) movedBack:(Timer*)timer
{
  point = targetPoint;
  layer = _extra_;
  size  = EXTRA_SIZE;
  
  [Sound play:@"drag cancel"];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dragStarted:(DragEvent*)event
{
  layer = _finger_;
  point = event.point;
  size = [Game current].fieldSize;
  [Sound play:@"drag start"];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dragMoved:(DragEvent*)event
{
  point = event.point;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dragCanceled:(DragEvent*)event
{
  point = event.point;
  targetPoint = CGRectCenter(extraButton.rect);
  [moveTimer stop];
  moveTimer = [Timer timerWithDuration:STONE_MOVE_TIME object:self tick:@selector(moveBack:) finish:@selector(movedBack:)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dragEnded:(DragEvent*)event
{
  [Sound play:@"drag end"];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onFrame:(double)delta
{
  float ang = DEG[[Controller instance].orientation] + angle;
  if (ang)
  {
    CGAffineTransform rot = CGAffineTransformMakeRotation(DEG2RAD(ang));
    float w = size/2.0f;
    float h = size/2.0f;
    CGPoint points[4] = { CGPointAdd(point, CGPointApplyAffineTransform(CGPointMake(-w,-h), rot)),
      CGPointAdd(point, CGPointApplyAffineTransform(CGPointMake( w,-h), rot)),
      CGPointAdd(point, CGPointApplyAffineTransform(CGPointMake(-w, h), rot)),
    CGPointAdd(point, CGPointApplyAffineTransform(CGPointMake( w, h), rot)) };
    
    [sprite drawWithPoints:points layer:layer];
  }
  else
  {
    [sprite drawAtPoint:point size:CGSizeMake(size,size) layer:layer];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) onEvent:(Event*)event
{
  if ([event isKindOfClass:[FrameEvent class]]) [self onFrame:((FrameEvent*)event).delta];
  return YES;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) jumpToPos:(Pos)pos onBoard:(Board*)board 
{
  layer = _finger_;
  extraButton.extra = nil;
  [extraButton nextExtra];
  [[Game current] stopWigglingExtra];
  [self startWiggle];
  
  if ([Game current] == [Game instance]) [[Game instance].awards extraUsed];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) jumpToPoint:(CGPoint)targetPoint_ fromPoint:(CGPoint)point_
{
  [[Controller instance] addEventReceiver:self type:@"frame"];
  
  layer = _finger_;
  size = 0;
  targetPoint = targetPoint_;
  point = point_;
  if (moveTimer) [moveTimer stop];
  CGPoint pointToTarget = CGVector(point, targetPoint);
  CGPoint pointToTargetNorm = CGVectorNorm(pointToTarget);
  CGPoint c1 = CGPointAdd(point,       CGPointScale(pointToTargetNorm, -0.5f));
  CGPoint c2 = CGPointAdd(targetPoint, CGPointScale(pointToTargetNorm,  0.5f));
  Bezier * bezier = [Bezier from:point over:c1 and:c2 to:targetPoint];
  
  float time = max(1.5f, 1.5f*CGPointLength(pointToTarget));
  [Timer timerWithDuration:time object:self tick:@selector(goToPoint:) finish:@selector(arrivedAtPoint:) info:bezier];
  [self startWiggle];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) goToPoint:(Timer*)timer
{
  size  = min(1.0f, timer.elapsedTime/0.4f)*EXTRA_SIZE;
  point = [((Bezier*)(timer.info)) pointAtTime:timer.fraction];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) arrivedAtPoint:(Timer*)timer
{
  point = targetPoint;
  layer = _extra_;
  [self stopWiggle];
  if (!extraButton) [self vanish];
}

@end

