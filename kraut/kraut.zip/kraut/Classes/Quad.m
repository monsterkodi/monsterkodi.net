//
//  Quad.m

#import "Quad.h"
#import "Tools.h"

NSMutableDictionary * Quads;
Quad  * currentQuad;

//------------------------------------------------------------------------------------------------------------------------
@implementation Quad
//------------------------------------------------------------------------------------------------------------------------

@synthesize key;
@synthesize additive;

//------------------------------------------------------------------------------------------------------------------------
+ (void) initQuads
{
  if (!Quads) Quads = [[NSMutableDictionary dictionaryWithCapacity:10] retain];
}

//------------------------------------------------------------------------------------------------------------------------
+ (Quad*) key:(NSString*)key
{
  
  Quad * quad = [Quads valueForKey:key];
  if (!quad)
  {
    quad = [[Quad alloc] init];
    quad.key = key;
    [Quads setValue:quad forKey:key];
    [quad release];
  }
  currentQuad = quad;
  return quad;
}

//------------------------------------------------------------------------------------------------------------------------
+ (Quad*) instance 
{ 
  if (!currentQuad) [Quad key:@"QUADS"]; 
  return currentQuad;
}

//------------------------------------------------------------------------------------------------------------------------

+ (void) withRect:(CGRect)rect color:(uint)color;
{
  [[Quad instance] drawAtPoint:CGRectCenter(rect) size:rect.size color:color];
}

//------------------------------------------------------------------------------------------------------------------------

+ (void) atPoint:(CGPoint)point size:(CGSize)size color:(uint)color
{
  [[Quad instance] drawAtPoint:point size:size color:color];
}

//------------------------------------------------------------------------------------------------------------------------
+ (void) flushQuads
{
  for (Quad * quad in [Quads allValues]) [quad flush];
}

//------------------------------------------------------------------------------------------------------------------------

- (id) init
{
  if ((self = [super init]))
  {
    [self initBuffer];
  }
  
  return self;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) initBuffer
{
  alloc = 80;
  count = 0;
  vsize = (2 * sizeof(GLfloat) + 4 * sizeof(GLubyte));
  verts = malloc(alloc * vsize);
}  

//------------------------------------------------------------------------------------------------------------------------

- (void) dealloc
{
  free(verts);  
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) drawWithPoints:(CGPoint*)points color:(uint)color
{
  if (count+6 > alloc && ![self growBuffer:64]) return;
  
  quad * v = &verts[count];
	v->x = points[0].x; 
	v->y = points[0].y; v->c = color; v++; count++;
  v->x = points[1].x; 
	v->y = points[1].y; v->c = color; v++; count++;
  v->x = points[2].x; 
	v->y = points[2].y; v->c = color; v++; count++;
  v->x = points[1].x; 
	v->y = points[1].y; v->c = color; v++; count++;
  v->x = points[2].x; 
	v->y = points[2].y; v->c = color; v++; count++;
  v->x = points[3].x; 
  v->y = points[3].y; v->c = color; v++; count++;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) drawAtPoint:(CGPoint)point size:(CGSize)size color:(uint)color
{
  if (count+6 > alloc && ![self growBuffer:64]) return;
  
  float width  = size.width/2;
  float height = size.height/2;
  
  quad * v = &verts[count];
	v->x = -width  + point.x;
	v->y = -height + point.y; v->c = color; v++; count++;
  v->x =  width  + point.x; 
	v->y = -height + point.y; v->c = color; v++; count++;
  v->x = -width  + point.x;
	v->y =  height + point.y; v->c = color; v++; count++;
  v->x =  width  + point.x; 
	v->y = -height + point.y; v->c = color; v++; count++;
  v->x = -width  + point.x; 
	v->y =  height + point.y; v->c = color; v++; count++;
  v->x =  width  + point.x; 
  v->y =  height + point.y; v->c = color; v++; count++;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) addVertex:(quad)vert
{
  if (count+1 > alloc && ![self growBuffer:32]) return;
  verts[count++] = vert;
}

//------------------------------------------------------------------------------------------------------------------------
-(BOOL) growBuffer:(uint)num
{
  alloc += num;
  verts  = reallocf(verts, alloc * vsize);
  
  if (verts == 0) 
  {
    count = 0;
    return FALSE;
  }
  return TRUE;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) flush
{
  if (count == 0) return;
  
  glEnable(GL_BLEND);
  if (additive) glBlendFunc(GL_SRC_ALPHA, GL_ONE);
  else          glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    
  glEnableClientState(GL_VERTEX_ARRAY);
  glEnableClientState(GL_COLOR_ARRAY);
  
  glVertexPointer  (2, GL_FLOAT,         vsize, verts);
  glColorPointer   (4, GL_UNSIGNED_BYTE, vsize, &verts[0].c);
  
  glDrawArrays(GL_TRIANGLES, 0, count);
  
  glDisable(GL_BLEND);  
  glDisableClientState(GL_VERTEX_ARRAY);
  glDisableClientState(GL_COLOR_ARRAY);
  
  count = 0;
}

@end
