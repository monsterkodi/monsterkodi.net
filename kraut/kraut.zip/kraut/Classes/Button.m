//
//  Button.m

#import "ExtraButton.h"
#import "MenuText.h"
#import "MenuHighscore.h"
#import "MenuSignature.h"
#import "MenuCampaign.h"
#import "MenuAwards.h"
#import "Screen.h"
#import "Sprite.h"
#import "Text.h"
#import "Tools.h"
#import "Resources.h"
#import "Event.h"
#import "Timer.h"
#import "Controller.h"
#import "Letters.h"
#import "Menu.h"
#import "Sound.h"
#import "Game.h"
#import "Extras.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation Button
//------------------------------------------------------------------------------------------------------------------------

@synthesize type;
@synthesize status;
@synthesize touchRect;
@synthesize letters;

//------------------------------------------------------------------------------------------------------------------------

+ (Button*) buttonWithDictionary:dict parent:parent
{
  NSString * type = [dict valueForKey:@"type"];
  Button * button = nil;
  if (type)
  {
    if      ([type isEqualToString:@"toggle"])        button = [[ToggleButton alloc]      initWithDictionary:dict parent:parent];
    else if ([type isEqualToString:@"radio"])         button = [[RadioButton alloc]       initWithDictionary:dict parent:parent];
    else if ([type isEqualToString:@"radial"])        button = [[RadialButton alloc]      initWithDictionary:dict parent:parent];
    else if ([type isEqualToString:@"extra"])         button = [[ExtraButton alloc]       initWithDictionary:dict parent:parent];
    else if ([type isEqualToString:@"game"])          button = [[SpriteButton alloc]        initWithDictionary:dict parent:parent];
    else if ([type isEqualToString:@"text"])          button = [[MenuText alloc]          initWithDictionary:dict parent:parent];
    else if ([type isEqualToString:@"scrolltext"])    button = [[MenuScrollText alloc]    initWithDictionary:dict parent:parent];
    else if ([type isEqualToString:@"flower"])        button = [[FlowerButton alloc]      initWithDictionary:dict parent:parent];
    else if ([type isEqualToString:@"highscore"])     button = [[MenuHighscore alloc]     initWithDictionary:dict parent:parent];
    else if ([type isEqualToString:@"signature"])     button = [[MenuSignature alloc]     initWithDictionary:dict parent:parent];
    else if ([type isEqualToString:@"bucket"])        button = [[FlowerBucket alloc]      initWithDictionary:dict parent:parent];
    else if ([type isEqualToString:@"campaign"])      button = [[MenuCampaign alloc]      initWithDictionary:dict parent:parent];
    else if ([type isEqualToString:@"awards"])        button = [[MenuAwards alloc]        initWithDictionary:dict parent:parent];
    else 
      NSAssert(NO, @"unknown button type");
  }
  else
  {
    button = [[Button alloc] initWithDictionary:dict parent:parent];
  }
  return [button autorelease]; 
}

//------------------------------------------------------------------------------------------------------------------------

- (id) initWithDictionary:(NSDictionary*)dict_ parent:(MenuObject*)parent_
{  
  if ((self = [super initWithDictionary:dict_ parent:parent_]))
  {    
    if (name)
    {
      letters = [[Letters alloc] init];
      if (![dict valueForKey:@"shadow"])
        letters.sprite = [Sprite withName:@"shadow"];
      nameHeight = [dict valueForKey:@"nameHeight"] ? [[dict valueForKey:@"nameHeight"] floatValue] : 0.23f;
      letterHeight = nameHeight;
      [letters setString:name withHeight:nameHeight atPoint:CGPointMake(0,0)];
      rect = CGRectMake(0, 0, letters.width, letters.height);
    }
    
    if ([dict valueForKey:@"sprite"])
    {
      sprite = [Sprite withName:[dict valueForKey:@"sprite"]];
      spriteSize   = [dict valueForKey:@"spriteSize"]  ? [[dict valueForKey:@"spriteSize"]  floatValue] : 0.3f;      
      spriteAlpha  = [dict valueForKey:@"spriteAlpha"] ? [[dict valueForKey:@"spriteAlpha"] floatValue] : 1.0f;      
      rect = CGRectMake(0, 0, spriteSize, spriteSize);
    }
    else
    {
      //sprite = [Sprite withName:@"debug"];
    }
    
    if ([dict valueForKey:@"screen"])
    {
      Screen * screen;
      id screenValue = [dict valueForKey:@"screen"];
      if ([screenValue isKindOfClass:[NSDictionary class]])
        screen = [[[MenuScreen alloc] initWithDictionary:screenValue parent:self] autorelease];
      else
        screen = [[MainMenu instance] screenWithName:screenValue];
      if (screen) [children addObject:screen];
    }
  }

  touchRect = rect;
  
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [letters release];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (NSString*) defaultsKey
{
  NSDictionary * eventDict = [dict objectForKey:@"event"];
  if (eventDict && [eventDict objectForKey:@"key"]) return [eventDict objectForKey:@"key"];
  return nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (NSString*) defaultsValue
{
  NSDictionary * eventDict = [dict objectForKey:@"event"];
  if (eventDict && [eventDict objectForKey:@"value"]) return [eventDict objectForKey:@"value"];
  return [NSString stringWithFormat:@"%d", self.status];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setDefaults
{
  NSString * key = [self defaultsKey];
  id value = [self defaultsValue];
  if (key && value != nil) [[NSUserDefaults standardUserDefaults] setObject:value forKey:key];
}

//------------------------------------------------------------------------------------------------------------------------

- (NSString*) getDefaults
{
  NSString * key = [self defaultsKey];
  if (key) return [[NSUserDefaults standardUserDefaults] objectForKey:[self defaultsKey]];
  return nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) moveBy:(CGPoint)vector
{
  [super moveBy:vector];
  // move touch rect here or not?
  if (letters) [letters moveTo:CGRectCenter(rect)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) moveTo:(CGPoint)point
{
  [super moveTo:point];
  touchRect = CGRectMakeCenterSize(point, touchRect.size);
  if (letters) 
    [letters setString:name withHeight:letterHeight atPoint:point];
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) isWiggling
{
  return (wiggleTimer != nil);
}

//------------------------------------------------------------------------------------------------------------------------
- (void) toggleWiggle
{
  if (!wiggleTimer) [self startWiggle];
  else              [self stopWiggle];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startWiggle
{
  if (!wiggleTimer)
  {
    wiggleTimer = [Timer timerWithObject:self tick:@selector(wiggle:)];
    [wiggleSoundTimer stop];
    wiggleSoundTimer = [Timer timerWithDuration:0.6f object:self tick:@selector(fadeWiggleSound:) finish:@selector(startWiggleSound:)];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) stopWiggle
{
  if (wiggleTimer)
  {
    [wiggleSoundTimer stop];
    [wiggleTimer stop];
    wiggleTimer = nil;
    wiggleSoundTimer = nil;
    
    [Sound stop:@"button wiggle"];
   
    if (letters)
    {
      for (Letter * letter in letters.letters) letter.angle = 0;
    }
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeWiggleSound:(Timer*)timer
{
  if (timer.fraction > 0.3f)
  {
    SoundSample * sample = [Sound sampleWithName:@"button wiggle"];
    if (![sample isLooping]) 
    {
      [sample loopWithVolume:0];
      //[sample setPitch:0.5f];
    }
    [sample setGain:(timer.fraction-0.3f)];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startWiggleSound:(Timer*)timer
{
  wiggleSoundTimer = nil;
  //[Sound loop:@"button wiggle"];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) wiggle:(Timer*)timer
{
  if (letters)
  {
    for (Letter * letter in letters.letters)
    {
      float angle = DEG2RAD(sin(timer.time*50.0f)*20.0f);
      letter.angle = angle;
    }
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onTouchDown:(TouchEvent*)event
{  
  if (CGRectContainsPoint(touchRect, event.point))
  {
    touched = YES;
    [self startWiggle];
  }
}
  
//------------------------------------------------------------------------------------------------------------------------
- (void) onTouchUp:(TouchEvent*)event
{
  if (CGRectContainsPoint(touchRect, event.point))
  {
    [self onPress];
  }
  [self stopWiggle];
  touched = NO;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onTouchMove:(TouchEvent*)event
{
  if (CGRectContainsPoint(touchRect, event.point))
  {
    [self startWiggle];
  }  
  else
  {
    [self stopWiggle];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onPress
{  
  //NSLog(@"Button::onPress %@", self);
  
  if ([dict valueForKey:@"screen"])
  {
    [self.menu displayScreen:[children objectAtIndex:0]];
  }
  else
  {
    ButtonEvent * event = [[ButtonEvent alloc] init];
    event.type   = @"button"; 
    event.key    = [[dict objectForKey:@"event"] objectForKey:@"key"];
    event.value  = [[dict objectForKey:@"event"] objectForKey:@"value"];
    event.status = status;
    [[Controller instance] sendEvent:event];
    [event release];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onFrame:(double)delta
{
  if (letters) 
  {
    [letters draw];
  }
  if (sprite) 
  {
    if (spriteAngle)
    {
      CGAffineTransform rot = CGAffineTransformMakeRotation(DEG2RAD(spriteAngle));
      float w = rect.size.width/2.0f;
      float h = rect.size.height/2.0f;
      CGPoint center = CGPointAdd(spriteOffset, CGRectCenter(rect));
      CGPoint points[4] = { CGPointAdd(center, CGPointApplyAffineTransform(CGPointMake(-w,-h), rot)),
                            CGPointAdd(center, CGPointApplyAffineTransform(CGPointMake( w,-h), rot)),
                            CGPointAdd(center, CGPointApplyAffineTransform(CGPointMake(-w, h), rot)),
                            CGPointAdd(center, CGPointApplyAffineTransform(CGPointMake( w, h), rot)) };
      [sprite drawWithPoints:points alpha:spriteAlpha layer:_menu_];
    }
    else
    {
      [sprite drawWithRect:CGRectMove(rect, spriteOffset) alpha:spriteAlpha layer:_menu_];
    }
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeIn:(float)value
{
  if (letters)
  {
    [letters fade:value offset:self.menu.fadeInOffset];
  }
  if (sprite)
  {
    spriteAlpha = value;
    spriteOffset = CGPointScale(self.menu.fadeInOffset, 1-value);
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeOut:(float)value
{
  if (letters) 
  {
    [letters fade:value offset:self.menu.fadeOutOffset];
  }
  if (sprite)
  {
    spriteAlpha = value;
    spriteOffset = CGPointScale(self.menu.fadeOutOffset, 1-value);
  }
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation ToggleButton
//------------------------------------------------------------------------------------------------------------------------

- (id) initWithDictionary:(NSDictionary*)dict_ parent:(MenuObject*)parent_
{
  if ((self = [super initWithDictionary:(NSDictionary*)dict_ parent:(MenuObject*)parent_]))
  {
    NSString * defaultsValue = [self getDefaults]; 
    if (defaultsValue && [defaultsValue isEqualToString:[self defaultsValue]]) self.status = 1;
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) setStatus:(int)newStatus
{
  if (status != newStatus)
  {
    float scale = (newStatus ? 1.5f : 1.0f);
    if (letters) 
    {
      letterHeight = nameHeight * scale; 
      [letters setHeight:letterHeight];
    }
    if (sprite)  rect = CGRectScale(CGRectMakeCenterSize(CGRectCenter(rect), CGSizeMake(spriteSize, spriteSize)), scale);
  }
  status = newStatus;
  
  if (status) [self setDefaults];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) onPress
{
  self.status = !status;
  
  [super onPress];
  
  [Sound play:@"button press"];
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation RadioButton
//------------------------------------------------------------------------------------------------------------------------

- (id) initWithDictionary:(NSDictionary*)dict_ parent:(MenuObject*)parent_
{
  if ((self = [super initWithDictionary:(NSDictionary*)dict_ parent:(MenuObject*)parent_]))
  {
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) onPress
{
  if (!status)
  {
    for (RadioButton * button in parent.children)
    {
      button.status = 0;
    }
    
    [super onPress];
  }
}

@end
  
//------------------------------------------------------------------------------------------------------------------------
@implementation RadialButton
//------------------------------------------------------------------------------------------------------------------------

@synthesize values;

- (id) initWithDictionary:(NSDictionary*)dict_ parent:(MenuObject*)parent_
{
  if ((self = [super initWithDictionary:(NSDictionary*)dict_ parent:(MenuObject*)parent_]))
  {
    if ([dict valueForKey:@"values"]) self.values = (NSArray*)[dict valueForKey:@"values"];
    status = -1;
    NSString * defaultsValue = [self getDefaults];
    for (NSString * valueString in self.values)
      if ([valueString isEqualToString:defaultsValue])
      {
        status = [self.values indexOfObject:valueString];  
        spriteAngle = -270.0f*status/([values count]-1)+90;
        ((Letters*)[lettersArray objectAtIndex:status]).height = 1.3f*letterHeight;
        [self sendEvent];
      }
    
    lockedStati  = [[NSMutableArray arrayWithCapacity:[values count]] retain];
    lettersArray = [[NSMutableArray arrayWithCapacity:[values count]] retain];

    letterRadius = [dict valueForKey:@"letterRadius"] ? [[dict valueForKey:@"letterRadius"] floatValue] : 0.7f;
    CGPoint rotVec = CGVectorRotate(POINT(0, letterRadius), 135);

    for (NSString * value in values)
    {
      Letters * valueLetters = [[Letters alloc] init];
      valueLetters.sprite = [Sprite withName:@"shadow"];
      nameHeight = [dict valueForKey:@"nameHeight"] ? [[dict valueForKey:@"nameHeight"] floatValue] : 0.23f;
      letterHeight = nameHeight;
      [valueLetters setString:value withHeight:nameHeight atPoint:CGPointAdd(POINT(0,0),rotVec)];      
      [lettersArray addObject:valueLetters];
      [valueLetters release];
      
      rotVec = CGVectorRotate(rotVec, -270.0f/([values count]-1));
    }
          
    touchRect = CGRectMakeCenterSize(CGRectCenter(rect), CGSizeMake(2, 2));
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [lockedStati release];
  [lettersArray release];
  [super dealloc];
}

- (void) startWiggle {}

//------------------------------------------------------------------------------------------------------------------------
- (NSString*) defaultsValue
{
  return [self.values objectAtIndex:self.status];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) moveTo:(CGPoint)point
{
  [super moveTo:point];
  
  CGPoint rotVec = CGVectorRotate(POINT(0, letterRadius), 135);
  for (Letters * l in lettersArray) 
  {
    [l moveTo:CGPointAdd(CGRectCenter(rect), rotVec)];
    rotVec = CGVectorRotate(rotVec, -270.0f/([values count]-1));
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onTouchDown:(TouchEvent*)event
{  
  [super onTouchDown:event];
  if (touched)
  {
    touchAngleStart = status*270.0f/([values count]-1)-135.0f;
    touchAngle = 0;
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onTouchMove:(TouchEvent*)event
{
  if (touched && event.delta != 0)
  {
    CGPoint center = CGRectCenter(rect);
    touchAngle += CGAngle(CGVector(center, event.point), CGVector(center, CGPointSub(event.point,event.direction)));    
    int newStatus = (int)([values count]*(touchAngleStart + touchAngle + 135.0f + 135.0f/[values count])/(270.0f+270.0f/[values count]));
    [self setStatus:clamp(newStatus, 0, [values count]-1)];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onTouchUp:(TouchEvent*)event
{
  if (touched)
  {
    CGPoint center = CGRectCenter(rect);
    float angle = CGAngle(CGVector(center, event.point), CGVector(center, POINT(0,1)));    
    int touchStatus = clamp((int)([values count]*(angle + 135.0f + 135.0f/[values count])/(270.0f+270.0f/[values count])), 0, [values count]-1);

    if (event.delta == 0)
    {      
      [self setStatus:touchStatus];
    }
    else
    {
      int startStatus = (int)([values count]*(touchAngleStart + 135.0f + 135.0f/[values count])/(270.0f+270.0f/[values count]));
      int endStatus = (int)([values count]*(touchAngleStart + touchAngle + 135.0f + 135.0f/[values count])/(270.0f+270.0f/[values count]));
      if (startStatus == endStatus) [self setStatus:touchStatus];
      
      spriteAngle = -270.0f*status/([values count]-1)+90;
    }
    
    [self stopWiggle];
    touched = NO;
    
    [self sendEvent];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) clearStatusLocks
{
  [lockedStati removeAllObjects];
  for (Letters * l in lettersArray) l.color = 0;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) lockStatus:(int)statusToLock
{
  if (![self isLockedStatus:statusToLock])
  {
    [lockedStati addObject:[NSNumber numberWithInt:statusToLock]];
    Letters * l = [lettersArray objectAtIndex:statusToLock];
    l.color = 0xff222222;
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) isLockedStatus:(int)checkStatus
{
  if (checkStatus < 0 || checkStatus >= [values count]) return YES;
  for (id lockedStatus in lockedStati)
    if ([lockedStatus intValue] == checkStatus) return YES;
  return NO;
}

//------------------------------------------------------------------------------------------------------------------------
- (int) nearestAllowedStatusForStatus:(int)checkStatus
{
  if ([self isLockedStatus:checkStatus])
  {
    for (int i = 1; i < 10; i++)
    {
      if (![self isLockedStatus:checkStatus-i]) return checkStatus-i;
      if (![self isLockedStatus:checkStatus+i]) return checkStatus+i;
    }
    
    NSAssert(0, @"no unlocked status?");
    return -1;
  }
  else
  {
    return checkStatus;
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setStatus:(int)newStatus
{
  int allowedStatus = [self nearestAllowedStatusForStatus:newStatus];
  
  if (status != allowedStatus)
  {
    if (status >= 0) ((Letters*)[lettersArray objectAtIndex:status]).height = letterHeight;
    ((Letters*)[lettersArray objectAtIndex:allowedStatus]).height = 1.3f*letterHeight;
    
    spriteAngle = -270.0f*allowedStatus/([values count]-1)+90;
    
    status = allowedStatus;
    [self sendEvent];
    [Sound play:@"dial button rotate"];
    
    [self setDefaults];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) sendEvent
{
  ButtonEvent * buttonEvent = [[ButtonEvent alloc] init];
  buttonEvent.type   = @"button"; 
  buttonEvent.key    = [[dict objectForKey:@"event"] objectForKey:@"key"];
  buttonEvent.value  = [values objectAtIndex:status];
  buttonEvent.status = status;
  [[Controller instance] sendEvent:buttonEvent];
  [buttonEvent release];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeIn:(float)value
{
  [super fadeIn:value];
  for (Letters * l in lettersArray) [l fade:value offset:self.menu.fadeInOffset];
}  

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeOut:(float)value
{
  [super fadeOut:value];
  for (Letters * l in lettersArray) [l fade:value offset:self.menu.fadeOutOffset];
}  

//------------------------------------------------------------------------------------------------------------------------
- (void) onFrame:(double)delta
{
  [super onFrame:delta];
  for (Letters * l in lettersArray) [l draw];
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation FlowerButton
//------------------------------------------------------------------------------------------------------------------------

@synthesize index;

- (id) initWithDictionary:(NSDictionary*)dict_ parent:(MenuObject*)parent_
{
  if ((self = [super initWithDictionary:(NSDictionary*)dict_ parent:(MenuObject*)parent_]))
  {
    index       = [[dict valueForKey:@"index"] intValue];
    spriteAlpha = 1.0f;
    spriteSize  = 0.45f;
    rect        = CGRectMake(0, 0, spriteSize, spriteSize); 
    touchRect   = rect;
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeIn:(float)value
{
  if (value == 0.0f)
  {
    stoneType = ((StoneType*)[[Game instance].arcadeInfo.flowers objectAtIndex:index]);
    sprite = stoneType.sprite;
    shadowSprite = [Sprite withName:@"shadow"];
  }
  
  [super fadeIn:value];
}

//------------------------------------------------------------------------------------------------------------------------
- (void)  onFrame:(double)delta
{
  [super onFrame:delta];
  [shadowSprite drawWithRect:CGRectMove(CGRectScale(rect, 1.7f), spriteOffset) alpha:spriteAlpha layer:_shadow_];
  [shadowSprite drawWithRect:CGRectMove(CGRectScale(rect, 1.7f), spriteOffset) alpha:spriteAlpha layer:_shadow_];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onPress
{
  [super onPress];
    
  [[Game instance] nextArcadeStoneTypeAtIndex:index];
  stoneType = (StoneType*)[[Game instance].arcadeInfo.flowers objectAtIndex:index];
  sprite = stoneType.sprite;
  [stoneType playSound];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startWiggle
{
  if (!wiggleTimer) 
  {
    wiggleTimer = [Timer timerWithObject:self tick:@selector(wiggle:)];
    //[stoneType playSound];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) wiggle:(Timer*)timer
{
  spriteAngle = DEG2RAD(sin(timer.time*50.0f)*20.0f);
}

@end

