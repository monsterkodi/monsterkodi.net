//
//  MenuObject.h

@class TouchEvent;
@class Menu;
@class Screen;

//------------------------------------------------------------------------------------------------------------------------
@interface MenuObject : NSObject 
//------------------------------------------------------------------------------------------------------------------------
{
  NSString       * name;
  NSDictionary   * dict; 
  MenuObject     * parent; 
  NSMutableArray * children; 
  CGRect           rect;
  float            fadeValue;
}

@property (assign)    NSString       * name;
@property (assign)    NSDictionary   * dict;
@property (assign)    MenuObject     * parent;
@property (readonly)  Menu           * menu;
@property (assign)    NSMutableArray * children;
@property (assign)    CGRect           rect;
@property (assign)    float            fadeValue;

- (id)      initWithDictionary:(NSDictionary*)dict parent:(MenuObject*)parent_;
- (void)    dealloc;
- (void)    onTouchUp:(TouchEvent*)event;
- (void)    onTouchDown:(TouchEvent*)event;
- (void)    onTouchMove:(TouchEvent*)event;
- (void)    moveBy:(CGPoint)vector;
- (void)    moveTo:(CGPoint)point;
- (void)    fadeIn:(float)value;
- (void)    fadeOut:(float)value;
- (void)    onFrame:(double)delta;

- (Screen*) screenWithName:(NSString*)screenName;

@end
//------------------------------------------------------------------------------------------------------------------------
