//
//  MenuSignature.m
//  kraut

#import "MenuSignature.h"
#import "Animation.h"
#import "Signature.h"
#import "Stone.h"
#import "Sound.h"
#import "Sprite.h"
#import "Tools.h"
#import "Menu.h"
#import "Line.h"
#import "Quad.h"
#import "Timer.h"
#import "Bezier.h"
#import "Game.h"
#import "Awards.h"
#import "Screen.h"
#import "Controller.h"
 
#define SIGNATURE_WIDTH         1.8f
#define SIGNATURE_HEIGHT        1.1124611f
#define SIGNATURE_YPOS          0.5f

//------------------------------------------------------------------------------------------------------------------------
@implementation BucketFlower
//------------------------------------------------------------------------------------------------------------------------

@synthesize fadeValue;
@synthesize type;
@synthesize point;

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) draw
{
  float s = 0.1f;
  [type.sprite drawAtPoint:point size:CGSizeMake(s,s) alpha:fadeValue layer:_finger_];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) showToPoint:(CGPoint)targetPoint type:(StoneType*)targetType_
{
  targetType = targetType_;
  CGPoint c1 = CGPointAdd(point,       POINT(RANDOMF(1.0f)-0.5f, RANDOMF(-1.0f)));
  CGPoint c2 = CGPointAdd(targetPoint, POINT(RANDOMF(1.0f)-0.5f, RANDOMF(0.5f)));
  Bezier * bezier = [Bezier from:point over:c1 and:c2 to:targetPoint];

  fadeValue = 1;
  if (moveTimer) [moveTimer stop];
  moveTimer = [Timer timerWithDuration:1.0f object:self tick:@selector(show:) finish:@selector(shown:) info:bezier];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) show:(Timer*)timer
{
  point = [((Bezier*)(timer.info)) pointAtTime:timer.fraction];

  [StoneType randomSound];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) shown:(Timer*)timer
{
  point = [((Bezier*)(timer.info)) pointAtTime:1];
  type = targetType;
  fadeValue = 1;  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) vanishToPoint:(CGPoint)targetPoint
{
  [self retain];
  CGPoint c1 = CGPointAdd(point,       POINT(RANDOMF(1.0f)-0.5f, RANDOMF(0.5f)));
  CGPoint c2 = CGPointAdd(targetPoint, POINT(RANDOMF(0.5f)-0.25f, RANDOMF(-0.25f)));
  Bezier * bezier = [Bezier from:point over:c1 and:c2 to:targetPoint];
  
  if (moveTimer) [moveTimer stop];
  moveTimer = [Timer timerWithDuration:0.5f object:self tick:@selector(vanish:) finish:@selector(vanished:) info:bezier];

  [StoneType randomSound];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) vanish:(Timer*)timer
{
  fadeValue = 1-timer.fraction;
  point = [((Bezier*)(timer.info)) pointAtTime:timer.fraction];
  [self draw];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) vanished:(Timer*)timer
{
  [StoneType randomSound];
  
  [self release];
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation FlowerBucket
//------------------------------------------------------------------------------------------------------------------------

@synthesize flowers;

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithDictionary:(NSDictionary*)dict_ parent:(MenuObject*)parent_
{
  if ((self = [super initWithDictionary:dict_ parent:parent_]))
  {
    flowers = [[NSMutableArray arrayWithCapacity:SIGNATURE_MAX_DOTS] retain];
    types   = [[NSMutableArray arrayWithCapacity:7] retain];
    
    for (int i = 0; i < [[dict valueForKey:@"flowers"] count]; i++)
    {
      [types addObject:[StoneType withName:[[dict valueForKey:@"flowers"] objectAtIndex:i]]];
    }
    
    randomType = RANDOMI([types count]);
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (CGPoint) flowerPoint
{
  float scale = ((float)[flowers count])/SIGNATURE_MAX_DOTS;
  float angle = 3600*200.0f/[flowers count];
  return CGPointAdd(CGRectCenter(rect), CGPointScale(CGPointMakeAngle(angle), scale*rect.size.width*0.5f));
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fill
{
  while ([flowers count] < SIGNATURE_MAX_DOTS)
  {
    BucketFlower * flower = [[BucketFlower alloc] init];
    flower.type = [self type];
    flower.point = [self flowerPoint];
    flower.fadeValue = 1.0f;
    [flowers addObject:flower];
    [flower release];
  }  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [flowers release];
  [types release];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) decrement:(int)num point:(CGPoint)point
{
  for (int i = 0; i < num; i++) 
  {
    if ([flowers count]) 
    {
      BucketFlower * flower = [flowers lastObject];
      [flower vanishToPoint:point];
      [flowers removeLastObject];      
    }
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) incrementFromPoint:(CGPoint)point type:(StoneType*)type_
{
  if ([flowers count] < SIGNATURE_MAX_DOTS)
  {
    BucketFlower * flower = [[BucketFlower alloc] init];
    flower.type = type_;
    flower.point = point;
    CGPoint targetPoint = [self flowerPoint];
    [flowers addObject:flower];
    [flower release];  
    [flower showToPoint:targetPoint type:[self type]];    
  }
}  

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) isFull { return ([flowers count] > 0); }

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeIn:(float)value
{
  for (BucketFlower * flower in flowers) flower.fadeValue = value;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeOut:(float)value
{
  for (BucketFlower * flower in flowers) flower.fadeValue = value;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onPress
{
  status = ((status+1) % ([types count]+1));
  if (status)
  {
    for (BucketFlower * flower in flowers) flower.type = [types objectAtIndex:(status-1)];
  }
  else
  {
    for (BucketFlower * flower in flowers) flower.type = [types objectAtIndex:RANDOMI([types count])];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (StoneType*) type
{
  if (status) 
  {
    return [types objectAtIndex:status-1];
  }
  else 
  {
    randomType = (randomType+1) % [types count];
    return [types objectAtIndex:randomType];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onFrame:(double)delta
{
  [super onFrame:delta];
  for (BucketFlower * flower in flowers) [flower draw];
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation MenuSignature
//------------------------------------------------------------------------------------------------------------------------

- (id) initWithDictionary:(NSDictionary*)dict_ parent:(MenuObject*)parent_
{  
  if ((self = [super initWithDictionary:dict_ parent:parent_]))
  {
    stoneType = [StoneType withName:@"flower00"];
  }
  
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onTouchDown:(TouchEvent*)event
{
  if (event.finger == 1)
  {
    if ([bucket isFull])
    {
      stoneType = [bucket type];
      [signature startStrokeOfType:stoneType.name atPoint:event.point];
    }
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onTouchMove:(TouchEvent*)event
{
  if (event.finger == 1)
  {
    if ([bucket isFull])
    {
      int num = [signature addStrokePoint:event.point ofType:stoneType.name];
      [bucket decrement:num point:event.point];
    }
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onTouchUp:(TouchEvent*)event
{
  if (event.finger > 1)
  {
    for (int i = 0; i < signature.strokePoints; i++)
    {
      [bucket incrementFromPoint:[signature strokePoint:i].point type:[signature stoneType:i]];
    }
    [signature clear];
  }
  else if (event.finger == 1)
  {
    if ([bucket isFull])
    {
      int num = [signature endStrokeAtPoint:event.point];
      [bucket decrement:num point:event.point];
    }
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeIn:(float)value
{
  if (value == 0) 
  {
    bucket = [[parent children] objectAtIndex:2];
    [bucket fill];
    signature = [Game instance].highscoreEntry.signature;
    CGPoint center = POINT(0, SIGNATURE_YPOS-SIGNATURE_HEIGHT/2);
    signature.rect = CGRectMakeCenterSize(center, CGSizeMake(SIGNATURE_WIDTH, SIGNATURE_HEIGHT));
  }

  fadeValue = value;
  offset = CGPointScale(self.menu.fadeInOffset, 1-value);    
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeOut:(float)value
{
  fadeValue = value;
  offset = CGPointScale(self.menu.fadeOutOffset, 1-value);
  
  if (fadeValue == 1)
  {
    signature = [signature copy];
    [Highscores saveHighscores];
    [[Game instance].awards highscoreAdded];
  }
  if (fadeValue == 0)
  {
    [signature release];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onFrame:(double)delta
{
  for (MenuObject* child in children) [child onFrame:delta];
  
  CGPoint center = POINT(0+offset.x, SIGNATURE_YPOS-SIGNATURE_HEIGHT/2+offset.y);
  signatureRect = CGRectMakeCenterSize(center, CGSizeMake(SIGNATURE_WIDTH, SIGNATURE_HEIGHT));
  
  float c = 0.2f; [Line color:RGBACOLOR(c,c,c,0.5f*fadeValue)]; [Line rect:signatureRect];
  
  [[Sprite withName:@"blank"] drawWithRect:signatureRect color:RGBACOLOR(0,0,0,0.1f+0.9f*fadeValue) layer:_text_];
  
  for (Stroke * stroke in signature.strokes)
  {
    for (StrokePoint * strokePoint in stroke.points)
    {
      float s = 1.44f*strokePoint.size;
      [stroke.type.sprite drawAtPoint:strokePoint.point size:CGSizeMake(s,s) alpha:fadeValue layer:_finger_];
    }
  }
}

@end
