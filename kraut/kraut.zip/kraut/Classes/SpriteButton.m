//
//  GameButton.m
//  kraut

#import "SpriteButton.h"
#import "Sprite.h"
#import "Tools.h"
#import "Timer.h"
#import "Text.h"
#import "Letters.h"
#import "Game.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation SpriteButton
//------------------------------------------------------------------------------------------------------------------------

@synthesize count;
@synthesize fadeInOffset;
@synthesize fadeOutOffset;

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithDictionary:(NSDictionary*)dict_ parent:(MenuObject*)parent_
{
  if ((self = [super initWithDictionary:dict_ parent:parent_]))
  {
    if ([dict valueForKey:@"sprites"])
    {
      int i = 0;
      for (NSDictionary * spriteDict in [dict valueForKey:@"sprites"])
      {
        if (i < 3)
        {
          float size              = [spriteDict valueForKey:@"spriteSize"]  ? [[spriteDict valueForKey:@"spriteSize"]  floatValue] : 0.3f;
          if ([spriteDict valueForKey:@"sprite"])
            spriteinfo[i].sprite  = [Sprite withName:[spriteDict valueForKey:@"sprite"]];
          spriteinfo[i].rect      = CGRectMake(0, 0, size, size);
          spriteinfo[i].layer     = [spriteDict valueForKey:@"layer"] ? [[spriteDict valueForKey:@"layer"] intValue] : spriteinfo[i].sprite.layer;
          if (i == 0 || i == 2)
          {            
            spriteinfo[i].colorname = [spriteDict valueForKey:@"colorname"] ? [spriteDict valueForKey:@"colorname"] : nil;
            
            if ([spriteDict valueForKey:@"color"])
            {
              NSArray * colors = [[spriteDict valueForKey:@"color"] componentsSeparatedByString:@" "];
              spriteinfo[i].color = RGBCOLOR([[colors objectAtIndex:0] floatValue], [[colors objectAtIndex:1] floatValue], [[colors objectAtIndex:2] floatValue]);
            }
            else spriteinfo[i].color = 0xffffffff;
          }
          else
          {
            spriteinfo[i].color = GLOW_COLOR;
          }
        }
        i++;
      }
      touchRect = spriteinfo[0].rect;
    }
    
    fadeInOffset  = CGPointMake(0,3);
    fadeOutOffset = CGPointMake(0,-3);
    
    countOffset   = CGPointMake(0.5f, -0.5f);
    countHeight   = [dict valueForKey:@"countHeight"] ? [[dict valueForKey:@"countHeight"] floatValue] : 0.1f;
    countBackgroundColor = 0xff000000;
    
    if ([dict valueForKey:@"countBackgroundColor"])
    {
      NSArray * colors = [[dict valueForKey:@"countBackgroundColor"] componentsSeparatedByString:@" "];
      countBackgroundColor = RGBACOLOR([[colors objectAtIndex:0] floatValue], [[colors objectAtIndex:1] floatValue], [[colors objectAtIndex:2] floatValue], [[colors objectAtIndex:3] floatValue]);
    }
    
    minCount = [dict valueForKey:@"minCount"] ? [[dict valueForKey:@"minCount"] intValue] : 1;
    
    if ([dict valueForKey:@"fadeInOffset"])
    {
      NSArray * coords = [[dict valueForKey:@"fadeInOffset"] componentsSeparatedByString:@" "];
      fadeInOffset = CGPointMake([[coords objectAtIndex:0] floatValue], [[coords objectAtIndex:1] floatValue]); 
    }
    
    if ([dict valueForKey:@"fadeOutOffset"])
    {
      NSArray * coords = [[dict valueForKey:@"fadeOutOffset"] componentsSeparatedByString:@" "];
      fadeOutOffset = CGPointMake([[coords objectAtIndex:0] floatValue], [[coords objectAtIndex:1] floatValue]); 
    }
    
    if ([dict valueForKey:@"countOffset"])
    {
      NSArray * coords = [[dict valueForKey:@"countOffset"] componentsSeparatedByString:@" "];
      countOffset = CGPointMake([[coords objectAtIndex:0] floatValue], [[coords objectAtIndex:1] floatValue]); 
    }
    
    if (letters)
    { 
      letters.color =  0xff000000; 
      letters.layer = _extra_; 
    }
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) wiggle:(Timer*)timer
{
  [super wiggle:timer];
  
  if (spriteinfo[2].sprite) spriteangle = sin(timer.time*50.0f)*20.0f;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) stopWiggle
{
  [super stopWiggle];
  spriteangle = 0;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onFrame:(double)delta
{
  [super onFrame:delta];
  
  for (int i = 0; i < 3; i++)
  {    
    SpriteInfo * info = &spriteinfo[i];
    if (info->sprite)
    {
      CGRect spriteRect = CGRectMove(info->rect, CGVector(CGRectCenter(info->rect), 
                                                          CGPointAdd(CGRectCenter(rect), offset)));
      
      if (i == 0)
        [info->sprite drawWithRect:spriteRect color:info->color layer:info->layer];
      else if (i == 2)
      {
        if (spriteangle) [info->sprite drawAtPoint:CGRectCenter(spriteRect) angle:spriteangle size:spriteRect.size color:info->color layer:info->layer];
        else [info->sprite drawWithRect:spriteRect color:info->color layer:info->layer];     
      }
      else
        [info->sprite drawWithRect:CGRectMove(spriteRect, POINT(-spriteRect.size.width/6.0f, spriteRect.size.height/6.0f)) color:GLOW_COLOR
         layer:info->layer];
    }
  }
  
  if (count > minCount)
  {
    SpriteInfo * info = &spriteinfo[0];
    
    float s = 0.65f;
    float w = info->rect.size.height*s;
    CGRect spriteRect = CGRectMakeCenterSize(POINT(rect.origin.x+offset.x + countOffset.x*w, rect.origin.y+offset.y + countOffset.y*w), CGSizeMake(w, w));
    
    [info->sprite drawWithRect:spriteRect color:countBackgroundColor layer:info->layer];
    
    [[NSString stringWithFormat:@"%d", count] drawAtCenter:CGRectCenter(spriteRect) 
                                                    height:countHeight 
                                                     color:info->color layer:info->layer];
  }  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setColor:(uint)color forName:(NSString*)colorname
{
  SpriteInfo * info = &spriteinfo[0];
  if (info->colorname && [info->colorname isEqualToString:colorname]) 
    info->color = color;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setColor:(uint)color forIndex:(int)spriteIndex
{
  SpriteInfo * info = &spriteinfo[spriteIndex];
  info->color = color;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setSprite:(Sprite*)sprite_
{
  spriteinfo[2].sprite = sprite_;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeIn:(float)value
{
  fadeValue = value;
  offset = CGPointScale(fadeInOffset, (1-value));
  if (letters) [letters moveTo:CGPointAdd(offset, CGRectCenter(rect))];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeOut:(float)value
{
  fadeValue = value;
  offset = CGPointScale(fadeOutOffset, (1-value));
  if (letters) [letters moveTo:CGPointAdd(offset, CGRectCenter(rect))];
}

@end
