//
//  Ramp.m

#import "Ramp.h"
#import "Game.h"
#import "Line.h"
#import "Bug.h"
#import "Bee.h"
#import "Butterfly.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation Ramp
//------------------------------------------------------------------------------------------------------------------------

@synthesize blocks;

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithRect:(CGRect)rect_ size:(int)size name:(NSString*)name_
{
  if ((self = [super initWithRect:rect_ cols:size rows:3 name:name_]))
  {
    blocks = [[NSMutableArray arrayWithCapacity:cols] retain];
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [blocks release];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onFrame:(double)delta
{
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadedIn:(Timer*)timer
{
  [super fadedIn:timer];  
  [game rampFadedIn];
}

//------------------------------------------------------------------------------------------------------------------------
- (Pos) jumpPosForBugAtPoint:(CGPoint)point
{
  Pos pos = [self posForPoint:point];
  pos.y = 1;
  return pos;
}

//------------------------------------------------------------------------------------------------------------------------
- (Pos) jumpPosForButAtPoint:(CGPoint)point
{
  Pos pos = [self posForPoint:point];
  return pos;
}

//------------------------------------------------------------------------------------------------------------------------
- (NSDictionary*) dictionary
{
  NSMutableArray * array = [NSMutableArray arrayWithCapacity:6];
  for (Block * block in blocks)
  {
    [array addObject:[NSArray arrayWithObjects:block.first.type.name, block.center.type.name, block.last.type.name, nil]];
  }
  return [NSDictionary dictionaryWithObject:array forKey:@"blocks"];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setupWithDictionary:(NSDictionary*)dictionary
{
  //NSLog(@"ramp::setupWithDictionary: dictionary %@", dictionary);
  int i = 0;
  for (NSArray * blockArray in [dictionary valueForKey:@"blocks"])
  {
    Block * block;
    if ([blockArray count])
    {
      block = [[Block alloc] initWithFirst:[StoneType withName:[blockArray objectAtIndex:0]] 
                                    center:[StoneType withName:[blockArray objectAtIndex:1]]  
                                      last:[StoneType withName:[blockArray objectAtIndex:2]]];  
    
      [self setStonesForBlock:block atPos:POS(i,1)];
    }
    else
    {
      block = [[Block alloc] init];
    }
    [blocks addObject:block];
    [block release];
    i++;
  }  
}

//------------------------------------------------------------------------------------------------------------------------
- (Block*) newBlock
{
  //NSLog(@"ramp::newBlock");
  return [[Game current] newBlockForRamp];
}

//------------------------------------------------------------------------------------------------------------------------

- (CGPoint) startPoint
{
  Field * fc = [self fieldAtPos:POS(1,1)];
  Field * fs = [self fieldAtPos:POS(0,1)];
  return CGPointAdd(CGRectCenter(fs.rect), CGVector(CGRectCenter(fc.rect), CGRectCenter(fs.rect)));
}

//------------------------------------------------------------------------------------------------------------------------
- (void) layout
{
  BOOL lefty = [Game current].lefty;
    
  rect = CGRectMakeCenterSize(POINT((lefty?1:-1)*(1-rect.size.width/2), 1.5f-rect.size.height/2), rect.size);
  
  float startSize = rect.size.height/3.0f;
  float endSize   = rect.size.height/3.0f;
  
  float x = lefty ? CGRectGetMaxX(rect) : CGRectGetMinX(rect);
  
  for (int col = 0; col < cols; col++)
  {
    float size = startSize + col*(endSize-startSize)/(cols-1);
    
    for (int row = 0; row < rows; row++)
    {
      float y = CGRectGetMaxY(rect) - (3-row) * size;
      CGRect fr = CGRectMake(offset.x + x, offset.y + y, size, size);
      [[self fieldAtCol:col row:row] moveTo:fr.origin];
    }

    x += size * (lefty ? -1 : 1);
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (Block*) insertNewBlock
{
  return [self insertBlock:[self newBlock]];
}

//------------------------------------------------------------------------------------------------------------------------
- (int) numBlocks
{
  int num = 0;
  for (Block * block in blocks) if (![block isEmpty]) num++;
  return num;
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) isEmpty
{
  return ([self numBlocks] == 0);
}

//------------------------------------------------------------------------------------------------------------------------
- (Block*) insertBlock:(Block*)newBlock
{
  //NSLog(@"ramp::insertBlock %@", newBlock);
  Block * oldBlock = nil; 
  
  if ([blocks count] >= cols) // remove last block
  {
    oldBlock = [[blocks lastObject] retain];
    [blocks removeLastObject];
  }
  
  for (int i = [blocks count]-1; i >= 0; i--) // shift remaining blocks
  {
    Block * block = [blocks objectAtIndex:i];
    [self delStonesForBlock:block];
    [self setStonesForBlock:block atPos:POS(i+1,1)];
  }
  
  [blocks insertObject:newBlock atIndex:0]; // insert new block
  [self setStonesForBlock:newBlock atPos:POS(0,1)];
  for (Stone * stone in newBlock.stones) [stone fadeIn]; // make stones visible
  
  return [oldBlock autorelease];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) clear
{
  [super clear];
  [blocks removeAllObjects];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fill
{
  //NSLog(@"ramp::fill");
  while ([blocks count] < cols) [self insertNewBlock];  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) resetExtraTarget
{
  for (int col = max(0,extraTargetCol-1); col <= min(extraTargetCol+1, cols-1); col++)
  for (int row = 0; row < 3; row++)
  {
    Field * field = [self fieldAtCol:col row:row];
    field.stone.alpha = 1.0f;
  }
  if (extraTargetPos) 
  {
    Field * field = [self fieldAtPos:extraTargetPos];
    field.stone.alpha = 1.0f;
  }
  
  extraTargetCol = -1;
  butTargetType = nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) displayBugTarget
{
  for (int col = max(0,extraTargetCol-1); col <= min(extraTargetCol+1, cols-1); col++)
  for (int row = 0; row < 3; row++) 
  {
    Field * field = [self fieldAtCol:col row:row];
    field.stone.alpha = 0.2f;
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) displayButTarget
{
  for (int col = max(0,extraTargetCol-1); col <= min(extraTargetCol+1, cols-1); col++)
    for (int row = 0; row < 3; row++) 
    {
      Field * field = [self fieldAtCol:col row:row];
      if (field.stone.type == butTargetType)
        field.stone.alpha = 0.2f;
    }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) displayBeeTarget
{
    Field * field = [self fieldAtPos:extraTargetPos];
    field.stone.alpha = 0.2f;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dragMoved:(DragEvent*)event
{
  if ([event.object isKindOfClass:[Bug class]])
  {
    [self resetExtraTarget];
    extraTargetCol = [self jumpPosForBugAtPoint:event.point].x;
    [self displayBugTarget];
  }  
  else if ([event.object isKindOfClass:[Butterfly class]])
  {
    [self resetExtraTarget];
    Pos pos = [self jumpPosForButAtPoint:event.point];
    extraTargetCol = pos.x;
    butTargetType = [self fieldAtPos:pos].stone.type;
    [self displayButTarget];
  }  
  else if ([event.object isKindOfClass:[Bee class]])
  {
    [self resetExtraTarget];
    [extraTargetPos release];
    extraTargetPos = [[self posForPoint:event.point] retain];
    butTargetType = [self fieldAtPos:extraTargetPos].stone.type;
    [self displayBeeTarget];
  }  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dragCanceled:(DragEvent*)event
{
  if ([event.object isKindOfClass:[Bug class]] || [event.object isKindOfClass:[Bee class]])
  {
    [self resetExtraTarget];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dragEnded:(DragEvent*)event
{    
  if ([event.object isKindOfClass:[Bug class]])
  {
    int col = min(extraTargetCol+1, cols-1);
    int num = col-max(0,extraTargetCol-1)+1;
    for (int i = 0; i < num; i++)
    {
      Block * oldBlock = [blocks objectAtIndex:col]; 
      [self delStonesForBlock:oldBlock];
      [blocks removeObjectAtIndex:col];
            
      for (int i = col-1; i >= 0; i--) // shift remaining blocks
      {
        Block * block = [blocks objectAtIndex:i];
        [self delStonesForBlock:block];
        [self setStonesForBlock:block atPos:POS(i+1,1)];
      }
      Block * newBlock = [self newBlock];
      [blocks insertObject:newBlock atIndex:0]; // insert new block
      [self setStonesForBlock:newBlock atPos:POS(0,1)];
      
      for (Stone * stone in newBlock.stones) [stone fadeIn]; // make stones visible
    }
          
    [self resetExtraTarget];
  }
  else if ([event.object isKindOfClass:[Butterfly class]])
  {
    int col = max(extraTargetCol-1, 0);
    int num = min(cols-1,extraTargetCol+1)-col+1;
    for (int i = 0; i < num; i++)
    {
      int numFlowers = game.levelInfo.numFlowers;
      int flowerIndex = [game.levelInfo.flowers indexOfObject:butTargetType];
      Block * block = [blocks objectAtIndex:col+i];
      for (int row = 0; row < 3; row++)
      {
        Stone * stone = [block.stones objectAtIndex:row];
        if (stone.type == butTargetType)
        {
          int randomOffset = 1 + RANDOMI(numFlowers-1);
          int newFlowerIndex = ((flowerIndex + randomOffset)%numFlowers);
          StoneType * newType = [game.levelInfo.flowers objectAtIndex:newFlowerIndex];
          Stone * newStone = [Stone ofType:newType];
          [block.stones replaceObjectAtIndex:row withObject:newStone];
          [self fieldAtCol:col+i row:row].stone = newStone;
          [newStone fadeIn];
          [stone explode];
          [newStone release];
        }
      }
    }
    
    [self resetExtraTarget];    
  }
  else if ([event.object isKindOfClass:[Bee class]])
  {
    int numFlowers = game.levelInfo.numFlowers;
    int flowerIndex = [game.levelInfo.flowers indexOfObject:butTargetType];
    int randomOffset = 1 + RANDOMI(numFlowers-1);
    int newFlowerIndex = ((flowerIndex + randomOffset)%numFlowers);
    StoneType * newType = [game.levelInfo.flowers objectAtIndex:newFlowerIndex];
    Stone * newStone = [Stone ofType:newType];
    Block * block = [blocks objectAtIndex:extraTargetPos.x];
    [block.stones replaceObjectAtIndex:extraTargetPos.y withObject:newStone];
    
    Field * field = [self fieldAtPos:extraTargetPos];
    Stone * stone = field.stone;
    field.stone = newStone;
    [newStone fadeIn];
    [stone explode];
    [newStone release];
    
    [self resetExtraTarget];    
    
    [extraTargetPos release];
    extraTargetPos = nil;
  }  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) handleDragEvent:(DragEvent*)dragEvent
{ 
  if ([dragEvent.object isKindOfClass:[Bug class]] || [dragEvent.object isKindOfClass:[Butterfly class]] || [dragEvent.object isKindOfClass:[Bee class]])
  {
    if (dragEvent.target == self) dragEvent.target = nil;
    if ([self isValidPos:[self posForPoint:dragEvent.point]])
    {
      if ([dragEvent.object isKindOfClass:[Bug class]])
        extraTargetCol = [self jumpPosForBugAtPoint:dragEvent.point].x;
      else if ([dragEvent.object isKindOfClass:[Butterfly class]])
        extraTargetCol = [self jumpPosForButAtPoint:dragEvent.point].x;
      else if ([dragEvent.object isKindOfClass:[Bee class]])
      {
        [extraTargetPos release];
        extraTargetPos = [[self posForPoint:dragEvent.point] retain];
      }
      dragEvent.target = self;
    }
    else
    {
      [self resetExtraTarget];
    }      
  }  
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) onEvent:(Event*)event_
{
  if ([event_ isKindOfClass:[DragEvent class]])
  {
    [self handleDragEvent:(DragEvent*)event_];
    return YES;
  }
  return [super onEvent:event_];
}


@end
