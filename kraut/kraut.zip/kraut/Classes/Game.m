//
//  Game.m

#import "Game.h"
#import "Controller.h"
#import "Campaign.h"
#import "Awards.h"
#import "Challenge.h"
#import "Particle.h"
#import "Extras.h"
#import "ExtraButton.h"
#import "Highscores.h"
#import "Menu.h"
#import "Screen.h"
#import "Ramp.h"
#import "Sound.h"
#import "Timer.h"
#import "Help.h"

float DIR[4][2] = { { 0, 1 }, { 1, 0 }, { 0, -1 }, { -1, 0 } };
float ANG[4]    = { 0, -M_PI_2, M_PI, M_PI_2 };
float DEG[4]    = { 0, -90, 180, 90 };

NSString * DIFFICULTY[3] = {@"Easy", @"Medium", @"Hard"};

int ARCADE_FLOWERS[NUM_ARCADE_FLOWERS] = { 71, 21, 22, 23, 40, 42, 43 };
uint POLLEN_COLORS[40] = {
0x880000,0x987000,0x3F003D,0xFEFEFE,0xC50042,
0xFF4900,0xE30000,0xDD0000,0xFFCD00,0xF4FF00,
0x4855D7,0x870000,0x5841FF,0xFF7900,0xBC0041,
0xBC0041,0x3E008F,0xF8E900,0x808AFF,0xD60000,
0xE0E7F6,0xFF0000,0xCA8FF2,0xFFFA00,0xFF0EFF,                          
0x617AE3,0xFF00F5,0xA9B3FC,0x7D8CFF,0xE779FF,
0x470099,0x76000A,0xAA0016,0xFFB600,0xBF0069,
0xFFFB00,0x536BEF,0xE2E2E4,0xDD306B,0x840000,
};

//------------------------------------------------------------------------------------------------------------------------
@implementation Game
//------------------------------------------------------------------------------------------------------------------------

@synthesize board;
@synthesize jump;
@synthesize ramp;
@synthesize levelInfo;
@synthesize arcadeInfo;
@synthesize campaign;
@synthesize challenge;
@synthesize awards;
@synthesize highscores;
@synthesize highscoreEntry;
@synthesize score;
@synthesize clock;
@synthesize lefty;
@synthesize menu;
@synthesize extras;
@synthesize fieldSize;
@synthesize beeButton;
@synthesize bugButton;
@synthesize butButton;
@synthesize stoneTypes;
@synthesize arcadeStoneTypes;
@synthesize stoneMoveTime;
@synthesize blockList;

//------------------------------------------------------------------------------------------------------------------------
+ (Game*) instance
{
  return [Controller instance].game;
}

//------------------------------------------------------------------------------------------------------------------------
+ (Game*) current
{
  return [Controller instance].currentGame;
}

//------------------------------------------------------------------------------------------------------------------------
- (id) init
{
  if ((self = [super init]))
  {
    stoneTypes = [[NSMutableDictionary dictionaryWithCapacity:40] retain];
    arcadeStoneTypes = [[NSMutableArray arrayWithCapacity:10] retain];
    
    [[Controller instance] addEventReceiver:self type:@"button"];
        
    float bs = RAMP_SIZE;
    
    float rw = 8.0f/7.0f;
    float rh = 4.0f/7.0f;
    
    board     = [[MainBoard alloc] initWithRect:CGRectMake(-1.0f, -1.5f,    2.0f, 2.0f) size:7 name:@"main"];
    ramp      = [[Ramp      alloc] initWithRect:CGRectMake(-1,     1.5f-rh, rw,   rh)   size:6 name:@"ramp"];
    jump      = [[Jump      alloc] initWithRect:CGRectMake( 1-bs,  1.5f-bs, bs,   bs)   size:3 name:@"jump"];    
    score     = [[Score     alloc] init];
    clock     = [[Clock     alloc] init];
    campaign  = [[Campaign  alloc] init];
    awards    = [[Awards    alloc] init];
    menu      = [[GameMenu  alloc] init];
    extras    = [[Extras    alloc] init];
    
    board.game = self;
    jump.game  = self;
    ramp.game  = self;
    
    gameIsOver = YES;
  }
  
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [[Controller instance] removeEventReceiver:self type:@"button"];
  //[[Controller instance] removeEventReceiver:self type:@"orientation"];

  [board      release];
  [ramp       release];
  [jump       release];
  [clock      release];
  [score      release];
  [highscores release];
  [arcadeInfo release];
  [campaign   release];
  [awards     release];
  //[level      release];
  [menu       release];
  [extras     release];
  
  [arcadeStoneTypes release];
  [stoneTypes       release];
  
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setup
{
  uint pollenAlpha = 0xff000000;
  uint scoreAlpha  = 0x99000000;
  uint buttonAlpha = 0x99000000;

  for (int i = 0; i < 40; i++)
  {
    int flowerIndex = (i%5) + 10*(i/5);
    NSString * flowerName = [NSString stringWithFormat:@"flower%02d", flowerIndex];
    StoneType * stoneType = [[StoneType alloc] initWithName:flowerName image:flowerName];
    stoneType.pollenColor = GLCOLOR(POLLEN_COLORS[i]) | pollenAlpha;
    stoneType.scoreColor  = GLCOLOR(POLLEN_COLORS[i]) | scoreAlpha;
    stoneType.buttonColor = GLCOLOR(POLLEN_COLORS[i]) | buttonAlpha;
    [stoneTypes setValue:stoneType forKey:flowerName];
    [stoneType release];
  }
  
  highscores = [[Highscores alloc] init];

  arcadeInfo = [[LevelInfo alloc] init];
  for (int i = 0; i < 7; i++)
    [arcadeInfo.flowers addObject:[StoneType withName:[[NSUserDefaults standardUserDefaults] stringForKey:[NSString stringWithFormat:@"stone%d", i]]]];
  arcadeInfo.size        = [[[NSUserDefaults standardUserDefaults] stringForKey:@"size"] intValue];
  arcadeInfo.difficulty  = [[[NSUserDefaults standardUserDefaults] stringForKey:@"difficulty"] intValue];
  //arcadeInfo.clockDecreaseDurationFactor = 0.1f;
  
  [menu setupWithGame:self];
  menu.mainScreen.fadeInTime = GAME_FADE_IN_TIME;
  menu.mainScreen.fadeOutTime = GAME_FADE_OUT_TIME;

  [awards   setup];
  [campaign setup];
  
  [self setupArcadeFlowers];
    
  [self loadGame];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setupArcadeFlowers
{
  NSArray * arcadeFlowerIndices = [[campaign.info valueForKey:@"modeflowers"] valueForKey:@"arcade"];
  for (id fi in arcadeFlowerIndices) 
    [self addArcadeFlower:[NSString stringWithFormat:@"flower%02d", [fi intValue]]];
  
  for (id flowerName in [awards wonFlowers])
    [self addArcadeFlower:flowerName];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) addArcadeFlower:(NSString*)flowerName
{
  if (flowerName)
  {
    //NSLog(@"Game::addArcadeFlower %@", flowerName);
    if (![arcadeStoneTypes containsObject:[StoneType withName:flowerName]])
      [arcadeStoneTypes addObject:[StoneType withName:flowerName]];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) changeOrientation:(Orientation)o
{
  board.angle = ANG[o];
  ramp.angle  = ANG[o];
  jump.angle  = ANG[o];
  score.angle = ANG[o];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) rampFadedIn
{
  [ramp fill];
  if (!jump.block) [self nextBlock];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) jumpFadedIn
{
  if (!jump.block) [self nextBlock];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeOut
{
  [Sound play:@"game fade out"];
  [self stopWigglingExtra];
  [extras deactivateAllExtras];
    
  [board fadeOut];
  [ramp  fadeOut];
  [jump  fadeOut];
  [score fadeOut];
  [clock fadeOut];
  [menu  fadeOut];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onStoneExploding
{
  if (challenge && clock.mode == CLEAR)
  {
    [clock setCount:clock.duration - [board numberOfFlowers]];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onBlockDropped
{
  if (challenge && clock.mode == CLEAR)
  {
    [clock setCount:clock.duration - [board numberOfFlowers]];
  }
}

//------------------------------------------------------------------------------------------------------------------------

- (void) explodeChains:(NSMutableArray*)chains reason:(int)reason
{
  //NSLog(@"explodeChains reason %d", reason);
  if (reason == EXPLODE_REASON_STONE_DROPPED) [self onBlockDropped];
  
  uint stoneCount = 0;
  uint colors[3];
  int ci = 0;
  CGPoint point = POINT(0,0);
  for (NSArray * chain in chains)
  {
    stoneCount += [chain count];
    for (Stone * stone in chain) point = CGPointAdd(point, CGRectCenter(stone.targetRect));
    for (int i = ci++; i < 3; i++) colors[i] = ((Stone*)[chain objectAtIndex:0]).type.pollenColor;
  }
  point = CGPointScale(point, 1.0f/stoneCount);
  
  CGPoint nearestPoint = POINT(999,999);
  float minDist = 999.0f;
  for (NSArray * chain in chains)
  {
    for (Stone * stone in chain)
    {
      CGPoint pointToStone = CGVector(point, CGRectCenter(stone.targetRect));
      float dist = absf(pointToStone.x) + absf(pointToStone.y);
      if (dist < minDist)
      {
        nearestPoint = CGRectCenter(stone.targetRect);
        minDist = dist;
      }
    }
  }
  
  uint pollen = [Score scoreForNumStones:stoneCount];
  
  if (reason != EXPLODE_REASON_PENALTY_STONE) 
  {
    if (reason == EXPLODE_REASON_BEE_DROPPED || ![levelInfo.prize isEqualToString:@"bee"])
    [clock addTimeForPollen:pollen];
  }

  ScoreDisplay * scoreDisplay = nil;
  
  if (pollen) // display the number of points ...
  {
    if (pollen > 2) 
    {
      scoreDisplay = [ScoreDisplay displayScore:pollen atPoint:nearestPoint colors:colors];
      
      if (pollen >= 100) [Sound play:@"score100"];
      else if (pollen >= 75) [Sound play:@"score75"]; 
      else if (pollen >= 50) [Sound play:@"score50"]; 
      else if (pollen >= 30) [Sound play:@"score30"];
      else if (pollen >= 20) [Sound play:@"score20"]; 
    }
    
    [Sound play:@"stone explode" volume:clamp(stoneCount/27.0f, 0.0f, 1.0f)];
    //[Sound play:@"stone drop"];
    
    [Extras extraForPollen:pollen score:score.value point:nearestPoint]; // add new extras
    
    //[level addPoints:pollen]; // add points to level
    score.pollen += pollen;
    
    if (pollen < stoneCount) // let the pollen fly ...
    {
      [Pollen forStone:[board stoneAtPos:[board posForPoint:nearestPoint]] count:pollen score:pollen];
    }
    else
    {
      int pollenLeft = pollen;
      int pollenPerStone = min(9,floor(pollen/stoneCount));
      int pollenScore = pollen/stoneCount;
      //NSLog(@"stoneCount %d pollen %d pollenPerStone %d pollenScore %d", stoneCount, pollen, pollenPerStone, pollenScore);
      
      int stoneIndex = 0;
      for (NSArray * chain in chains)
      {
        for (Stone * stone in chain)
        {
          if (stoneIndex == stoneCount - 1) pollenScore = pollenLeft;
          [Pollen forStone:stone count:pollenPerStone score:pollenScore];
          pollenLeft -= pollenScore;
          stoneIndex++;
        }
      }
    }
    
    for (NSArray * chain in chains) // explode the stones ...
    {
      for (Stone * stone in chain)
      {
        stone.field.stone = nil;
        [stone explode];
      }
    }    
  }
  else
  {
    //[Sound play:@"stone drop"];
  }
  
  //NSLog(@"game::explodeChains gameIsOver %d", gameIsOver);
  
  if (gameIsOver || [self checkGameOver])
  {
    //NSLog(@"cancel score display");
    [scoreDisplay cancel];
  }
  else
  {
    //NSLog(@"game not over");
    if (reason == EXPLODE_REASON_STONE_DROPPED) [self nextBlock];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) clockCounterFinished
{
  //NSLog(@"game::clockCounterFinished");
  [self challengeWon];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) saveGame
{
  NSMutableDictionary * dict = nil;
  
  [awards save];
  
  if (!gameIsOver)
  {
    dict = [NSMutableDictionary dictionaryWithCapacity:3];
    [dict setValue:[levelInfo dictionary] forKey:@"info"];
    [dict setValue:[board dictionary] forKey:@"board"];
    [dict setValue:[ramp dictionary]  forKey:@"ramp"];
    [dict setValue:[jump dictionary]  forKey:@"jump"];
    [dict setValue:[score dictionary] forKey:@"score"];
    [dict setValue:[clock dictionary] forKey:@"clock"];
    if (blockList) [dict setValue:blockList forKey:@"blockList"];
    if (challenge) [dict setValue:challenge.name forKey:@"challenge"];
  }
  
  //NSLog(@"saveGame dict %@", dict);
  [[NSUserDefaults standardUserDefaults] setValue:dict forKey:@"saveGame"];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) loadGame
{
  NSDictionary * dict = [[NSUserDefaults standardUserDefaults] valueForKey:@"saveGame"];
  if (dict) 
  {
    //NSLog(@"loadGame dict %@", dict);  

    levelInfo = [[LevelInfo alloc] initWithDictionary:[dict valueForKey:@"info"]];
    [board setCols:levelInfo.size rows:levelInfo.size];
    
    [board setupWithDictionary:[dict valueForKey:@"board"]];
    [ramp  setupWithDictionary:[dict valueForKey:@"ramp"]];
    [jump  setupWithDictionary:[dict valueForKey:@"jump"]];
    [score setupWithDictionary:[dict valueForKey:@"score"]];
    [clock setupWithDictionary:[dict valueForKey:@"clock"]];
    
    blockList = [dict valueForKey:@"blockList"];
    challenge = [Campaign challengeWithName:[dict valueForKey:@"challenge"]];
    
    gameIsOver = NO;
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) hasSaveGame
{
  return ([[NSUserDefaults standardUserDefaults] objectForKey:@"saveGame"] != nil);
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startChallenge:(Challenge*)challenge_
{
  challenge = challenge_;
  [Campaign instance].currentChallenge = challenge;
  [Campaign instance].solvedChallenge  = nil;
  
  if (levelInfo == nil)
  {
    levelInfo = [challenge.levelInfo copy];
    
    if (levelInfo.bugs == 0 && ![awards isPrizeWon:@"bug"]) levelInfo.bugs = -1;
    if (levelInfo.bees == 0 && ![awards isPrizeWon:@"bee"]) levelInfo.bees = -1;
    if (levelInfo.buts == 0 && ![awards isPrizeWon:@"but"]) levelInfo.buts = -1;
    
    [board setCols:levelInfo.size rows:levelInfo.size];
    [score clear];
    [clock startWithLevelInfo:levelInfo];

    if (challenge.board)
    {
      for (NSArray * fieldInfo in challenge.board)
      {
        NSArray * point = [fieldInfo objectAtIndex:0];
        Field * field = [board fieldAtCol:[[point objectAtIndex:0] intValue] row:[[point objectAtIndex:1] intValue]];
        NSString * flowerNumber = [fieldInfo objectAtIndex:1];
        if ([flowerNumber length] == 2)
          [field setStone:[Stone ofType:[StoneType withName:[NSString stringWithFormat:@"flower%02d", [flowerNumber intValue]]]]];
        else
        {
          int num = [flowerNumber intValue];
          NSAssert2(num < [levelInfo.flowers count], @"challenge board: flower number too large (index:%d, count:%d)", num, [levelInfo.flowers count]);
          [field setStone:[Stone ofType:[levelInfo.flowers objectAtIndex:num]]];
        }
      }
    } 

    [blockList release];
    blockList = nil;

    if (challenge.ramp)
    {
      blockList = [[NSMutableArray arrayWithArray:challenge.ramp] retain];
    }
  }

  [menu showInfo:challenge.text];
  
  [[MainMenu instance] fadeOut];
  [self startGame];
  
  if (challenge.pattern)
  {
    for (NSArray * points in challenge.pattern)
    {
      Field * field = [board fieldAtCol:[[points objectAtIndex:0] intValue] row:[[points objectAtIndex:1] intValue]];
      field.marked = YES;
    }
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startArcade
{
  //NSLog(@"game::startArcade challenge=nil");
  challenge = nil;
  
  [blockList release];
  blockList = nil;
  
  if (levelInfo == nil)
  {
    levelInfo = [arcadeInfo copy];
    
    levelInfo.mode = @"move_time";
    int numExtras = 1;
    levelInfo.bees = numExtras;
    levelInfo.bugs = numExtras;
    levelInfo.buts = numExtras;
    
    [board setCols:levelInfo.size rows:levelInfo.size];
    [score clear];   
    
    [clock startWithLevelInfo:levelInfo];   
  }
  else
  {
    NSString * size = [NSString stringWithFormat:@"%dx%d", levelInfo.size, levelInfo.size];
    NSString * diff = levelInfo.difficulty == 0 ? @"Easy" : (levelInfo.difficulty == 1 ? @"Medium" : @"Hard"); 
    NSString * arcadeText = [NSString stringWithFormat:@"[Arcade]\n%@ %@\n<green>Level %d", size, diff, clock.level+1];
    [menu showInfo:arcadeText atPoint:POINT(0,-0.8f)];
  }
  
  [self startGame];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) arcadeTimeRanOut
{
  int numFields = [board numberOfEmptyFields];
  if (numFields < 1) [self gameOver];
  else
  {
    CGPoint point = clock.rect.origin;
    int numPenaltyStones = max(1, ceil(numFields * 0.1f));
    NSMutableArray * emptyFields = [board emptyFields];
    for (int i = 0; i < numPenaltyStones; i++)
    {
      Field * field = [emptyFields objectAtIndex:RANDOMI([emptyFields count])];
      Stone * stone = [Stone ofType:[StoneType penaltyStoneWithIndex:((field.col + board.cols - field.row)%3)]];
      [stone penaltyMoveFromPoint:point toRect:field.rect];
      [emptyFields removeObject:field];
      [stone release];
    }    
  }
  
  [Sound play:@"penalty"];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startGame
{
  [Sound play:@"game fade in"];

  gameIsOver = NO;
  
  [Controller instance].currentGame = self;
    
  buttons[BUT].count = levelInfo.buts;
  buttons[BUG].count = levelInfo.bugs;
  buttons[BEE].count = levelInfo.bees;
  
  [board fadeIn];
  [ramp  fadeIn];
  [jump  fadeIn];
  [score fadeIn];
  [clock fadeIn];
  [menu  fadeIn];
  
  score.color = ((StoneType*)[levelInfo.flowers objectAtIndex:0]).scoreColor;
  clock.color = score.color;
  uint buttonColor = ((StoneType*)[levelInfo.flowers objectAtIndex:0]).buttonColor;
  
  for (MenuObject * child in menu.currScreen.children)
  {
    if ([child isKindOfClass:[SpriteButton class]])
      [(SpriteButton*)child setColor:buttonColor forName:@"scorecolor"];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) challengeWon
{
  //NSLog(@"game::challengeWon gameIsOver %d", gameIsOver);
  if (!gameIsOver)
  {
    //NSLog(@"game::challengeWon set challenge to solved");
    BOOL passed = [challenge isPuzzle] && levelInfo.extrasUsed;
    if (passed) [challenge passed];
    else        [challenge solved];
    [clock stop];
    [Sound play:@"challenge completed"];
    [PopupDisplay displayString:@"Challenge"  atPoint:POINT(0,0.15f)  duration:GAME_OVER_PREPARE_TIME];
    [PopupDisplay displayString:(passed ? @"Passed!" : @"Solved!") atPoint:POINT(0,-0.15f) duration:GAME_OVER_PREPARE_TIME];
    [Timer timerWithDuration:GAME_OVER_PREPARE_TIME object:self tick:nil finish:@selector(challengeWonPrepared:)];  
  }
  gameIsOver = YES;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) challengeFailed
{
  if (!gameIsOver)
  {
    [clock stop];
    [Sound play:@"failed"];
    [PopupDisplay displayString:@"FAILED!" atPoint:POINT(0,0.15f)  duration:GAME_OVER_PREPARE_TIME];
    [Timer timerWithDuration:GAME_OVER_PREPARE_TIME object:self tick:nil finish:@selector(challengeFailedPrepared:)];  
  }
  gameIsOver = YES;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) gameOver
{
  if (!gameIsOver)
  {
    levelInfo = nil;
    [clock stop];
    [Sound play:@"game over"];
    [PopupDisplay displayString:@"Game" atPoint:POINT(0,0.15f) duration:GAME_OVER_PREPARE_TIME];
    [PopupDisplay displayString:@"Over" atPoint:POINT(0,-0.15f) duration:GAME_OVER_PREPARE_TIME];
    [Timer timerWithDuration:GAME_OVER_PREPARE_TIME object:self tick:nil finish:@selector(gameOverPrepared:)];  
  }
  gameIsOver = YES;
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) isGameOver
{
  //NSLog(@"game::isGameOver ramp empty: %d jump empty: %d active extras: %d", [ramp isEmpty], [jump isEmpty], [[Extras instance] numberOfActiveExtras]);
  
  BOOL log = NO;
  if (levelInfo.bugs > 0)                              { if (log) NSLog(@"game::isGameOver NO  (bugs left)");       return NO;  } // bugs left
  if (levelInfo.buts > 0)                              { if (log) NSLog(@"game::isGameOver NO  (buts left)");       return NO;  } // buts left
  if ([board.stones count] >= board.rows * board.cols) { if (log) NSLog(@"game::isGameOver YES (board full)");      return YES; } // board full
  if (levelInfo.bees > 0)                              { if (log) NSLog(@"game::isGameOver NO  (bees left)");       return NO;  } // board not full and bees left
  if ([[Extras instance] numberOfActiveExtras])        { if (log) NSLog(@"game::isGameOver NO  (active extras)");   return NO;  } // board not full and active extras
  if ([ramp isEmpty] && [jump isEmpty])                { if (log) NSLog(@"game::isGameOver YES (no blocks left)");  return YES; } // no blocks on ramp and jump left  
  
  for (uint row = 0; row < board.rows; row++)
  {
    for (uint col = 0; col < board.cols; col++)  
    {
      if ([board hasSpaceForBlockWithOrientation:RIGHT atPos:POS(col,row)] ||
          [board hasSpaceForBlockWithOrientation:UP atPos:POS(col,row)])
        { if (log) NSLog(@"game::isGameOver NO  (space for block left)");  return NO; }
    }
  }
  
  if (log) NSLog(@"game::isGameOver YES  (no space for block left)");
  return YES;
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) checkGameOver
{
  //NSLog(@"game::checkGameOver");
  if ([self isGameOver])
  {
    //NSLog(@"game::checkGameOver YES");
    if (challenge) [self challengeFailed];
    else           [self gameOver];
    return YES;
  }  
  //NSLog(@"game::checkGameOver NO");
  
  return NO;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) challengeWonFinished:(Timer*)timer
{
  [awards gameFinished];

  [levelInfo release]; levelInfo = nil;
  [self fadeOut];
  [[MainMenu instance] loadScreenWithName:@"Campaign"];
  [[MainMenu instance] pushScreenWithName:@"Kraut"];
  
  //NSLog(@"game::challengeWonFinished challenge=nil");
  challenge = nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) challengeFailedFinished:(Timer*)timer
{
  [awards gameFinished];

  [levelInfo release]; levelInfo = nil;
  [self fadeOut];
  [[MainMenu instance] loadScreenWithName:@"Campaign"];
  [[MainMenu instance] pushScreenWithName:@"Kraut"];  
  
  //NSLog(@"game::challengeFailedFinished challenge=nil");
  challenge = nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) cleanUp
{
  //NSLog(@"game::cleanUp challenge=nil");
  challenge  = nil;
  levelInfo  = nil;
  gameIsOver = YES;
  [board clear];
  [jump  clear];
  [ramp  clear];
  [score clear];
  [clock stop];  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) gameOverFinished:(Timer*)timer
{
  [awards gameFinished];
  
  BOOL arcade = (challenge == nil);
  int  pollenScore = arcade ? score.pollen : 0;

  [self cleanUp];
  
  if (arcade)
  {
    highscoreEntry = [highscores addEntryForScore:pollenScore];
    if (highscoreEntry)
    {
      [self fadeOut];
      [[MainMenu instance] loadScreenWithName:@"Highscore!"];
      [[MainMenu instance] pushScreenWithName:@"Kraut"];
      [[MainMenu instance] pushScreenWithName:@"Arcade"];
      [[MainMenu instance] pushScreenWithName:@"Highscore"];
    }
    else
    {
      [self fadeOut];
      [[MainMenu instance] loadScreenWithName:@"Arcade"];
      [[MainMenu instance] pushScreenWithName:@"Kraut"];
    }
  }
  else
  {
    [[MainMenu instance] popToMainScreen];
  }  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onUserQuitGame
{
  [awards gameFinished];

  BOOL arcade = (challenge == nil);
  int  pollenScore  = arcade ? score.pollen : 0;
  
  [self cleanUp];
  
  highscoreEntry = [highscores addEntryForScore:pollenScore];
  
  if (arcade && highscoreEntry)
  {
      [[MainMenu instance] loadScreenWithName:@"Highscore!"];
      [[MainMenu instance] pushScreenWithName:@"Kraut"];
      [[MainMenu instance] pushScreenWithName:@"Highscore"];
  }
  else
  {
    [[MainMenu instance] popToMainScreen];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) gameOverPrepared:(Timer*)timer
{
  [self clearBoards];
  [Timer timerWithDuration:STONE_EXPLODE_TIME+0.1f object:self tick:nil finish:@selector(gameOverFinished:)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) challengeWonPrepared:(Timer*)timer
{
  [self clearBoards];
  [Timer timerWithDuration:STONE_EXPLODE_TIME+0.1f object:self tick:nil finish:@selector(challengeWonFinished:)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) challengeFailedPrepared:(Timer*)timer
{
  [self clearBoards];
  [Timer timerWithDuration:STONE_EXPLODE_TIME+0.1f object:self tick:nil finish:@selector(challengeFailedFinished:)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) clearBoards
{
  [board explodeStones];
  [board clear];
  [jump  explodeStones];
  [jump  clear];
  [ramp  explodeStones];
  [ramp  clear];  
}

//------------------------------------------------------------------------------------------------------------------------
- (Block*) newBlockForRamp
{
  if ([blockList count])
  {
    NSArray * block = [blockList objectAtIndex:0];
    if ([block count] == 3)
    {
      StoneType * type1 = [levelInfo.flowers objectAtIndex:[[block objectAtIndex:0] intValue]];
      StoneType * type2 = [levelInfo.flowers objectAtIndex:[[block objectAtIndex:1] intValue]];
      StoneType * type3 = [levelInfo.flowers objectAtIndex:[[block objectAtIndex:2] intValue]];
      [blockList removeObjectAtIndex:0];
      [blockList addObject:block];
      return [[[Block alloc] initWithFirst:type1 center:type2 last:type3] autorelease];
    }
    else
    {
      //NSLog(@"ramp list end reached!");
      return [[[Block alloc] init] autorelease];
    }
  }
  else
  {
    Block * block;
    if (  FALSE &&   [Controller instance].debug) // debug cheat
    {
      if (RANDOMI(4))
      {
        StoneType * type = [StoneType random];
        block = [[Block alloc] initWithFirst:type center:type last:type];  
      }
      else
      {
        StoneType * type1 = [StoneType random];
        StoneType * type2 = [StoneType random];
        block = [[Block alloc] initWithFirst:type1 center:type2 last:type1];  
      }
    }
    else 
    {
      block = [[Block alloc] initWithFirst:[StoneType random] center:[StoneType random] last:[StoneType random]];  
    }
    return [block autorelease];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) nextBlock
{
  NSAssert(!jump.block, @"next block for filled jump?");  
  Block * block = [ramp insertNewBlock];
  [jump setBlock:block];
}

//------------------------------------------------------------------------------------------------------------------------
- (StoneType*) arcadeStoneTypeAtIndex:(int)index
{
  return [arcadeStoneTypes objectAtIndex:index];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) nextArcadeStoneTypeAtIndex:(int)index
{
  //NSLog(@"nextArcadeStoneTypeAtIndex %d", index);
  StoneType * startFlower = (StoneType*)[arcadeInfo.flowers objectAtIndex:index];
  int numArcadeFowers = [arcadeStoneTypes count];
  int startIndex = [arcadeStoneTypes indexOfObject:startFlower];
  for (int i = 0; i < numArcadeFowers; i++)
  {
    int flowerIndex = (startIndex+i)%numArcadeFowers;
    BOOL used = 0;
    for (int j = 0; j < arcadeInfo.numFlowers; j++)
    {
      if ([arcadeInfo.flowers objectAtIndex:j] == [arcadeStoneTypes objectAtIndex:flowerIndex])
      {
        used = 1;
        break;
      }
    }
    if (!used)
    {
      [arcadeInfo.flowers replaceObjectAtIndex:index withObject:[arcadeStoneTypes objectAtIndex:flowerIndex]];
      
      [[NSUserDefaults standardUserDefaults] setValue:((StoneType*)[arcadeInfo.flowers objectAtIndex:index]).name forKey:[NSString stringWithFormat:@"stone%d", index]];
      
      return;
    }
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setLevelSize:(int)size difficulty:(int)difficulty
{
  arcadeInfo.size = size;
  arcadeInfo.difficulty = difficulty;
  int flowerCounts[7][3] = {{2,3,4},{2,3,4},{3,4,5},{3,4,5},{4,5,6},{4,5,6},{5,6,7}};
  arcadeInfo.numFlowers = flowerCounts[arcadeInfo.size-5][difficulty];
  
  for (int c = 1; c < arcadeInfo.numFlowers; c++)
  {
    for (int f = 0; f < c; f++)
    {
      if ([((StoneType*)[arcadeInfo.flowers objectAtIndex:f]).name isEqualToString:((StoneType*)[arcadeInfo.flowers objectAtIndex:c]).name])
        [self nextArcadeStoneTypeAtIndex:c];
    }        
  }
}    

//------------------------------------------------------------------------------------------------------------------------
- (void) onButton:(ButtonEvent*)event
{
  //NSLog(@"Game::onButton %@", event);
  
  if ([event.key isEqualToString:@"size"])
  {
    int size = [[[event.value componentsSeparatedByString:@"x"] objectAtIndex:0] intValue];
    [self setLevelSize:size difficulty:arcadeInfo.difficulty];
  }
  else if ([event.key isEqualToString:@"difficulty"])
  {
    int difficulty = 0;
    for (int i = 0; i < 3; i++)
      if ([event.value isEqualToString:DIFFICULTY[i]]) difficulty = i;

    [self setLevelSize:arcadeInfo.size difficulty:difficulty];
  }
  else if ([event.key isEqualToString:@"start"] || [event.key isEqualToString:@"continue"])
  {
    //NSLog(@"game::onButton %@ challenge %@", event.key, challenge);
    [[MainMenu instance] fadeOut];
    if (challenge) [self startChallenge:challenge];
    else [self startArcade];
  }
  else if ([event.key isEqualToString:@"restart"])
  {
    Challenge * currentChallenge = challenge;
    [levelInfo release];
    levelInfo = nil;
    [self cleanUp];
    [[MainMenu instance] fadeOut];
    if (currentChallenge) [self startChallenge:currentChallenge];
    else [self startArcade];
  }
  else if ([event.key isEqualToString:@"quit"])
  {
    [self onUserQuitGame];
  }
  else if ([event.key isEqualToString:@"menu"])
  {
    if (!gameIsOver)
    {
      [self fadeOut];
      [[MainMenu instance] loadScreenWithName:@"Pause"];
    }
  }
  else if ([event.key isEqualToString:@"help"])
  {
    [[Help instance] displayHelp:event.value];
  }

  else if ([event.key isEqualToString:@"cleardefaults"])
  {
    [[Controller instance] resetDefaults];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) onEvent:(Event*)event
{
  if ([event isKindOfClass:[ButtonEvent class]])
  {
    [self onButton:(ButtonEvent*)event];
  }
  
  return YES;
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) lefty 
{
  return [[[NSUserDefaults standardUserDefaults] stringForKey:@"layout"] isEqualToString:@"lefty"];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) stopWigglingExtra
{
  if (board.wigglingExtra) 
  {
    [board.wigglingExtra toggleWiggle];
    board.wigglingExtra = nil;
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (float) fieldSize { return 2.0f/levelInfo.size; }
- (float) stoneMoveTime { return 0.3f; }
- (void) setButButton:(ExtraButton*)button { buttons[BUT] = button; }
- (void) setBugButton:(ExtraButton*)button { buttons[BUG] = button; }
- (void) setBeeButton:(ExtraButton*)button { buttons[BEE] = button; }
- (ExtraButton*) butButton { return buttons[BUT]; }
- (ExtraButton*) bugButton { return buttons[BUG]; }
- (ExtraButton*) beeButton { return buttons[BEE]; }

@end
