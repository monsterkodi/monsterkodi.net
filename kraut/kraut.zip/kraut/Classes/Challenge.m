//
//  Challenge.m
//  kraut

#import "Challenge.h"
#import "Level.h"
#import "Stone.h"
#import "Sprite.h"
#import "Campaign.h"
#import "Awards.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation Challenge
//------------------------------------------------------------------------------------------------------------------------

@synthesize type;
@synthesize stoneType;
@synthesize name;
@synthesize text;
@synthesize title;
@synthesize levelInfo;
@synthesize pattern;
@synthesize board;
@synthesize ramp;
@synthesize ring;
@synthesize index;
@synthesize angle;
@synthesize status;
@synthesize parent;
@synthesize siblings;
@synthesize isSolved;
@synthesize isOpen;
@synthesize isLocked;
@synthesize isPassed;

//------------------------------------------------------------------------------------------------------------------------

- (id) initWithDictionary:(NSDictionary*)dict
{
  if ((self = [super init]))
  {
    text      = [[dict valueForKey:@"text"] copy];
    status    = ([dict valueForKey:@"open"] && [[dict valueForKey:@"open"] boolValue]) ? OPEN : LOCKED;
    levelInfo = [[LevelInfo alloc] initWithDictionary:[dict valueForKey:@"info"]];
    pattern   = [[dict valueForKey:@"pattern"] copy];
    board     = [[dict valueForKey:@"board"] copy];
    ramp      = [[dict valueForKey:@"ramp"] copy];
    siblings  = [[NSMutableArray arrayWithCapacity:3] retain];
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [siblings   release];
  [levelInfo  release];
  [name       release];
  [text       release];
  [pattern    release];
  [board      release];
  [super      dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setRing:(int)ring_ index:(int)index_
{
  ring = ring_;
  index = index_;
  
  name = [[NSString stringWithFormat:@"%d.%d", ring, index+1] retain];
  if (!text) text = [[NSString stringWithFormat:@"[%@]", name] retain];
  
  if ([[[NSUserDefaults standardUserDefaults] valueForKey:@"solved"] valueForKey:name])  
  {
    BOOL solved = [[[[[NSUserDefaults standardUserDefaults] valueForKey:@"solved"] valueForKey:name] valueForKey:@"solved"] boolValue];
    status = solved ? SOLVED : PASSED;
  }
  else if ([[[NSUserDefaults standardUserDefaults] valueForKey:@"open"] valueForKey:name])  
  {
    status = OPEN;  
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) passedWithStatus:(int)newStatus
{
  //NSLog(@"challenge::solved oldStatus %d -> %d", status, SOLVED);
  if (status < newStatus)
  {
    [Campaign instance].solvedChallenge = self;
    for (Challenge * sibling in siblings) [sibling open];
    
    status = newStatus;
  
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    
    NSMutableDictionary * solvedInfos;
    if ([defaults valueForKey:@"solved"]) solvedInfos = [NSMutableDictionary dictionaryWithDictionary:[[NSUserDefaults standardUserDefaults] valueForKey:@"solved"]];
    else                                  solvedInfos = [NSMutableDictionary dictionaryWithCapacity:1];

    NSMutableDictionary * solvedInfo;
    if ([solvedInfos valueForKey:name]) solvedInfo = [NSMutableDictionary dictionaryWithDictionary:[solvedInfos valueForKey:name]];
    else                                solvedInfo = [NSMutableDictionary dictionaryWithCapacity:1];
    
    int solvedCount = [solvedInfo valueForKey:@"count"] ? [[solvedInfo valueForKey:@"count"] intValue] : 0;
    solvedCount += 1;
    [solvedInfo setValue:[NSNumber numberWithInt:solvedCount] forKey:@"count"];

    [solvedInfo setValue:[NSNumber numberWithInt:(newStatus == SOLVED) ? 1 : 0] forKey:@"solved"];
    
    [solvedInfos setValue:solvedInfo forKey:name];
    [defaults setValue:solvedInfos forKey:@"solved"];
    
    //NSLog(@"challenge::solved save info %@", solvedInfos);
    
    [defaults synchronize];
  }    
}

//------------------------------------------------------------------------------------------------------------------------
- (void) passed
{
  [self passedWithStatus:PASSED];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) solved
{
  [self passedWithStatus:SOLVED];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) open
{
  if (status == LOCKED) 
  {
    //NSLog(@"challenge::open %@", self);
    [[Campaign instance].openedChallenges addObject:self];
    status = OPEN;
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (NSString*) type
{
  if ([levelInfo.prize isEqualToString:@"bee"]) return @"bee";
  if ([levelInfo.prize isEqualToString:@"bug"]) return @"bug";
  if ([levelInfo.prize isEqualToString:@"but"]) return @"but";
  return levelInfo.mode;
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) isPuzzle
{
  return [self.type isEqualToString:@"puzzle"];
}

//------------------------------------------------------------------------------------------------------------------------
- (Sprite*) prizeSprite
{
  if ([levelInfo.prize  isEqualToString:@"9x9"])    return ((StoneType*)[levelInfo.flowers objectAtIndex:1]).sprite;
  if ([levelInfo.prize  isEqualToString:@"10x10"])  return ((StoneType*)[levelInfo.flowers objectAtIndex:1]).sprite;
  if ([levelInfo.prize  isEqualToString:@"11x11"])  return ((StoneType*)[levelInfo.flowers objectAtIndex:1]).sprite;
  if (levelInfo.prize) return [[Awards instance] spriteForPrize:levelInfo.prize];
  NSAssert(0, @"no prize sprite?");
  return nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (StoneType*) stoneType
{
  return [levelInfo.flowers objectAtIndex:0];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) stoneSetOnMarkedField
{
  if (pattern)
  {
    NSMutableDictionary * typeDict = [NSMutableDictionary dictionaryWithCapacity:1];
    for (NSArray * points in pattern)
    {
      Field * field = [[Game instance].board fieldAtCol:[[points objectAtIndex:0] intValue] row:[[points objectAtIndex:1] intValue]];
      if (field.stone && field.stone.type)
      {
        if (![typeDict valueForKey:field.stone.type.name]) [typeDict setValue:[NSNumber numberWithInt:1] forKey:field.stone.type.name];
        else [typeDict setValue:[NSNumber numberWithInt:[[typeDict valueForKey:field.stone.type.name] intValue]+1] forKey:field.stone.type.name];
      }
    }
    int maxNum = 0;
    for (NSNumber * n in [typeDict allValues]) maxNum = max(maxNum, [n intValue]);
    [[Game instance].clock setCount:maxNum];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (NSString*) title
{
  return [[text componentsSeparatedByString:@"\n"] objectAtIndex:0];
}

//------------------------------------------------------------------------------------------------------------------------
- (NSString*) prize
{
  return levelInfo.prize;
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) isOpen   { return status != LOCKED; }
- (BOOL) isLocked { return status == LOCKED; }
- (BOOL) isSolved { return status == SOLVED; }
- (BOOL) isPassed { return status >= PASSED; }

@end
