//
//  Level.h

#import "Event.h"

//------------------------------------------------------------------------------------------------------------------------
@interface LevelInfo : NSObject
//------------------------------------------------------------------------------------------------------------------------
{
  int               size; // board size
  int               bees;
  int               bugs;
  int               buts;
  int               extrasUsed;
  int               difficulty;
  float             clockDuration;
  NSString        * mode;
  NSString        * prize;
  NSMutableArray  * flowers;
  int               numFlowers;
}

@property (assign) int              size;
@property (assign) int              bees;
@property (assign) int              bugs;
@property (assign) int              buts;
@property (assign) int              extrasUsed;
@property (assign) int              difficulty;
@property (assign) int              numFlowers;
@property (assign) float            clockDuration;
@property (assign) NSString       * mode;
@property (assign) NSString       * prize;
@property (assign) NSMutableArray * flowers;
@property (readonly) NSString     * key;

- (id) init;
- (id) copy;
- (NSDictionary*) dictionary;

@end

