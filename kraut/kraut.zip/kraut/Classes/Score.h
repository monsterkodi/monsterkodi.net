//
//  Score.h

#import "Event.h"

@class Timer;
@class Sprite;
@class Letter;
@class Letters;

//------------------------------------------------------------------------------------------------------------------------
@interface Digit : NSObject
//------------------------------------------------------------------------------------------------------------------------
{
  int      value;   // number [0..9]
  int      factor;  // zehnerpotenz
  int      index; 
  uint     color;
  BOOL     dotmode;
  Letter * letter;
  CGRect   rect;
  Sprite * sprite[3];
}

@property (assign) int      value;
@property (assign) int      factor;
@property (assign) int      index;
@property (assign) uint     color;
@property (assign) CGRect   rect;
@property (assign) Letter * letter;
@property (assign) BOOL     dotmode;

- (id)    init;
- (void)  dealloc;
- (void)  draw;
- (void)  setValue:(int)value;
- (void)  setDotmode:(BOOL)textmode;
- (void)  updateLetter;
- (void)  moveBy:(CGPoint)vector;
- (void)  moveTo:(CGPoint)point;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface Score : NSObject <EventReceiver>
//------------------------------------------------------------------------------------------------------------------------
{
  CGRect            rect;
  CGPoint           offset;
  float             angle;
  uint              color;  
  int               value;
  int               pollen;
  int               maxfactor;
  float             digitsize;
  float             digitspace;
  NSMutableArray  * digits;
  Digit           * first;
  Timer           * fadeTimer;
}

@property (assign) CGRect           rect;
@property (assign) float            angle;
@property (assign) float            digitsize;
@property (assign) float            digitspace;
@property (assign) int              value;
@property (assign) int              pollen;
@property (assign) int              maxfactor;
@property (assign) NSMutableArray * digits;
@property (assign) Digit          * first;
@property (assign) uint             color;

+ (Score*)        instance;
+ (int)           scoreForNumStones:(int)stones;
+ (CGPoint)       pollenTarget;
- (void)          clear;
- (void)          setValue:(int)value;
- (void)          layout;
- (Digit*)        addDigit;
- (void)          pollenArrivedWithScore:(int)score;
- (BOOL)          onEvent:(Event*)event;
- (void)          onFrame:(double)delta;
- (void)          moveBy:(CGPoint)vector;
- (void)          moveTo:(CGPoint)point;
- (void)          fadeIn;
- (void)          fadeOut;
- (void)          fadingOut:(Timer*)timer;
- (void)          fadedOut:(Timer*)timer;
- (void)          setDigitValues;
- (void)          setupWithDictionary:(NSDictionary*)dictionary;
- (NSDictionary*) dictionary;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface ScoreDisplay : NSObject
//------------------------------------------------------------------------------------------------------------------------
{
  CGPoint    point;
  NSString * string;
  Letters  * letters;
  uint       colors[3];
  
  Timer    * displayTimer;
}

+ (ScoreDisplay*) displayScore:(int)score atPoint:(CGPoint)point colors:(uint*)colors;
- (id)            initWithScore:(int)score point:(CGPoint)point colors:(uint*)colors;
- (void)          dealloc;
- (void)          tick:(Timer*)timer;
- (void)          finish:(Timer*)timer;
- (void)          cancel;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface PopupDisplay : NSObject
//------------------------------------------------------------------------------------------------------------------------
{
  CGPoint    point;
  NSString * string;
  Letters  * letters;
}

+ (void) displayString:(NSString*)string atPoint:(CGPoint)point duration:(float)duration;
- (id)   initWithString:(NSString*)string point:(CGPoint)point  duration:(float)duration;
- (void) dealloc;
- (void) tick:(Timer*)timer;
- (void) finish:(Timer*)timer;

@end

