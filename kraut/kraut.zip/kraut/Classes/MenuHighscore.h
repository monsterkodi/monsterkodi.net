//
//  MenuText.h
//  kraut

#import "Button.h"

//------------------------------------------------------------------------------------------------------------------------
@interface MenuHighscore : Button
//------------------------------------------------------------------------------------------------------------------------
{
  NSMutableArray * scores;
  NSMutableArray * signatures;
  int              page;
}

- (id)    initWithDictionary:(NSDictionary*)dict parent:(MenuObject*)parent;
- (void)  dealloc;
- (void)  initHighscore;
- (void)  onTouchUp:(TouchEvent*)event;
- (void)  fadeIn:(float)value;
- (void)  fadeOut:(float)value;
- (void)  onFrame:(double)delta;
@end
