//
//  Achievements.h
//  kraut

@class Sprite;

enum AwardIndizes {
  BeeMaster,        
  BugMaster,        
  ButterflyMaster,
  ScoreMaster,      
  BestMoveMaster,
  PatternMaster,
  PollenMillionaire,
  AspirantAddict,
  SeriousAddict,
  CampaignHero,
  AideTamer,
  ArcadeKing,
  PuzzleMaster,
  HighscorePainter,
  NumAwards
};

typedef struct 
{
  NSString * name;
  NSString * info;
  NSString * text;
  NSString * prize;
  
} AwardInfo;

typedef struct 
{
  NSString * name;
  int        total;
  NSString * sprite;
  NSString * text;
  NSString * prize;
} PrizeData;

//------------------------------------------------------------------------------------------------------------------------
@interface PrizeInfo : NSObject 
//------------------------------------------------------------------------------------------------------------------------
{
  NSString  * name;
  int         printValue;
  int         count;
  int         total;
  NSString  * spriteName;
  Sprite    * sprite;
  NSString  * text;
  NSString  * prize;
}

@property (assign) NSString * name;
@property (assign) Sprite   * sprite;
@property (assign) NSString * spriteName;
@property (assign) NSString * text;
@property (assign) NSString * prize;
@property (assign) int        count;
@property (assign) int        printValue;
@property (assign) int        total;

- (NSString*) description;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface Awards : NSObject 
//------------------------------------------------------------------------------------------------------------------------
{
  NSMutableDictionary * prizeInfos;
}

+ (Awards*)     instance;
- (void)        dealloc;
- (void)        setup;
- (void)        save;
- (void)        gameFinished;
- (void)        extraUsed;
- (void)        highscoreAdded;
- (BOOL)        gotAwardAtIndex:(int)index;
- (AwardInfo*)  awardAtIndex:(int)index;
- (void)        setValue:(int)value forAward:(int)index;

- (NSString*)   textForPrize:(NSString*)prize;
- (NSString*)   prizeForPrize:(NSString*)prize;
- (NSString*)   flowerForPrize:(NSString*)prize;
- (Sprite*)     spriteForPrize:(NSString*)prize;
- (int)         countForPrize:(NSString*)prize;
- (int)         totalForPrize:(NSString*)prize;
- (int)         printValueForPrize:(NSString*)prize;
- (PrizeInfo*)  infoForPrize:(NSString*)prize;
- (NSArray*)    prizeFlowers;
- (NSArray*)    flowerPrizes;
- (NSArray*)    wonFlowers;
- (void)        increaseTotalForPrize:(NSString*)prize;
- (void)        increaseCountForPrize:(NSString*)prize;
- (void)        setCount:(int)value forPrize:(NSString*)prize;
- (BOOL)        isPrizeWon:(NSString*)prize;

@end
