//
//  Bug.h
//  kraut

#import "Extra.h"

@class Bezier;
@class Stone;

//------------------------------------------------------------------------------------------------------------------------
@interface Bug : Extra
//------------------------------------------------------------------------------------------------------------------------
{
  Bezier          * bezier;
  NSMutableArray  * stones;
  Stone           * stone;
  
  float             targetAngle;
}

- (id)   init;
- (void) dealloc;
- (void) eatStone;
- (void) deactivate;
- (void) jumpToPos:(Pos)pos onBoard:(Board*)board;

@end
