//
//  MenuText.h
//  kraut

#import "Button.h"

//------------------------------------------------------------------------------------------------------------------------
@interface MenuText : Button
//------------------------------------------------------------------------------------------------------------------------
{
  NSMutableArray * lines;
  NSMutableArray * lineOffsets;
  
  CGPoint point;
  uint    alignment;
  float   lineSpace;
  float   preHeadSpace;
  float   postHeadSpace;
  float   textSize;
  float   headSize;
  uint    textColor;
  uint    headColor;
  uint    layer;
}

@property (assign) CGPoint point;
@property (assign) float lineSpace;
@property (assign) float preHeadSpace;
@property (assign) float postHeadSpace;
@property (assign) float textSize;
@property (assign) float headSize;
@property (assign) uint  textColor;
@property (assign) uint  headColor;
@property (assign) uint  alignment;
@property (assign) uint  layer;

- (id)    init;
- (void)  dealloc;
- (id)    initWithDictionary:(NSDictionary*)dict parent:(MenuObject*)parent;
- (void)  setText:(NSString*)text;
- (void)  fadeIn:(float)value;
- (void)  fadeIn:(float)value offset:(CGPoint)offset;
- (void)  fadeOut:(float)value;
- (void)  fadeOut:(float)value offset:(CGPoint)offset;
- (void)  draw;
- (void)  onFrame:(double)delta;
- (void)  moveBy:(CGPoint)vector;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface MenuScrollText : MenuText
//------------------------------------------------------------------------------------------------------------------------
{
  float autoScrollDelay;
  float minScrollOffset;
  float maxScrollOffset;
  float scrollValue;
  float scrollDelta;
  
  Timer * scrollTimer;
}

@property (assign) float autoScrollDelay;
@property (assign) float minScrollOffset;
@property (assign) float maxScrollOffset;

- (id)        initWithDictionary:(NSDictionary*)dict parent:(MenuObject*)parent;
- (void)      onTouchDown:(TouchEvent*)event;
- (void)      onTouchMove:(TouchEvent*)event;
- (void)      startAutoScroll:(Timer*)timer;
- (void)      stopAutoScroll;

@end
