//
//  MenuCampaign.h
//  kraut

#import "Button.h"

@class ChallengeFlower;
@class Challenge;
@class Timer;
@class MenuText;
@class PrizeWheel;

#define CAMPAIGN_MIN_SCALE 0.6f
#define CAMPAIGN_MAX_SCALE 3.0f

//------------------------------------------------------------------------------------------------------------------------
@interface MenuCampaign : Button 
//------------------------------------------------------------------------------------------------------------------------
{  
  NSMutableArray  * flowers;
  ChallengeFlower * touchedFlower;
  ChallengeFlower * selectedFlower;
  PrizeWheel      * prizeWheel;

  float   scale;
  float   targetScale;
  float   scaleSpeed;
  float   offsetSpeed;
  CGPoint offset;
  CGPoint targetOffset;

  float   wiggleAngle;
  float   time;
  
  MenuText * activeInfo;
  MenuText * inactiveInfo;
  
  Timer * showInfoTimer;
  Timer * hideInfoTimer;
}

@property (assign) float    scale;
@property (assign) float    targetScale;
@property (assign) float    wiggleAngle;
@property (assign) CGPoint  offset;
@property (assign) CGPoint  targetOffset;

- (id)                initWithDictionary:(NSDictionary*)dict parent:(MenuObject*)parent;
- (void)              setupChallenges;
- (CGPoint)           pointForChallenge:(Challenge*)challenge;
- (ChallengeFlower*)  flowerForChallenge:(Challenge*)challenge;
- (void)              fadeIn:(float)value;
- (void)              fadeOut:(float)value;
- (void)              onFrame:(double)delta;
- (void)              selectFlower:(ChallengeFlower*)flower;
- (void)              showInfo;
- (void)              showInfoForPrize:(NSString*)prize;
- (void)              hideInfo;
- (void)              onTouchUp:(TouchEvent*)event;
- (void)              onTouchDown:(TouchEvent*)event;
- (void)              onTouchMove:(TouchEvent*)event;
- (void)              startAnimationForOpenedChallenges;

@end
