//
//  Sprite.h

#import "Layers.h"

//------------------------------------------------------------------------------------------------------------------------
@interface Sprite : NSObject
//------------------------------------------------------------------------------------------------------------------------
{
  uint  texid;
  uint  blend;
  uint  layer;
  float uv[4];
}

@property (readonly) uint texid;
@property (readonly) float * uv;
@property (assign)   uint blend;
@property (assign)   uint layer;

+ (Sprite*) withName:(NSString*)name;
- (id)   initWithTextureId:(uint)texture;
- (id)   initWithTextureId:(uint)texture uv:(float*)uv;
- (void) dealloc;

- (void) drawWithRect:(CGRect)rect;
- (void) drawWithRect:(CGRect)rect layer:(uint)_layer_;
- (void) drawWithRect:(CGRect)rect color:(uint)color;
- (void) drawWithRect:(CGRect)rect color:(uint)color layer:(uint)_layer_;
- (void) drawWithRect:(CGRect)rect alpha:(float)alpha;
- (void) drawWithRect:(CGRect)rect alpha:(float)alpha layer:(uint)_layer_;

- (void) drawAtPoint:(CGPoint)point size:(CGSize)size;
- (void) drawAtPoint:(CGPoint)point size:(CGSize)size layer:(uint)_layer_;
- (void) drawAtPoint:(CGPoint)point size:(CGSize)size alpha:(float)alpha;
- (void) drawAtPoint:(CGPoint)point size:(CGSize)size alpha:(float)alpha layer:(uint)_layer_;
- (void) drawAtPoint:(CGPoint)point size:(CGSize)size color:(uint)color;
- (void) drawAtPoint:(CGPoint)point size:(CGSize)size color:(uint)color layer:(uint)_layer_;

- (void) drawAtPoint:(CGPoint)point angle:(float)degrees size:(CGSize)size color:(uint)color layer:(uint)_layer_;

- (void) drawWithPoints:(CGPoint*)points layer:(uint)_layer_;
- (void) drawWithPoints:(CGPoint*)points alpha:(float)alpha;
- (void) drawWithPoints:(CGPoint*)points alpha:(float)alpha layer:(uint)_layer_;

- (void) addVertex:(sprite_vertex*)vert layer:(uint)_layer_;
- (float*) uv;

@end

