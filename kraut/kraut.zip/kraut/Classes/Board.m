//
//  Board.m

#import "Controller.h"
#import "Game.h"
#import "Timer.h"
#import "Bee.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation Board
//------------------------------------------------------------------------------------------------------------------------

@synthesize rows;
@synthesize cols;
@synthesize rect;
@synthesize fields;
@synthesize stones;
@synthesize game;
@synthesize name;
@synthesize angle;

//------------------------------------------------------------------------------------------------------------------------
- (id) init
{
  if ((self = [super init]))
  {
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithRect:(CGRect)rect_ size:(int)size name:(NSString*)name_
{
  if ((self = [self init]))
  {
    rect = rect_;
    name = name_;
    
    [self setCols:size rows:size];
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithRect:(CGRect)rect_ cols:(int)cols_ rows:(int)rows_ name:(NSString*)name_
{
  if ((self = [self init]))
  {
    rect = rect_;
    name = name_;
        
    [self setCols:cols_ rows:rows_];
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setAngle:(float)angle_
{
  angle = angle_;
  for (Stone * stone in self.stones) stone.angle = angle;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setCols:(int)cols_ rows:(int)rows_
{
  cols = cols_;
  rows = rows_;

  if (!fields) fields = [[NSMutableArray arrayWithCapacity:cols*rows] retain];

  [fields removeAllObjects];
  for (int row = 0; row < rows; row++)
  {
    for (int col = 0; col < cols; col++)
    {
      CGRect fieldRect = CGRectMake(0, 0, rect.size.width/cols, rect.size.height/rows);
      Field * field = [[Field alloc] initWithRect:fieldRect];
      field.col = col; 
      field.row = row;
      [fields addObject:field];
      field.board = self;
      [field release];
    }
  }

  [self layout];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) layout
{
  CGSize fs = CGSizeMake(rect.size.width/rows, rect.size.height/cols);
  for (int row = 0; row < rows; row++)
  {
    float y = CGRectGetMinY(rect) + row * fs.height;
    for (int col = 0; col < cols; col++)      
    {
      float x = CGRectGetMinX(rect) + col * fs.width;
      [[self fieldAtCol:col row:row] moveTo:CGPointAdd(CGPointMake(x, y), offset)];
    }
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeIn
{  
  [[Controller instance] addEventReceiver:self type:@"frame"];
    
  for (Field * field in self.fields) [field fadeIn];
  for (Stone * stone in self.stones) [stone fadeIn];

  offset = CGPointMake(0,3);
  [self layout];

  if (fadeTimer) [fadeTimer stop];
  fadeTimer = [Timer timerWithDuration:GAME_FADE_IN_TIME object:self tick:@selector(fadingIn:) finish:@selector(fadedIn:)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadingIn:(Timer*)timer
{
  offset = CGPointMake(0,(1-timer.fraction)*3);
  [self layout];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadedIn:(Timer*)timer
{
  offset = CGPointMake(0,0);
  [self layout];
  
  if (game == [Game instance])
  {
    [[Controller instance] addEventReceiver:self type:@"move"];
    [[Controller instance] addEventReceiver:self type:@"down"];
    [[Controller instance] addEventReceiver:self type:@"up"];  
  }
  [[Controller instance] addEventReceiver:self type:@"drag"];
  
  fadeTimer = nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeOut
{
  if (game == [Game instance])
  {
    [[Controller instance] removeEventReceiver:self type:@"move"];
    [[Controller instance] removeEventReceiver:self type:@"down"];
    [[Controller instance] removeEventReceiver:self type:@"up"];  
  }
  [[Controller instance] removeEventReceiver:self type:@"drag"];
  
  if (fadeTimer) [fadeTimer stop];
  fadeTimer = [Timer timerWithDuration:GAME_FADE_OUT_TIME object:self tick:@selector(fadingOut:) finish:@selector(fadedOut:)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadingOut:(Timer*)timer
{
  offset = CGPointMake(0,-3*timer.fraction);
  [self layout];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadedOut:(Timer*)timer
{
  for (Field * field in self.fields) [field fadedOut];
  for (Stone * stone in self.stones) [stone fadedOut];

  [[Controller instance] removeEventReceiver:self type:@"frame"];
  
  fadeTimer = nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) moveBy:(CGPoint)vector
{
  rect.origin = CGPointAdd(self.rect.origin, vector);
  for (Field * field in self.fields) [field moveBy:vector];
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) hasSpaceForBlockWithOrientation:(int)orientation atPos:(Pos)pos
{
  for (int i = -1; i <= 1; i++)
  {
    Pos checkPos = [pos sum:POS(i*DIR[orientation][0], i*DIR[orientation][1])];
    if (![self isValidPos:checkPos]) return NO;
    if (![[self fieldAtPos:checkPos] isEmpty]) return NO;
  }
  return YES;  
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) hasSpaceForBlock:(Block*)block atPos:(Pos)pos
{
  return [self hasSpaceForBlockWithOrientation:block.orientation atPos:pos];
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) hasSpaceForBlock:(Block*)block
{
  return [self hasSpaceForBlock:block atPos:[self posForPoint:CGRectCenter(block.center.rect)]];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setStonesForBlock:(Block*)block
{
  NSAssert2([self hasSpaceForBlock:block], @"no space on board %@ for block %@", self, block);
  [self setStonesForBlock:block atPos:[self posForPoint:CGRectCenter(block.center.rect)]];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setStonesForBlock:(Block*)block atPos:(Pos)pos
{
  [self fieldAtPos:[pos sum:[block indexPos:0]]].stone = block.first;
  [self fieldAtPos: pos                        ].stone = block.center;
  [self fieldAtPos:[pos sum:[block indexPos:2]]].stone = block.last;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) delStonesForBlock:(Block*)block
{
  for (Stone * stone in block.stones)
  {
    stone.field.stone = nil;
    stone.field       = nil;
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (Pos) jumpPosForBugAtPoint:(CGPoint)point
{
  return [self posForPoint:point];
}

//------------------------------------------------------------------------------------------------------------------------
- (NSMutableArray*) emptyFields
{
  NSMutableArray * array = [NSMutableArray arrayWithCapacity:25];
  for (Field * field in fields) if ([field isEmpty]) [array addObject:field];
  return array;
}

//------------------------------------------------------------------------------------------------------------------------
- (Field*) randomEmptyField
{
  NSMutableArray * array = [self emptyFields];
  if ([array count] < 1) return nil;
  return [array objectAtIndex:RANDOMI([array count])];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) clear
{
  for (Field * field in fields)
  {
    field.stone.field = nil;
    field.stone       = nil;
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) explodeStones
{
  for (Stone * stone in self.stones) [stone explode];
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) isValidPos:(Pos)pos
{
  return (pos.x >= 0 && pos.y >= 0 && pos.x < cols && pos.y < rows);
}

//------------------------------------------------------------------------------------------------------------------------

- (int) indexForPos:(Pos)pos
{
  return pos.y*cols+pos.x;
}

//------------------------------------------------------------------------------------------------------------------------
- (Field*) fieldAtPos:(Pos)pos
{
  if ([self isValidPos:pos])
    return [fields objectAtIndex:[self indexForPos:pos]];
  return nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (Field*) fieldAtCol:(int)col row:(int)row
{
  if (col >= 0 && row >= 0 && col < cols && row < rows)
    return [fields objectAtIndex:row*cols+col];
  return nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (Stone*) stoneAtPos:(Pos)pos
{
  if ([self isValidPos:pos])
    return [[fields objectAtIndex:pos.y*cols+pos.x] stone];
  return nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (Stone*) stoneAtCol:(int)col row:(int)row
{
  if (col >= 0 && row >= 0 && col < cols && row < rows)
    return [[fields objectAtIndex:row*cols+col] stone];
  return nil;
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) retainStones { return NO; }

//------------------------------------------------------------------------------------------------------------------------
- (NSDictionary*) dictionary
{
  NSMutableDictionary * dict = [NSMutableDictionary dictionaryWithCapacity:[fields count]/2];
  for (Field * field in fields)
  {
    if (field.stone)
    {
      NSString * typeName = field.stone.type ? field.stone.type.name : @"bee";
      [dict setValue:typeName forKey:[NSString stringWithFormat:@"%d %d", field.col, field.row]];
    }
  }
  return dict;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setupWithDictionary:(NSDictionary*)dictionary
{
  for (int row = 0; row < rows; row++)
  {
    for (int col = 0; col < cols; col++)      
    {
      NSString * typeName = [dictionary valueForKey:[NSString stringWithFormat:@"%d %d", col, row]];
      if (typeName)
      {
        Field * field = [self fieldAtCol:col row:row];
        if ([typeName isEqualToString:@"bee"])
        {
          Bee * bee = [[Bee alloc] init];
          field.stone = (Stone*)bee;
          [bee release];
        }
        else
        {
          [field setStone:[Stone ofType:[StoneType withName:typeName]]];
        }
      }
    }
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (int) numberOfFlowers
{
  int number = 0;
  for (Field * field in fields) if (field.stone && field.stone.type) number++;
  return number;
}

//------------------------------------------------------------------------------------------------------------------------
- (NSArray*) stones
{
  NSMutableArray * array = [[NSMutableArray arrayWithCapacity:[fields count]] retain];
  for (Field * field in fields)
  {
    if (field.stone) [array addObject:field.stone];
  }
  return [array autorelease];
}

//------------------------------------------------------------------------------------------------------------------------
- (int) rowForPoint:(CGPoint)point
{
  int row = -1;
  if (CGRectContainsPoint(rect, point)) 
  {
    row = (int)((point.y - rect.origin.y)*rows/rect.size.height);
  }
  
  return row;
}

//------------------------------------------------------------------------------------------------------------------------
- (int) colForPoint:(CGPoint)point
{
  int col = -1;
  if (CGRectContainsPoint(rect, point)) 
  {
    col = (int)((point.x - rect.origin.x)*cols/rect.size.width);
  }
    
  return col;
}

//------------------------------------------------------------------------------------------------------------------------
- (Pos) posForPoint:(CGPoint)point
{
  int x = -1, y = -1;
  if (CGRectContainsPoint(rect, point)) 
  {
    x = (int)((point.x - rect.origin.x)*cols/rect.size.width);
    y = (int)((point.y - rect.origin.y)*rows/rect.size.height);
  }
  
  return POS(x, y);
}

//------------------------------------------------------------------------------------------------------------------------
- (CGPoint) pointForPos:(Pos)pos
{
  NSAssert1([self isValidPos:pos], @"invalid pos %@", pos);
  return CGRectCenter([self fieldAtPos:pos].rect);
}

//------------------------------------------------------------------------------------------------------------------------
- (int) numberOfEmptyFields
{
  return (cols * rows - [self.stones count]);
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [fields release];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) onFrame:(double)delta {}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) onEvent:(Event*)event
{
  if ([event isKindOfClass:[FrameEvent class]]) [self onFrame:((FrameEvent*)event).delta];
  return YES;
}

//------------------------------------------------------------------------------------------------------------------------
- (NSString*) description
{
  return [NSString stringWithFormat:@"<Board: '%@' %dx%d>", name, cols, rows];
}

@end
