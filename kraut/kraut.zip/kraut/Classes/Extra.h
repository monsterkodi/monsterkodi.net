//
//  Extra.h
//  kraut

#import "Event.h"

@class Timer;
@class ExtraButton;
@class Board;
@class Sprite;

#define EXTRA_SIZE          0.25f
#define EXTRA_FADE_IN_TIME  0.8f

//------------------------------------------------------------------------------------------------------------------------
@interface Extra : NSObject <DragObject, EventReceiver>
//------------------------------------------------------------------------------------------------------------------------
{
  CGPoint point;
  float   size;
  float   angle;
  uint    layer;
  
  CGPoint       targetPoint;
  ExtraButton * extraButton;
  Sprite      * sprite;
  Timer       * wiggleTimer;
  Timer       * fadeTimer;
  Timer       * moveTimer;
}

@property (assign) uint           layer;
@property (assign) float          size;
@property (assign) float          angle;
@property (assign) CGPoint        point;
@property (assign) CGPoint        targetPoint;
@property (assign) ExtraButton  * extraButton;
@property (assign) Sprite       * sprite;

- (id)   init;
- (void) dealloc;
- (void) show;
- (void) hide;
- (void) vanish;
- (BOOL) onEvent:(Event*)event;
- (void) playWiggleSound;
- (void) stopWiggleSound;
- (void) stopWigglingAndSound;
- (void) toggleWiggle;
- (void) startWiggle;
- (void) stopWiggle;
- (void) wiggle:(Timer*)timer;
- (void) deactivate;
- (void) moveTo:(CGPoint)point;
- (void) moveBack:(Timer*)timer;
- (void) movedBack:(Timer*)timer;
- (void) goToPoint:(Timer*)timer;
- (void) arrivedAtPoint:(Timer*)timer;
- (void) jumpToPos:(Pos)pos onBoard:(Board*)board;
- (void) jumpToPoint:(CGPoint)targetPoint fromPoint:(CGPoint)point;

@end

