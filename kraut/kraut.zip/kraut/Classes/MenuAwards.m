//
//  MenuAwards.m
//  kraut

#import "MenuAwards.h"
#import "MenuAward.h"
#import "MenuText.h"
#import "Tools.h"
#import "Menu.h"
#import "Screen.h"
#import "Sound.h"
#import "Letters.h"
#import "Layers.h"
#import "SpriteButton.h"
#import "Controller.h"
#import "Timer.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation MenuAwards
//------------------------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithDictionary:(NSDictionary*)dict_ parent:(MenuObject*)parent_
{
  if ((self = [super initWithDictionary:dict_ parent:parent_]))
  {
    awards = [[NSMutableArray arrayWithCapacity:16] retain];
    
    for (int i = 0; i < NumAwards; i++)
    {
      MenuAward * award = [[MenuAward alloc] initWithIndex:i parent:self];
      
      award.menu = self.menu;
      award.button.parent = self;
      
      [awards addObject:award];
      [award release];
    }
    
    minScrollOffset = 0;
    maxScrollOffset = 0;
    scrollValue = 0;
    scrollDelta = 0;
    
    openAward = -1;
    
    [[Controller instance] addEventReceiver:self type:@"button"];
  }
  
  [self layout];
  
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [[Controller instance] removeEventReceiver:self type:@"button"];
  [awards release];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeIn:(float)value
{
  for (MenuAward * award in awards) [award fadeIn:value];  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeOut:(float)value
{
  for (MenuAward * award in awards) [award fadeOut:value];  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onFrame:(double)delta
{
  for (MenuAward * award in awards) [award onFrame:delta];  
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) noBackTouchEvent:(TouchEvent*)event
{
  return !CGRectContainsPoint(((Button*)[self.menu.currScreen.children lastObject]).touchRect, event.point);
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onTouchUp:(TouchEvent*)event 
{
  if ([self noBackTouchEvent:event]) for (MenuAward * a in awards)  [a.button onTouchUp:event];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onTouchDown:(TouchEvent*)event 
{
  if ([self noBackTouchEvent:event]) for (MenuAward * a in awards)  [a.button onTouchDown:event];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) layout
{
  float y = 0.85f+scrollValue;
  maxScrollOffset = -2.0f;
  for (MenuAward * a in awards) 
  {
    [a moveTo:POINT(0, y)];
    y -= a.height;
    maxScrollOffset += a.height;
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onTouchMove:(TouchEvent*)event
{
  for (MenuAward * a in awards)  [a.button onTouchMove:event];
  
  scrollDelta = event.direction.y;
  
  if (scrollValue+scrollDelta > maxScrollOffset) 
  {
    scrollDelta = (scrollDelta <= 0) ? max(scrollDelta, maxScrollOffset-scrollValue) : max(0, maxScrollOffset-scrollValue);
  }
  else if (scrollValue+scrollDelta < minScrollOffset) 
  {
    scrollDelta = minScrollOffset-scrollValue;
  }
  
  scrollValue += scrollDelta;
  
  [self layout];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) toggleAwardAtIndex:(int)index
{
  NSString * sound = nil;
  
  if (openAward >= 0 && ((MenuAward*)[awards objectAtIndex:openAward]).open) 
  { 
    [[awards objectAtIndex:openAward] toggle];
    sound = @"fade out";
  }
  if (index != openAward)
  {
    openAward = -1;
    [[awards objectAtIndex:index] toggle];
    if (((MenuAward*)[awards objectAtIndex:index]).open) 
    {
      openAward = index;
      sound = @"fade in 2";
    }
    else
    {
     sound = @"fade out"; 
    }
  }
  else
  {
    openAward = -1;
  }
  
  if (sound) [Sound play:sound];
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) onEvent:(Event*)event
{
  if ([event isKindOfClass:[ButtonEvent class]])
  {
    ButtonEvent * buttonEvent = (ButtonEvent*)event;
    if ([buttonEvent.key isEqualToString:@"award"])
    {
      [self toggleAwardAtIndex:[buttonEvent.value intValue]];
    }
  }
  return YES;
}

@end
