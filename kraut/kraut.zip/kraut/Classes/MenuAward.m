//
//  MenuAward.m
//  kraut

#import "MenuAward.h"
#import "MenuAwards.h"
#import "MenuText.h"
#import "SpriteButton.h"
#import "Tools.h"
#import "Sprite.h"
#import "Sound.h"
#import "Letters.h"
#import "Layers.h"
#import "Timer.h"
#import "Menu.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation MenuAward
//------------------------------------------------------------------------------------------------------------------------

@synthesize title;
@synthesize prize;
@synthesize menu;
@synthesize button;
@synthesize index;
@synthesize height;
@synthesize open;
@synthesize awarded;
@synthesize point;
@synthesize slideValue;
@synthesize parent;

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithIndex:(int)index_ parent:(MenuAwards*)parent_
{
  if ((self = [super init]))
  {
    parent = parent_;
    index  = index_;
    title  = [[MenuText alloc] init];
    text   = [[MenuText alloc] init];
    prize  = [[MenuText alloc] init];
    
    NSDictionary * buttonDict = [[NSDictionary dictionaryWithObjectsAndKeys:
                                  [NSArray arrayWithObjects:
                                   [NSDictionary dictionaryWithObjectsAndKeys: @"extra_bg", @"sprite", 
                                    @"0.28", @"spriteSize", 
                                    @"0.15 0.15 0.15", @"color", 
                                    @"47", @"layer", 
                                    nil],
                                   [NSDictionary dictionaryWithObjectsAndKeys: @"extra_add", @"sprite", 
                                    @"0.28", @"spriteSize", 
                                    @"48", @"layer", 
                                    nil],
                                   [NSDictionary dictionaryWithObjectsAndKeys: @"award", @"sprite", 
                                    @"0.24", @"spriteSize", 
                                    @"0.0 0.0 0.0", @"color",
                                    @"49", @"layer", 
                                    nil], nil], @"sprites", 
                                  [NSDictionary dictionaryWithObjectsAndKeys:  @"award", @"key", [NSString stringWithFormat:@"%d", index], @"value", nil], @"event",
                                  nil] retain];
    
    button = [[SpriteButton alloc] initWithDictionary:buttonDict parent:nil];    
    
    title.alignment = ALIGN_LEFT;
    text.alignment = ALIGN_LEFT;
    prize.alignment = ALIGN_LEFT;
    title.layer = _challenge_;
    title.preHeadSpace = 0;
    title.postHeadSpace = 0;
    text.layer = _challenge_;
    text.textSize = 0.09f;
    text.textColor = RGBCOLOR(1,1,1);
    prize.layer = _challenge_;
    prize.textSize = 0.09f;
    prize.textColor = RGBCOLOR(1,1,1);

    AwardInfo * info = [[Awards instance] awardAtIndex:index];
    
    buttonDict = [[NSDictionary dictionaryWithObjectsAndKeys:
                                  [NSArray arrayWithObjects:
                                   [NSDictionary dictionaryWithObjectsAndKeys: @"extra_bg", @"sprite", 
                                    @"0.38", @"spriteSize", 
                                    @"0.15 0.15 0.15", @"color", 
                                    @"48", @"layer", 
                                    nil],
                                   [NSDictionary dictionaryWithObjectsAndKeys: @"extra_add", @"sprite", 
                                    @"0.38", @"spriteSize", 
                                    @"48", @"layer", 
                                    nil],
                                   [NSDictionary dictionaryWithObjectsAndKeys: @"award", @"sprite", 
                                    @"0.32", @"spriteSize", 
                                    @"0.0 0.0 0.0", @"color",
                                    @"49", @"layer", 
                                    nil], nil], @"sprites", 
                                  nil] retain];
    
    prizeSprite = [[SpriteButton alloc] initWithDictionary:buttonDict parent:nil];
    [prizeSprite setSprite:[[Awards instance] spriteForPrize:info->prize]];
    
    height = 0.3f;
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [slideTimer stop];
  [title  release];
  [text   release];
  [prize  release];
  [super  dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) update
{
  awarded = [[Awards instance] gotAwardAtIndex:index];
  AwardInfo * info = [[Awards instance] awardAtIndex:index];

  //NSLog(@"update %d", index);
  
  if (awarded)
  {
    [button setColor:RGBCOLOR(1,1,1) forIndex:2];
    [prizeSprite setColor:RGBCOLOR(1,1,1) forIndex:2];
    title.textColor = RGBCOLOR(1,1,1);
    prize.textColor = RGBCOLOR(1,1,1);
    title.preHeadSpace = -0.03f;
    [title  setText:[NSString stringWithFormat:@"[%@]", info->name]];
    [text   setText:[NSString stringWithFormat:info->info, [[Awards instance] printValueForPrize:info->prize]]];
    [prize  setText:[[Awards instance] textForPrize:info->prize]];
  }
  else
  {
    float c = 0.2f+slideValue*0.8f;
    title.textColor = RGBCOLOR(c,c,c);
    [title  setText:info->name];
    [text   setText:[NSString stringWithFormat:info->text, [[Awards instance] printValueForPrize:info->prize], [[Awards instance] totalForPrize:info->prize]]];
    [prize  setText:[[Awards instance] prizeForPrize:info->prize]];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeIn:(float)value
{
  if (value == 0) { [self update]; }
  [title  fadeIn:value offset:menu.fadeInOffset];  
  [text   fadeIn:value offset:menu.fadeInOffset];  
  [prize  fadeIn:value offset:menu.fadeInOffset];  
  button.fadeInOffset      = menu.fadeInOffset;
  prizeSprite.fadeInOffset = menu.fadeInOffset;
  [button       fadeIn:value];
  [prizeSprite  fadeIn:value];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeOut:(float)value
{
  [title  fadeOut:value offset:menu.fadeOutOffset];  
  [text   fadeOut:value offset:menu.fadeOutOffset];  
  [prize  fadeOut:value offset:menu.fadeOutOffset];  
  button.fadeOutOffset      = menu.fadeOutOffset;
  prizeSprite.fadeOutOffset = menu.fadeOutOffset;
  [button      fadeOut:value];
  [prizeSprite fadeOut:value];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onFrame:(double)delta
{
  [title draw];
  if (slideValue) 
  {
    [text  draw];
    [prize draw];    
    [prizeSprite onFrame:delta];
  }
  [button onFrame:delta];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) moveTo:(CGPoint)point_
{
  point = point_;
  [title  moveTo:POINT(-0.6f, point.y)];
  if (slideValue) 
  {
    [text  moveTo:POINT(-0.6f, point.y-0.2f)];
    [prize moveTo:POINT(-0.18f, point.y-0.63f)];
    [prizeSprite moveTo:POINT(-0.4f, point.y-0.83f)];
  }
  [button moveTo:POINT(-0.8f, point.y-0.15f)];  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setSlideValue:(float)slideValue_
{
  slideValue = slideValue_;
 
  if (open) 
  {
    [text  fadeIn:slideValue offset:POINT(2,0)];  
    [prize fadeIn:slideValue offset:POINT(2,0)];
    prizeSprite.fadeInOffset = POINT(2,0);
    [prizeSprite fadeIn:slideValue];
  }
  else      
  {
    [text  fadeOut:slideValue offset:POINT(2,0)];  
    [prize fadeOut:slideValue offset:POINT(2,0)];  
    prizeSprite.fadeOutOffset = POINT(2,0);
    [prizeSprite fadeOut:slideValue];
  }

  height = 0.3f + slideValue * 0.70f;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) toggle
{
  open = !open;
  
  [slideTimer stop];
  slideTimer = [Timer timerWithDuration:0.5f object:self tick:@selector(slide:) finish:@selector(slided:)];  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) slide:(Timer*)timer
{
  self.slideValue = (open ? timer.fraction : (1-timer.fraction));
  
  if (!awarded) 
  {
    float c = 0.2f+slideValue*0.8f;
    title.textColor = RGBCOLOR(c,c,c);
    prize.textColor = RGBCOLOR(c,c,c);
    AwardInfo * info = [[Awards instance] awardAtIndex:index];
    [title setText:info->name];
  }
  else
  {
    prize.textColor = RGBCOLOR(1,1,1);
  }
  
  [parent layout];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) slided:(Timer*)timer
{
  slideTimer = nil;
  self.slideValue = (open ? 1 : 0);
  [parent layout];
}

@end