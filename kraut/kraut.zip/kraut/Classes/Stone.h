//
//  Stone.h

#import "Event.h"
#import "Game.h"
@class Sprite;

#define STONE_EXPLODE_TIME 1.0f

//------------------------------------------------------------------------------------------------------------------------
@interface StoneType : NSObject
//------------------------------------------------------------------------------------------------------------------------
{
  Sprite    * sprite;
  NSString  * name;
  uint        pollenColor;
  uint        buttonColor;
  uint        scoreColor;
}

@property (assign)    Sprite    * sprite;
@property (readonly)  NSString  * name;
@property (assign)    uint        pollenColor;
@property (assign)    uint        buttonColor;
@property (assign)    uint        scoreColor;

- (id) initWithName:(NSString*)name image:(NSString*)image;
- (void) playSound:(Timer*)timer;
- (void) playSound;
- (void) playSoundWithDelay:(float)delay;
+ (StoneType*) random;
+ (void)       randomSound;
+ (StoneType*) penaltyStoneWithIndex:(int)index;
+ (StoneType*) withName:(NSString*)name;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface Stone : NSObject <EventReceiver>
//------------------------------------------------------------------------------------------------------------------------
{
  StoneType * type;
  Field     * field;
  CGRect      rect, startRect, targetRect;
  float       alpha;
  float       scale;
  float       angle;
  BOOL        above;
  
  Timer * moveTimer;
  Timer * explodeTimer;
}

@property (assign) StoneType  * type;
@property (assign) Field      * field;
@property (assign) CGRect       rect;
@property (assign) CGRect       startRect;
@property (assign) CGRect       targetRect;
@property (assign) float        alpha;
@property (assign) float        scale;
@property (assign) float        angle;
@property (assign) BOOL         above;

+ (Stone*)  ofType:(StoneType*)type;
- (void)    fadeIn;
- (void)    fadedOut;
- (void)    explode;
- (id)      initWithType:(StoneType*)type;
- (void)    transform:(CGAffineTransform)trans;
- (BOOL)    onEvent:(Event*)event;
- (void)    onFrame:(double)delta;
- (void)    moveBy:(CGPoint)vector;
- (void)    setCenter:(CGPoint)point;
- (void)    moveToRect:(CGRect)rect;
- (void)    penaltyMoveFromPoint:(CGPoint)point toRect:(CGRect)rect;
- (void)    playSound;
- (void)    playSoundWithDelay:(float)delay;

@end
