//
//  Extras.m

#import "Extras.h"
#import "Controller.h"
#import "Game.h"
#import "Extra.h"
#import "ExtraButton.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation Extras
//------------------------------------------------------------------------------------------------------------------------

+ (void) extraForPollen:(int)pollen score:(int)oldScore point:(CGPoint)point
{
  int newScore = oldScore+pollen;
  
  //NSLog(@"%d + %d = newScore %d", oldScore, pollen, newScore);
    
  int butScore = 200;
  int bugScore = 100;
  int beeScore = 50;
  
  if ([Controller instance].debug)
  {
    butScore = 40;
    bugScore = 20;
    beeScore = 10;
  }
  
  if ((int)(oldScore/butScore) != (int)(newScore/butScore))
  { 
    if ([Game current].levelInfo.buts >= 0)
    {
      [Game current].levelInfo.buts++;
      [[Game current].butButton addExtraFromPoint:point];
    }
  }
  if ((int)(oldScore/bugScore) != (int)(newScore/bugScore)) 
  { 
    if ([Game current].levelInfo.bugs >= 0)
    {
      [Game current].levelInfo.bugs++;
      [[Game current].bugButton addExtraFromPoint:point]; 
    }
  }
  if ((int)(oldScore/beeScore) != (int)(newScore/beeScore)) 
  { 
    if ([Game current].levelInfo.bees >= 0)
    {
      [Game current].levelInfo.bees++;
      [[Game current].beeButton addExtraFromPoint:point]; 
    }
  }
}

//------------------------------------------------------------------------------------------------------------------------
+ (Extras*) instance
{
  return [Game current].extras;
}

//------------------------------------------------------------------------------------------------------------------------
- (id) init
{
  if ((self = [super init]))
  {
    activeExtras = [[NSMutableArray arrayWithCapacity:10] retain];
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [self deactivateAllExtras];
  [activeExtras release];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) deactivateAllExtras
{
  for (Extra * extra in activeExtras)
  {
    [extra deactivate];
  }
  [activeExtras removeAllObjects];
}

//------------------------------------------------------------------------------------------------------------------------
- (int) numberOfActiveExtras
{
  return [activeExtras count];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) removeActiveExtra:(Extra*)extra
{
  //NSLog(@"extras::removeActiveExtra: %@ [%d]", extra, [activeExtras count]);
  [activeExtras removeObject:extra];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) addActiveExtra:(Extra*)extra
{
  //NSLog(@"extras::addActiveExtra: %@ [%d]", extra, [activeExtras count]);
  [activeExtras addObject:extra];
}

@end

