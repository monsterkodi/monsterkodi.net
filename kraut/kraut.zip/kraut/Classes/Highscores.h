//
//  Highscores.h

@class LevelInfo;
@class Signature;

//------------------------------------------------------------------------------------------------------------------------
@interface HighscoreEntry : NSObject 
//------------------------------------------------------------------------------------------------------------------------
{
  int         score;
  Signature * signature;
}

@property (assign) int          score;
@property (assign) Signature  * signature;

- (id)    init;
- (id)    initWithCoder:(NSCoder*)decoder;
- (void)  encodeWithCoder:(NSCoder*)encoder;
- (void)  dealloc;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface Highscore : NSObject 
//------------------------------------------------------------------------------------------------------------------------
{
  NSMutableArray * entries;
}

@property (assign) NSMutableArray * entries;

- (id)                init;
- (id)                initWithCoder:(NSCoder*)decoder;
- (void)              encodeWithCoder:(NSCoder*)encoder;
- (void)              dealloc;
- (int)               scoreForPlace:(int)place;
- (int)               numberOfEntries;
- (HighscoreEntry*)   entryForPlace:(int)place;
- (HighscoreEntry*)   addEntryForScore:(int)score;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface Highscores : NSObject 
//------------------------------------------------------------------------------------------------------------------------
{
  NSMutableDictionary * highscores;
}

+ (Highscores*)     instance;
+ (int)             scoreForPlace:(int)place;
+ (HighscoreEntry*) entryForPlace:(int)place;
+ (void)            saveHighscores;
- (id)              init;
- (void)            dealloc;
- (void)            save;
- (void)            load;
- (Highscore*)      highscoreForLevel:(LevelInfo*)levelInfo;
- (HighscoreEntry*) addEntryForScore:(int)score;
- (int)             numberOfEntries;

@end
