//
//  Menu.h

#import "MenuObject.h"
#import "Event.h"

@class Screen;
@class Title;
@class Game;
@class Timer;
@class MenuText;

//------------------------------------------------------------------------------------------------------------------------
@interface Menu : MenuObject <EventReceiver>
//------------------------------------------------------------------------------------------------------------------------
{
  Screen * currScreen;
  Screen * mainScreen;
  Screen * lastScreen;
  
  NSMutableArray * screenHistory;

  CGPoint  fadeOutOffset;
  CGPoint  fadeInOffset;
}
@property (assign) Screen * currScreen;
@property (assign) Screen * mainScreen;
@property (assign) Screen * lastScreen;
@property (assign) CGPoint fadeInOffset;
@property (assign) CGPoint fadeOutOffset;

- (void)      dealloc;
- (void)      fadeOut;
- (void)      fadeIn;
- (void)      displayScreen:(Screen*)screen;
- (void)      pushScreen:(Screen*)screen;
- (void)      popScreen;
- (void)      clearHistory;
- (BOOL)      onEvent:(Event*)event;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface MainMenu : Menu
//------------------------------------------------------------------------------------------------------------------------
{  
  NSMutableArray * flowers;
  NSMutableArray * screens;
  Title          * title;
  NSArray        * screenDicts;
}

@property (readonly) Title * title;

+ (MainMenu*) instance;
- (void)      popToMainScreen;
- (void)      loadScreenWithName:(NSString*)screenName;
- (void)      pushScreenWithName:(NSString*)screenName;
- (Screen*)   screenWithName:(NSString*)screenName;
- (id)        init;
- (void)      dealloc;
- (void)      setup;
- (void)      startTitleStroke;
- (void)      fadeOutTitle;
- (void)      fadeOut;
- (void)      fadeIn;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface GameMenu : Menu
//------------------------------------------------------------------------------------------------------------------------
{
  Game * game;
  NSDictionary * menuDict;
  
  Timer           * showInfoTimer;
  Timer           * hideInfoTimer;
  MenuText        * info;  
}

@property (assign) Game * game;

- (void) setupWithGame:(Game*)game;
- (void) showInfo:(NSString*)text;
- (void) showInfo:(NSString*)text atPoint:(CGPoint)point;

@end
