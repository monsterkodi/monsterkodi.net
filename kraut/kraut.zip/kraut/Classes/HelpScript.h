//
//  HelpScript.h
//  kraut

@class MenuText;
@class Timer;
@class HelpScriptAction;

//------------------------------------------------------------------------------------------------------------------------
@interface HelpScript : NSObject 
//------------------------------------------------------------------------------------------------------------------------
{
  NSMutableArray * actions;
  BOOL stopped;
}

- (id)    initWithDictionary:(NSDictionary*)dict;
- (void)  startAction:(int)index;
- (void)  play;
- (void)  stop;
- (void)  actionWithKey:(NSString*)key;
- (void)  actionFadedOut:(HelpScriptAction*)action;
@end
