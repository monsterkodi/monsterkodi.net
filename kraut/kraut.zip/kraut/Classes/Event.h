//
//  Event.h

#import "Tools.h"

//------------------------------------------------------------------------------------------------------------------------
@interface Event : NSObject
//------------------------------------------------------------------------------------------------------------------------
{
  NSString * type;
}
@property (assign) NSString * type;
@end

//------------------------------------------------------------------------------------------------------------------------
@interface OrientationEvent : Event
//------------------------------------------------------------------------------------------------------------------------
{
  Orientation orientation;
}
@property (assign) Orientation orientation;
@end

//------------------------------------------------------------------------------------------------------------------------
@interface SleepEvent : Event
//------------------------------------------------------------------------------------------------------------------------
{
  BOOL wakeup;
}
@property (assign) BOOL wakeup;
@end

//------------------------------------------------------------------------------------------------------------------------
@interface KeyValueEvent : Event
//------------------------------------------------------------------------------------------------------------------------
{
  NSString * key;
  NSString * value;
}
@property (assign) NSString * key;
@property (assign) NSString * value;
@end

//------------------------------------------------------------------------------------------------------------------------
@interface ButtonEvent : KeyValueEvent
//------------------------------------------------------------------------------------------------------------------------
{
  uint       status;
}
@property (assign) uint       status;
@end

//------------------------------------------------------------------------------------------------------------------------
@interface FrameEvent : Event
//------------------------------------------------------------------------------------------------------------------------
{
  double delta;
}
@property (assign) double delta;
@end

@class DragEvent;
//------------------------------------------------------------------------------------------------------------------------
@protocol DragObject
//------------------------------------------------------------------------------------------------------------------------

- (void) dragStarted:(DragEvent*)event;
- (void) dragMoved:(DragEvent*)event;
- (void) dragEnded:(DragEvent*)event;
- (void) dragCanceled:(DragEvent*)event;
@end

//------------------------------------------------------------------------------------------------------------------------
@interface DragEvent : Event
//------------------------------------------------------------------------------------------------------------------------
{
  CGPoint point;
  CGPoint delta;
  id<DragObject>  object;
  id<DragObject>  source;
  id<DragObject>  target;
}

@property (assign)  CGPoint point;
@property (assign)  CGPoint delta;
@property (assign)  id      object;
@property (assign)  id      source;
@property (assign)  id      target;
@end

//------------------------------------------------------------------------------------------------------------------------
@interface TouchEvent : Event
//------------------------------------------------------------------------------------------------------------------------
{
  int       finger;
  CGPoint   point;
  CGPoint   direction;
  UIEvent * event;
  int       tapCount;
  double    delta;
  double    distanceDelta;
}

@property (assign)  double    delta;
@property (assign)  double    distanceDelta;
@property (assign)  int       finger;
@property (assign)  int       tapCount;
@property (assign)  CGPoint   point;
@property (assign)  CGPoint   direction;
@property (assign)  UIEvent * event;

@end

//------------------------------------------------------------------------------------------------------------------------
@protocol EventReceiver
//------------------------------------------------------------------------------------------------------------------------

- (BOOL) onEvent:(Event*)event;

@end
