//
//  Field.h

#import "Event.h"
#import "Game.h"
#import "Tools.h"

@class Stone;

#define FIELD_COLOR 0xffbbbbbb
//#define FIELD_COLOR 0xff999999

//------------------------------------------------------------------------------------------------------------------------
@interface Field : NSObject <EventReceiver>
//------------------------------------------------------------------------------------------------------------------------
{
  CGRect    rect;
  Stone   * stone;
  Board   * board;
  Sprite  * sprite;
  
  BOOL      highlight;
  BOOL      marked;
  float     markerTime;
  int       row;
  int       col;
}

@property (assign)   CGRect  rect;
@property (assign)   Stone * stone;
@property (assign)   Board * board;
@property (assign)   BOOL    highlight;
@property (assign)   BOOL    marked;
@property (assign)   int     row;
@property (assign)   int     col;

- (id)      initWithRect:(CGRect)rect;
- (void)    fadeIn;
- (void)    fadedOut;
- (void)    onFrame:(double)delta;
- (BOOL)    isEmpty;
- (Pos)     pos;
- (CGPoint) center;
- (void)    moveTo:(CGPoint)point;
- (void)    moveBy:(CGPoint)vector;
- (void)    setRect:(CGRect)rect;

@end
