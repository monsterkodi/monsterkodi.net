//
//  Menu.m

#import "Menu.h"
#import "Screen.h"
#import "Controller.h"
#import "MenuFlower.h"
#import "Event.h"
#import "Game.h"
#import "Sound.h"
#import "Line.h"
#import "Signature.h"
#import "MenuText.h"
#import "Timer.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation Menu
//------------------------------------------------------------------------------------------------------------------------

@synthesize currScreen;
@synthesize mainScreen;
@synthesize lastScreen;

@synthesize fadeInOffset;
@synthesize fadeOutOffset;

//------------------------------------------------------------------------------------------------------------------------
- (Menu*) menu
{
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (id) init
{
  if ((self = [super init]))
  {
    screenHistory = [[[NSMutableArray alloc] initWithCapacity:5] retain];
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [[Controller instance] removeEventReceiver:self type:@"up"];
  [[Controller instance] removeEventReceiver:self type:@"down"];
  [[Controller instance] removeEventReceiver:self type:@"move"];
  [[Controller instance] removeEventReceiver:self type:@"button"];
  [[Controller instance] removeEventReceiver:self type:@"frame"];
  
  [screenHistory  release];
  [super          dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) displayScreen:(Screen*)newScreen
{
  if (newScreen != currScreen)
  {
    fadeOutOffset = CGPointMake(-3.0, 0.0f);
    fadeInOffset  = CGPointMake(0.5, 0.0f);
    lastScreen = currScreen;
    currScreen = newScreen;
    [lastScreen startFadeOut];
    [currScreen startFadeIn];
    
    [self pushScreen:lastScreen];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) clearHistory
{
  [screenHistory removeAllObjects];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) pushScreen:(Screen*)screen
{
  if (![screenHistory containsObject:screen])
  {
    [screenHistory addObject:screen];
    [Sound play:@"fade in"];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) popScreen
{
  fadeOutOffset = CGPointMake(3.0, 0.0f);
  fadeInOffset  = CGPointMake(-0.5, 0.0f);
  lastScreen = currScreen;
  currScreen = [screenHistory lastObject];
  NSAssert(currScreen, @"popping screen without lasstScreen?");
  [screenHistory removeLastObject];
  [lastScreen startFadeOut];
  [currScreen startFadeIn];
  [Sound play:@"fade out"];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) fadeIn
{  
  [[Controller instance] addEventReceiver:self type:@"frame"];
  [[Controller instance] addEventReceiver:self type:@"up"];
  [[Controller instance] addEventReceiver:self type:@"down"];
  [[Controller instance] addEventReceiver:self type:@"move"];
  [[Controller instance] addEventReceiver:self type:@"button"];
  
  fadeInOffset  = CGPointMake(1.5, 0.0f);
  
  [currScreen startFadeIn];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) fadeOut
{  
  [[Controller instance] removeEventReceiver:self type:@"up"];
  [[Controller instance] removeEventReceiver:self type:@"down"];
  [[Controller instance] removeEventReceiver:self type:@"move"];
  [[Controller instance] removeEventReceiver:self type:@"button"];
  
  [currScreen startFadeOut];
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) onEvent:(Event*)event
{  
  if ([event isKindOfClass:[FrameEvent class]])
  {
    double delta = ((FrameEvent*)event).delta;

    if ([currScreen isVisible])               [currScreen onFrame:delta];
    if (lastScreen && [lastScreen isVisible]) [lastScreen onFrame:delta];    
  }
  else if ([event isKindOfClass:[TouchEvent class]])
  {
    if ([event.type isEqualToString:@"up"])
    {
      [currScreen onTouchUp:(TouchEvent*)event];
    }
    else if ([event.type isEqualToString:@"down"])
    {
      [currScreen onTouchDown:(TouchEvent*)event];
    }
    else if ([event.type isEqualToString:@"move"])
    {
      [currScreen onTouchMove:(TouchEvent*)event];
    }
  }
  else if ([event isKindOfClass:[ButtonEvent class]])
  {
    ButtonEvent * buttonEvent = (ButtonEvent*)event;
    if ([buttonEvent.key isEqualToString:@"back"])
    {
      [self popScreen];
    }
  }
  
  return YES;
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation MainMenu
//------------------------------------------------------------------------------------------------------------------------

@synthesize title;

//------------------------------------------------------------------------------------------------------------------------
+ (MainMenu*) instance
{
  return [Controller instance].menu;
}

//------------------------------------------------------------------------------------------------------------------------
- (id) init
{
  if ((self = [super init]))
  {
    flowers = [[[NSMutableArray alloc] initWithCapacity:NUM_MENU_FLOWERS] retain];
  }
  
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [title    release];
  [flowers  release];
  [screens  release];
  //CFRelease(screenDicts);
  [super    dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setup
{
  screenDicts = LoadPropertyList(@"MainMenuXML.plist");
  if (screenDicts)
  {      
    screens = [[NSMutableArray arrayWithCapacity:2] retain];
    for (NSDictionary * screenDict in screenDicts)
    {
      Screen * screen = [[MenuScreen alloc] initWithDictionary:screenDict parent:self];
      [screens addObject:screen];
      [screen release];
    }
    mainScreen  = [screens objectAtIndex:0];
    currScreen  = mainScreen;
  }
      
  for (int i = 0; i < NUM_MENU_FLOWERS; i++)
  {
    MenuFlower * flower = [[MenuFlower alloc] initWithIndex:i];
    [flowers addObject:flower];
    [flower release];
  }
  
  title = [[Title alloc] init];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startTitleStroke
{
  [title startStrokeInWithDuration:4.0f];  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeOutTitle
{
  if (title) { [title startFadeOut]; title = nil; }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) popToMainScreen
{
  [self clearHistory];
  [screenHistory addObject:mainScreen];
  [self popScreen];
}

//------------------------------------------------------------------------------------------------------------------------
- (Screen*) screenWithName:(NSString*)screenName
{
  for (Screen * screen in screens)
    if ([screen.name isEqualToString:screenName])
      return screen;
  return [[screens objectAtIndex:0] screenWithName:screenName];
}  

//------------------------------------------------------------------------------------------------------------------------
- (void) loadScreenWithName:(NSString*)screenName
{
  [screenHistory removeAllObjects];
  lastScreen = nil;
  currScreen = [self screenWithName:screenName];
  [self fadeIn];
}  

//------------------------------------------------------------------------------------------------------------------------
- (void) pushScreenWithName:(NSString*)screenName
{
  Screen * screen = [self screenWithName:screenName];
  [screenHistory addObject:screen];
}  

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeIn
{  
  for (MenuFlower * flower in flowers) [flower startFadeIn];
  [self fadeOutTitle];
  
  [super fadeIn];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeOut
{
  for (MenuFlower * flower in flowers) [flower startFadeOut];
  [super fadeOut];  
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation GameMenu
//------------------------------------------------------------------------------------------------------------------------

@synthesize game;

//------------------------------------------------------------------------------------------------------------------------

- (void) setupWithGame:(Game*)game_
{
  game = game_;
  menuDict = LoadPropertyList(@"GameMenuXML.plist");
  if (menuDict)
  {      
    mainScreen = [[Screen alloc] initWithDictionary:menuDict parent:self];
    currScreen = mainScreen;
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  CFRelease(menuDict);
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) showInfo:(NSString*)text atPoint:(CGPoint)point
{
  info          = [[MenuText alloc] init];  
  info.point    = point;
  info.textSize = 0.09f;
  info.headSize = 0.12f;
  [info setText:text];
  [info fadeIn:0 offset:POINT(-2, 0)];
  
  if (showInfoTimer) [showInfoTimer stop];
  showInfoTimer = [Timer timerWithDuration:1.0f object:self tick:@selector(showingInfo:) finish:@selector(infoShown:)];  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) showInfo:(NSString*)text
{
  [self showInfo:text atPoint:POINT(0,-0.7f)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) showingInfo:(Timer*)timer
{
  [info fadeIn:timer.fraction offset:POINT(-2, 0)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) infoShown:(Timer*)timer
{
  [info fadeIn:1 offset:POINT(-2, 0)];
  showInfoTimer = nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) hideInfo
{
  if (info && !hideInfoTimer)
    hideInfoTimer = [Timer timerWithDuration:1.0f object:self tick:@selector(hidingInfo:) finish:@selector(infoHidden:)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) hidingInfo:(Timer*)timer
{
  [info fadeOut:(1-timer.fraction) offset:POINT(2, 0)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) infoHidden:(Timer*)timer
{
  hideInfoTimer = nil;
  [info fadeOut:0 offset:POINT(2, 0)];
  [info release];
  info = nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) onEvent:(Event*)event
{  
  if ([event isKindOfClass:[FrameEvent class]])
  {
    [info draw];
  }
  else if ([event isKindOfClass:[TouchEvent class]])
  {
    if ([event.type isEqualToString:@"down"])
    {
      [self hideInfo];
    }
  }
  else if ([event isKindOfClass:[ButtonEvent class]])
  {
    ButtonEvent * buttonEvent = (ButtonEvent*)event;
    if ([buttonEvent.key isEqualToString:@"back"])
    {
      [self hideInfo];
    }
  }
  
  return [super onEvent:event];
}

@end
