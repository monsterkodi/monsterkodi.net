//
//  Bee.h
//  kraut

#import "Extra.h"

@class Bezier;
@class Field;
@class Timer;

//------------------------------------------------------------------------------------------------------------------------
@interface Bee : Extra
//------------------------------------------------------------------------------------------------------------------------
{
  Bezier          * bezier;
  NSMutableArray  * stones;
  Field           * field;
  Timer           * explodeTimer;
  
  float             targetAngle;
}

@property (assign) Field * field;

- (id)   init;
- (void) dealloc;
- (void) setCenter:(CGPoint)point;
- (void) explode;
- (void) exploded:(Timer*)timer;
- (void) exploding:(Timer*)timer;
- (void) jumpToPos:(Pos)pos onBoard:(Board*)board;
- (void) goToField:(Timer*)timer;
- (void) arrivedAtField:(Timer*)timer;
- (void) dragEnded:(DragEvent*)event;

@end
