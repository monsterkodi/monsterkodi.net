//
//  Timer.m

#import "Timer.h"
#import "Controller.h"

Timer * active;
Timer * inactive;
Timer * semiactive;

int timers;

//------------------------------------------------------------------------------------------------------------------------
@implementation Timers
//------------------------------------------------------------------------------------------------------------------------

+ (Timer*) timer
{
  if (!inactive) inactive = [[Timer alloc] init];
  Timer * nextInactive = inactive.next;
  if (active)
  {
    active.prev   = inactive;
    inactive.next = active;
    active        = inactive;
  }
  else
  {
    active        = inactive;
    active.next   = nil;
  }
  
  inactive        = nextInactive;  
  inactive.prev   = nil;
  
  NSAssert((active && (active != active.next)), @"activating timer failed: active timer.next equals itself?");
  NSAssert(!(inactive && (inactive == inactive.next)), @"activating timer failed: inactive timer.next equals itself?");

  /*
  NSLog(@"+timer active:");
  Timer * t = active;
  while (t) { NSLog(@"%@", t); t = t.next; }

  NSLog(@"inactive:");
  t = inactive;
  while (t) { NSLog(@"%@", t); t = t.next; }
  */

  //NSLog(@"+timer %@", active);

  return active;
}

//------------------------------------------------------------------------------------------------------------------------

+ (void) deactivate:(Timer*)timer
{
  //NSLog(@"-timer %@", timer);
  
  NSAssert((timer != inactive), @"deactivating timer failed: inactive == timer?");

  if (timer.prev) timer.prev.next = timer.next; 
  else                     active = timer.next;
  if (timer.next) timer.next.prev = timer.prev;
  if (inactive) inactive.prev = timer;
  timer.next = inactive;
  inactive = timer;
  inactive.prev = nil;
  
  NSAssert((!active || (active != active.next)), @"deactivating timer failed: active timer.next equals itself?");
  NSAssert((inactive && (inactive != inactive.next)), @"deactivating timer failed: inactive timer.next equals itself?");  

  /*
  NSLog(@"active:");
  Timer * t = active;
  while (t) { NSLog(@"%@", t); t = t.next; }
  
  NSLog(@"inactive:");
  t = inactive;
  while (t) { NSLog(@"%@", t); t = t.next; }  
   */
}

//------------------------------------------------------------------------------------------------------------------------

+ (void) onFrame:(double)delta
{
  Timer * timer = active;
  while (timer) 
  {
    Timer * nextTimer = timer.next;
    [timer onFrame:delta];
    if (timer.time < 0) [Timers deactivate:timer];    
    timer = nextTimer;
  }
}

//------------------------------------------------------------------------------------------------------------------------
+ (void) stopAllTimers
{
  Timer * timer = active;
  while (timer) 
  {
    Timer * nextTimer = timer.next;
    [timer stop];
    [Timers deactivate:timer];    
    timer = nextTimer;
  }  
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation Timer
//------------------------------------------------------------------------------------------------------------------------

@synthesize time;
@synthesize elapsedTime;
@synthesize duration;
@synthesize delta;
@synthesize tick;
@synthesize finish;
@synthesize object;
@synthesize info;

@synthesize next;
@synthesize prev;
@synthesize num;

//------------------------------------------------------------------------------------------------------------------------
+ (Timer*)  timerWithDuration:(float)duration object:(id)object tick:(SEL)tick finish:(SEL)finish info:(id)info
{
  Timer * timer   = [Timers timer];
  timer.duration  = duration;
  timer.time      = duration;
  timer.object    = object;
  timer.tick      = tick;
  timer.finish    = finish;
  timer.info      = info;
  //NSLog(@"timer %@", timer);
  return timer;
}

//------------------------------------------------------------------------------------------------------------------------
+ (Timer*)  timerWithDuration:(float)duration object:(id)object tick:(SEL)tick finish:(SEL)finish
{
  return [Timer timerWithDuration:duration object:object tick:tick finish:finish info:nil];
}

//------------------------------------------------------------------------------------------------------------------------
+ (Timer*)  timerWithObject:(id)object tick:(SEL)tick
{
  return [Timer timerWithDuration:0 object:object tick:tick finish:nil info:nil];
}

//------------------------------------------------------------------------------------------------------------------------
- (id) init
{
  if ((self = [super init]))
  {    
    num = ++timers;
    //NSLog(@"timer alloc %@", self);
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  NSLog(@"timer dealloc %@", self);
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (float) fraction
{
  if (duration) return (1.0f-time/duration);
  return 0;
}

//------------------------------------------------------------------------------------------------------------------------
- (float) elapsedTime
{
  if (duration) return duration-time;
  return time;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onFrame:(double)delta_
{
  if (time <= -111111) return;
  if (duration)
  {
    time -= delta_;

    delta = delta_/duration;

    if (time >= 0.0f)
    {
      if (tick) [object performSelector:tick withObject:self];
    }
    else
    {
      if (finish) [object performSelector:finish withObject:self];
      [self stop];
    }
  }
  else
  {
    time += delta_;
    delta = delta_;
    
    if (tick) [object performSelector:tick withObject:self];
  }  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) stop
{
  time = -999999;
  finish = nil;
  [info release]; 
  info = nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (NSString*) description
{
  //return [NSString stringWithFormat:@"<Timer %d duration %0.2f time %0.2f fraction %0.2f>", num, duration, time, self.fraction];
  return [NSString stringWithFormat:@"<Timer %d [%d] %d>", prev.num, num, next.num];
}

@end
