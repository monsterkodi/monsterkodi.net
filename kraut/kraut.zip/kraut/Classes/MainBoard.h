//
//  MainBoard.h

#import "Board.h"

@class Extra;
@class Bee;

//------------------------------------------------------------------------------------------------------------------------
@interface MainBoard : Board <DragObject>
//------------------------------------------------------------------------------------------------------------------------
{
  NSMutableArray * targetFields;
  Extra          * wigglingExtra;
  int              extraTargetIndex;
}

@property (assign) Extra * wigglingExtra;

- (id)    init;
- (void)  dealloc;

- (void)  fadeIn;

- (BOOL)  onEvent:(Event*)event;

- (void)  handleDragEvent:(DragEvent*)dragEvent;
- (void)  dragStarted:(DragEvent*)event;
- (void)  dragMoved:(DragEvent*)event;
- (void)  dragEnded:(DragEvent*)event;
- (void)  dragCanceled:(DragEvent*)event;

- (void)  displayTargetForBlock:(Block*)block atPos:(Pos)pos;
- (void)  resetTargetFields;
- (BOOL)  hasSpaceForExtra:(Extra*)extra atPos:(Pos)pos;

- (void)  penaltyStone:(Stone*)stone arrivedAtPoint:(CGPoint)point;

- (void)  bee:(Bee*)bee arrivedAtPoint:(CGPoint)point;

@end
