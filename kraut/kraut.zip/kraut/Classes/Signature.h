//
//  Sigature.h
//  kraut

#import "Event.h"

@class Timer;
@class StoneType;
@class Sprite;
@class Bezier;

#define SIGNATURE_MIN_DOT_SIZE 0.03f
#define SIGNATURE_MAX_DOT_SIZE 0.10f
#define SIGNATURE_MAX_DOTS     200

//------------------------------------------------------------------------------------------------------------------------
@interface StrokePoint : NSObject
//------------------------------------------------------------------------------------------------------------------------
{
  CGPoint point;
  float   size;
}

@property (assign) CGPoint point;
@property (assign) float   size;

- (id)    initWithPoint:(CGPoint)point size:(float)size;
- (id)    initWithCoder:(NSCoder*)decoder;
- (void)  encodeWithCoder:(NSCoder*)encoder;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface Stroke : NSObject
//------------------------------------------------------------------------------------------------------------------------
{
  NSMutableArray * points;
  StoneType      * type;
}

@property (assign) NSMutableArray * points;
@property (assign) StoneType      * type;

- (id)      initWithType:(NSString*)type;
- (id)      initWithCoder:(NSCoder*)decoder;
- (void)    encodeWithCoder:(NSCoder*)encoder;
- (int)     addPoint:(CGPoint)point;
- (int)     endPoint:(CGPoint)point;
- (void)    dealloc;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface Signature : NSObject
//------------------------------------------------------------------------------------------------------------------------
{
  NSMutableArray  * strokes;
  Stroke          * currentStroke;
  int               strokePoints;
  CGRect            rect;
  float             fadeValue;
  Timer           * fadeTimer;
  float             strokeValue;
  Timer           * strokeTimer;
  Sprite          * shadowSprite;
}

@property (assign) NSMutableArray * strokes;
@property (assign) Stroke         * currentStroke;
@property (assign) int              strokePoints;
@property (assign) CGRect           rect;

- (id)            init;
- (Signature*)    copy;
- (id)            initWithCoder:(NSCoder*)decoder;
- (void)          encodeWithCoder:(NSCoder*)encoder;
- (void)          dealloc;
- (void)          clear;
- (void)          draw;
- (void)          startStrokeOfType:(NSString*)type atPoint:(CGPoint)point;
- (int)           addStrokePoint:(CGPoint)point ofType:(NSString*)type;
- (int)           endStrokeAtPoint:(CGPoint)point;
- (void)          startStrokeIn;
- (void)          startStrokeInWithDuration:(float)duration;
- (void)          startFadeIn;
- (void)          fadeIn:(Timer*)timer;
- (void)          fadedIn:(Timer*)timer;
- (void)          startFadeOut;
- (void)          fadeOut:(Timer*)timer;
- (void)          fadedOut:(Timer*)timer;
- (StrokePoint*)  strokePoint:(int)index;
- (StoneType*)    stoneType:(int)index;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface Title : Signature <EventReceiver>
//------------------------------------------------------------------------------------------------------------------------
{
}

- (id)   init;
- (void) dealloc;
- (BOOL) onEvent:(Event*)event;

@end
