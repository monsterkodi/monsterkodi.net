//
//  HelpScriptSpriteAction.m
//  kraut

#import "HelpScriptSpriteAction.h"
#import "Controller.h"
#import "AnimBezier.h"
#import "Bezier.h"
#import "Timer.h"
#import "Tools.h"
#import "Sprite.h"
#import "Event.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation HelpScriptSpriteAction
//------------------------------------------------------------------------------------------------------------------------

- (int) parsePoints:(NSArray*)points to:(CGPoint*)pts
{
  int i = 0;
  for (id obj in points)
  {
    if ([obj isKindOfClass:[NSArray class]])
    {
      pts[i++] = POINT([[obj objectAtIndex:0] floatValue], [[obj objectAtIndex:1] floatValue]);
    }
    else
    {
      NSString * str = (NSString*)obj;
      if      ([str isEqualToString:@"bug"]) pts[i++] = POINT(-2/7.0f, 0.5+2/7.0f);
      else if ([str isEqualToString:@"bee"]) pts[i++] = POINT(      0, 0.5+2/7.0f);
      else if ([str isEqualToString:@"but"]) pts[i++] = POINT(-4/7.0f, 0.5+2/7.0f);
      else
      {
        int x = [[str substringWithRange:NSMakeRange(1, 1)] intValue];
        int y = [[str substringWithRange:NSMakeRange(2, 1)] intValue];
        if ([str characterAtIndex:0] == 'j') // jump
          pts[i++] = POINT(2*x/7.0f,(7+4*y)/14.0f);
        else if ([str characterAtIndex:0] == 'r') // ramp
          pts[i++] = POINT(-1+(2*x-1)*(8/(7.0f*12)), 1.5f-4/7.0f+(2*y-1)*(4/(7.0f*6)));
        else if ([str characterAtIndex:0] == 'b') // board
          pts[i++] = POINT((2*x-8)/7.0f,(4*y-23)/14.0f);
      }
    }
  }
  return i;
}

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithDictionary:(NSDictionary*)dict
{
  if ((self = [super initWithDictionary:dict]))
  {
    sprite = [Sprite withName:[dict valueForKey:@"sprite"]];
    size   = CGSizeMake([dict floatForKey:@"width" default:0.2f], [dict floatForKey:@"height" default:0.2f]);
    loop   = [dict floatForKey:@"loop" default:0];
    
    beziers = [[NSMutableArray arrayWithCapacity:1] retain];
    bezierIndex = 0;
    
    if ([dict valueForKey:@"beziers"])
    {
      NSArray * bezs = [dict valueForKey:@"beziers"];
      
      for (int i = 0; i < [bezs count]; i++)
      {
        NSDictionary * bezDict = [bezs objectAtIndex:i];
        NSDictionary * nxtDict = [bezs objectAtIndex:(i+1)%[bezs count]];
        
        CGPoint bezPts[4];
        int bezCount = [self parsePoints:[bezDict valueForKey:@"points"] to:bezPts];
        if (bezCount < 4)
        {
          CGPoint nxtPts[4];
          int nxtCount = [self parsePoints:[nxtDict valueForKey:@"points"] to:nxtPts];
          NSAssert(nxtCount, @"bezier with less than 4 points and no points in next bezier?");
          bezPts[3] = nxtPts[0];
        }
        
        AnimBezier * bez = [[AnimBezier alloc] init];
        bez.duration   = [bezDict floatForKey:@"duration" default:1.0f];
        bez.startAngle = [bezDict floatForKey:@"angle"    default:0.0f];
        bez.endAngle   = [nxtDict floatForKey:@"angle"    default:0.0f];
        
        if ([bezDict valueForKey:@"startEvent"])
        {
          bez.startEvent = [[KeyValueEvent alloc] init];
          bez.startEvent.type = @"help";
          bez.startEvent.key = [[bezDict valueForKey:@"startEvent"] valueForKey:@"key"];
          bez.startEvent.value = [[bezDict valueForKey:@"startEvent"] valueForKey:@"value"];
        }

        if ([bezDict valueForKey:@"endEvent"])
        {
          bez.endEvent = [[KeyValueEvent alloc] init];
          bez.endEvent.type = @"help";
          bez.endEvent.key = [[bezDict valueForKey:@"endEvent"] valueForKey:@"key"];
          bez.endEvent.value = [[bezDict valueForKey:@"endEvent"] valueForKey:@"value"];
        }
        
        bez.interpolation = [bezDict intForKey:@"interpolation" default:1];
        
        if (bezCount == 1)
        {
          bezPts[1] = CGPointAdd(bezPts[0], CGPointScale(CGVector(bezPts[0], bezPts[3]),  0.33f));
          bezPts[2] = CGPointAdd(bezPts[3], CGPointScale(CGVector(bezPts[0], bezPts[3]), -0.33f));          
        }
        if (bezCount == 2) 
        {
          CGPoint cp = bezPts[1];
          bezPts[1] = CGPointAdd(bezPts[0], CGPointScale(CGVector(bezPts[0], cp), 0.66f));
          bezPts[2] = CGPointAdd(bezPts[3], CGPointScale(CGVector(bezPts[3], cp), 0.66f));          
        }
        
        bez.bezier = [[Bezier from:bezPts[0] over:bezPts[1] and:bezPts[2] to:bezPts[3]] retain];
        [beziers addObject:bez];
        [bez release];
      }
    }
    
    point = [[beziers objectAtIndex:0] pointAtTime:0];
  }
  return self;  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [beziers release];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) delayFinished:(Timer*)timer 
{
  if (fadeInBezierCount)
  {
    AnimBezier * bez = [beziers objectAtIndex:fadeInBezierCount-1];
    if (actionTimer) [actionTimer stop];
    actionTimer = [Timer timerWithDuration:bez.duration object:self tick:@selector(fadeIn:) finish:@selector(fadedIn:) info:bez];
  }
  else [super delayFinished:timer];
}

//------------------------------------------------------------------------------------------------------------------------
- (CGPoint) spritePointForBezierStatus:(AnimBezierStatus*)status
{
  return status.point;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) drawSpriteWithBezier:(AnimBezier*)bez atTime:(float)time
{
  AnimBezierStatus * status = [bez statusAtTime:time];
  [sprite drawAtPoint:[self spritePointForBezierStatus:status] angle:status.angle size:status.size color:0xffffffff layer:sprite.layer];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startAction
{
  if (actionTimer) [actionTimer stop];
  [self startAnimation:[beziers objectAtIndex:bezierIndex]];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startAnimation:(AnimBezier*)bez
{
  [bez sendStartEvent];

  actionTimer = [Timer timerWithDuration:bez.duration object:self tick:@selector(animation:) finish:@selector(animationEnd:) info:bez];  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) animation:(Timer*)timer
{
  bezierTime = timer.fraction; 
  [self drawSpriteWithBezier:timer.info atTime:bezierTime];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) animationEnd:(Timer*)timer
{
  [self drawSpriteWithBezier:timer.info atTime:timer.fraction];
    
  bezierIndex = fadeInBezierCount + ((bezierIndex - fadeInBezierCount + 1) % ([beziers count] - fadeInBezierCount));
  bezierTime  = 0;
  [self startAnimation:[beziers objectAtIndex:bezierIndex]];
  
  [timer.info sendEndEvent];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeIn:(Timer*)timer
{
  [super fadeIn:timer];
  
  if (fadeInBezierCount)
  {
    bezierTime = timer.fraction; 
    [self drawSpriteWithBezier:timer.info atTime:bezierTime];
  }
  else
  {
    [sprite drawAtPoint:CGPointAdd(point, CGPointScale(POINT(2, 0), 1-fadeValue)) size:size alpha:fadeValue];  
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadedIn:(Timer*)timer
{
  if (fadeInBezierCount) 
  {
    bezierTime = timer.fraction;
    [self drawSpriteWithBezier:timer.info atTime:bezierTime];
    bezierIndex = fadeInBezierCount;
  }
  [super fadedIn:timer];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeOut:(Timer*)timer
{
  [super fadeOut:timer];
  [sprite drawAtPoint:CGPointAdd(point, CGPointScale(POINT(-2, 0), 1-fadeValue)) size:size alpha:fadeValue];  
}

//------------------------------------------------------------------------------------------------------------------------
- (AnimBezierStatus*) bezierStatus
{
  return [[beziers objectAtIndex:bezierIndex] statusAtTime:bezierTime];
}

@end
