//
//  Challenge.h
//  kraut

@class LevelInfo;
@class StoneType;
@class Sprite;

enum ChallengeStatus {
  LOCKED, OPEN, PASSED, SOLVED,
};

//------------------------------------------------------------------------------------------------------------------------
@interface Challenge : NSObject 
//------------------------------------------------------------------------------------------------------------------------
{
  NSString        * name;
  NSString        * text;
  int               ring;
  int               index;
  LevelInfo       * levelInfo;
  NSMutableArray  * siblings;
  NSArray         * pattern;
  NSArray         * board;
  NSArray         * ramp;
  Challenge       * parent;
  uint              status;
  float             angle;
}

@property (assign)   NSString *       name;
@property (assign)   NSString *       text;
@property (assign)   LevelInfo      * levelInfo;
@property (assign)   int              ring;
@property (assign)   int              index;
@property (assign)   uint             status;
@property (assign)   float            angle;
@property (assign)   Challenge      * parent;
@property (assign)   NSMutableArray * siblings;
@property (assign)   NSArray        * pattern;
@property (assign)   NSArray        * board;
@property (assign)   NSArray        * ramp;
@property (readonly) BOOL             isSolved;
@property (readonly) BOOL             isOpen;
@property (readonly) BOOL             isLocked;
@property (readonly) BOOL             isPassed;
@property (readonly) StoneType      * stoneType;
@property (readonly) NSString *       type;
@property (readonly) NSString       * title;
@property (readonly) NSString       * prize;

- (id)          initWithDictionary:(NSDictionary*)dict;
- (void)        setRing:(int)ring index:(int)index;
- (void)        stoneSetOnMarkedField;
- (void)        solved;
- (void)        passed;
- (void)        open;
- (StoneType*)  stoneType;
- (Sprite*)     prizeSprite;
- (BOOL)        isPuzzle;

@end
