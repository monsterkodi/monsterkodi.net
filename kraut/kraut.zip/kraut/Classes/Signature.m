//
//  Sigature.m
//  kraut

#import "Signature.h"
#import "Screen.h"
#import "Sprite.h"
#import "Timer.h"
#import "Tools.h"
#import "Line.h"
#import "Quad.h"
#import "Stone.h"
#import "Bezier.h"
#import "Controller.h"
#import "Animation.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation StrokePoint
//------------------------------------------------------------------------------------------------------------------------

@synthesize point;
@synthesize size;

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithPoint:(CGPoint)point_ size:(float)size_
{
  if ((self = [super init]))
  {
    point = point_;
    size  = size_;
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (id)  initWithCoder:(NSCoder*)decoder
{
  point = [decoder decodeCGPointForKey:@"point"];
  size  = [decoder decodeFloatForKey:@"size"];
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void)  encodeWithCoder:(NSCoder*)encoder
{
  [encoder encodeCGPoint:point forKey:@"point"];
  [encoder encodeFloat:size forKey:@"size"];
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation Stroke
//------------------------------------------------------------------------------------------------------------------------

@synthesize points;
@synthesize type;

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithType:(NSString*)type_
{
  if ((self = [super init]))
  {
    points = [[NSMutableArray arrayWithCapacity:4] retain];
    type   = [StoneType withName:type_];
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [points release];
  [super  dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (id)  initWithCoder:(NSCoder*)decoder
{
  points = [[NSMutableArray arrayWithArray:[decoder decodeObjectForKey:@"points"]] retain];
  type   = [StoneType withName:[decoder decodeObjectForKey:@"type"]];
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void)  encodeWithCoder:(NSCoder*)encoder
{
  [encoder encodeObject:points    forKey:@"points"];
  [encoder encodeObject:type.name forKey:@"type"];
}

//------------------------------------------------------------------------------------------------------------------------
- (int) addPoint:(CGPoint)point
{
  int count = 0;
  if ([points count])
  {
    float   lastSize      = ((StrokePoint*)[points lastObject]).size; 
    CGPoint lastPoint     = ((StrokePoint*)[points lastObject]).point; 
    CGPoint lastToCurrent = CGVector(lastPoint, point);
    float   distance      = CGPointLength(lastToCurrent);
    float   distanceAdded = 0;
    
    if (distance > SIGNATURE_MIN_DOT_SIZE)
    {
      while (distanceAdded < distance)
      {
        float size     = max(min(lastSize+0.0075f, min(distance, SIGNATURE_MAX_DOT_SIZE)), lastSize-0.01f);
        lastSize       = size;
        distanceAdded += size;
        CGPoint p = CGPointAdd(lastPoint, CGPointScale(lastToCurrent, distanceAdded/distance));
        StrokePoint * strokePoint = [[StrokePoint alloc] initWithPoint:p size:size];
        [points addObject:strokePoint];
        [strokePoint release];
        count++;
      }
    }
  }
  else
  {
    StrokePoint * strokePoint = [[StrokePoint alloc] initWithPoint:point size:SIGNATURE_MIN_DOT_SIZE];
    [points addObject:strokePoint];
    [strokePoint release];
    count++;
  }
  return count;
}

//------------------------------------------------------------------------------------------------------------------------
- (int) endPoint:(CGPoint)point
{
  if ([points count] > 0)
  {
    return [self addPoint:point];
  }
  StrokePoint * strokePoint = [[StrokePoint alloc] initWithPoint:point size:SIGNATURE_MAX_DOT_SIZE];
  [points addObject:strokePoint];
  [strokePoint release];
  return 1;
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation Signature
//------------------------------------------------------------------------------------------------------------------------

@synthesize strokes;
@synthesize currentStroke;
@synthesize strokePoints;
@synthesize rect;

//------------------------------------------------------------------------------------------------------------------------
- (id) init
{  
  if ((self = [super init]))
  {
    strokes = [[NSMutableArray arrayWithCapacity:10] retain];
    shadowSprite  = [Sprite withName:@"shadow"];
  }
  
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (Signature*) copy
{
  Signature * sig = [[Signature alloc] init];
  sig.strokePoints = strokePoints;
  sig.rect = rect;
  [sig.strokes release];
  sig.strokes = [strokes copy];
  return sig;
}

//------------------------------------------------------------------------------------------------------------------------
- (id)  initWithCoder:(NSCoder*)decoder
{
  strokes       = [[NSMutableArray arrayWithArray:[decoder decodeObjectForKey:@"strokes"]] retain];
  strokePoints  = [decoder decodeIntForKey:@"strokePoints"];
  rect          = [decoder decodeCGRectForKey:@"rect"];
  shadowSprite  = [Sprite withName:@"shadow"];
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void)  encodeWithCoder:(NSCoder*)encoder
{
  [encoder encodeObject:strokes forKey:@"strokes"];
  [encoder encodeInt:strokePoints forKey:@"strokePoints"];
  [encoder encodeCGRect:rect forKey:@"rect"];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [strokes release];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) clear
{
  [strokes release];
  strokes = [[NSMutableArray arrayWithCapacity:10] retain];
  strokePoints = 0;
  currentStroke = nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setRect:(CGRect)rect_
{
  float xscale = rect_.size.width/rect.size.width;
  float yscale = rect_.size.height/rect.size.height;
  for (Stroke * stroke in strokes)
  {
    for (StrokePoint * strokePoint in stroke.points)
    {
      strokePoint.point = CGPointSub(strokePoint.point, rect.origin);
      strokePoint.point = CGPointMake(strokePoint.point.x * xscale, strokePoint.point.y * yscale);
      strokePoint.point = CGPointAdd(strokePoint.point, rect_.origin);
    }
  }
  rect = rect_;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) draw
{
  if (strokeValue)
  {
    int strokedPoints = 0;
    for (Stroke * stroke in strokes)
    {
      for (StrokePoint * strokePoint in stroke.points)
      {
        float s = 1.44f*strokePoint.size * rect.size.width/1.9f;
        [stroke.type.sprite drawAtPoint:strokePoint.point size:CGSizeMake(s,s) alpha:fadeValue layer:_finger_];
        [shadowSprite drawAtPoint:strokePoint.point size:CGSizeMake(s*3,s*3) alpha:fadeValue layer:_shadow_];
        strokedPoints++;
        if (strokedPoints > strokePoints * strokeValue) break;
      }
      if (strokedPoints > strokePoints * strokeValue) break;
    }  
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startFadeIn
{
  if (fadeTimer) [fadeTimer stop];
  fadeTimer = [Timer timerWithDuration:SCREEN_FADE_IN_TIME object:self tick:@selector(fadeIn:) finish:@selector(fadedIn:)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeIn:(Timer*)timer
{
  fadeValue = timer.fraction;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadedIn:(Timer*)timer
{
  fadeTimer = nil;
  fadeValue = 1;
  
  [self startStrokeIn];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startStrokeIn
{
  [self startStrokeInWithDuration:SCREEN_FADE_IN_TIME];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startStrokeInWithDuration:(float)duration
{
  if (fadeTimer) { [fadeTimer stop]; fadeTimer = nil; }
  fadeValue = 1.0f; 
  strokeValue = 0;
  if (strokeTimer) [strokeTimer stop];
  strokeTimer = [Timer timerWithDuration:duration object:self tick:@selector(strokeIn:) finish:@selector(strokedIn:)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) strokeIn:(Timer*)timer
{
  strokeValue = timer.fraction;  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) strokedIn:(Timer*)timer
{
  strokeTimer = nil;
  strokeValue = 1;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startFadeOut
{
  if (strokeTimer) { [strokeTimer stop]; strokeTimer = nil; }
  if (fadeTimer) [fadeTimer stop];
  fadeTimer = [Timer timerWithDuration:SCREEN_FADE_IN_TIME object:self tick:@selector(fadeOut:) finish:@selector(fadedOut:)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeOut:(Timer*)timer
{
  fadeValue = 1-timer.fraction;
  strokeValue = min(strokeValue, fadeValue);
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadedOut:(Timer*)timer
{
  fadeTimer = nil;
  fadeValue = 0;
  strokeValue = 0;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startStrokeOfType:(NSString*)type atPoint:(CGPoint)point
{
  if (CGRectContainsPoint(rect, point))
  {
    currentStroke = [[Stroke alloc] initWithType:type];
    [strokes addObject:currentStroke];
    [currentStroke release];
  }
  else 
  {
    currentStroke = nil;
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (int) addStrokePoint:(CGPoint)point ofType:(NSString*)type
{
  int num = 0;
  if (!currentStroke) 
  { 
    [self startStrokeOfType:type atPoint:point];
  }
  else
  {
    if (CGRectContainsPoint(rect, point))
    {
      num = [currentStroke addPoint:point];
      strokePoints += num;
    }
    else
    {
      currentStroke = nil;
    }
  }
  return num;
}

//------------------------------------------------------------------------------------------------------------------------
- (int) endStrokeAtPoint:(CGPoint)point
{
  int num = 0;
  if (CGRectContainsPoint(rect, point))
  {
    if (currentStroke) 
    {
      num = [currentStroke endPoint:point];
      strokePoints += num;
    }
  }
  currentStroke = nil;
  return num;
}

//------------------------------------------------------------------------------------------------------------------------
- (StrokePoint*) strokePoint:(int)index
{
  for (Stroke * stroke in strokes)
  {
    if (index < [stroke.points count]) return [stroke.points objectAtIndex:index];
    else index -= [stroke.points count];
  }
  return nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (StoneType*) stoneType:(int)index
{
  for (Stroke * stroke in strokes)
  {
    if (index < [stroke.points count]) return stroke.type;
    else index -= [stroke.points count];
  }
  return nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (NSString*) description
{
  return [NSString stringWithFormat:@"<Signature strokes %d points: %d>", [strokes count], strokePoints];
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation Title
//------------------------------------------------------------------------------------------------------------------------

- (id) init
{  
  if ((self = [super init]))
  {
    rect = CGRectMake(-1.0f, -1.5f, 2.0f, 3.0f);
    
    CGPoint p[11][4] = {
      {POINT(-0.76f,  0.3f),    POINT(-0.79f, 0.1f),    POINT(-0.79f, -0.1f),   POINT(-0.73f, -0.27f)},
      {POINT(-0.73f, -0.27f),   POINT(-0.73f, 0.15f),   POINT(-0.43f,  0.45f),  POINT(-0.13f,  0.45f)},
      {POINT(-0.63f,  0.1f),    POINT(-0.43f, 0.1f),    POINT(-0.17f, -0.19f),  POINT(-0.17f, -0.45f)},
      {POINT(-0.40f,  0.05f),   POINT(-0.41f, 0.12f),   POINT(-0.41f,  0.175f), POINT(-0.38f,  0.25f)},
      {POINT(-0.38f,  0.25f),   POINT(-0.11f, 0.45f),   POINT(-0.01f,  0.15f),  POINT(-0.41f,  0.15f)},
      {POINT(-0.41f,  0.15f),   POINT( 0.05f, 0.15f),   POINT( 0.01f, -0.18f),  POINT( 0.27f, -0.18f)},
      {POINT(-0.07f,  0.16f),   POINT(-0.15f, 0.5f),    POINT( 0.3f,   0.45f),  POINT( 0.19f,  0.05f)},
      {POINT( 0.19f,  0.05f),   POINT( 0.17f, 0.15f),   POINT( 0.11f,  0.24f),  POINT(-0.07f,  0.24f)},
      {POINT( 0.30f,  0.31f),   POINT( 0.08f,-0.14f),   POINT( 0.72f, -0.12f),  POINT( 0.48f,  0.29f)},
      {POINT( 0.56f,  0.24f),   POINT( 0.60f, 0.21f),   POINT( 0.76f,  0.23f),  POINT( 0.80f,  0.26f)},
      {POINT( 0.66f,  0.23f),   POINT( 0.69f, 0.11f),   POINT( 0.69f,  0.03f),  POINT( 0.66f, -0.04f)},
    };
    
    int flowers[11] = {22,22,22, 21,21,21, 32,32, 30, 51,51};
    int stepnum[11] = {12,12,12, 12,16,21, 22,12, 20, 12,12};
    
    for (int i = 0; i < 11; i++)
    {
      NSString * flower = [NSString stringWithFormat:@"flower%02d", flowers[i]];
      Bezier * bez = [Bezier bezierWithPoints:p[i]];
      
      [self startStrokeOfType:flower atPoint:[bez pointAtTime:0]];
     
      int steps = stepnum[i];
      for (int s = 1; s < steps; s++) [self addStrokePoint:[bez pointAtTime:s*1.0f/steps] ofType:flower];
      
      [self endStrokeAtPoint:[bez pointAtTime:1]];
    }
    
    [[Controller instance] addEventReceiver:self type:@"frame"];    
  }
  
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadedOut:(Timer*)timer
{
  [[Controller instance] removeEventReceiver:self type:@"frame"];
  [self release];
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) onEvent:(Event*)event
{
  [self draw];
  return YES;
}

@end

