//
//  PrizeWheel.h
//  kraut

#import "Event.h"
#import "SpriteButton.h"

@class Timer;
@class ChallengeFlower;
@class MenuCampaign;

//------------------------------------------------------------------------------------------------------------------------
@interface PrizeButton : SpriteButton
//------------------------------------------------------------------------------------------------------------------------
{
  int     index;
  Timer * animTimer;
}

@property (assign) int index;

- (void)  fadeInWithDelay:(float)delay;
- (void)  fadeOutWithDelay:(float)delay;
- (void)  explodeWithDelay:(float)delay;

- (void)  startFadeIn:(Timer*)timer;
- (void)  fadeIn:(Timer*)timer;
- (void)  fadedIn:(Timer*)timer;

- (void)  startFadeOut:(Timer*)timer;
- (void)  fadeOut:(Timer*)timer;
- (void)  fadedOut:(Timer*)timer;

- (void)  startExplode:(Timer*)timer;
- (void)  explode:(Timer*)timer;
- (void)  exploded:(Timer*)timer;

@end 

//------------------------------------------------------------------------------------------------------------------------
@interface PrizeWheel : NSObject <EventReceiver> 
//------------------------------------------------------------------------------------------------------------------------
{
  ChallengeFlower * flower;
  MenuCampaign    * parent;
  NSMutableArray  * prizeArray;
  int               prizeCount;
  int               totalCount;
  
  float             buttonSize;
  float             spriteSize;
  
  Timer           * animTimer;  
}

- (id)    initWithParent:(MenuCampaign*)parent;
- (void)  dealloc;

- (void)  showWithFlower:(ChallengeFlower*)flower count:(int)current total:(int)count;

- (void)  startFadeIn;
- (void)  fadedIn:(Timer*)timer;

- (void)  startFadeOut;
- (void)  fadedOut:(Timer*)timer;

- (void)  startExplode;
- (void)  exploded:(Timer*)timer;

- (void)  onFrame:(double)delta;
- (BOOL)  onEvent:(Event*)event;

@end
