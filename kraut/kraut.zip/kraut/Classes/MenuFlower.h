//
//  MenuFlower.h

#import "Event.h"

@class Sprite;
@class Timer;

#define NUM_MENU_FLOWERS 21

//------------------------------------------------------------------------------------------------------------------------
@interface MenuFlower : NSObject <EventReceiver>
//------------------------------------------------------------------------------------------------------------------------
{
  Sprite    * sprite;
  Sprite    * shadowSprite;
  CGRect      rect;
  CGRect      shadowRect;
  int         index;
  uint        layer;
  float       alpha;
  float       angle;
  float       rotation;
  float       speed;
  float       fadeValue;
  Timer     * fadeTimer;
}

@property (assign) Sprite     * sprite;
@property (assign) CGRect       rect;
@property (assign) float        alpha;
@property (assign) float        angle;
@property (assign) float        speed;
@property (assign) float        fadeValue;

- (id)      initWithIndex:(int)index;
- (void)    initRect:(float)y;
- (Sprite*) randomFlower;
- (void)    transform:(CGAffineTransform)trans;
- (void)    moveBy:(CGPoint)vector;
- (void)    onFrame:(double)delta;
- (void)    startFadeIn;
- (void)    startFadeOut;
- (void)    fadingOut:(Timer*)timer;
- (void)    fadedOut:(Timer*)timer;

@end
