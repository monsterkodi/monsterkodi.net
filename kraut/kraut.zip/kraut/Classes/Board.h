//
//  Board.h

#import "Event.h"
#import "Tools.h"

@class Block;
@class Stone;
@class Field;
@class Game;
@class Timer;

//------------------------------------------------------------------------------------------------------------------------
@interface Board : NSObject <EventReceiver>
//------------------------------------------------------------------------------------------------------------------------
{
  NSMutableArray  * fields;
  NSString        * name;
  Game            * game;
  
  int     rows;
  int     cols;
  CGRect  rect;
  float   angle;

  CGPoint offset;
  
  Timer * fadeTimer;
}

@property (readonly) CGRect           rect;
@property (readonly) int              rows;
@property (readonly) int              cols;
@property (assign)   float            angle;
@property (readonly) NSArray        * stones;
@property (assign)   NSMutableArray * fields;
@property (assign)   NSString       * name;
@property (assign)   Game           * game;

- (id)      init;
- (id)      initWithRect:(CGRect)rect size:(int)size name:(NSString*)name;
- (id)      initWithRect:(CGRect)rect cols:(int)cols rows:(int)rows name:(NSString*)name;

- (void)    onFrame:(double)delta;
- (BOOL)    onEvent:(Event*)event;

- (void)    fadeIn;
- (void)    fadeOut;
- (void)    fadingIn:(Timer*)timer;
- (void)    fadingOut:(Timer*)timer;
- (void)    fadedIn:(Timer*)timer;
- (void)    fadedOut:(Timer*)timer;

- (void)    clear;
- (void)    explodeStones;
- (void)    setCols:(int)cols rows:(int)rows;
- (void)    layout;
- (BOOL)    hasSpaceForBlock:(Block*)block;
- (BOOL)    hasSpaceForBlock:(Block*)block atPos:(Pos)pos;
- (BOOL)    hasSpaceForBlockWithOrientation:(int)orientation atPos:(Pos)pos;
- (Pos)     jumpPosForBugAtPoint:(CGPoint)point;
- (BOOL)    isValidPos:(Pos)pos;
- (BOOL)    retainStones; 
- (void)    setStonesForBlock:(Block*)block atPos:(Pos)pos;
- (void)    setStonesForBlock:(Block*)block;
- (void)    delStonesForBlock:(Block*)block;
- (void)    moveBy:(CGPoint)vector;
- (Pos)     posForPoint:(CGPoint)point;
- (CGPoint) pointForPos:(Pos)pos;
- (int)     rowForPoint:(CGPoint)point;
- (int)     colForPoint:(CGPoint)point;
- (Field*)  fieldAtCol:(int)col row:(int)row;
- (Field*)  fieldAtPos:(Pos)pos;
- (Field*)  randomEmptyField;
- (NSMutableArray*) emptyFields;
- (int)     numberOfEmptyFields;
- (int)     numberOfFlowers;
- (int)     indexForPos:(Pos)pos;
- (Stone*)  stoneAtCol:(int)col row:(int)row;
- (Stone*)  stoneAtPos:(Pos)pos;
- (void)    setupWithDictionary:(NSDictionary*)dictionary;
- (NSDictionary*) dictionary;

@end
