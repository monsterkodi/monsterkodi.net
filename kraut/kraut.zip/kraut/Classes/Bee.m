//
//  Bee.m
//  kraut

#import "Bee.h"
#import "Sprite.h"
#import "ExtraButton.h"
#import "Bezier.h"
#import "Timer.h"
#import "Controller.h"
#import "Stone.h"
#import "Board.h"
#import "Game.h"
#import "Sound.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation Bee
//------------------------------------------------------------------------------------------------------------------------

@synthesize field;

//------------------------------------------------------------------------------------------------------------------------
- (id) init
{
  if ((self = [super init]))
  {
    layer = _extra_;
    sprite = [Sprite withName:@"bee"];
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  //NSLog(@"bee dealloc %@", self);
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setAlpha:(float)alpha {}
- (void) moveToRect:(CGRect)rect { /* NSLog(@"moveToRect"); */ }
- (void) setCenter:(CGPoint)point_ { point = point_; }
- (void) fadedOut { [self stopWiggle]; [self vanish]; }
- (void) fadeIn { [self show]; [self startWiggle]; }
- (StoneType*) type { return nil; }

//------------------------------------------------------------------------------------------------------------------------
- (CGRect) targetRect
{
  return CGRectMake(targetPoint.x, targetPoint.y, size, size);
}

//------------------------------------------------------------------------------------------------------------------------
- (void) goToField:(Timer*)timer
{
  point = [((Bezier*)(timer.info)) pointAtTime:timer.fraction];
  size  = [Game current].fieldSize + 0.15f*sin(timer.fraction*M_PI);
}

- (void) playWiggleSound { [Sound loop:@"bee loop" volume:0.5f]; }
- (void) stopWiggleSound { [Sound stop:@"bee loop"]; }

//------------------------------------------------------------------------------------------------------------------------
- (void) arrivedAtField:(Timer*)timer
{
  [Sound stop:@"bee loop"];
  
  [[Extras instance] removeActiveExtra:self];
  
  point = targetPoint;
  if (field.board == [Game current].board)
    [[Game current].board bee:self arrivedAtPoint:targetPoint];
  else
    [self explode];
  size = [Game current].fieldSize;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) explode
{
  [self stopWiggle];
  if (explodeTimer) [explodeTimer stop];
  explodeTimer = [Timer timerWithDuration:1.0f object:self tick:@selector(exploding:) finish:@selector(exploded:)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) exploding:(Timer*)timer
{
  float fieldSize = [Game current].fieldSize;
  size = (1-timer.fraction)*max(fieldSize + fieldSize*sin(timer.fraction*1.5f*M_PI), 0);
  angle = 360*timer.fraction*timer.fraction;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) exploded:(Timer*)timer
{
  explodeTimer = nil;
  [self vanish];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dragEnded:(DragEvent*)event
{
  [super dragEnded:event];

  Board * board = (Board*)event.target;
  [self jumpToPos:[board posForPoint:point] onBoard:board];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) jumpToPos:(Pos)pos onBoard:(Board*)board
{
  [self stopWiggleSound];
  [self startWiggle];
  [Sound loop:@"bee loop"];

  [super jumpToPos:pos onBoard:board];
  [Game current].levelInfo.bees--;
  
  field = [board fieldAtPos:pos];
  
  BOOL mainBoard = (board == [Game current].board);

  targetPoint = [board pointForPos:pos];
  if (moveTimer) [moveTimer stop];
  CGPoint pointToTarget = CGVector(point, targetPoint);
  CGPoint pointToTargetNorm = CGVectorNorm(pointToTarget);
  CGPoint c1 = CGPointAdd(point,       CGPointScale(pointToTargetNorm, -0.5f));
  CGPoint c2 = CGPointAdd(targetPoint, CGPointScale(pointToTargetNorm,  0.5f));
  bezier = [Bezier from:point over:c1 and:c2 to:targetPoint];
  
  if (mainBoard) [[Extras instance] addActiveExtra:self];
  
  float time = max(0.4f, 0.6f*CGPointLength(pointToTarget));
  [Timer timerWithDuration:time object:self tick:@selector(goToField:) finish:@selector(arrivedAtField:) info:bezier];
}

@end
