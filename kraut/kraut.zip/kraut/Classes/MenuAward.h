//
//  MenuAward.h
//  kraut

@class MenuText;
@class SpriteButton;
@class Menu;
@class Timer;
@class Sprite;
@class MenuAwards;

//------------------------------------------------------------------------------------------------------------------------
@interface MenuAward : NSObject
//------------------------------------------------------------------------------------------------------------------------
{
  MenuText      * title;
  MenuText      * text;
  MenuText      * prize;
  Menu          * menu;
  MenuAwards    * parent;
  SpriteButton  * button;
  SpriteButton  * prizeSprite;
  int             index;
  float           slideValue;
  BOOL            open;
  BOOL            awarded;
  float           height;
  CGPoint         point;
  Timer         * slideTimer;
}

@property (assign) Menu         * menu;
@property (assign) MenuText     * title;
@property (assign) MenuText     * prize;
@property (assign) SpriteButton * button;
@property (assign) int            index;
@property (assign) float          slideValue;
@property (assign) float          height;
@property (assign) BOOL           open;
@property (assign) BOOL           awarded;
@property (assign) CGPoint        point;
@property (assign) MenuAwards   * parent;

- (id)      initWithIndex:(int)index parent:(MenuAwards*)parent;
- (void)    fadeIn:(float)value;
- (void)    fadeOut:(float)value;
- (void)    moveTo:(CGPoint)point;
- (void)    onFrame:(double)delta;
- (void)    toggle;

@end
