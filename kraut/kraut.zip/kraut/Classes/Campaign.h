//
//  Campaign.h
//  kraut

#define CAMPAIGN_RINGS   6
#define CAMPAIGN_RADIUS  0.3f

@class Challenge;

//------------------------------------------------------------------------------------------------------------------------
@interface Campaign : NSObject 
//------------------------------------------------------------------------------------------------------------------------
{
  NSMutableArray  * challenges;
  NSMutableArray  * ringChallenges;
  Challenge       * currentChallenge;
  NSDictionary    * info;
  float angles[CAMPAIGN_RINGS];
  
  NSMutableArray  * openedChallenges;
  Challenge       * solvedChallenge;
}

@property (assign) NSMutableArray * challenges;
@property (assign) Challenge * currentChallenge;
@property (assign) NSDictionary * info;

@property (assign) NSMutableArray * openedChallenges;
@property (assign) Challenge * solvedChallenge;

+ (Campaign*)   instance;
+ (Challenge*)  challengeWithName:(NSString*)name;
- (id)          init;
- (void)        setup;
- (void)        dealloc;
- (void)        connectSiblings;
- (Challenge*)  challengeWithName:(NSString*)name;
- (NSDictionary*) solvedChallengesCounts;

@end
