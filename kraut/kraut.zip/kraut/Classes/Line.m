//
//  Line.m

#import "Line.h"
#import "Resources.h"
#import "Tools.h"

NSMutableDictionary * Lines;
Line  * currentLine;
Trail * currentTrail;

//------------------------------------------------------------------------------------------------------------------------
@implementation Line
//------------------------------------------------------------------------------------------------------------------------

@synthesize color;
@synthesize key;

//------------------------------------------------------------------------------------------------------------------------
+ (Line*) key:(NSString*)key
{
  if (!Lines) Lines = [[NSMutableDictionary dictionaryWithCapacity:10] retain];
  Line * line = [Lines valueForKey:key];
  if (!line)
  {
    line = [[Line alloc] init];
    line.key = key;
    [Lines setValue:line forKey:key];
    [line release];
  }
  currentLine = line;
  return line;
}

//------------------------------------------------------------------------------------------------------------------------
+ (void) from:(CGPoint)point to:(CGPoint)toPoint
{
  [[Line instance] from:point to:toPoint];
}

//------------------------------------------------------------------------------------------------------------------------
+ (void) rect:(CGRect)rect
{
  CGPoint bl = rect.origin;
  CGPoint br = CGPointAdd(rect.origin, POINT(rect.size.width,0));
  CGPoint tl = CGPointAdd(rect.origin, POINT(0,rect.size.height));
  CGPoint tr = CGPointAdd(rect.origin, POINT(rect.size.width,rect.size.height));
  [[Line instance] from:bl to:tl];
  [[Line instance] from:bl to:br];
  [[Line instance] from:br to:tr];
  [[Line instance] from:tl to:tr];
}

//------------------------------------------------------------------------------------------------------------------------
+ (void) color:(uint)color
{
  [Line instance].color = color;
}

//------------------------------------------------------------------------------------------------------------------------
+ (Line*) instance 
{ 
  if (!currentLine) [Line key:@"LINES"]; 
  return currentLine;
}

//------------------------------------------------------------------------------------------------------------------------
+ (void) flushLines
{
  for (Line * line in [Lines allValues]) [line flush];
}

//------------------------------------------------------------------------------------------------------------------------
- (id) init
{
  if ((self = [super init]))
  {
    color = 0xfffffff;
    [self initBuffer];
  }
  
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) initBuffer
{
  alloc = 1024;
  count = 0;
  lsize = (2 * sizeof(GLfloat) + 4 * sizeof(GLubyte));
  lines = malloc(alloc * lsize);
}  

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  free(lines);
  
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) delete
{
  if (currentLine == self) currentLine = nil;
  if (currentTrail == self) currentTrail = nil;
  [Lines removeObjectForKey:key];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) from:(CGPoint)point to:(CGPoint)toPoint
{
  if (count+2 > alloc && ![self growBuffer:64]) return;
  
  line * l = &lines[count];
	l->x = point.x; 
	l->y = point.y;  l->c = color; l++; count++;
  l->x = toPoint.x; 
	l->y = toPoint.y; l->c = color; l++; count++;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) addLine:(line)line_
{
  if (count+1 > alloc && ![self growBuffer:32]) return;
  lines[count++] = line_;
}

//------------------------------------------------------------------------------------------------------------------------
-(BOOL) growBuffer:(uint)num
{
  //NSLog(@"grow(%d): reallocating line buffer for id %d old size %d -> new size %d", num, id_, alloc, alloc+num);
  alloc += num;
  lines  = reallocf(lines, alloc * lsize);
  
  if (lines == 0) 
  {
    count = 0;
    return FALSE;
  }
  return TRUE;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) flush
{
  if (count == 0) return;
    
  glEnableClientState(GL_VERTEX_ARRAY);
  glEnableClientState(GL_COLOR_ARRAY);

  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);  

  glVertexPointer  (2, GL_FLOAT,         lsize, lines);
  glColorPointer   (4, GL_UNSIGNED_BYTE, lsize, &lines[0].c);
  
  glDrawArrays(GL_LINES, 0, count);
  
  glDisable(GL_BLEND);
  
  glDisableClientState(GL_VERTEX_ARRAY);
  glDisableClientState(GL_COLOR_ARRAY);
  
  [self flushed];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) flushed
{
  count = 0;
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation Vector
//------------------------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------------------------
+ (void) from:(CGPoint)point dir:(CGPoint)vector
{
  [Line from:point to:CGPointAdd(point, vector)];
}

//------------------------------------------------------------------------------------------------------------------------
+ (void) color:(uint)color
{
  [Line instance].color = color;
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation Trail
//------------------------------------------------------------------------------------------------------------------------

+ (Trail*) instance 
{ 
  if (!currentTrail) [Trail key:@"TRAIL"]; 
  return currentTrail;
}

//------------------------------------------------------------------------------------------------------------------------
+ (void) clear
{
  [[Trail instance] clear];
}

//------------------------------------------------------------------------------------------------------------------------
+ (void) color:(uint)color
{
  [Trail instance].color = color;
}

//------------------------------------------------------------------------------------------------------------------------
+ (Trail*) key:(NSString*)key
{
  Trail * trail = (Trail*)[Lines valueForKey:key];
  if (!trail)
  {
    trail = [[Trail alloc] init];
    trail.key = key;
    [Lines setValue:trail forKey:key];
    [trail release];
  }
  currentTrail = trail;
  return trail;
}

//------------------------------------------------------------------------------------------------------------------------
+ (void) addPoint:(CGPoint)point
{
  [[Trail instance] addPoint:point];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) addPoint:(CGPoint)point
{
  if (count < 2)
  {
    line * l = &lines[count];
    l->x = point.x;
    l->y = point.y;  l->c = color; count++;
  }
  else
  {
    if (count+2 > alloc && ![self growBuffer:64]) return;
    
    line * l = &lines[count];
    l->x = lines[count-1].x; 
    l->y = lines[count-1].y;  l->c = lines[count-1].c; l++; count++;
    l->x = point.x; 
    l->y = point.y;  l->c = color; l++; count++;
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) clear
{
  count = 0;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) flushed
{
}

@end
