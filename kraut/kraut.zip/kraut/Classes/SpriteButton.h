//
//  SpriteButton.h
//  kraut

#import "Button.h"

//------------------------------------------------------------------------------------------------------------------------
@interface SpriteButton : Button
//------------------------------------------------------------------------------------------------------------------------
{
  SpriteInfo    spriteinfo[3];
  float         spriteangle; 
  CGPoint       offset;
  CGPoint       fadeInOffset;
  CGPoint       fadeOutOffset;
  CGPoint       countOffset;
  float         countHeight;
  int           count;
  int           minCount;
  uint          countBackgroundColor;
}

@property (assign) int     count;
@property (assign) CGPoint fadeInOffset;
@property (assign) CGPoint fadeOutOffset;

- (id)    initWithDictionary:(NSDictionary*)dict parent:(MenuObject*)parent;
- (void)  onFrame:(double)delta;
- (void)  setColor:(uint)color forName:(NSString*)name;
- (void)  setColor:(uint)color forIndex:(int)spriteIndex;
- (void)  setSprite:(Sprite*)sprite;
- (void)  fadeIn:(float)value;
- (void)  fadeOut:(float)value;

@end
