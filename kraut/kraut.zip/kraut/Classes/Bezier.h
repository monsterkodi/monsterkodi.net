//
//  Bezier.h

//------------------------------------------------------------------------------------------------------------------------
@interface Bezier : NSObject 
//------------------------------------------------------------------------------------------------------------------------
{
  CGPoint pts[4];
  CGPoint vec[3];
}

+ (Bezier*)   bezierWithPoints:(CGPoint*)points;
+ (Bezier*)   from:(CGPoint)fromPoint over:(CGPoint)c1Point and:(CGPoint)c2Point to:(CGPoint)toPoint;

- (id)        initWithPoints:(CGPoint*)points;
- (CGPoint)   pointAtTime:(float)time;
- (void)      draw;

@end
