//
//  kriegAppDelegate.m

#import "Controller.h"
#import "Resources.h"
#import "Animation.h"
#import "Event.h"
#import "Sprite.h"
#import "Layers.h"
#import "Quad.h"
#import "Line.h"
#import "Text.h"
#import "GLView.h"
#import "Console.h"
#import "Board.h"
#import "Help.h"
#import "MainBoard.h"
#import "Ramp.h"
#import "Jump.h"
#import "Field.h"
#import "Stone.h"
#import "Menu.h"
#import "Sound.h"
#import "Timer.h"

#define DEBUG_HELP      0
#define DEBUG_AWARDS    0
#define DEBUG_CAMPAIGN  0
#define DEBUG_HIGHSCORE 0

//------------------------------------------------------------------------------------------------------------------------
@implementation Controller
//------------------------------------------------------------------------------------------------------------------------

@synthesize resources;
@synthesize animation;
@synthesize dragEvent;
@synthesize currentGame;
@synthesize game;
@synthesize help;
@synthesize menu;
@synthesize sound;
@synthesize orientation;
@synthesize active;
@synthesize intro;
@synthesize debug;

//------------------------------------------------------------------------------------------------------------------------
+ (void) initialize
{
  [[NSFileManager defaultManager] changeCurrentDirectoryPath:[[NSBundle mainBundle] resourcePath]];
    
  NSDictionary * defaultsDict = LoadPropertyList(@"DefaultsXML.plist");
  if (defaultsDict)
  {      
    [[NSUserDefaults standardUserDefaults] registerDefaults:defaultsDict];
    CFRelease(defaultsDict);
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) resetDefaults
{
  [NSUserDefaults  resetStandardUserDefaults];
  [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"highscores"];
  [[NSUserDefaults standardUserDefaults] synchronize];
}

//------------------------------------------------------------------------------------------------------------------------
- (id) init
{  
  if ((self = [super init]))
  {
    //NSLog(@"Controller::init");
    
    [[UIApplication sharedApplication] setDelegate:self];
    
    receivers = [[NSMutableDictionary dictionaryWithCapacity:8] retain];
    [receivers setValue:[NSMutableArray arrayWithCapacity:128] forKey:@"frame"];
    [receivers setValue:[NSMutableArray arrayWithCapacity:8]   forKey:@"button"];
    [receivers setValue:[NSMutableArray arrayWithCapacity:32]  forKey:@"down"];
    [receivers setValue:[NSMutableArray arrayWithCapacity:32]  forKey:@"move"];
    [receivers setValue:[NSMutableArray arrayWithCapacity:32]  forKey:@"up"];
    [receivers setValue:[NSMutableArray arrayWithCapacity:16]  forKey:@"drag"];
    [receivers setValue:[NSMutableArray arrayWithCapacity:16]  forKey:@"orientation"];
    [receivers setValue:[NSMutableArray arrayWithCapacity:4]   forKey:@"sleep"];
    [receivers setValue:[NSMutableArray arrayWithCapacity:4]   forKey:@"help"];

    timers = [[NSMutableArray arrayWithCapacity:128] retain];
    intro = TRUE;

    frameEvent = [[FrameEvent alloc] init];
    frameEvent.type = @"frame";
    
    [[UIApplication sharedApplication] setStatusBarHidden:YES];
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) applicationDidFinishLaunching:(UIApplication *)application 
{
  //NSLog(@"Controller::applicationDidFinishLaunching");
    
  srandom([[NSDate date] timeIntervalSince1970]);
  
  resources = [[Resources alloc] init];
  [resources loadSprites];
  [resources loadFont];
  
  animation = [[Animation alloc] init];
  game      = [[Game      alloc] init];
  menu      = [[MainMenu  alloc] init];
  sound     = [[Sound     alloc] init];
  help      = [[Help      alloc] init];
    
  [sound     setup];
  [game      setup];
  [menu      setup];
  [help      setup];
  
  [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
  
  /* [[NSNotificationCenter defaultCenter] addObserver:self
                                           selector:@selector(deviceOrientationDidChange:)
                                               name:@"UIDeviceOrientationDidChangeNotification"
                                             object:nil];  
   */
  
  [Quad initQuads];
  [glView createFramebuffer];
  [animation start];
  
  [Sound loop:@"song"];
    
  // debug:
  if (DEBUG_HELP)
  {
    intro = FALSE;
    [help displayHelp:@"arcade"];
  }
  else if (DEBUG_HIGHSCORE)
  {
    game.highscoreEntry = [game.highscores addEntryForScore:200];
    [[MainMenu instance] loadScreenWithName:@"Highscore!"];
    [[MainMenu instance] pushScreenWithName:@"Kraut"];
    [[MainMenu instance] pushScreenWithName:@"Highscore"];

    //[[MainMenu instance] fadeOut];
    //[game startArcade];
  }
  if (DEBUG_AWARDS)
  {
    intro = FALSE;
    [[MainMenu instance] loadScreenWithName:@"Awards"];
    [[MainMenu instance] pushScreenWithName:@"Kraut"];
  }  
  else if (DEBUG_CAMPAIGN)
  {
    intro = FALSE;
    [[MainMenu instance] loadScreenWithName:@"Campaign"];
    [[MainMenu instance] pushScreenWithName:@"Kraut"];
  }
  else
  {
    [menu startTitleStroke];
  }
}

//------------------------------------------------------------------------------------------------------------------------
-(void) dealloc
{
  //NSLog(@"Controller::dealloc");
  
  [[UIDevice currentDevice] endGeneratingDeviceOrientationNotifications];
  
  for (NSMutableArray * recs in [receivers allValues]) [recs removeAllObjects];
  
  [resources  release];
  [animation  release];
  [game       release];
  [menu       release];
  [sound      release];
  [help       release];

  [receivers  release];
  [timers     release];
  [frameEvent release];

  [glView destroyFramebuffer];
  [glView release];
	[window release];
  
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
+ (Controller*) instance
{
  Controller * controller = [[UIApplication sharedApplication] delegate];
  NSAssert(controller, @"no Controller instance?");
  return controller;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) deviceOrientationDidChange:(NSNotification*)notification
{
  UIDeviceOrientation o = [[UIDevice currentDevice] orientation];
  Orientation dir = -1;
  switch (o)
  {
    case UIDeviceOrientationPortrait:           dir = UP;     break;
    case UIDeviceOrientationLandscapeLeft:      dir = RIGHT;  break;
    case UIDeviceOrientationLandscapeRight:     dir = LEFT;   break;
    case UIDeviceOrientationPortraitUpsideDown: dir = DOWN;   break;
  };
  if (dir != -1) 
  {
    orientation = dir;
    //NSLog(@"orientation did change dir %d %@", dir, notification);
    OrientationEvent * event = [[[OrientationEvent alloc] init] autorelease];
    event.type = @"orientation";
    event.orientation = dir;
    [self sendEvent:event];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startFadeOutSong
{
  [Timer timerWithDuration:6.0f object:self tick:@selector(fadeOutSong:) finish:@selector(songFadedOut:)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeOutSong:(Timer*)timer
{
  float value = (1-timer.fraction);
  value *= value;
  [Sound changeSample:@"song" volume:value];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) songFadedOut:(Timer*)timer
{
  [Sound stop:@"song"];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) addTimer:(Timer*)timer
{
  [timers addObject:timer];
  NSLog(@"timers++ %d", [timers count]);
}

//------------------------------------------------------------------------------------------------------------------------
- (void) removeTimer:(Timer*)timer
{
  [timers removeObject:timer];
  NSLog(@"timers-- %d", [timers count]);
}

//------------------------------------------------------------------------------------------------------------------------
- (void) addEventReceiver:(id <EventReceiver>)receiver type:(NSString *)type
{
  //NSLog(@"add receiver %@ for event type '%@'", receiver, type);
  NSMutableArray * array = [receivers valueForKey:type];
  NSAssert1(array, @"[ERROR] no receiver array found for event type '%@'", type);
  if (array && ![array containsObject:receiver]) [array addObject:receiver];
  //NSLog(@"event receivers %d", [array count]);
}

//------------------------------------------------------------------------------------------------------------------------
- (void) removeEventReceiver:(id <EventReceiver>)receiver type:(NSString *)type
{
  //NSLog(@"remove receiver %@ for event type '%@'", receiver, type);
  NSMutableArray * array = [receivers valueForKey:type];
  if (array && [array containsObject:receiver]) [array removeObject:receiver];
  else if (!array) NSLog(@"[ERROR] no receiver array found for event type '%@'", type);
}

//------------------------------------------------------------------------------------------------------------------------
- (void) sendEvent:(Event*)event
{
  NSArray * list = [[receivers valueForKey:event.type] copy];
  for (id <EventReceiver> receiver in list)
  {
    if (![receiver onEvent:event]) break;
  }
  [list release];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) touchEvent:(UIEvent*)uiEvent view:(UIView*)view touches:(NSSet*)touches type:(NSString*)type
{
  BOOL isUpEvent = [type isEqualToString:@"up"];

  if (intro) 
  { 
    if (isUpEvent)
    { 
      if ([[[NSUserDefaults standardUserDefaults] valueForKey:@"firstRun"] boolValue])
      {
        [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"firstRun"];
        help.firstRun = YES;
        [menu fadeOutTitle];
        [help displayHelp:@"intro"];
      }
      else
      {
        [Sound play:@"fade in"];
        if ([game hasSaveGame]) [menu loadScreenWithName:@"Pause"];
        else [menu fadeIn];
      }
      intro = FALSE; 
      
      [Sound play:@"challenge open"];
      [self startFadeOutSong];
    } 
    return; 
  }
  
  TouchEvent * event = [[[TouchEvent alloc] init] autorelease];
  
  NSEnumerator * touchesEnumerator = [touches objectEnumerator];
  UITouch * touch = [touchesEnumerator nextObject];
    
  CGPoint eventPoint = [touch locationInView:view];
  CGPoint prevPoint  = [touch previousLocationInView:view];
    
  event.point     = CGPointMake(2*eventPoint.x/320.0f-1.0f, 3*(1.0f-eventPoint.y/480.0f)-1.5f);
  CGPoint dir     = CGVector(prevPoint, eventPoint); 
  dir.y           = -dir.y;
  
  //NSLog(@"type %@ %@ eventPoint %f %f prevPoint %f %f dir %f %f", lastTouchType, type, eventPoint.x, eventPoint.y, prevPoint.x, prevPoint.y, dir.x, dir.y);
  
  dir             = CGPointScale(dir, 1.0f/160.0f);
  
  if (isUpEvent && [lastTouchType isEqualToString:@"down"]) 
  { 
    dir.x = 0; 
    dir.y = 0; 
  }
  [lastTouchType release];
  lastTouchType = [type copy];
  
  event.type      = type;
  event.event     = uiEvent;
  event.direction = dir;
  event.delta     = CGPointLength(event.direction);
  event.finger    = [[uiEvent touchesForView:view] count];
  event.tapCount  = [touch tapCount];
  
  event.distanceDelta = 0;
  
  if (event.finger == 2)
  {
    UITouch * touch2 = [touchesEnumerator nextObject];
    CGPoint eventPoint2 = [touch2 locationInView:view];
    CGPoint prevPoint2  = [touch2 previousLocationInView:view];
    event.distanceDelta = CGPointLength(CGVector(eventPoint, eventPoint2))-CGPointLength(CGVector(prevPoint, prevPoint2));
  }

  if ([Game current] == [Help instance] || [self handleDragEvent:event]) [self sendEvent:event];
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) handleDragEvent:(TouchEvent*)event
{
  if (!dragEvent) return YES;
  if ([event.type isEqualToString:@"move"] && event.finger == 1)
  {
    dragEvent.type = @"dragMove";
    dragEvent.delta = CGVector(dragEvent.point, event.point);
    dragEvent.point = event.point;
    [dragEvent.source dragMoved:dragEvent];
    [dragEvent.object dragMoved:dragEvent];
    [dragEvent.target dragMoved:dragEvent];
    dragEvent.type = @"drag";
    [self sendEvent:dragEvent];
  }
  else if ([event.type isEqualToString:@"up"] && event.finger == 1)
  {
    dragEvent.delta = CGVector(dragEvent.point, event.point);
    dragEvent.point = event.point;
    if (dragEvent.target) [self endDrag];
    else                  [self cancelDrag];
    return NO; // don't send up events on end of drag event
  }
  return YES;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startDrag:(id <DragObject>)obj source:(id <DragObject>)source point:(CGPoint)point
{
  //NSLog(@"startDrag");
  dragEvent = [[DragEvent alloc] init];
  dragEvent.object = [((NSObject*)obj) retain];
  dragEvent.source = source;
  dragEvent.point = point;
  dragEvent.type = @"dragStart";
  [source dragStarted:dragEvent];
  [obj dragStarted:dragEvent];
  [self sendEvent:dragEvent];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) cancelDrag
{
  //NSLog(@"cancelDrag");
  dragEvent.type = @"dragCancel";
  [dragEvent.source dragCanceled:dragEvent];
  [dragEvent.object dragCanceled:dragEvent];
  [self sendEvent:dragEvent];
  [dragEvent.object release];
  [dragEvent release];
  dragEvent = nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) endDrag
{
  //NSLog(@"endDrag");
  dragEvent.type = @"dragEnd";
  [dragEvent.source dragEnded:dragEvent];
  [dragEvent.object dragEnded:dragEvent];
  [dragEvent.target dragEnded:dragEvent];
  [self sendEvent:dragEvent];
  [dragEvent.object release];  
  [dragEvent release];
  dragEvent = nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) applicationWillResignActive:(UIApplication *)application 
{
  [[NSUserDefaults standardUserDefaults] synchronize];
  NSLog(@"Controller::applicationWillResignActive");

  SleepEvent * event = [[SleepEvent alloc] init];
  event.type = @"sleep";
  event.wakeup = FALSE;
  [self sendEvent:event];
  [event release];
  
  [animation stop];
  active = FALSE;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) applicationDidBecomeActive:(UIApplication *)application 
{
  //NSLog(@"Controller::applicationDidBecomeActive");

  SleepEvent * event = [[SleepEvent alloc] init];
  event.type = @"sleep";
  event.wakeup = TRUE;
  [self sendEvent:event];
  [event release];

  active = TRUE;
  [animation start];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) applicationWillTerminate:(UIApplication *)application
{
  //NSLog(@"Controller::applicationWillTerminate");  
  [game saveGame];
  [[NSUserDefaults standardUserDefaults] synchronize];
  [animation stop];
  [sound shutdown];
  active = FALSE;
  [self release];
}

//------------------------------------------------------------------------------------------------------------------------
- (NSMutableArray*) frameReceivers
{
  return [receivers valueForKey:@"frame"];
}

//------------------------------------------------------------------------------------------------------------------------
-(void) drawFrame:(double)delta
{    
  frameEvent.delta = delta;
  [self sendEvent:frameEvent];

  [Timers onFrame:delta];
    
  [glView drawBegin];

  [Layers flush];
  [Quad   flushQuads];
  [Line   flushLines];
     
  [glView drawEnd];
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) debug
{
  return [[[NSUserDefaults standardUserDefaults] stringForKey:@"debug"] isEqualToString:@"on"];
}

@end
