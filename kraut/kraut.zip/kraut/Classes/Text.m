//
//  Text.m

#import "Text.h"
#import "Controller.h"
#import "Resources.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation NSString (TextDrawing)
//------------------------------------------------------------------------------------------------------------------------

- (void) drawAtPoint:(CGPoint)point height:(float)height
{
  [[Font instance] drawText:self atPoint:point height:height color:0xffffffff layer:_text_];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) drawAtPoint:(CGPoint)point height:(float)height alpha:(float)alpha
{
  uint color = 0xffffff | ((uint)(alpha*0xff)<<24);
  [[Font instance] drawText:self atPoint:point height:height color:color layer:_text_];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) drawAtPoint:(CGPoint)point height:(float)height color:(uint)color layer:(uint)_layer_
{
  [[Font instance] drawText:self atPoint:point height:height color:color layer:_layer_];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) drawAtCenter:(CGPoint)point height:(float)height color:(uint)color layer:(uint)_layer_
{
  Font * font = [Font instance];
  float textWidth = [font widthOfText:self height:height];
  [font drawText:self atPoint:POINT(point.x-textWidth/2, point.y-height/2) height:height color:color layer:_layer_];
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation Font
//------------------------------------------------------------------------------------------------------------------------

+ (Font*) instance
{
  return (Font*)[[Resources instance] sprite:@"font"];
}

//------------------------------------------------------------------------------------------------------------------------

- (id) initWithTextureId:(uint)tex_id
{
  float uv_[4]={0,0,1,1};
  if ((self = [super initWithTextureId:tex_id uv:uv_]))
  {
    layer = _text_;
    //characters  = @"ABCDEFGHIJKLMNOPQRSTUVWXYZÄÖÜ@0123456789?!ß\"()*/abcdefghijklmnopqrstuvwxyzäöü&,.:<>+-";    
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (float) widthOfText:(NSString*)text height:(float)height
{
  float width = 0.0f;
  for (uint ci = 0; ci < [text length]; ci++)
  {
    unichar c = [text characterAtIndex:ci];
    if (c == 223) c = 3;
    width += (CHAR[c][1]-CHAR[c][0]) * height * 0.025f;
  }
  return width;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) drawText:(NSString*)text atPoint:(CGPoint)point height:(float)height color:(GLuint)color layer:(uint)_layer_
{
  CGPoint p = point;

  sprite_vertex v;
  v.c = color;

  GLfloat us, ue, vb, vt;
  float x, y, yo, w, h;
  x = p.x;
    
  for (uint ci = 0; ci < [text length]; ci++)
  {
    unichar c = [text characterAtIndex:ci];
    
    if (c == 223) c = 3;
    
    yo = (CHAR[c][4]-2)/256.0f;
    y  = p.y - yo;
    h  = height + yo;
    w  = (CHAR[c][1]-CHAR[c][0]) * height * 0.025f;
        
    us = CHAR[c][0]/512.0f;
    ue = CHAR[c][1]/512.0f;
    
    vb =      (CHAR[c][2]-CHAR[c][3])/256.0f;
    vt = vb + (CHAR[c][3]+CHAR[c][4])/256.0f;

    v.x =      x; v.u = us;
    v.y =      y; v.v = vt; [self addVertex:&v layer:_layer_];
    v.x =  w + x; v.u = ue;
    v.y =      y; v.v = vt; [self addVertex:&v layer:_layer_];
    v.x =      x; v.u = us;
    v.y =  h + y; v.v = vb; [self addVertex:&v layer:_layer_];
    v.x =  w + x; v.u = ue;
    v.y =      y; v.v = vt; [self addVertex:&v layer:_layer_];
    v.x =      x; v.u = us;
    v.y =  h + y; v.v = vb; [self addVertex:&v layer:_layer_];
    v.x =  w + x; v.u = ue;
    v.y =  h + y; v.v = vb; [self addVertex:&v layer:_layer_];
    
    x += w;
  }
}

//------------------------------------------------------------------------------------------------------------------------

static uint COLORS[8] = 
{
0x0000ff,
0xff8800,
0x00ffff,
0xff0000,
0xff00ff,
0x00ff00,
0x888800,
0x008800,
};

- (void) colorText:(NSString*)text atPoint:(CGPoint)point height:(float)height layer:(uint)_layer_
{
  float textWidth = [self widthOfText:text height:height];
  
  CGPoint p = point;
  
  int colorIndex = [text characterAtIndex:0] % 8;
  
  sprite_vertex v;
  
  GLfloat us, ue, vb, vt;
  float x, y, yo, w, h;
  x = p.x - textWidth/2.0;
  
  for (uint ci = 0; ci < [text length]; ci++)
  {
    unichar c = [text characterAtIndex:ci];
    
    if (c == 223) c = 3;
    
    yo = (CHAR[c][4]-2)/256.0f;
    y  = p.y - yo;
    h  = height + yo;
    w  = (CHAR[c][1]-CHAR[c][0]) * height * 0.025f;
    
    us = CHAR[c][0]/512.0f;
    ue = CHAR[c][1]/512.0f;
    
    vb =      (CHAR[c][2]-CHAR[c][3])/256.0f;
    vt = vb + (CHAR[c][3]+CHAR[c][4])/256.0f;

    v.c = (COLORS[colorIndex] | (0xff<<24));

    v.x =      x; v.u = us;
    v.y =      y; v.v = vt; [self addVertex:&v layer:_layer_];
    v.x =  w + x; v.u = ue;
    v.y =      y; v.v = vt; [self addVertex:&v layer:_layer_];
    v.x =      x; v.u = us;
    v.y =  h + y; v.v = vb; [self addVertex:&v layer:_layer_];
    v.x =  w + x; v.u = ue;
    v.y =      y; v.v = vt; [self addVertex:&v layer:_layer_];
    v.x =      x; v.u = us;
    v.y =  h + y; v.v = vb; [self addVertex:&v layer:_layer_];
    v.x =  w + x; v.u = ue;
    v.y =  h + y; v.v = vb; [self addVertex:&v layer:_layer_];
    
    x += w;
    
    colorIndex = (colorIndex + c) % 8;
  }
}

uint CHAR[123][5] = { //@"ABCDEFGHIJKLMNOPQRSTUVWXYZÄÖÜ@0123456789?!ß\"()*/abcdefghijklmnopqrstuvwxyzäöü&,.:<>+-"
// x1, x2, y, heightup, heightdown
{  3, 32, 38, 38, 2 }, // 196 "Ä"
{  3, 32, 38, 38, 2 }, // 214 "Ö"
{  3, 32, 38, 38, 2 }, // 220 "Ü"
{332,361,141, 38, 12 }, // 223 "ß"
{  3, 32, 38, 38, 2 }, // 228 "ä"
{  3, 32, 38, 38, 2 }, // 246 "ö"
{  3, 32, 38, 38, 2 }, // 252 "ü"

{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},
{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},
{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},
{0,0,0,0,0},
{0,24,0,0,0}, // 32
{316,328,141, 38, 2 }, // 33 !
{365,385,141, 41, 0 }, // 34 "
{  0,  0,  0,  0, 0 },
{  0,  0,  0,  0, 0 },
{  0,  0,  0,  0, 0 },
{290,324,245, 37, 2 }, // 38 &
{365,375,141, 41, 0 }, // 39 '
{389,406,141, 41, 8 }, // 40 (
{409,426,141, 41, 8 }, // 41 )
{427,453,124, 27, 0 }, // 42 *
{428,455,247, 29, 0 }, // 43 +
{326,341,245, 28, 7 }, // 44 ,
{458,482,245, 28, 0 }, // 45 -
{344,357,245, 28, 0 }, // 46 .
{456,482,141, 41, 4 }, // 47 /
{  3, 31,141, 38, 2 }, // 48 0
{ 34, 52,141, 38, 2 }, // 49 1
{ 55, 81,141, 38, 2 }, // 50 2
{ 86,110,141, 38, 2 }, // 51 3
{114,142,141, 38, 2 }, // 52 4
{144,170,141, 38, 2 }, // 53 5
{171,196,141, 38, 2 }, // 54 6
{199,226,141, 38, 2 }, // 55 7
{228,255,141, 38, 2 }, // 56 8
{259,286,141, 38, 2 }, // 57 9
{362,375,245, 26, 0 }, // 58 :
{  0,  0,  0,  0, 0 },
{379,401,245, 28, 0 }, // 60 <
{  0,  0,  0,  0, 0 },
{405,427,245, 28, 0 }, // 62 >
{288,312,141, 38, 2 }, // 63 ?
{  3, 32, 38, 38, 2 }, // 64 @
{  3, 34, 38, 38, 2 }, // 65 A
{ 37, 64, 38, 38, 2 }, // 66 B
{ 67, 94, 38, 38, 2 }, // 67 C
{ 98,129, 38, 38, 2 }, // 68 D
{131,156, 38, 38, 2 }, // 69 E
{160,184, 38, 38, 2 }, // 70 F
{186,217, 38, 38, 2 }, // 71 G
{220,250, 38, 38, 2 }, // 72 H
{253,272, 38, 38, 2 }, // 73 I
{276,306, 38, 38, 2 }, // 74 J
{306,333, 38, 38, 2 }, // 75 K
{337,361, 38, 38, 2 }, // 76 L
{363,402, 38, 38, 2 }, // 77 M
{405,436, 38, 38, 2 }, // 78 N
{438,471, 38, 38, 2 }, // 79 O
{475,503, 38, 38, 2 }, // 80 P
{  3, 39, 90, 38, 2 }, // 81 Q
{ 41, 71, 90, 38, 2 }, // 82 R
{ 75,102, 90, 38, 2 }, // 83 S
{104,134, 90, 38, 2 }, // 84 T
{135,165, 90, 38, 2 }, // 85 U
{167,199, 90, 38, 2 }, // 86 V
{199,247, 90, 38, 2 }, // 87 W
{251,282, 90, 38, 2 }, // 88 X
{282,312, 90, 38, 2 }, // 89 Y
{316,348, 90, 38, 2 }, // 90 Z
{  0,  0,  0,  0, 0 },
{  0,  0,  0,  0, 0 },
{  0,  0,  0,  0, 0 },
{  0,  0,  0,  0, 0 },
{457,483,238, 38, 0 }, // 95 _
{  0,  0,  0,  0, 0 },
{  3, 29,193, 28, 2 }, // 97 a
{ 32, 58,193, 38, 2 }, // 98 b
{ 61, 85,193, 29, 2 }, // 99 c
{ 88,115,193, 38, 2 }, // 100 d
{118,144,193, 27, 2 }, // 101 e
{146,168,193, 38, 2 }, // 102 f
{168,194,193, 27,13 }, // 103 g
{198,224,193, 38, 2 }, // 104 h
{227,239,193, 38, 2 }, // 105 i
{239,257,193, 38,13 }, // 106 j
{262,287,193, 38, 2 }, // 107 k
{288,301,193, 38, 2 }, // 108 l
{305,340,193, 29, 2 }, // 109 m
{344,368,193, 29, 2 }, // 110 n
{370,396,193, 28, 2 }, // 111 o
{400,424,193, 28,13 }, // 112 p
{426,451,193, 28,13 }, // 113 q
{454,477,193, 29, 2 }, // 114 r
{477,500,193, 29, 2 }, // 115 s
{  4, 26,245, 38, 2 }, // 116 t
{ 27, 53,245, 28, 2 }, // 117 u
{ 52, 77,245, 28, 2 }, // 118 v
{ 78,114,245, 28, 2 }, // 119 w
{115,142,245, 28, 2 }, // 120 x
{144,172,245, 28,10 }, // 121 y
{172,200,245, 28, 2 }  // 122 z
};

@end
