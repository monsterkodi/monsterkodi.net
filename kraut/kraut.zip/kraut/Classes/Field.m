//
//  Field.m

#import "Controller.h"
#import "Resources.h"
#import "Sprite.h"
#import "Challenge.h"
#import "Game.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation Field
//------------------------------------------------------------------------------------------------------------------------

@synthesize rect;
@synthesize stone;
@synthesize board;
@synthesize highlight;
@synthesize marked;
@synthesize col;
@synthesize row;

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithRect:(CGRect)rect_
{
  if ((self = [super init]))
  {
    rect  = rect_;
    stone = nil;
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeIn
{
  sprite = [[Resources instance] sprite:@"field"];
  [[Controller instance] addEventReceiver:self type:@"frame"];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadedOut
{
  [[Controller instance] removeEventReceiver:self type:@"frame"];
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) isEmpty
{
  return (self.stone == nil);
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onFrame:(double)delta
{
  [sprite drawWithRect:CGRectScale(rect,(marked || highlight ? 1.0f : 0.2f)) color:FIELD_COLOR];
  if (highlight) [[Sprite withName:@"field_highlight"] drawWithRect:rect];
  if (marked)    
  {
    markerTime += delta; 
    float speed = 0.1f;
    float sz = 1.0f * (stone ? 1.50f : 1.2f);
    float a  = stone ? 0.65f : 0.5f;
    float s1 = (markerTime*speed)-(int)(markerTime*speed);             float a1 = a*sin(s1*M_PI);
    float s2 = (markerTime*speed+0.33f)-(int)(markerTime*speed+0.33f); float a2 = a*sin(s2*M_PI);
    float s3 = (markerTime*speed+0.66f)-(int)(markerTime*speed+0.66f); float a3 = a*sin(s3*M_PI);
    [[Sprite withName:@"field_marker"]    drawWithRect:CGRectScale(rect,s1*sz) alpha:a1];
    [[Sprite withName:@"field_marker"]    drawWithRect:CGRectScale(rect,s2*sz) alpha:a2];
    [[Sprite withName:@"field_marker"]    drawWithRect:CGRectScale(rect,s3*sz) alpha:a3];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) onEvent:(Event*)event
{
  if ([event isKindOfClass:[FrameEvent class]]) [self onFrame:((FrameEvent*)event).delta];
  return YES;
}

//------------------------------------------------------------------------------------------------------------------------
- (Pos) pos
{
  return POS(col, row);
}

//------------------------------------------------------------------------------------------------------------------------

- (CGPoint) center
{
  return CGPointMake(CGRectGetMidX(rect), CGRectGetMidY(rect));
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setRect:(CGRect)rect_
{
  rect = rect_;
  if (stone) [stone moveToRect:rect];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) moveTo:(CGPoint)point
{
  rect.origin = point;
  if (stone) [stone setCenter:CGRectCenter(rect)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) moveBy:(CGPoint)vector
{
  rect.origin = CGPointAdd(self.rect.origin, vector);
  if (stone) [stone moveBy:vector];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setStone:(Stone*)stone_
{
  if (stone && [board retainStones]) [stone release]; 
  stone = stone_;
  if (stone)
  {
    stone.field = self;
    
    if ([board retainStones]) [stone retain];
    
    if (marked)
    {
      [[Game current].challenge stoneSetOnMarkedField];
    }
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (NSString *) description
{
  return [NSString stringWithFormat:@"<Field: pos %@ empty %d %@>", self.pos, [self isEmpty], board];
}

@end
