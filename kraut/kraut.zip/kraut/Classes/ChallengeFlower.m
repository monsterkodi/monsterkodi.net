//
//  ChallengeFlower.m
//  kraut

#import "ChallengeFlower.h"
#import "MenuCampaign.h"
#import "Campaign.h"
#import "Challenge.h"
#import "Stone.h"
#import "Sprite.h"
#import "Sound.h"
#import "Line.h"
#import "Timer.h"
#import "Animation.h"
#import "Particle.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation ChallengeFlower
//------------------------------------------------------------------------------------------------------------------------

@synthesize selected;
@synthesize fadeValue;
@synthesize type;
@synthesize point;
@synthesize center;
@synthesize targetCenter;
@synthesize rect;
@synthesize screen;
@synthesize challenge;

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithChallenge:(Challenge*)challenge_
{
  if ((self = [super init]))
  {
    challenge = challenge_;
    
    open  = challenge.isOpen;
    prize = !challenge.isSolved; 
    alpha = (open ? 1.0f : 0.5f);
    prizeSize = alpha;
    
    type = challenge.stoneType;
    
    shadowSprite = [Sprite withName:@"shadow"];
    
    fadeValue = 1;
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (float) size
{
  return alpha * screen.scale * CHALLENGE_FLOWER_SIZE;
}

//------------------------------------------------------------------------------------------------------------------------
- (CGRect) rect
{
  float s = self.size;
  return CGRectMakeCenterSize(self.center, CGSizeMake(s, s));
}

//------------------------------------------------------------------------------------------------------------------------
- (CGPoint) center
{
  return CGPointAdd(screen.offset, CGPointScale(point, screen.scale));
}

//------------------------------------------------------------------------------------------------------------------------
- (CGPoint) targetCenter
{
  return CGPointAdd(screen.targetOffset, CGPointScale(point, screen.targetScale));
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startAnimateSelection
{
  animTimer = [Timer timerWithDuration:1.0f object:self tick:@selector(animateSelection:) finish:@selector(selectionAnimated:)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) animateSelection:(Timer*)timer
{
  alpha     = [Animation springValue:timer.fraction from:alpha to:(open ? 1.0f : 0.5f) ratio:0.2f overshot:0.2f];
  prizeSize = [Animation springValue:timer.fraction from:prizeSize to:(open ? 1.0f : 0.5f) ratio:0.2f overshot:0.2f];  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) selectionAnimated:(Timer*)timer
{
  alpha = prizeSize = (open ? 1.0f : 0.5f);
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startOpenAnimationWithDelay:(float)delay
{
  if (delay) animTimer = [Timer timerWithDuration:delay object:self tick:nil finish:@selector(startOpenAnimation:)];
  else [self startAnimateOpen];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startOpenAnimation:(Timer*)timer
{
  [self startAnimateOpen];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startAnimateOpen
{
  open = YES;
  animTimer = [Timer timerWithDuration:4.0f object:self tick:@selector(animateOpen:) finish:@selector(openAnimated:)];
  
  [Pollen forChallengeFlower:self speed:0.35f count:24];
  
  [Sound play:@"challenge open"];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) animateOpen:(Timer*)timer
{
  alpha     = [Animation springValue:timer.fraction from:0.25f to:1.0f ratio:0.3f overshot:0.2f];
  prizeSize = [Animation springValue:timer.fraction from:0.05f to:1.0f ratio:0.5f overshot:0.3f];
  
  if (timer.fraction > 0.33f && timer.fraction - timer.delta <= 0.33f)
  {
    [Pollen forChallengeFlower:self speed:0.75f count:16];
    //[Sound play:@"challenge kids"];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) openAnimated:(Timer*)timer
{
  open = YES;
  alpha = 1.0f;
  prizeSize = alpha;  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) hidePrize
{
  prize = NO;
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) containsPoint:(CGPoint)point_
{
  return CGRectContainsPoint(self.rect, point_);
}

//------------------------------------------------------------------------------------------------------------------------
- (float) prizeScale
{
  return prizeSize * screen.scale * 0.68f * CHALLENGE_FLOWER_SIZE;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) draw
{
  CGPoint p = self.center;
  float   s = self.size;
  float   a = fadeValue * clamp(alpha, 0, 1);
  
  [shadowSprite drawAtPoint:p size:CGSizeMake(2.4*s,2.4*s) alpha:fadeValue layer:_challenge_shadow_];
  if (selected) [[Sprite withName:@"extra_add"] drawAtPoint:p size:CGSizeMake(2*s,2*s) color:type.pollenColor layer:_challenge_glow_];
  [type.sprite drawAtPoint:p size:CGSizeMake(s,s) alpha:a layer:_challenge_];
  
  if (prize)
  {
    Sprite * prizeSprite = [challenge prizeSprite];
    float scale = [self prizeScale];
    float angle = open ? screen.wiggleAngle : 0;
    [prizeSprite drawAtPoint:p angle:angle size:CGSizeMake(scale, scale) color:ALPHASCALE(0xffffffff,a) layer:_prize_];
  }  
}

@end
