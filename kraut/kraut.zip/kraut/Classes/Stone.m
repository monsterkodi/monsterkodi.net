//
//  Stone.m

#import "Stone.h"
#import "Resources.h"
#import "Controller.h"
#import "Sprite.h"
#import "Line.h"
#import "Bezier.h"
#import "Particle.h"
#import "Timer.h"
#import "Tools.h"
#import "Game.h"
#import "Sound.h"
#import "Animation.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation StoneType
//------------------------------------------------------------------------------------------------------------------------

@synthesize sprite;
@synthesize name;
@synthesize pollenColor;
@synthesize buttonColor;
@synthesize scoreColor;

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithName:(NSString*)name_ image:(NSString*)image
{
  if ((self = [super init]))
  {
    name = name_;
    self.sprite = [[Resources instance] sprite:image];
  }
  
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
+ (StoneType*) random
{
  int index = RANDOMI([Game current].levelInfo.numFlowers);
  return [[Game current].levelInfo.flowers objectAtIndex:index];
}

//------------------------------------------------------------------------------------------------------------------------
+ (StoneType*) penaltyStoneWithIndex:(int)index
{
  return [StoneType withName:[NSString stringWithFormat:@"flower%02d", 11+index]];
}

//------------------------------------------------------------------------------------------------------------------------
+ (StoneType*) withName:(NSString*)name
{
  StoneType * stoneType = [[[Game instance] stoneTypes] valueForKey:name];
  if (!stoneType)
    NSAssert1(stoneType, @"no stone type with name '%@'?", name);
  return stoneType;
}

//------------------------------------------------------------------------------------------------------------------------
+ (void) randomSound
{
  static NSDate * lasttime = nil;
  if (!lasttime)
  { 
    [Sound play:[NSString stringWithFormat:@"fl%02d", RANDOMI(8)+7]];
    lasttime = [[Animation now] copy]; 
  }
  else if ([Animation timeSince:lasttime] > 0.05f) 
  { 
    [Sound play:[NSString stringWithFormat:@"fl%02d", RANDOMI(8)+7]]; 
    [lasttime release]; 
    lasttime = [[Animation now] copy]; 
  }  
}

//------------------------------------------------------------------------------------------------------------------------
- (NSString*) description
{
  return [NSString stringWithFormat:@"<StoneType '%@'>", name];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) playSound
{
  [Sound play:name];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) playSoundWithDelay:(float)delay
{
  if (delay > 0) [Timer timerWithDuration:delay object:self tick:nil finish:@selector(playSound:)];
  else           [self playSound:nil];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) playSound:(Timer*)timer
{
  [Sound play:name];
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation Stone
//------------------------------------------------------------------------------------------------------------------------

@synthesize rect;
@synthesize startRect;
@synthesize targetRect;
@synthesize type;
@synthesize field;
@synthesize alpha;
@synthesize scale;
@synthesize angle;
@synthesize above;

//------------------------------------------------------------------------------------------------------------------------
+ (Stone*) ofType:(StoneType*)type
{
  return [[Stone alloc] initWithType:type];
}

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithType:(StoneType*)type_
{
  if ((self = [super init]))
  {
    self.type  = type_;
    self.alpha = 1.0f;
    self.scale = 1.0f;
    self.angle = [Game current].board.angle;
    
    CGPoint startPos = [[Game current].ramp startPoint];
    rect = CGRectMake(startPos.x, startPos.y, 0.0f, 0.0f);    
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  //NSLog(@"stone dealloc %@", self);
  [moveTimer    stop];
  [explodeTimer stop];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) playSoundWithDelay:(float)delay
{
  [type playSoundWithDelay:delay];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) playSound
{
  [type playSound];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeIn
{
  [[Controller instance] addEventReceiver:self type:@"frame"];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadedOut
{
  [[Controller instance] removeEventReceiver:self type:@"frame"];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setRect:(CGRect)rect_
{
  rect = rect_;
  startRect  = rect;
  targetRect = rect;  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setCenter:(CGPoint)point
{
  self.rect = CGRectMakeCenterSize(point, targetRect.size);
}

//------------------------------------------------------------------------------------------------------------------------
- (void) moveBy:(CGPoint)vector
{
  CGPoint p = CGPointAdd(targetRect.origin, vector);
  [self moveToRect:CGRectMake(p.x, p.y, targetRect.size.width, targetRect.size.height)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) moveToRect:(CGRect)rect_
{
  //NSLog(@"moveToRect %@", self);
  startRect  = rect;
  targetRect = rect_;
  if (moveTimer) [moveTimer stop];
  moveTimer = [Timer timerWithDuration:[Game current].stoneMoveTime object:self tick:@selector(move:) finish:@selector(moved:)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setField:(Field*)field_
{
  field = field_;
  //NSLog(@"field %@", field);
  if (field) [self moveToRect:field.rect];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) penaltyMoveFromPoint:(CGPoint)startPoint toRect:(CGRect)toRect
{
  Bezier * bezier = [Bezier from:startPoint over:CGPointMake(1,startPoint.y) and:CGPointMake(1,toRect.origin.y) to:toRect.origin];
  float l = (1-startPoint.x) + abs(toRect.origin.y-startPoint.y) + (1-toRect.origin.x);
  rect.origin = startPoint;
  rect.size   = toRect.size;
  startRect   = rect;
  targetRect  = toRect;
  if (moveTimer) [moveTimer stop];
  moveTimer = [Timer timerWithDuration:l/2.0f object:self tick:@selector(penaltyMove:) finish:@selector(penaltyMoved:) info:bezier];
  [self fadeIn];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) penaltyMove:(Timer*)timer
{
  Bezier * bezier = (Bezier*)timer.info;
  float w, h, f;
  f = [timer fraction];

  CGPoint p = [bezier pointAtTime:timer.fraction];
  w = CGFade(startRect.size.width,  targetRect.size.width,  f); 
  h = CGFade(startRect.size.height, targetRect.size.height, f); 
  rect = CGRectMake(p.x, p.y, w, h);
  
  Orientation o = [Controller instance].orientation;
  
  angle -= (1-timer.fraction)*40*timer.delta;
  float finishfactor = 1.0f;
  [Particle withSprite:[Sprite withName:@"pollen"] 
              duration:2.0f-(1-finishfactor)
               atPoint:CGRectCenter(rect) 
                    to:CGPointMake(p.x+RANDOMF(0.4f)-0.2f, p.y+RANDOMF(0.4f)-0.2f) 
                 speed:CGPointMake(DIR[o][0]*RANDOMF(0.4f)*finishfactor,DIR[o][1]*RANDOMF(0.4f)*finishfactor) 
                 color:type.pollenColor];  
}  

//------------------------------------------------------------------------------------------------------------------------
- (void) penaltyMoved:(Timer*)timer
{
  moveTimer = nil;
  rect = targetRect;
  [[Game current].board penaltyStone:self arrivedAtPoint:CGRectCenter(rect)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) move:(Timer*)timer
{
  float x, y, w, h, f;
  f = timer.fraction;
  x = CGFade(startRect.origin.x,    targetRect.origin.x,    f); 
  y = CGFade(startRect.origin.y,    targetRect.origin.y,    f); 
  w = CGFade(startRect.size.width,  targetRect.size.width,  f); 
  h = CGFade(startRect.size.height, targetRect.size.height, f); 
  rect = CGRectMake(x, y, w, h);
}  

//------------------------------------------------------------------------------------------------------------------------
- (void) moved:(Timer*)timer
{
  moveTimer = nil;
  rect = targetRect;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) explode
{
  
  NSAssert(explodeTimer==nil, @"explode twice?");
  if (explodeTimer) [explodeTimer stop];
  explodeTimer = [Timer timerWithDuration:STONE_EXPLODE_TIME object:self tick:@selector(exploding:) finish:@selector(exploded:)];
  
  [[Game current] onStoneExploding];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) exploding:(Timer*)timer
{
  float s = 1.0f+sin(0.3*M_PI+timer.fraction*0.77*M_PI)-sin(0.3f*M_PI);
  self.scale = s;
  self.alpha = clamp(s, 0.0f, 1.0f);
  self.angle = 3*M_PI*timer.fraction*timer.fraction;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) exploded:(Timer*)timer
{
  if (moveTimer) { [moveTimer stop]; moveTimer = nil; }
  explodeTimer = nil;
  [[Controller instance] removeEventReceiver:self type:@"frame"];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) transform:(CGAffineTransform)trans
{
  rect.origin = CGPointApplyAffineTransform(rect.origin, trans);
  startRect = rect;
  targetRect = rect;
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) onEvent:(Event*)event
{
  if ([event isKindOfClass:[FrameEvent class]])
  {
    [self onFrame:((FrameEvent*)event).delta];
  }
  
  return YES;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onFrame:(double)delta
{
  Sprite * sprite = [type sprite];
  CGRect transRect = CGRectScale(rect, scale);
  uint _layer_ = above ? _finger_ : _stone_;
  if (angle)
  {
    CGAffineTransform rot = CGAffineTransformMakeRotation(angle);
    float w = transRect.size.width/2.0f;
    float h = transRect.size.height/2.0f;
    CGPoint center = CGRectCenter(transRect);
    CGPoint points[4] = { CGPointAdd(center, CGPointApplyAffineTransform(CGPointMake(-w,-h), rot)),
                          CGPointAdd(center, CGPointApplyAffineTransform(CGPointMake( w,-h), rot)),
                          CGPointAdd(center, CGPointApplyAffineTransform(CGPointMake(-w, h), rot)),
                          CGPointAdd(center, CGPointApplyAffineTransform(CGPointMake( w, h), rot)) };
    [sprite drawWithPoints:points alpha:alpha layer:_layer_];
  }
  else
  {
    [sprite drawWithRect:transRect alpha:alpha layer:_layer_];
  }
}

//------------------------------------------------------------------------------------------------------------------------
/*
- (NSString *) description
{
  return [NSString stringWithFormat:@"<Stone[%d]: type %@ field %@>", [self retainCount], type, field];
}*/

@end
