//
//  Letters.h

@class Sprite;

enum ALIGNMENT {
  ALIGN_CENTER,
  ALIGN_LEFT,
  ALIGN_RIGHT,
};

//------------------------------------------------------------------------------------------------------------------------
@interface Letter : NSObject
//------------------------------------------------------------------------------------------------------------------------
{
  unichar   character;
  CGPoint   points[4], uvrect[4], mpoints[4];
  CGRect    rect;
  CGPoint   offset;
  float     alpha;
  float     height;
  float     angle;
  float     baseangle;
  uint      color;
  uint      layer;
  Sprite  * sprite;
  float     spritealpha;
}

@property (assign)    unichar  character;
@property (readonly)  CGRect   rect;
@property (assign)    CGPoint  offset;
@property (assign)    float    alpha;
@property (assign)    float    height;
@property (assign)    float    angle;
@property (assign)    float    baseangle;
@property (assign)    uint     color;
@property (assign)    uint     layer;
@property (assign)    Sprite * sprite;
@property (assign)    float    spritealpha;

- (id)    initWithCharacter:(unichar)c color:(uint)color_;
- (void)  setRect:(CGRect)rect;
- (void)  setUVRect:(CGRect)uv;
- (void)  setNumber:(int)number;
- (float) getWidth;
- (void)  updatePoints;
- (void)  moveBy:(CGPoint)vector;
- (void)  moveTo:(CGPoint)point;
- (void)  draw;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface Letters : NSObject 
//------------------------------------------------------------------------------------------------------------------------
{
  NSMutableArray * letters;
  NSString       * string;
  Sprite         * sprite;
  uint             color;
  CGPoint          point;
  uint             layer;
  float            height;
  float            width;
  float            angle;
  float            alpha;
  float            randomangle;
  uint             alignment;
}

@property (readonly) NSArray  * letters;
@property (assign)   NSString * string;
@property (assign)   Sprite   * sprite;
@property (assign)   uint       color;
@property (assign)   float      randomangle;
@property (readonly) CGPoint    point;
@property (readonly) float      width;
@property (assign)   uint       layer;
@property (assign)   uint       alignment;
@property (assign)   float      height;
@property (assign)   float      angle;
@property (assign)   float      alpha;

- (void)  draw;
- (void)  fade:(float)value offset:(CGPoint)offset;
- (void)  setString:(NSString*)string withHeight:(float)height atPoint:(CGPoint)point;
- (void)  setString:(NSString*)string;
- (void)  moveTo:(CGPoint)point;
- (void)  moveBy:(CGPoint)vector;
- (void)  setHeight:(float)height;

@end
