//
//  Score.m

#import "Score.h"
#import "Sprite.h"
#import "Text.h"
#import "Letters.h"
#import "Timer.h"
#import "Game.h"
#import "Clock.h"
#import "Sound.h"
#import "Quad.h"
#import "Line.h"
#import "Awards.h"
#import "Resources.h"
#import "Controller.h"
#import "Animation.h"
//                                    4  5   6   7   8   9  10  11   12   13   14   15   16   17   18   19   20    21    22    23    24    25     26     27
static    int POINTS[28] = { 0,0,0,0, 1, 2,  6, 12, 20, 30, 50, 75, 100, 150, 200, 250, 300, 400, 500, 600, 750, 1000, 1500, 2000, 5000, 1000, 20000, 50000 };

//------------------------------------------------------------------------------------------------------------------------
@implementation Digit
//------------------------------------------------------------------------------------------------------------------------

@synthesize value;
@synthesize factor;
@synthesize index;
@synthesize rect;
@synthesize letter;
@synthesize color;
@synthesize dotmode;

//------------------------------------------------------------------------------------------------------------------------
- (id) init
{
  if ((self = [super init]))
  {
    sprite[0] = [Sprite withName:@"button"];
    sprite[1] = [Sprite withName:@"score"];
    sprite[2] = [Sprite withName:@"pollen"];
    
    letter = [[Letter alloc] initWithCharacter:48 color:RGBCOLOR(1,1,1)];
    letter.alpha = 0.8f;
    [letter setNumber:0];
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [letter release];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) draw
{
  [sprite[0] drawWithRect:rect layer:_shadow_];
  
  if (dotmode)
  {
    [sprite[1] drawWithRect:CGRectScale(rect, value/9.0f) color:color];
    [sprite[2] drawWithRect:CGRectScale(rect, value/9.0f) color:GLOW_COLOR];
  }
  else
  {
    letter.color = color;
    [letter draw];
    [sprite[2] drawWithRect:CGRectMove(rect, POINT(-rect.size.width/6.0f, rect.size.height/6.0f)) color:GLOW_LETTER];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setRect:(CGRect)rect_
{
  rect = rect_;
  [letter setRect:rect];
  [self updateLetter];
}  

//------------------------------------------------------------------------------------------------------------------------
- (void) setValue:(int)value_
{
  if (value != value_)
  {
    value = value_;
    
    [letter setNumber:value];
    if (!dotmode) [self updateLetter];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setDotmode:(BOOL)dotmode_
{
  dotmode = dotmode_;
  if (!dotmode) [self updateLetter];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) updateLetter
{
  letter.baseangle = [Game current].score.angle ? [Game current].score.angle*0.7f : DEG2RAD(RANDOMF(20.0f)-10.0f);
  [letter setRect:CGRectMakeCenterSize(CGRectCenter(rect), CGSizeMake([letter getWidth], rect.size.height))];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) moveBy:(CGPoint)vector
{
  self.rect = CGRectMove(rect, vector);
  [letter setRect:CGRectMakeCenterSize(CGRectCenter(rect), CGSizeMake([letter getWidth], rect.size.height))];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) moveTo:(CGPoint)point
{
  [self moveBy:CGVector(rect.origin, point)];
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation Score
//------------------------------------------------------------------------------------------------------------------------

@synthesize digits;
@synthesize value;
@synthesize pollen;
@synthesize maxfactor;
@synthesize digitsize;
@synthesize digitspace;
@synthesize rect;
@synthesize first;
@synthesize angle;
@synthesize color;

//------------------------------------------------------------------------------------------------------------------------
+ (int) scoreForNumStones:(int)stones { return POINTS[stones]; }
+ (Score*) instance { return [Game current].score; }
+ (CGPoint) pollenTarget { return CGRectCenter([Score instance].first.rect); }

//------------------------------------------------------------------------------------------------------------------------
- (id) init
{
  if ((self = [super init]))
  {
    digits = [[NSMutableArray arrayWithCapacity:10] retain];
    digitsize  = SCORE_HEIGHT;
    digitspace = PIXELSIZE;
    
    [self clear];
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [digits release];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) clear
{
  value     = 0;
  pollen    = 0;
  maxfactor = 0;
  [digits removeAllObjects];
  first = [self addDigit];  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setValue:(int)value_
{
  [self clear];
  value = value_;
  while (value >= 10*maxfactor) [self addDigit];
  [self setDigitValues];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setupWithDictionary:(NSDictionary*)dictionary
{
  [self setValue:[[dictionary valueForKey:@"value"] intValue]];
  pollen = value;
}

//------------------------------------------------------------------------------------------------------------------------
- (NSDictionary*) dictionary
{
  return [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d", pollen], @"value", nil];
}

//------------------------------------------------------------------------------------------------------------------------
- (Digit*) addDigit
{
  maxfactor = max(maxfactor * 10, 1);
  Digit * digit = [[Digit alloc] init];
  digit.index = [digits count];
  digit.factor = maxfactor;
  digit.color = color;
  digit.rect = CGRectMake(-1.0f-(digitsize+digitspace), 0.5f, digitsize, digitsize);
  digit.dotmode = [[NSUserDefaults standardUserDefaults] boolForKey:@"dotscore"];  
  [digits addObject:digit];
  [digit release];
  [self layout];
  [[Clock instance] digitAdded:digit.index];
  return digit;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) layout
{
  if ([Game current].lefty)
  {
    rect = CGRectMake(1-[digits count]*(digitsize+digitspace), 0.5f, [digits count]*(digitsize+digitspace), SCORE_HEIGHT); 
    for (Digit * d in digits) 
      [d moveTo:CGPointAdd(offset, POINT( 1 - (d.index+1) * (digitsize+digitspace), rect.origin.y))];
  }
  else
  {
    rect = CGRectMake(-1, 0.5f, [digits count]*(digitsize+digitspace), SCORE_HEIGHT); 
    for (Digit * d in digits)
      [d moveTo:CGPointAdd(offset, POINT(-1 + ([digits count]-1-d.index) * (digitsize+digitspace), rect.origin.y))];
  }
  [[Game current].clock layout];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) pollenArrivedWithScore:(int)score
{
  [Sound play:@"score"];
  while (value + score >= 10*maxfactor)
  {
    [self addDigit];
  }
  value += score;

  [self setDigitValues];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setDigitValues
{
  int rest = value;
  for (int i = [digits count]-1; i >= 0; i--)
  {
    Digit * digit = [digits objectAtIndex:i];
    digit.value = rest/digit.factor;
    rest -= digit.value * digit.factor;
  }  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) toggleDisplayMode
{
  BOOL dotmode = ![[NSUserDefaults standardUserDefaults] boolForKey:@"dotscore"];
  [[NSUserDefaults standardUserDefaults] setBool:dotmode forKey:@"dotscore"];
  for (Digit * digit in digits) digit.dotmode = dotmode;  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onFrame:(double)delta
{
  for (Digit * digit in digits) [digit draw];
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) onEvent:(Event*)event
{
  if ([event isKindOfClass:[FrameEvent class]]) [self onFrame:((FrameEvent*)event).delta];
  else if ([event isKindOfClass:[TouchEvent class]]) 
  {
    if ([event.type isEqualToString:@"up"] && CGRectContainsPoint(rect, ((TouchEvent*)event).point))
    {
      if ([[Awards instance] isPrizeWon:@"dotscore"])
        [self toggleDisplayMode];
    }
  }
  
  return YES;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) moveBy:(CGPoint)vector
{
  rect.origin = CGPointAdd(self.rect.origin, vector);
  for (Digit * digit in digits) [digit moveBy:vector];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) moveTo:(CGPoint)point
{
  [self moveBy:CGVector(rect.origin, point)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeIn
{
  [[Controller instance] addEventReceiver:self type:@"frame"];
  [[Controller instance] addEventReceiver:self type:@"up"];
  
  if (fadeTimer) [fadeTimer stop];
  fadeTimer = [Timer timerWithDuration:GAME_FADE_IN_TIME object:self tick:@selector(fadingIn:) finish:@selector(fadedIn:)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadingIn:(Timer*)timer
{
  offset = CGPointMake(0,(1-timer.fraction)*3);
  [self layout];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadedIn:(Timer*)timer
{
  offset = CGPointMake(0,0);
  [self layout];
  fadeTimer = nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadeOut
{
  if (fadeTimer) [fadeTimer stop];
  fadeTimer = [Timer timerWithDuration:GAME_FADE_OUT_TIME object:self tick:@selector(fadingOut:) finish:@selector(fadedOut:)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadingOut:(Timer*)timer
{
  offset = CGPointMake(0,-3*timer.fraction);
  [self layout];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadedOut:(Timer*)timer
{
  [[Controller instance] removeEventReceiver:self type:@"frame"];
  [[Controller instance] removeEventReceiver:self type:@"up"];
  [self layout];
  fadeTimer = nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setAngle:(float)angle_
{
  angle = angle_;
  for (Digit * digit in digits) [digit updateLetter]; 
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setColor:(uint)color_
{
  color = color_;
  for (Digit * digit in digits) digit.color = color; 
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation ScoreDisplay
//------------------------------------------------------------------------------------------------------------------------

+ (ScoreDisplay*) displayScore:(int)score atPoint:(CGPoint)point colors:(uint*)colors
{
  return [[ScoreDisplay alloc] initWithScore:score point:point colors:colors];
}

//------------------------------------------------------------------------------------------------------------------------

- (id) initWithScore:(int)score point:(CGPoint)point_ colors:(uint*)colors_
{
  if ((self = [super init]))
  {
    for (int i = 0; i < 3; i++) colors[i] = colors_[i];
    point  = point_;
    string = [[NSString stringWithFormat:@"%d", score] retain];
    letters = [[Letters alloc] init];
    letters.randomangle = 0;
    letters.sprite = [Sprite withName:@"shadow"];

    displayTimer = [Timer timerWithDuration:1.6f object:self tick:@selector(tick:) finish:@selector(finish:)];
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [displayTimer stop];
  [string  release];
  [letters release];
  [super   dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) tick:(Timer*)timer
{
  float alpha = 1.0f, height= 0.4f;
  uint _layer_ = _finger_;
  
  if (timer.fraction < 0.6f)
  {
    alpha = 1.0f;
    height = 0.4f * [Animation springValue:timer.fraction/0.6f from:0.0f to:1.0f ratio:0.3f overshot:0.2f];
  }
  else if (timer.fraction > 0.75f)
  {
    alpha = 1.0f-(timer.fraction-0.75f)*4;
    height = 0.2f+0.2f*alpha;
    _layer_ = _shadow_;
  }
  
  uint color = ((0xffffff&colors[(uint)(timer.fraction*12)%3]) | ((uint)(alpha*0xff)<<24));
  
  letters.angle = RAD2DEG([Game current].score.angle);
  [letters setString:string withHeight:height atPoint:point];
  letters.color = color;
  letters.alpha = alpha;
  letters.layer = _layer_;
  [letters draw];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) finish:(Timer*)timer
{
  displayTimer = nil;
  [self release];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) cancel
{
  [displayTimer stop];
  [self release];
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation PopupDisplay
//------------------------------------------------------------------------------------------------------------------------

+ (void) displayString:(NSString*)string atPoint:(CGPoint)point duration:(float)duration
{
  [[PopupDisplay alloc] initWithString:string point:point duration:duration];
}

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithString:(NSString*)string_ point:(CGPoint)point_ duration:(float)duration
{
  if ((self = [super init]))
  {
    point  = point_;
    string = [string_ copy];
    letters = [[Letters alloc] init];
    letters.randomangle = 0;
    letters.sprite = [Sprite withName:@"shadow"];
    
    [Timer timerWithDuration:duration object:self tick:@selector(tick:) finish:@selector(finish:)];
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [string  release];
  [letters release];
  [super   dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) tick:(Timer*)timer
{
  float alpha = 1.0f;
  uint _layer_ = _finger_;
  
  float textScale = 1.6f/[[Font instance] widthOfText:string height:0.4f];
  float height = textScale * 0.4f;
  
  if (timer.fraction < 0.6f)
  {
    alpha = 1.0f;
    height = textScale * 0.4f * [Animation springValue:timer.fraction/0.6f from:0.0f to:1.0f ratio:0.3f overshot:0.2f];
  }
  else if (timer.fraction > 0.75f)
  {
    alpha = 1.0f-(timer.fraction-0.75f)*4;
    height = textScale * (0.2f+0.2f*alpha);
    _layer_ = _shadow_;
  }
    
  letters.angle = RAD2DEG([Game current].score.angle);
  [letters setString:string withHeight:height atPoint:point];
  letters.alpha = alpha;
  letters.layer = _layer_;
  [letters draw];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) finish:(Timer*)timer
{
  [self release];
}

@end

