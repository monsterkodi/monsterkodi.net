//
//  Layers.h

#import <OpenGLES/EAGL.h>
#import <OpenGLES/ES1/gl.h>
#import <OpenGLES/ES1/glext.h>

@class Sprite;

//------------------------------------------------------------------------------------------------------------------------

enum LayerID {
  _field_,
  _score_,
  _glow_,
  _extra_,
  _stone_, 
  _challenge_shadow_ = _stone_ + 42,
  _challenge_glow_, // 47
  _challenge_,
  _prize_, // !!!
  _shadow_,
  _menu_, // 50
  _text_,
  _pollen_,
  _finger_,
  _hand_,
  _debug_,
  __layers__,
};

//------------------------------------------------------------------------------------------------------------------------

enum BatchTypes {
  BLEND_NONE  = 0x0000,
  BLEND_ALPHA = 0x0001,
  BLEND_ADD   = 0x0002,
  BLEND_MASK  = BLEND_ADD | BLEND_ALPHA,
  DATA_VERTEX = 0x0010,
  DATA_SPRITE = 0x0020,
};

//------------------------------------------------------------------------------------------------------------------------

typedef struct vertex_data {
  GLfloat x, y;
  GLuint  c;
} vertex;

//------------------------------------------------------------------------------------------------------------------------

typedef struct sprite_vertex_data {
  GLfloat x, y;
  GLuint  c;
  float u, v;
} sprite_vertex;

//------------------------------------------------------------------------------------------------------------------------

typedef struct batch_data 
{
  uint   type;  // blend mode and vertex data type

  void * verts; // vertex data buffer
  int    alloc; // number of allocated vertices
  int    count; // number of used vertices
  int    vsize; // size of vertex data in bytes 
  
  uint   texid;
  
} batch;

//------------------------------------------------------------------------------------------------------------------------

typedef struct layer_data 
{
  batch * batches;
  int     count; // number of used batches
  int     alloc; // number of allocated batches
} Layer;

//------------------------------------------------------------------------------------------------------------------------
@interface Layers : NSObject 
//------------------------------------------------------------------------------------------------------------------------
{
}

+ (batch*)  newBatchOfType:(uint)type layer:(uint)layer;
+ (batch*)  batchForLayer:(int)layerid texture:(uint)texid blend:(uint)blend;
+ (void)    drawSprite:(Sprite*)sprite withPoints:(CGPoint*)points color:(uint)color;
+ (void)    drawSprite:(Sprite*)sprite withPoints:(CGPoint*)points color:(uint)color layer:(uint)_layer_;
+ (void)    drawSprite:(Sprite*)sprite withPointArray:(float*)points color:(uint)color;
+ (void)    drawSprite:(Sprite*)sprite withPointArray:(float*)points color:(uint)color layer:(uint)_layer_;
+ (void)    addVertex:(sprite_vertex*)vert forSprite:(Sprite*)sprite layer:(uint)_layer_;
+ (void)    flush;

@end
