//
//  Tools.h

//------------------------------------------------------------------------------------------------------------------------
@interface NSDictionary (Tools)
//------------------------------------------------------------------------------------------------------------------------

- (float)     floatForKey:(NSString*)key default:(float)defaultValue;
- (int)       intForKey:(NSString*)key default:(int)defaultValue;
- (NSString*) stringForKey:(NSString*)key default:(NSString*)defaultValue;
- (void)      setDefaultFloat:(float)defaultValue forKey:(NSString*)key;

@end

//------------------------------------------------------------------------------------------------------------------------

#define RANDOMF(f)   ((f) * ((float)random() / (float)INT32_MAX))
#define RANDOMI(i)   ((int)((i)*RANDOMF(1.0f)))
#define RAD2DEG(a)   ((a)*180.0/M_PI)
#define DEG2RAD(a)   (M_PI*(a)/180.0)

#define GOLDEN_MEAN  1.61803399f

//------------------------------------------------------------------------------------------------------------------------

typedef enum Orientation_ {
  UP,
  RIGHT,
  DOWN,
  LEFT,
} Orientation;

//------------------------------------------------------------------------------------------------------------------------
// CGPoint tools
//------------------------------------------------------------------------------------------------------------------------

float             CGPointAngle      (CGPoint a);
float             CGAngle           (CGPoint a, CGPoint b); 
CG_INLINE float   CGFade            (float a, float b, float f) { return a + f * (b-a); }
CG_INLINE float   CGAngleFade       (float a, float b, float f) { while (abs(a-b) > 180) { if (a < b) a += 360; else a -= 360; } return a + f * (b-a); }

CG_INLINE CGPoint CGPointMakeArray  (float a[])               { return CGPointMake(a[0], a[1]); }
CG_INLINE CGPoint CGPointNeg        (CGPoint a)               { return CGPointMake(-a.x,-a.y); }
CG_INLINE CGPoint CGPointAdd        (CGPoint a, CGPoint b)    { return CGPointMake(a.x+b.x, a.y+b.y); }
CG_INLINE CGPoint CGPointSub        (CGPoint a, CGPoint b)    { return CGPointMake(a.x-b.x, a.y-b.y); }
CG_INLINE CGPoint CGPointMul        (CGPoint a, CGPoint b)    { return CGPointMake(a.x*b.x, a.y*b.y); }
CG_INLINE CGPoint CGPointScale      (CGPoint a, float s)      { return CGPointMake(a.x*s, a.y*s); } 
CG_INLINE CGPoint CGVector          (CGPoint a, CGPoint b)    { return CGPointSub(b, a); }
CG_INLINE float   CGPointLength     (CGPoint a)               { return sqrt(a.x*a.x + a.y*a.y); }
CG_INLINE CGPoint CGVectorNorm      (CGPoint v)               { return CGPointScale(v, 1.0f/CGPointLength(v)); }
CG_INLINE CGPoint CGVectorRotate    (CGPoint v, float a)      { float cosa = cos(DEG2RAD(a)); float sina = sin(DEG2RAD(a)); return CGPointMake(cosa*v.x - sina*v.y, sina*v.x + cosa*v.y); }
CG_INLINE CGPoint CGPointMakeAngle  (float a)                 { return CGVectorRotate(CGPointMake(0,1), a); }
CG_INLINE CGPoint CGPointFade       (CGPoint a, CGPoint b, float f) { return CGPointAdd(a, CGPointScale(CGVector(a,b), f)); }
CG_INLINE CGPoint CGVectorFade      (CGPoint a, CGPoint b, float f) { return CGPointScale(CGVectorNorm(CGVectorRotate(a, CGAngle(a,b) * f)), CGFade(CGPointLength(a), CGPointLength(b), f)); }
CG_INLINE CGPoint CGPointFromSize   (CGSize size)             { return CGPointMake(size.width, size.height); }
CG_INLINE CGPoint CGSizeCenter      (CGSize size)             { return CGPointMake(size.width/2.0f, size.height/2.0f); }
CG_INLINE CGRect  CGRectMakeArray   (float a[])               { return CGRectMake(a[0], a[1], a[2], a[3]); }
CG_INLINE CGRect  CGRectMakeCenterSize (CGPoint c, CGSize s)  { return CGRectMake(c.x-s.width/2, c.y-s.height/2, s.width, s.height); }
CG_INLINE CGPoint CGRectCenter      (CGRect rect)             { return CGPointAdd(rect.origin,CGSizeCenter(rect.size)); }
CG_INLINE CGRect  CGRectScale       (CGRect rect, float s)    { float  w=rect.size.width*s, h=rect.size.height*s; CGPoint c=CGRectCenter(rect); 
                                                                return CGRectMake(c.x-w/2.0f, c.y-h/2.0f, w, h); }
CG_INLINE CGRect  CGRectMove        (CGRect rect, CGPoint v)  { return CGRectMake(rect.origin.x+v.x,rect.origin.y+v.y,rect.size.width,rect.size.height); }

CG_INLINE float   absf(float a)         {return (a < 0) ? -a : a; }
CG_INLINE float   min(float a, float b) {return (a  < b) ? a : b; }
CG_INLINE float   max(float a, float b) {return (a >= b) ? a : b; }
CG_INLINE float   clamp(float value, float v1, float v2) { return max(min(v1,v2),min(max(v1,v2),value)); }

CG_INLINE int     mini(int a, int b) {return (a  < b) ? a : b; }
CG_INLINE int     maxi(int a, int b) {return (a >= b) ? a : b; }
CG_INLINE int     clampi(int value, int v1, int v2) { return max(min(v1,v2),min(max(v1,v2),value)); }

id LoadPropertyList(NSString * path);

//------------------------------------------------------------------------------------------------------------------------
@interface Posn : NSObject
//------------------------------------------------------------------------------------------------------------------------
{
  int x, y;
};

@property (assign) int x;
@property (assign) int y;

typedef Posn* Pos;

+ (Pos) x:(int)x y:(int)y;
- (Pos) add:(Pos)p;
- (Pos) sum:(Pos)p;

@end

#define PIXELSIZE 0.00625f

Pos POS(int x, int y);
#define POINT(x,y)  CGPointMake((x),(y))
#define VECTOR(x,y) CGPointMake((x),(y))

#define GLCOLOR(c)          ((c&0xff00ff00)|((c&0x00ff0000)>>16)|((c&0x000000ff)<<16))
#define RGBCOLOR(r,g,b)     (0xff000000|(((uint)(b*0xff))<<16)|(((uint)(g*0xff))<<8)|((uint)(r*0xff)))
#define RGBACOLOR(r,g,b,a)  ((((uint)(a*0xff))<<24)|(((uint)(b*0xff))<<16)|(((uint)(g*0xff))<<8)|((uint)(r*0xff)))
#define RGBSCALE(c,s)       ((c&0xff000000) | (((uint)(((c&0xff0000)>>16)*s))<<16) | (((uint)(((c&0xff00)>>8)*s))<<8) | ((uint)((c&0xff)*s)))
#define ALPHASCALE(c,s)     ((((uint)(((c&0xff000000)>>24)*s))<<24)|(c&0xffffff))

