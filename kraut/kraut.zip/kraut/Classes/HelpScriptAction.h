//
//  HelpScriptAction.h
//  kraut

@class Timer;
@class MenuText;
@class HelpScript;
@class Sprite;
@class Bezier;
@class AnimBezier;
@class AnimBezierStatus;

//------------------------------------------------------------------------------------------------------------------------
@interface HelpScriptAction : NSObject 
//------------------------------------------------------------------------------------------------------------------------
{
  HelpScript  * script;
  Timer       * actionTimer;
  float         delay;
  float         fadeValue;
  float         fadeInTime;
  float         fadeOutTime;
  
  NSDictionary * initDict;
}

@property (assign) HelpScript * script;

+ (HelpScriptAction*) withDict:(NSDictionary*)dict;

- (id)    initWithDictionary:(NSDictionary*)dict;
- (void)  delayAction:(Timer*)timer;
- (void)  delayFinished:(Timer*)timer;
- (void)  fadeIn:(Timer*)timer;
- (void)  fadedIn:(Timer*)timer;
- (void)  fadeOut:(Timer*)timer;
- (void)  fadedOut:(Timer*)timer;
- (void)  startAction;
- (void)  play;
- (void)  stop;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface HelpScriptKeyAction : HelpScriptAction
//------------------------------------------------------------------------------------------------------------------------
{
  NSString * key;
}

- (void) startAction;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface HelpScriptSetupAction : HelpScriptAction
//------------------------------------------------------------------------------------------------------------------------
{
  NSArray * ramp;
  NSArray * board;
  id bees;
  id bugs;
  id buts;
  id score;
}

- (void) startAction;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface HelpScriptTextAction : HelpScriptAction 
//------------------------------------------------------------------------------------------------------------------------
{
  MenuText * text;
}

- (id)    initWithDictionary:(NSDictionary*)dict;
- (void)  dealloc;
- (void)  startAction;
- (void)  fadeIn:(Timer*)timer;
- (void)  display:(Timer*)timer;
- (void)  fadeOut:(Timer*)timer;

@end
