//
//  Campaign.m
//  kraut

#import "Campaign.h"
#import "Challenge.h"
#import "Game.h"
#import "Tools.h"
#import "Awards.h"

/*
ring 0 count 1
ring 1 count 6
ring 2 count 11
ring 3 count 18
ring 4 count 24
ring 5 count 30
challenges 90
*/

//------------------------------------------------------------------------------------------------------------------------
@implementation Campaign
//------------------------------------------------------------------------------------------------------------------------

@synthesize challenges;
@synthesize currentChallenge;

@synthesize openedChallenges;
@synthesize solvedChallenge;

@synthesize info;

//------------------------------------------------------------------------------------------------------------------------
+ (Campaign*) instance { return [Game instance].campaign; }
+ (Challenge*) challengeWithName:(NSString*)name { return [[Campaign instance] challengeWithName:name]; }

//------------------------------------------------------------------------------------------------------------------------
- (id) init
{  
  if ((self = [super init]))
  {
    challenges = [[NSMutableArray arrayWithCapacity:64] retain];
    ringChallenges = [[NSMutableArray arrayWithCapacity:CAMPAIGN_RINGS] retain];
    openedChallenges = [[NSMutableArray arrayWithCapacity:4] retain];
  }
    
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [info release];
  [ringChallenges release];
  [challenges release];
  [openedChallenges release];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setup
{
  NSDictionary * campaignData = LoadPropertyList(@"CampaignXML.plist");
  info = [[NSDictionary dictionaryWithDictionary:[campaignData valueForKey:@"info"]] retain];
  NSArray * challengeRingArrays = [campaignData valueForKey:@"rings"];
  
  //int i = 0;
  
  for (NSArray * ringArray in challengeRingArrays)
  {
    [ringChallenges addObject:[NSMutableArray arrayWithCapacity:1]];
    for (NSDictionary * challengeDict in ringArray)
    {
      Challenge * challenge = [[Challenge alloc] initWithDictionary:challengeDict];
      [challenge setRing:[ringChallenges count]-1 index:[[ringChallenges lastObject] count]];
      [challenges addObject:challenge];
      [[ringChallenges lastObject] addObject:challenge];
      [challenge release];
      
      Awards * awards = [Awards instance];
      [awards increaseTotalForPrize:challenge.prize];
      if ([challenge.prize hasPrefix:@"prize"])
      {
        if (challenge.status == SOLVED)
          [awards increaseCountForPrize:challenge.prize];
      }
    }
    
    //NSLog(@"ring %d count %d", i++, [[ringChallenges lastObject] count]);
  }
  CFRelease(campaignData);  

  //NSLog(@"challenges %d", [challenges count]);

  [self connectSiblings];
  
  currentChallenge = [Campaign challengeWithName:[[NSUserDefaults standardUserDefaults] valueForKey:@"currentChallenge"]];
}

//------------------------------------------------------------------------------------------------------------------------
- (NSDictionary*) solvedChallengesCounts
{
  NSMutableDictionary * dict = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                [NSNumber numberWithInt:0], @"open",
                                [NSNumber numberWithInt:0], @"bee",
                                [NSNumber numberWithInt:0], @"bug",
                                [NSNumber numberWithInt:0], @"pollen",
                                [NSNumber numberWithInt:0], @"pattern",
                                [NSNumber numberWithInt:0], @"puzzle",
                                [NSNumber numberWithInt:0], @"bestmove",
                                nil];
  
  for (Challenge * challenge in challenges)
  {
    if (challenge.isOpen) 
      [dict setValue:[NSNumber numberWithInt:[[dict valueForKey:@"open"] intValue]+1] forKey:@"open"];
    if (challenge.isSolved)
      [dict setValue:[NSNumber numberWithInt:[[dict valueForKey:challenge.type] intValue]+1] forKey:challenge.type];
  }
  //NSLog(@"solved challenges dict %@", dict);
  return dict;
}

//------------------------------------------------------------------------------------------------------------------------
- (Challenge*) challengeWithName:(NSString*)name
{
  if (name)
  {
    for (Challenge * challenge in challenges)
      if ([challenge.name isEqualToString:name]) return challenge;
  }
  return nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setCurrentChallenge:(Challenge*)challenge
{
  currentChallenge = challenge;
  [[NSUserDefaults standardUserDefaults] setValue:currentChallenge.name forKey:@"currentChallenge"];
}

//------------------------------------------------------------------------------------------------------------------------
- (float) angleFromChallenge:(Challenge*)c1 toChallenge:(Challenge*)c2
{
  float angleDiff = c2.angle - c1.angle;
  if (abs(angleDiff) > 180) angleDiff = (angleDiff > 0) ? angleDiff - 360 : angleDiff + 360;
  return angleDiff;
}

//------------------------------------------------------------------------------------------------------------------------
- (Challenge*) nextChallenge:(Challenge*)challenge
{
  for (Challenge * c in [ringChallenges objectAtIndex:challenge.ring])
  {
    float angleDiff = [self angleFromChallenge:challenge toChallenge:c];
    if (angleDiff > 0 && angleDiff < 1.1f*angles[challenge.ring]) return c;
  }
  return nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (Challenge*) prevChallenge:(Challenge*)challenge
{
  for (Challenge * c in [ringChallenges objectAtIndex:challenge.ring])
  {
    float angleDiff = [self angleFromChallenge:challenge toChallenge:c];
    if (angleDiff < 0 && abs(angleDiff) < 1.1f*angles[challenge.ring]) return c;
  }
  return nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (NSArray*) nearChallengesOnNextRing:(Challenge*)challenge
{
  if (challenge.ring == 0) return [ringChallenges objectAtIndex:1];
  
  NSMutableArray * result = [NSMutableArray arrayWithCapacity:3];
  int ring = challenge.ring+1;
  if (ring < CAMPAIGN_RINGS)
  {
    for (Challenge * c in [ringChallenges objectAtIndex:ring])
    {
      float angleDiff = [self angleFromChallenge:challenge toChallenge:c];
      if (abs(angleDiff) <= 1.1f*angles[ring]) [result addObject:c];
    }
  }
  return result;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) connectSiblings
{
  for (int i = 0; i < CAMPAIGN_RINGS; i++) angles[i] = 360.0f/[[ringChallenges objectAtIndex:i] count];
  
  for (NSArray * ring in ringChallenges)
  {
    float angle = 0;
    for (Challenge * challenge in ring)
    {
      challenge.angle = angle;
      angle += angles[challenge.ring];
    }
  }
  
  for (Challenge * challenge in challenges)
  {
    Challenge * prevOnRing = [self prevChallenge:challenge];
    if (prevOnRing) [challenge.siblings addObject:prevOnRing];
    
    Challenge * nextOnRing = [self nextChallenge:challenge];
    if (nextOnRing) [challenge.siblings addObject:nextOnRing];
      
    for (Challenge * near in [self nearChallengesOnNextRing:challenge])
      [challenge.siblings addObject:near];
  }
  
  for (Challenge * challenge in challenges)
    if (challenge.isPassed)
      for (Challenge * c in challenge.siblings) 
        if (c.status == LOCKED) c.status = OPEN;
}


@end
