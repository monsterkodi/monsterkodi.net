//
//  EAGLView.m

#import <QuartzCore/QuartzCore.h>
#import <OpenGLES/EAGLDrawable.h>

#import "GLView.h"
#import "Controller.h"
#import "Console.h"

#define USE_DEPTH_BUFFER 0

//------------------------------------------------------------------------------------------------------------------------
@implementation GLView
//------------------------------------------------------------------------------------------------------------------------

@synthesize context;

//------------------------------------------------------------------------------------------------------------------------

+ (Class) layerClass { return [CAEAGLLayer class]; }

//------------------------------------------------------------------------------------------------------------------------

- (id) initWithCoder:(NSCoder*) coder 
{
  //NSLog(@"GLView::initWithCoder");
  
  viewFramebuffer = 0;
  viewRenderbuffer = 0;
  depthRenderbuffer = 0;
  
	if ((self = [super initWithCoder:coder])) 
  {
		CAEAGLLayer *eaglLayer = (CAEAGLLayer *)self.layer;
		
		eaglLayer.opaque = YES;
		eaglLayer.drawableProperties = [NSDictionary dictionaryWithObjectsAndKeys:
                                    [NSNumber numberWithBool:NO],  
                                    kEAGLDrawablePropertyRetainedBacking, 
                                    kEAGLColorFormatRGBA8, 
                                    kEAGLDrawablePropertyColorFormat, nil];
		
		context = [[EAGLContext alloc] initWithAPI:kEAGLRenderingAPIOpenGLES1];
		
		if (!context || ![EAGLContext setCurrentContext:context]) 
    {
			[self release];
			return nil;
		}
    
    self.multipleTouchEnabled = YES;    
  }
  
	return self;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) dealloc 
{	
  [self destroyFramebuffer];
  
	if ([EAGLContext currentContext] == context) [EAGLContext setCurrentContext:nil];
	
	[context release];
	[super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------

- (void) drawBegin
{			
	[EAGLContext setCurrentContext:context];

  glBindFramebufferOES(GL_FRAMEBUFFER_OES, viewFramebuffer);
	glViewport(0, 0, backingWidth, backingHeight);

  glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrthof(-1.0f, 1.0f, -1.5f, 1.5f, -1.0f, 1.0f);
	glMatrixMode(GL_MODELVIEW);

  /*
  float angle = 0.5f;
  glRotatef(angle, 0.0f, 0.0f, 1.0f);
  */
  
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
  //glClearColor(1.0f, 1.0f, 1.0f, 1.0f);

	glClear(GL_COLOR_BUFFER_BIT);
  
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);    
}

//------------------------------------------------------------------------------------------------------------------------

- (void) drawEnd
{
	glBindRenderbufferOES(GL_RENDERBUFFER_OES, viewRenderbuffer);
	[context presentRenderbuffer:GL_RENDERBUFFER_OES];
}

//------------------------------------------------------------------------------------------------------------------------

- (BOOL) createFramebuffer
{	
	glGenFramebuffersOES(1, &viewFramebuffer);
	glGenRenderbuffersOES(1, &viewRenderbuffer);
	
	glBindFramebufferOES(GL_FRAMEBUFFER_OES, viewFramebuffer);
	glBindRenderbufferOES(GL_RENDERBUFFER_OES, viewRenderbuffer);
	[context renderbufferStorage:GL_RENDERBUFFER_OES fromDrawable:(CAEAGLLayer*)self.layer];
	glFramebufferRenderbufferOES(GL_FRAMEBUFFER_OES, GL_COLOR_ATTACHMENT0_OES, GL_RENDERBUFFER_OES, viewRenderbuffer);
	
	glGetRenderbufferParameterivOES(GL_RENDERBUFFER_OES, GL_RENDERBUFFER_WIDTH_OES, &backingWidth);
	glGetRenderbufferParameterivOES(GL_RENDERBUFFER_OES, GL_RENDERBUFFER_HEIGHT_OES, &backingHeight);
	
	if (USE_DEPTH_BUFFER) 
  {
		glGenRenderbuffersOES(1, &depthRenderbuffer);
		glBindRenderbufferOES(GL_RENDERBUFFER_OES, depthRenderbuffer);
		glRenderbufferStorageOES(GL_RENDERBUFFER_OES, GL_DEPTH_COMPONENT16_OES, backingWidth, backingHeight);
		glFramebufferRenderbufferOES(GL_FRAMEBUFFER_OES, GL_DEPTH_ATTACHMENT_OES, GL_RENDERBUFFER_OES, depthRenderbuffer);
	}

	if (glCheckFramebufferStatusOES(GL_FRAMEBUFFER_OES) != GL_FRAMEBUFFER_COMPLETE_OES) 
  {
		NSLog(@"failed to make complete framebuffer object %x", glCheckFramebufferStatusOES(GL_FRAMEBUFFER_OES));
		return NO;
	}
  	
	return YES;
}

//------------------------------------------------------------------------------------------------------------------------

- (void) destroyFramebuffer 
{	
  [EAGLContext setCurrentContext:context];
  if (viewFramebuffer) glDeleteFramebuffersOES(1, &viewFramebuffer);
	viewFramebuffer = 0;
	if (viewRenderbuffer) glDeleteRenderbuffersOES(1, &viewRenderbuffer);
	viewRenderbuffer = 0;
	if (depthRenderbuffer) glDeleteRenderbuffersOES(1, &depthRenderbuffer);
  depthRenderbuffer = 0;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) touchesBegan:(NSSet*)touchesSet withEvent:(UIEvent*)event 
{
  [[Controller instance] touchEvent:event view:self touches:touchesSet type:@"down"];  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) touchesMoved:(NSSet*)touchesSet withEvent:(UIEvent*)event
{
  [[Controller instance] touchEvent:event view:self touches:touchesSet type:@"move"];  
}  

//------------------------------------------------------------------------------------------------------------------------
- (void) touchesEnded:(NSSet*)touchesSet withEvent:(UIEvent*)event
{
  [[Controller instance] touchEvent:event view:self touches:touchesSet type:@"up"];  
}

@end
