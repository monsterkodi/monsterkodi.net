//
//  kriegAppDelegate.h

#import <UIKit/UIKit.h>
#import "Event.h"
#import "Tools.h"

@class GLView;
@class Resources;
@class Animation;
@class MainMenu;
@class Game;
@class Help;
@class Sound;
@class Layers;
@class Timer;

//------------------------------------------------------------------------------------------------------------------------
@interface Controller : NSObject <UIApplicationDelegate> 
//------------------------------------------------------------------------------------------------------------------------
{
	IBOutlet UIWindow * window;
	IBOutlet GLView   * glView;
  
  Animation * animation;
  Resources * resources;
  
  Game      * game;
  Help      * help;
  Game      * currentGame;
  MainMenu  * menu;
  Sound     * sound;
  
  BOOL        active;
  BOOL        intro;
  Orientation orientation;
  NSString  * lastTouchType;
  
  NSMutableDictionary * receivers;
  NSMutableArray      * timers;
  
  FrameEvent  * frameEvent;
  DragEvent   * dragEvent;
}

@property (readonly) Resources    * resources;
@property (readonly) Animation    * animation;
@property (readonly) Game         * game;
@property (assign)   Game         * currentGame;
@property (readonly) Help         * help;
@property (readonly) Sound        * sound;
@property (readonly) MainMenu     * menu;
@property (readonly) DragEvent    * dragEvent;
@property (readonly) Orientation    orientation;
@property (readonly) BOOL           active;
@property (readonly) BOOL           intro;
@property (readonly) BOOL           debug;

+ (Controller*) instance;

- (id)    init;
- (void)  dealloc;
- (void)  drawFrame:(double)delta;
- (void)  resetDefaults;

- (void)  sendEvent:(Event*)event;
- (void)  addEventReceiver:(id <EventReceiver>)receiver type:(NSString*)type;
- (void)  removeEventReceiver:(id <EventReceiver>)receiver type:(NSString*)type;

- (void)  addTimer:(Timer*)timer;
- (void)  removeTimer:(Timer*)timer;
- (NSMutableArray*) frameReceivers;

- (void)  touchEvent:(UIEvent*)uiEvent view:(UIView*)view touches:(NSSet*)touches type:(NSString*)type;
- (BOOL)  handleDragEvent:(TouchEvent*)event;
- (void)  startDrag:(id <DragObject>)object source:(id <DragObject>)source point:(CGPoint)point;
- (void)  cancelDrag;
- (void)  endDrag;

@end

