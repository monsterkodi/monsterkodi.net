
#import "MainBoard.h"
#import "Ramp.h"
#import "Jump.h"
#import "Level.h"
#import "Score.h"
#import "Clock.h"
#import "Field.h"
#import "Stone.h"
#import "Block.h"
#import "Tools.h"
#import "Menu.h"
#import "Extras.h"
#import "Highscores.h"

@class ExtraButton;
@class Campaign;
@class Awards;
@class Challenge;

#define NUM_ARCADE_FLOWERS 7

#define FIELD_SIZE    (2.0f/7.0f)
#define RAMP_SIZE     FIELD_SIZE*3
#define JUMP_SIZE     FIELD_SIZE*3
#define SCORE_HEIGHT  PIXELSIZE*22
#define GLOW_COLOR    0x44ffffff
#define GLOW_LETTER   0x22ffffff

#define GAME_FADE_IN_TIME       0.7f
#define GAME_FADE_OUT_TIME      0.6f

#define STONE_MOVE_TIME         0.3f
#define GAME_OVER_PREPARE_TIME  4.0f

enum ExtraIds {
  BUT, BUG, BEE,
};

enum ExplodeChainsResons {
  EXPLODE_REASON_STONE_DROPPED,
  EXPLODE_REASON_BEE_DROPPED,
  EXPLODE_REASON_PENALTY_STONE,
};

//------------------------------------------------------------------------------------------------------------------------
@interface Game : NSObject <EventReceiver>
//------------------------------------------------------------------------------------------------------------------------
{
  MainBoard       * board;
  Ramp            * ramp;
  Jump            * jump;
  Score           * score;
  Clock           * clock;
  Campaign        * campaign;
  Awards          * awards;
  Challenge       * challenge;
  LevelInfo       * levelInfo;
  LevelInfo       * arcadeInfo;
  Highscores      * highscores;
  HighscoreEntry  * highscoreEntry;
  GameMenu        * menu;
  Extras          * extras;
  
  ExtraButton     * buttons[3];
  
  BOOL              gameIsOver;
 
  NSMutableArray  * blockList;
   
  NSMutableDictionary * stoneTypes;
  NSMutableArray      * arcadeStoneTypes;
}

@property (readonly) MainBoard      * board;
@property (readonly) Jump           * jump;
@property (readonly) Ramp           * ramp;
@property (readonly) NSDictionary   * stoneTypes;
@property (readonly) NSArray        * arcadeStoneTypes; 
@property (assign)   LevelInfo      * levelInfo;
@property (assign)   LevelInfo      * arcadeInfo;
@property (assign)   Campaign       * campaign;
@property (assign)   Awards         * awards;
@property (assign)   Challenge      * challenge;
@property (assign)   Highscores     * highscores;
@property (assign)   HighscoreEntry * highscoreEntry;
@property (assign)   Score          * score;
@property (assign)   Clock          * clock;
@property (assign)   GameMenu       * menu;
@property (assign)   Extras         * extras;
@property (readonly) float            fieldSize;
@property (assign)   ExtraButton    * bugButton;
@property (assign)   ExtraButton    * beeButton;
@property (assign)   ExtraButton    * butButton;
@property (readonly) BOOL             lefty;
@property (readonly) float            stoneMoveTime;
@property (retain)   NSMutableArray * blockList;

+ (Game*) instance;
+ (Game*) current;
- (id)    init;
- (void)  setup;
- (void)  saveGame;
- (void)  loadGame;
- (void)  startGame;
- (void)  startArcade;
- (void)  startChallenge:(Challenge*)challenge;
- (void)  clockCounterFinished;
- (void)  rampFadedIn;
- (void)  jumpFadedIn;
- (void)  fadeOut;
- (void)  dealloc;
- (void)  nextBlock;
- (void)  clearBoards;
- (Block*) newBlockForRamp;
- (void)  arcadeTimeRanOut;
- (void)  nextArcadeStoneTypeAtIndex:(int)index;
- (BOOL)  onEvent:(Event*)event;
- (void)  onButton:(ButtonEvent*)event;
- (void)  explodeChains:(NSMutableArray*)chains reason:(int)reason;
- (void)  changeOrientation:(Orientation)o;
- (void)  onStoneExploding;
- (void)  setupArcadeFlowers;
- (void)  addArcadeFlower:(NSString*)flowerName;
- (StoneType*) arcadeStoneTypeAtIndex:(int)index;

- (void)  stopWigglingExtra;

- (BOOL)  hasSaveGame;
- (BOOL)  checkGameOver;
- (BOOL)  isGameOver;
- (void)  gameOver;
- (void)  challengeWon;
- (void)  challengeFailed;
- (void)  cleanUp;

@end

extern float DIR[4][2];
extern float DEG[4];
extern float ANG[4];
extern NSString * DIFFICULTY[3];
