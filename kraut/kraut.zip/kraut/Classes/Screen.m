//
//  Screen.m

#import "Screen.h"
#import "ExtraButton.h"
#import "Highscores.h"
#import "Timer.h"
#import "Tools.h"
#import "Text.h"
#import "Menu.h"
#import "MenuText.h"
#import "Awards.h"
#import "Sound.h"
#import "Game.h"
#import "Letters.h"

#define SCREEN_TITLE_POS_Y    1.1f
#define SCREEN_TITLE_HEIGHT   0.3f

//------------------------------------------------------------------------------------------------------------------------
@implementation Layout
//------------------------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithDictionary:(NSDictionary*)dict_ parent:(MenuObject*)parent_
{
  if ((self = [super initWithDictionary:dict_ parent:parent_]))
  {
    layoutType = [dict valueForKey:@"layout"];
    if (!layoutType) layoutType = @"screen";
  }
  
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (int) layoutBackButton
{
  uint count = [children count];
  if (parent && ![parent isKindOfClass:[Menu class]] || [layoutType isEqualToString:@"signature"])
  {
    count -= 1;
    Button * button = [children lastObject];
    [button moveTo:CGPointMake(-0.8f, SCREEN_TITLE_POS_Y)];
    //float h = button.rect.size.height;
    //button.touchRect = CGRectMake(-1, SCREEN_TITLE_POS_Y-h/2, 1.5, h);
  }
  return count;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) layoutHighscoreButton
{
  SpriteButton * button = [children objectAtIndex:0];
  
  Highscore * highscore = [[Highscores instance] highscoreForLevel:[Game instance].arcadeInfo];
  button.count = [highscore numberOfEntries];
  if (button.count)
    [button moveTo:CGPointMake(0.8f, SCREEN_TITLE_POS_Y)];
  else 
    [button moveTo:CGPointMake(1.8f, SCREEN_TITLE_POS_Y)];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) layout
{
  if ([layoutType isEqualToString:@"screen"])
  {
    int count = [self layoutBackButton];
    
    if (count > 2)
    {
      CGPoint p = CGPointMake(0.0f, 0.5f);
      for (int i = 0; i < count; i++)
      {
        Button * button = [children objectAtIndex:i];
        [button moveTo:p];
        p.y -= 2.0f/count;
      }
    }
    else if (count == 2)
    {
      CGPoint p = CGPointMake(0.0f, 0.2f);
      for (int i = 0; i < count; i++)
      {
        Button * button = [children objectAtIndex:i];
        [button moveTo:p];
        p.y -= 1.7f/count;
      }
    }
    else //if (count == 1)
    {
      CGPoint p = CGPointMake(0.0f, -0.2f);
      Button * button = [children objectAtIndex:0];
      if (![button isKindOfClass:[MenuText class]])
          [button moveTo:p];
    }
  }
  else if ([layoutType isEqualToString:@"size"])
  {
    [self layoutBackButton];

    CGPoint p = CGPointMake(0.0f, -0.2f);
    RadialButton * button = [children objectAtIndex:0];
    [button moveTo:p];
    
    [button clearStatusLocks];
    Awards * awards = [Awards instance];
    if (![awards isPrizeWon:@"8x8"])   [button lockStatus:3];
    if (![awards isPrizeWon:@"9x9"])   [button lockStatus:4];
    if (![awards isPrizeWon:@"10x10"]) [button lockStatus:5];
    if (![awards isPrizeWon:@"11x11"]) [button lockStatus:6];
  } 
  else if ([layoutType isEqualToString:@"campaign"])
  {
    [self layoutBackButton];
    Button * button = [children lastObject];
    button.touchRect = button.rect;
  }
  else if ([layoutType isEqualToString:@"awards"])
  {
    [self layoutBackButton];
  }
  else if ([layoutType isEqualToString:@"highscore"])
  {
    [self layoutBackButton];
  }
  else if ([layoutType isEqualToString:@"signature"])
  {
    [self layoutBackButton];
    
    Button * button = [children objectAtIndex:2];
    [button moveTo:POINT(0, -1)];
  }
  else if ([layoutType isEqualToString:@"arcade"])
  {
    [self layoutBackButton];
    [self layoutHighscoreButton];

    Button * button;
    
    int startIndex  = 1;
    int sizeIndex   = startIndex+1;
    int levelIndex  = sizeIndex+1;
    int flowerIndex = levelIndex+1;
    
    button = [children objectAtIndex:sizeIndex];
    [button.name release];
    button.name = [[NSString stringWithFormat:@"Size: %dx%d", [Game instance].arcadeInfo.size, [Game instance].arcadeInfo.size] retain];

    button = [children objectAtIndex:levelIndex];
    [button.name release];
    button.name = [[NSString stringWithFormat:@"Level: %@", DIFFICULTY[[Game instance].arcadeInfo.difficulty]] retain];

    float yoff[5] = {0, 0.55f, 0.1f, -0.25f, -0.8f};
    
    CGPoint p = CGPointMake(0.0f, 0.5f);
    for (int i = startIndex; i <= levelIndex; i++) // start size and level buttons
    {
      p.y = yoff[i];
      button = [children objectAtIndex:i];
      [button moveTo:p];
      float h = button.rect.size.height;
      button.touchRect = CGRectMake(-1, p.y-h/2, 2, h);
    }
    
    p.y = yoff[flowerIndex];
    int flowerCount = [Game instance].arcadeInfo.numFlowers;
    if (flowerCount > 4) p.y += 0.15f;
    int row1 = ((flowerCount > 4) ? ceil(flowerCount/2.0f) : flowerCount);
    float pos[3][4] = {{-0.3f, 0.3f, 0, 0}, {-0.5f, 0, 0.5f, 0}, {-0.75f, -0.25f, 0.25f, 0.75f}};
    for (int i = 0; i < row1; i++)
    {
      button = [children objectAtIndex:i+flowerIndex];
      [button moveTo:POINT(pos[row1-2][i], p.y)];
    }
    p.y -= 0.5f; 
    for (int i = row1; i < 7; i++)
    {
      button = [children objectAtIndex:i+flowerIndex];
      if (i < flowerCount) [button moveTo:POINT(pos[flowerCount-row1-2][i-row1], p.y)];
      else [button moveTo:POINT(10,10)];
    }    
  }
  else if ([layoutType isEqualToString:@"flowers"])
  {
    int count = [self layoutBackButton];
    CGPoint p = CGPointMake(-0.35f, 0.5f);
    for (int i = 0; i < count; i++)
    {
      Button * button = [children objectAtIndex:i];
      [button moveTo:p];
      p.y -= 2.0f/(count/2);
      if (i == count/2-1)
        p = CGPointMake(0.35f, 0.5f);
    }
  }
  else if ([layoutType isEqualToString:@"game"])
  {
    BOOL lefty = [Game current].lefty;

    Button * button = (Button*)[children objectAtIndex:0]; 
    button.letters.sprite = nil;
    button.letters.angle = -90;

    for (int i = 0; i < 4; i++)
    {
      button = (Button*)[children objectAtIndex:i];

      if (lefty) [button moveTo:CGPointMake( 1-(i+0.5f)*FIELD_SIZE, 0.5f+SCORE_HEIGHT+0.5f*FIELD_SIZE)];
      else       [button moveTo:CGPointMake(-1+(i+0.5f)*FIELD_SIZE, 0.5f+SCORE_HEIGHT+0.5f*FIELD_SIZE)];
    }
  }
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation Screen
//------------------------------------------------------------------------------------------------------------------------

@synthesize fadeInTime;
@synthesize fadeOutTime;

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithDictionary:(NSDictionary*)dict_ parent:(MenuObject*)parent_
{
  if ((self = [super initWithDictionary:dict_ parent:parent_]))
  {
    fadeTimer = nil;
    fadeInTime = SCREEN_FADE_IN_TIME;
    fadeOutTime = SCREEN_FADE_OUT_TIME;
    
    if ([dict valueForKey:@"buttons"])
    {
      for (NSDictionary * buttonDict in [dict valueForKey:@"buttons"])
      {
        [children addObject:[Button buttonWithDictionary:buttonDict parent:self]];
      }
    }
  }
  
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startFadeIn
{
  [self layout];
  for (MenuObject * child in children) [child fadeIn:0.0f];
  
  if (fadeTimer) [fadeTimer stop];
  fadeTimer = [Timer timerWithDuration:fadeInTime 
                                object:self 
                                  tick:@selector(fadingIn:) 
                                finish:@selector(fadedIn:)];  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startFadeOut
{
  if (fadeTimer) [fadeTimer stop];
  fadeTimer = [Timer timerWithDuration:fadeOutTime 
                                object:self 
                                  tick:@selector(fadingOut:) 
                                finish:@selector(fadedOut:)];
  
  for (MenuObject * child in children)  [child fadeOut:1.0f];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadingIn:(Timer*)timer
{  
  fadeValue = [timer fraction];
  for (MenuObject * child in children) [child fadeIn:fadeValue];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadedIn:(Timer*)timer
{
  fadeTimer = nil;
  fadeValue = 1.0f;
  for (MenuObject * child in children) [child fadeIn:fadeValue];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadingOut:(Timer*)timer
{  
  fadeValue = 1.0f-[timer fraction];
  for (MenuObject * child in children) [child fadeOut:fadeValue];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadedOut:(Timer*)timer
{
  fadeTimer = nil;
  fadeValue = 0.0f;
  for (MenuObject * child in children) [child fadeOut:fadeValue];  
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) isVisible { return (fadeValue != 0.0f); }

//------------------------------------------------------------------------------------------------------------------------
- (void)  onTouchDown:(TouchEvent*)event 
{
  for (MenuObject * child in children) [child onTouchDown:event];
}

//------------------------------------------------------------------------------------------------------------------------
- (void)  onTouchUp:(TouchEvent*)event 
{
  for (MenuObject * child in children) [child onTouchUp:event];
}

//------------------------------------------------------------------------------------------------------------------------
- (void)  onTouchMove:(TouchEvent*)event 
{
  for (MenuObject * child in children) [child onTouchMove:event];
}

//------------------------------------------------------------------------------------------------------------------------
- (NSString*) description
{
  return [NSString stringWithFormat:@"<%@ '%@'>", [self class], name];
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation MenuScreen
//------------------------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithDictionary:(NSDictionary*)dict_ parent:(MenuObject*)parent_
{
  if ((self = [super initWithDictionary:dict_ parent:parent_]))
  {
    letters = [[Letters alloc] init];
    letters.sprite = [Sprite withName:@"shadow"];
    float titleHeight = ([dict valueForKey:@"titleHeight"] ? [[dict valueForKey:@"titleHeight"] floatValue] : SCREEN_TITLE_HEIGHT);
    [letters setString:name withHeight:titleHeight atPoint:CGPointMake(0, SCREEN_TITLE_POS_Y)];
    
    if (parent && ![parent isKindOfClass:[Menu class]] || [layoutType isEqualToString:@"signature"])
    {
      backButtonDict = [[NSDictionary dictionaryWithObjectsAndKeys:
                                    @"<", @"name", 
                                    @"button", @"sprite", 
                                    [NSString stringWithFormat:@"%f", SCREEN_TITLE_HEIGHT], @"nameHeight", 
                                    [NSDictionary dictionaryWithObjectsAndKeys:@"back", @"key", nil], @"event",
                                    nil] retain];
      Button * backButton = [[Button alloc] initWithDictionary:backButtonDict parent:self];
      backButton.letters.sprite = nil;
      backButton.letters.color = 0xff444444;
      [children addObject:backButton];
      [backButton release];
    }
    
    [self layout];    
  }
    
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [backButtonDict release];
  [letters release];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onFrame:(double)delta
{  
  [letters draw];
  [super onFrame:delta];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startFadeIn
{
  [super startFadeIn];
  for (Letter * letter in letters.letters) 
  {
    letter.alpha = 0.0f;
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadingIn:(Timer*)timer
{  
  [super fadingIn:timer];  
  [letters fade:fadeValue offset:self.menu.fadeInOffset];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadedIn:(Timer*)timer
{
  [super fadedIn:timer];  
  [letters fade:fadeValue offset:self.menu.fadeInOffset];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadingOut:(Timer*)timer
{  
  [super fadingOut:timer];
  [letters fade:fadeValue offset:self.menu.fadeOutOffset];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadedOut:(Timer*)timer
{
  [super fadedOut:timer];
  [letters fade:fadeValue offset:self.menu.fadeOutOffset];
}

@end
