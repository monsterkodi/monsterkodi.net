//
//  Clock.h

#import "Event.h"

@class Sprite;
@class Timer;
@class LevelInfo;

enum ClockMode {HELP, MOVE_TIME, CLEAR, POLLEN, BESTMOVE, PATTERN};

//------------------------------------------------------------------------------------------------------------------------
@interface Clock : NSObject <EventReceiver>
//------------------------------------------------------------------------------------------------------------------------
{
  float     totalTime;
  float     time;
  float     displaytime;
  float     countdown;
  float     duration;
  float     nextLevelTime;
  int       level;
  int       levelSequence;
  
  BOOL      running;
  BOOL      paused;
  BOOL      active;
  
  CGRect    rect;
  CGPoint   offset;
  
  int       mode;
  
  uint      color;
  
  Sprite  * sprite[3][3];
  
  Timer   * fadeTimer;
  Timer   * countdownTimer;
}

@property (assign) float  time;
@property (assign) float  totalTime;
@property (assign) float  duration;
@property (assign) float  nextLevelTime;
@property (assign) int    level;
@property (assign) int    levelSequence;
@property (assign) BOOL   running;
@property (assign) BOOL   paused;
@property (assign) BOOL   active;
@property (assign) CGRect rect;
@property (assign) uint   color;
@property (assign) int    mode;

+ (Clock*)  instance;
- (id)      init;
- (void)    dealloc;
- (void)    startWithLevelInfo:(LevelInfo*)levelInfo;
- (void)    start;
- (void)    stop;
- (void)    startCountDown;

- (void)    onTimeRanOut;
- (void)    levelUp;

- (void)    digitAdded:(int)index;

- (void)    addCount:(int)count;
- (void)    setCount:(int)count;
- (void)    addTimeForPollen:(int)pollen;

- (void)    onFrame:(double)delta;
- (BOOL)    onEvent:(Event*)event;

- (void)    fadeIn;
- (void)    fadeOut;
- (void)    fadingOut:(Timer*)timer;
- (void)    fadedOut:(Timer*)timer;

- (void)    layout;

- (void)    setupWithDictionary:(NSDictionary*)dictionary;
- (NSDictionary*) dictionary;

@end
