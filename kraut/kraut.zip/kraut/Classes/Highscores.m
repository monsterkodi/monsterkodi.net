//
//  Highscores.m
//  kraut

#import "Highscores.h"
#import "MenuSignature.h"
#import "Signature.h"
#import "Game.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation HighscoreEntry
//------------------------------------------------------------------------------------------------------------------------

@synthesize score;
@synthesize signature;

//------------------------------------------------------------------------------------------------------------------------
- (id) init
{
  if ((self = [super init]))
  {
    signature = [[Signature alloc] init];
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (id)  initWithCoder:(NSCoder*)decoder
{
  [self setSignature:[[decoder decodeObjectForKey:@"signature"] retain]];
  [self setScore:[decoder decodeIntForKey:@"score"]];
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void)  encodeWithCoder:(NSCoder*)encoder
{
  [encoder encodeObject:signature forKey:@"signature"];
  [encoder encodeInt:score forKey:@"score"];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [signature release];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (NSString*) description
{
  return [NSString stringWithFormat:@"<Entry score %d signature %@>", score, signature];
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation Highscore
//------------------------------------------------------------------------------------------------------------------------

@synthesize entries;

//------------------------------------------------------------------------------------------------------------------------
- (id) init
{
  if ((self = [super init]))
  {
    entries = [[NSMutableArray arrayWithCapacity:10] retain];
    for (int i = 0; i < 10; i++)
    {
      HighscoreEntry * entry = [[HighscoreEntry alloc] init];
      [entries addObject:entry];
      [entry release];
    }
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (id)  initWithCoder:(NSCoder*)decoder
{
  [self setEntries:[[NSMutableArray arrayWithArray:[decoder decodeObjectForKey:@"entries"]] retain]];
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) encodeWithCoder:(NSCoder*)encoder
{
  [encoder encodeObject:entries forKey:@"entries"];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [entries release];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (HighscoreEntry*) entryForPlace:(int)place
{
  return [entries objectAtIndex:place];
}

//------------------------------------------------------------------------------------------------------------------------
- (int) scoreForPlace:(int)place
{
  HighscoreEntry * entry = [entries objectAtIndex:place];
  return entry.score;
}

//------------------------------------------------------------------------------------------------------------------------
- (HighscoreEntry*) addEntryForScore:(int)score
{
  for (int i = 0; i < 10; i++)
  {
    HighscoreEntry * entry = [entries objectAtIndex:i];
    if (score > entry.score)
    {
      HighscoreEntry * newEntry = [[HighscoreEntry alloc] init];
      newEntry.score = score;
      [entries insertObject:newEntry atIndex:i];
      [entries removeLastObject];
      return newEntry;
    }
  }
  return nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (int) numberOfEntries
{
  int num = 0;
  for (HighscoreEntry * entry in entries) if (entry.score > 0) num++;
  return num;
}

//------------------------------------------------------------------------------------------------------------------------
- (NSString*) description
{
  return [NSString stringWithFormat:@"<Highscore %@>", entries];
}

@end

//------------------------------------------------------------------------------------------------------------------------
@implementation Highscores
//------------------------------------------------------------------------------------------------------------------------

+ (Highscores*) instance { return [Game instance].highscores; }

//------------------------------------------------------------------------------------------------------------------------
+ (int) scoreForPlace:(int)place 
{ 
  Highscore * highscore = [[Game instance].highscores highscoreForLevel:[Game instance].arcadeInfo];
  return [highscore scoreForPlace:place];
}

//------------------------------------------------------------------------------------------------------------------------
+ (HighscoreEntry*) entryForPlace:(int)place 
{ 
  Highscore * highscore = [[Game instance].highscores highscoreForLevel:[Game instance].arcadeInfo];
  return [highscore entryForPlace:place];
}

//------------------------------------------------------------------------------------------------------------------------
+ (void) saveHighscores
{
  [[Game instance].highscores save];
}

//------------------------------------------------------------------------------------------------------------------------
- (id) init
{
  if ((self = [super init]))
  {
    [self load];
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [highscores release];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) load
{
  if (highscores) [highscores release];
  highscores = nil;
  NSData * data = [[NSUserDefaults standardUserDefaults] dataForKey:@"highscores"];
  if (data)
  {
    NSDictionary * highDict = (NSDictionary*)[NSKeyedUnarchiver unarchiveObjectWithData:data];
    highscores = [[NSMutableDictionary dictionaryWithDictionary:highDict] retain];
  }
  if (!highscores) 
  {
    highscores = [[NSMutableDictionary dictionaryWithCapacity:10] retain];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) save
{
  NSData * data = [NSKeyedArchiver archivedDataWithRootObject:highscores];
  if (!data) NSLog(@"[ERROR] unable to save highscores!");
  [[NSUserDefaults standardUserDefaults] setObject:data forKey:@"highscores"];
}

//------------------------------------------------------------------------------------------------------------------------
- (Highscore *) highscoreForLevel:(LevelInfo*)levelInfo
{
  Highscore * highscore = [highscores objectForKey:levelInfo.key];
  if (!highscore)
  {
    highscore = [[Highscore alloc] init];
    [highscores setValue:highscore forKey:levelInfo.key];
  }
  return highscore;
}

//------------------------------------------------------------------------------------------------------------------------
- (HighscoreEntry*) addEntryForScore:(int)score
{
  Highscore * highscore = [self highscoreForLevel:[Game instance].arcadeInfo];
  return [highscore addEntryForScore:score];
}

//------------------------------------------------------------------------------------------------------------------------
- (int) numberOfEntries
{
  int num = 0;
  for (Highscore * highscore in [highscores allValues]) num += [highscore numberOfEntries];
  return num;
}

@end
