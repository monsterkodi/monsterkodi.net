//
//  Timer.h

#import "Event.h"

//------------------------------------------------------------------------------------------------------------------------
@interface Timer : NSObject
//------------------------------------------------------------------------------------------------------------------------
{
  float   time;
  float   duration;
  float   delta;
  id      object;
  SEL     tick;
  SEL     finish;
  id      info;
  
  int num;
  
  Timer * next;
  Timer * prev;
}

@property (assign)   float    time;
@property (assign)   float    duration;
@property (assign)   float    delta;
@property (readonly) float    elapsedTime;
@property (readonly) float    fraction;
@property (assign)   SEL      tick;
@property (assign)   SEL      finish;
@property (assign)   id       object;
@property (retain)   id       info;

@property (assign)   Timer *  next;
@property (assign)   Timer *  prev;
@property (assign)   int  num;

+ (Timer*)  timerWithObject:(id)object tick:(SEL)tick;
+ (Timer*)  timerWithDuration:(float)duration object:(id)object tick:(SEL)tick finish:(SEL)finish;
+ (Timer*)  timerWithDuration:(float)duration object:(id)object tick:(SEL)tick finish:(SEL)finish info:(id)info;
- (id)      init;
- (void)    stop;
- (void)    dealloc;
- (void)    onFrame:(double)delta;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface Timers : NSObject
//------------------------------------------------------------------------------------------------------------------------
{
}

+ (Timer*)  timer;
+ (void)    deactivate:(Timer*)timer;
+ (void)    onFrame:(double)delta;
+ (void)    stopAllTimers;

@end
