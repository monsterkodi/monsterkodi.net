//
//  Bug.m
//  kraut

#import "Bug.h"
#import "Sprite.h"
#import "ExtraButton.h"
#import "Bezier.h"
#import "Timer.h"
#import "Controller.h"
#import "Stone.h"
#import "Board.h"
#import "Sound.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation Bug
//------------------------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------------------------
- (id) init
{
  if ((self = [super init]))
  {
    layer = _extra_;
    sprite = [Sprite withName:@"bug"];
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  //NSLog(@"bug dealloc %@", self);
  [stones release];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) goHome:(Timer*)timer
{
  point = [((Bezier*)(timer.info)) pointAtTime:timer.fraction];
  size = [Game current].fieldSize+0.15f*sin(timer.fraction*M_PI);
}

//------------------------------------------------------------------------------------------------------------------------
- (void) wentHome:(Timer*)timer
{
  moveTimer = nil;
  layer = _extra_;
  extraButton.extra = self;
}

- (void) playWiggleSound { [Sound loop:@"bug loop" volume:0.5f]; }
- (void) stopWiggleSound { [Sound stop:@"bug loop"]; }

//------------------------------------------------------------------------------------------------------------------------
- (void) goAway
{
  Orientation o = [Controller instance].orientation;
  CGPoint target, c1, c2;
  if (o == UP || o == DOWN) 
  {
    target = POINT(point.x + ((point.x > 0) ? -0.5f : 0.5f), -2.0f * DIR[o][1]);
    c1     = POINT(target.x, point.y + DIR[o][1]*0.75f);
    c2     = POINT(target.x, point.y - DIR[o][1]*0.75f);
    targetAngle = (point.x > 0) ? 180 : -180;
  }
  else
  {
    target = POINT(-DIR[o][0], point.y + ((point.y > -0.25f) ? -0.5f : 0.5f));
    c1     = POINT(point.x + DIR[o][0]*0.75f, target.y);
    c2     = POINT(point.x - DIR[o][0]*0.75f, target.y);      
    targetAngle = ((o == RIGHT) ? ((point.y > -0.25f) ? -180 : 180) : ((point.y > -0.25f) ? 180 : -180));
  }
  bezier = [Bezier from:point over:c1 and:c2 to:target];
  [self stopWiggle];

  if (moveTimer) [moveTimer stop];

  [Sound stop:@"bug loop"];
  [Sound play:@"bug jump"];

  moveTimer = [Timer timerWithDuration:1.5f object:self tick:@selector(goingAway:) finish:@selector(wentAway:) info:bezier];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) goingAway:(Timer*)timer
{
  point = [((Bezier*)(timer.info)) pointAtTime:timer.fraction];
  size  = [Game current].fieldSize+0.10f*sin(timer.fraction*M_PI);
  angle = timer.fraction*targetAngle;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) wentAway:(Timer*)timer
{
  moveTimer = nil;
  [self vanish];
  [[Game current] checkGameOver];  
}

//------------------------------------------------------------------------------------------------------------------------
- (void) goToStone:(Timer*)timer
{
  point = [((Bezier*)(timer.info)) pointAtTime:timer.fraction];
  size = [Game current].fieldSize+0.15f*sin(timer.fraction*M_PI);
}

//------------------------------------------------------------------------------------------------------------------------
- (void) arrivedAtStone:(Timer*)timer
{
  moveTimer = nil;
  [stone playSound];
  [stone explode];
  [self eatStone];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) eatStone
{
  if (moveTimer) [moveTimer stop];
  if (stones && [stones count])
  {
    stone = [stones objectAtIndex:RANDOMI([stones count])];
    [stones removeObject:stone];
    if ([stones count] == 0) { [stones release]; stones = nil; }

    CGPoint target = CGRectCenter(stone.rect);
    CGPoint pointToTarget = CGVectorNorm(CGVector(point, target));
    CGPoint c1 = CGPointAdd(point,  CGPointScale(pointToTarget, -0.5f));
    CGPoint c2 = CGPointAdd(target, CGPointScale(pointToTarget,  0.5f));
    bezier = [Bezier from:point over:c1 and:c2 to:target];

    moveTimer = [Timer timerWithDuration:1.2f object:self tick:@selector(goToStone:) finish:@selector(arrivedAtStone:) info:bezier];
  }
  else 
  {
    [[Extras instance] removeActiveExtra:self];
    [self goAway];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) deactivate
{
  [super deactivate];
  [stone explode];
  for (stone in stones) [stone explode];
  [stones removeAllObjects];
  [stones release];
  stones = nil;
  stone = nil;
  
  [self goAway];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dragEnded:(DragEvent*)event
{
  [super dragEnded:event];
  
  Board * board = (Board*)event.target;
  Pos pos = [board jumpPosForBugAtPoint:point];
    
  [self jumpToPos:pos onBoard:board];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) jumpToPos:(Pos)pos onBoard:(Board*)board
{
  [Sound loop:@"bug loop"];
  
  BOOL mainBoard = (board == [Game current].board);
  [super jumpToPos:pos onBoard:board];
  [Game current].levelInfo.bugs--;

  stones = [[NSMutableArray arrayWithCapacity:9] retain];

  for (int col = -1; col <= 1; col++)
    for (int row = -1; row <= 1; row++)
    {
      Pos offpos = [pos sum:POS(col, row)];
      Field * field = [board fieldAtPos:offpos];
      if (field)
      {
        if (field.stone && [field.stone isKindOfClass:[Stone class]])
        {
          if (mainBoard)
          {
            [stones addObject:field.stone];
          }
          else
          {
            [field.stone explode];
          }
          field.stone = nil;
        }
      }
    }
  
  if (mainBoard) 
  {
    [[Extras instance] addActiveExtra:self];
    [self eatStone];
  }
  else [self goAway];
}

@end
