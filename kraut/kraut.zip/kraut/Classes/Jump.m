//
//  Jump.m

#import "Jump.h"
#import "Game.h"
#import "Event.h"
#import "Sound.h"
#import "Bug.h"
#import "Bee.h"
#import "Butterfly.h"
#import "Controller.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation Jump
//------------------------------------------------------------------------------------------------------------------------

@synthesize block;
@synthesize draggedOutside;

//------------------------------------------------------------------------------------------------------------------------
- (void) layout
{
  BOOL lefty = [Game current].lefty;
  
  rect = CGRectMakeCenterSize(POINT((lefty?-1:1)*(1-rect.size.width/2),1.5f-rect.size.height/2), rect.size);

  [super layout];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) clear
{
  [super clear];
  [self setBlock:nil];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) fadedIn:(Timer*)timer
{
  [super fadedIn:timer];  
  [game jumpFadedIn];
}

//------------------------------------------------------------------------------------------------------------------------
- (NSDictionary*) dictionary
{
  NSArray * array = [NSArray arrayWithObjects:block.first.type.name, block.center.type.name, block.last.type.name, nil];
  return [NSDictionary dictionaryWithObject:array forKey:@"block"];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setupWithDictionary:(NSDictionary*)dictionary
{
  //NSLog(@"jump::setupWithDictionary %@", dictionary);
  
  NSArray * blockArray = [dictionary valueForKey:@"block"];

  Block * block_;
  if ([blockArray count])
    block_ = [[Block alloc] initWithFirst:[StoneType withName:[blockArray objectAtIndex:0]] 
                                   center:[StoneType withName:[blockArray objectAtIndex:1]]  
                                     last:[StoneType withName:[blockArray objectAtIndex:2]]];  
  else
    block_ = [[Block alloc] init];
    
  [self setBlock:block_];
  [block_ release];
  
  draggedOutside = NO;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) setBlock:(Block*)block_
{
  //NSLog(@"jump::setBlock %@", block_);
  
  if (block)
  {
    [self delStonesForBlock:block];
    [block release];
    block = nil;
  }
  
  if (block_)
  {
    block = [block_ retain];
    [self setStonesForBlock:block atPos:POS(1,1)];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) isEmpty
{
  return (block == nil || [block isEmpty]);
}

//------------------------------------------------------------------------------------------------------------------------
- (Pos) jumpPosForBugAtPoint:(CGPoint)point
{
  return POS(1,1);
}

//------------------------------------------------------------------------------------------------------------------------
- (Pos) jumpPosForButAtPoint:(CGPoint)point
{
  return [self posForPoint:point];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) resetExtraTarget
{
  for (Field * field in fields) 
  {
    if (field.stone) field.stone.alpha = 1.0f;
  }
  butTargetType = nil;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) displayBugTarget
{
  for (Field * field in fields) 
  {
    if (field.stone) field.stone.alpha = 0.2f;
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) displayButTarget
{
  for (Field * field in fields) 
  {
    if (field.stone && field.stone.type == butTargetType) field.stone.alpha = 0.2f;
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) displayBeeTarget
{
  Field * field = [self fieldAtPos:extraTargetPos];
  field.stone.alpha = 0.2f;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dragStarted:(DragEvent*)event
{
  if (event.object == block)
  {
    [[Game current] stopWigglingExtra];
    [self setBlock:nil];
    draggedOutside = NO;
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dragMoved:(DragEvent*)event
{
  if ([event.object isKindOfClass:[Block class]])
  {
    if (!CGRectContainsPoint(rect, event.point))
      draggedOutside = YES;
  }
  else if ([event.object isKindOfClass:[Bug class]])
  {
    [self resetExtraTarget];
    [self displayBugTarget];
  }  
  else if ([event.object isKindOfClass:[Butterfly class]])
  {
    [self resetExtraTarget];
    Pos pos = [self jumpPosForButAtPoint:event.point];
    if ([self fieldAtPos:pos].stone)
    {
      butTargetType = [self fieldAtPos:pos].stone.type;
      [self displayButTarget];
    }
  }  
  else if ([event.object isKindOfClass:[Bee class]])
  {
    [self resetExtraTarget];
    [extraTargetPos release];
    extraTargetPos = [[self posForPoint:event.point] retain];
    butTargetType = [self fieldAtPos:extraTargetPos].stone.type;
    [self displayBeeTarget];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dragCanceled:(DragEvent*)event
{
  if ([event.object isKindOfClass:[Block class]])
  {
    [self clear];
    [self setBlock:event.object];  
    draggedOutside = NO;
  }  
  else if ([event.object isKindOfClass:[Extra class]])
  {
    [self resetExtraTarget];
    [extraTargetPos release];
    extraTargetPos = nil;
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dragEnded:(DragEvent*)event
{    
  if ([event.object isKindOfClass:[Block class]])
  {
    [self clear];
    draggedOutside = NO;  
  }
  else if ([event.object isKindOfClass:[Bug class]])
  {
    [self clear];
    [game nextBlock];
    [self resetExtraTarget];
  }
  else if ([event.object isKindOfClass:[Butterfly class]])
  {
    int numFlowers = game.levelInfo.numFlowers;
    int flowerIndex = [game.levelInfo.flowers indexOfObject:butTargetType];

    for (int row = 0; row < 3; row++)
    {
      Stone * stone = [block.stones objectAtIndex:row];
      if (stone.type == butTargetType)
      {
        int randomOffset = 1 + RANDOMI(numFlowers-1);
        int newFlowerIndex = ((flowerIndex + randomOffset)%numFlowers);
        StoneType * newType = [game.levelInfo.flowers objectAtIndex:newFlowerIndex];
        Stone * newStone = [Stone ofType:newType];
        [block.stones replaceObjectAtIndex:row withObject:newStone];
        stone.field.stone = newStone;
        [newStone fadeIn];
        [stone explode];
        [newStone release];
      }
    }
    
    [self resetExtraTarget];
  }
  else if ([event.object isKindOfClass:[Bee class]])
  {
    int numFlowers = game.levelInfo.numFlowers;
    int flowerIndex = [game.levelInfo.flowers indexOfObject:butTargetType];
    int randomOffset = 1 + RANDOMI(numFlowers-1);
    int newFlowerIndex = ((flowerIndex + randomOffset)%numFlowers);
    StoneType * newType = [game.levelInfo.flowers objectAtIndex:newFlowerIndex];
    Stone * newStone = [Stone ofType:newType];
    //[block.stones replaceObjectAtIndex:extraTargetPos.y withObject:newStone];
    Stone * oldStone = [self fieldAtPos:extraTargetPos].stone;
    [block.stones replaceObjectAtIndex:[block.stones indexOfObject:oldStone] withObject:newStone];
    
    Field * field = [self fieldAtPos:extraTargetPos];
    Stone * stone = field.stone;
    field.stone = newStone;
    [newStone fadeIn];
    [stone explode];
    [newStone release];

    [self resetExtraTarget];

    [extraTargetPos release];
    extraTargetPos = nil;        
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) onTap:(TouchEvent*)event
{
  if (event.delta == 0 || !draggedOutside)
  {
    int dir = 1;
    if (event.delta != 0)
    {
      float a = CGAngle(CGVector(CGRectCenter(rect), event.point), CGVector(CGRectCenter(rect), CGPointSub(event.point,event.direction)));
      //NSLog(@"Jump::onTap angle %f event.delta %f event.direction %f %f", a, event.delta, event.direction.x, event.direction.y);
      dir = (a > 0) ? 1 : -1;
    }
    [block rotate:dir];
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) handleDragEvent:(DragEvent*)dragEvent
{ 
  if ([dragEvent.object isKindOfClass:[Bug class]] || [dragEvent.object isKindOfClass:[Butterfly class]] || [dragEvent.object isKindOfClass:[Bee class]])
  {
    if (dragEvent.target == self) dragEvent.target = nil;

    Pos pos = [self posForPoint:dragEvent.point];
    if ([self isValidPos:pos])
    {
      if ([dragEvent.object isKindOfClass:[Bug class]])
        dragEvent.target = self;
      else
        if ([self stoneAtPos:pos]) dragEvent.target = self;
    }
    else
    {
      [self resetExtraTarget];
    }      
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (BOOL) onEvent:(Event*)event_
{
  if (!block) return YES;
  if ([event_ isKindOfClass:[DragEvent class]])
  {
    [self handleDragEvent:(DragEvent*)event_];
    return YES;
  }  
  else if ([event_ isKindOfClass:[TouchEvent class]] && CGRectContainsPoint(rect, ((TouchEvent*)event_).point)) 
  {
    TouchEvent * event = (TouchEvent*)event_;
    if ([event.type isEqualToString:@"up"])
    {
      [self onTap:event];
    }
    else if ([event.type isEqualToString:@"move"])
    {
      if (![Controller instance].dragEvent)
      {
        if (block && [self stoneAtPos:[self posForPoint:event.point]])
        {
          [[Controller instance] startDrag:block source:self point:event.point];
        }
      }
    }
  }
  
  return YES;
}

@end
