//
//  EAGLView.h

#import <UIKit/UIKit.h>
#import <OpenGLES/EAGL.h>
#import <OpenGLES/ES1/gl.h>
#import <OpenGLES/ES1/glext.h>

@class Controller;

//------------------------------------------------------------------------------------------------------------------------
@interface GLView : UIView 
//------------------------------------------------------------------------------------------------------------------------
{	
@private
	
  EAGLContext * context;

	GLint   backingWidth, backingHeight;  // backbuffer dimensions
	GLuint  viewRenderbuffer, viewFramebuffer, depthRenderbuffer; // OpenGL buffers		
}

@property (nonatomic, retain) EAGLContext * context;

- (BOOL) createFramebuffer;
- (void) destroyFramebuffer;

- (void) drawBegin;
- (void) drawEnd;

@end
