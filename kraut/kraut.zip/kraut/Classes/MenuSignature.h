//
//  MenuSignature.h
//  kraut

#import "Button.h"
#import "Event.h"

@class Signature;
@class StoneType;
@class Timer;

//------------------------------------------------------------------------------------------------------------------------
@interface BucketFlower : NSObject
//------------------------------------------------------------------------------------------------------------------------
{
  float           fadeValue;
  CGPoint         point;
  StoneType     * type;
  StoneType     * targetType;
  Timer         * moveTimer;
}

@property (assign) float          fadeValue;
@property (assign) CGPoint        point;
@property (assign) StoneType    * type;

- (void) dealloc;
- (void) draw;
- (void) vanishToPoint:(CGPoint)point;
- (void) showToPoint:(CGPoint)point type:(StoneType*)type;
- (void) show:(Timer*)timer;
- (void) shown:(Timer*)timer;
- (void) vanish:(Timer*)timer;
- (void) vanished:(Timer*)timer;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface FlowerBucket : Button
//------------------------------------------------------------------------------------------------------------------------
{
  NSMutableArray * flowers;
  NSMutableArray * types;
  int randomType;
}

@property (assign) NSMutableArray * flowers;

- (id)          initWithDictionary:(NSDictionary*)dict parent:(MenuObject*)parent;
- (void)        fadeIn:(float)value;
- (void)        fadeOut:(float)value;
- (void)        onPress;
- (void)        onFrame:(double)delta;
- (void)        decrement:(int)num point:(CGPoint)point;
- (void)        incrementFromPoint:(CGPoint)point type:(StoneType*)type;
- (StoneType*)  type;
- (BOOL)        isFull;
- (void)        fill;

@end

//------------------------------------------------------------------------------------------------------------------------
@interface MenuSignature : Button
//------------------------------------------------------------------------------------------------------------------------
{
  FlowerBucket   * bucket;
  NSMutableArray * flowers;
  
  Signature      * signature;
  StoneType      * stoneType;
  
  CGRect  signatureRect;
  CGPoint offset;
}

- (id)    initWithDictionary:(NSDictionary*)dict parent:(MenuObject*)parent;
- (void)  dealloc;
- (void)  fadeIn:(float)value;
- (void)  fadeOut:(float)value;
- (void)  onFrame:(double)delta;
- (void)  onTouchUp:(TouchEvent*)event;
- (void)  onTouchDown:(TouchEvent*)event;
- (void)  onTouchMove:(TouchEvent*)event;

@end

