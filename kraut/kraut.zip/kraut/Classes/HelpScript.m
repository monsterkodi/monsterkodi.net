//
//  HelpScript.m
//  kraut

#import "HelpScript.h"
#import "HelpScriptAction.h"
#import "HelpScriptHandAction.h"
#import "AnimBezier.h"
#import "Help.h"
#import "MenuText.h"
#import "Timer.h"
#import "Tools.h"

//------------------------------------------------------------------------------------------------------------------------
@implementation HelpScript
//------------------------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------------------------
- (id) initWithDictionary:(NSDictionary*)dict
{
  if ((self = [super init]))
  {
    actions = [[NSMutableArray arrayWithCapacity:4] retain];
    for (NSDictionary * actionDict in [dict valueForKey:@"actions"])
    {
      HelpScriptAction * action = [HelpScriptAction withDict:actionDict];
      action.script = self;      
      [actions addObject:action];
    }
  }
  return self;
}

//------------------------------------------------------------------------------------------------------------------------
- (void) dealloc
{
  [actions release];
  [super dealloc];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) play
{
  for (HelpScriptAction * action in actions) [action play];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) stop
{
  if (!stopped)
  {
    stopped = YES;
    if ([actions count] == 0)
    { 
      [[Help instance] scriptFinished:self]; 
    } 
    else
    {
      NSArray * actionsCopy = [actions copy];
      for (HelpScriptAction * action in actionsCopy) [action stop];
      [actionsCopy release];
    }
  }
}

//------------------------------------------------------------------------------------------------------------------------
- (void) startAction:(int)index
{
  [[actions objectAtIndex:index] stop];
  [[actions objectAtIndex:index] play];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) actionWithKey:(NSString*)key
{
  [[Help instance] actionWithKey:key];
}

//------------------------------------------------------------------------------------------------------------------------
- (void) actionFadedOut:(HelpScriptAction*)action
{
  if ([action isKindOfClass:[HelpScriptHandAction class]])
  {
    [Help instance].handStatus = [((HelpScriptSpriteAction*)action) bezierStatus];
    ((AnimBezierStatus*)([Help instance].handStatus)).size = CGSizeMake(0.15f, 0.3f);
  }
  
  if (stopped)
  {
    [actions removeObject:action];
    if ([actions count] == 0) [[Help instance] scriptFinished:self];
  }
}

@end
